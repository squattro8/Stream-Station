"""Scenes: the profiles seen as a list the user manages. Same idea as the original software's scenes:

    - they can be added, renamed, copied, deleted and put in order
    - one of them is the DEFAULT scene: what shows when the application in front has no scene of its own
    - they can be bound to applications (an application belongs to one scene only: binding it to another takes it from the first)
    - they can be exported to a single file and imported again (with the icons they use)
"""
from __future__ import annotations

import json
import os
import re
import shutil
import zipfile

import yaml

from . import profiles

BUNDLE_EXT = ".ssscene"
FORBIDDEN = re.compile(r'[\\/:*?"<>|\x00-\x1f]')


class SceneError(ValueError):
    pass


def folder() -> str:
    return os.path.join(profiles.CONFIG, "profiles")


def path(name: str) -> str:
    return os.path.join(folder(), f"{name}.yaml")


def exists(name: str) -> bool:
    return os.path.isfile(path(name))


def valid_name(name: str) -> str:
    name = (name or "").strip()
    if not name or name in (".", "..") or FORBIDDEN.search(name) or len(name) > 60:
        raise SceneError("invalid name")
    return name


def names() -> list[str]:
    """Every scene, in the user's order (new ones go to the end, alphabetically)."""
    try:
        found = sorted(f[:-5] for f in os.listdir(folder()) if f.endswith(".yaml"))
    except OSError:
        return []
    order = [n for n in profiles.load_settings().get("scene_order") or [] if n in found]
    return order + [n for n in found if n not in order]


def _save_order(order: list[str]):
    profiles.save_setting("scene_order", list(order))


def _read(name: str) -> dict:
    with open(path(name)) as fh:
        return yaml.safe_load(fh) or {}


def _write(name: str, data: dict):
    os.makedirs(folder(), exist_ok=True)
    with open(path(name) + ".tmp", "w") as fh:
        yaml.safe_dump(data, fh, allow_unicode=True, sort_keys=False)
    os.replace(path(name) + ".tmp", path(name))


def unique(name: str) -> str:
    base, n, out = name, 2, name
    while exists(out):
        out, n = f"{base} {n}", n + 1
    return out


def create(name: str) -> str:
    name = valid_name(name)
    if exists(name):
        raise SceneError("that scene already exists")
    _write(name, {"name": name, "keys": {}})
    _save_order(names())
    return name


def rename(old: str, new: str) -> str:
    new = valid_name(new)
    if new == old:
        return old
    if exists(new):
        raise SceneError("that scene already exists")
    data = _read(old); data["name"] = new
    _write(new, data); os.remove(path(old))
    order = [new if n == old else n for n in names_with(old)]
    _save_order(order)
    if profiles.load_settings().get("default_profile") == old:
        profiles.save_setting("default_profile", new)
    return new


def names_with(name: str) -> list[str]:
    """names() but still counting `name` (whose file may already be gone) where it was."""
    order = [n for n in profiles.load_settings().get("scene_order") or []]
    return order if name in order else order + [name]


def duplicate(name: str, suffix: str = " (copia)") -> str:
    new = unique(valid_name(name + suffix))
    data = _read(name); data["name"] = new; data.pop("match", None)      # the copy is not bound to the same applications
    _write(new, data)
    order = names()
    _save_order(order)
    return new


def delete(name: str) -> bool:
    """The scene goes to a `.eliminada` file next to the others (recoverable by hand); the last scene cannot go."""
    if not exists(name) or len(names()) <= 1:
        return False
    os.replace(path(name), path(name) + ".eliminada")
    _save_order([n for n in names()])
    if profiles.load_settings().get("default_profile") == name:
        profiles.save_setting("default_profile", "")
    return True


def move(name: str, delta: int) -> list[str]:
    order = names()
    if name in order:
        i = order.index(name); j = max(0, min(len(order) - 1, i + delta))
        order.insert(j, order.pop(i))
        _save_order(order)
    return order


def default() -> str | None:
    d = profiles.load_settings().get("default_profile") or ""
    return d if d and exists(d) else None


def set_default(name: str | None):
    profiles.save_setting("default_profile", name or "")


def bind(name: str, rules: list[dict]) -> dict[str, list[dict]]:
    """Bind `name` to the applications in `rules`. An application can belong to one scene only, so any other scene that had one
    of them loses it; returns {scene: rules taken away}."""
    mine = {json.dumps(r, sort_keys=True) for r in rules}
    taken: dict[str, list[dict]] = {}
    for other in names():
        if other == name:
            continue
        data = _read(other)
        kept, lost = [], []
        for r in profiles._rules(data.get("match")):
            (lost if json.dumps(r, sort_keys=True) in mine else kept).append(r)
        if lost:
            if kept:
                data["match"] = kept
            else:
                data.pop("match", None)
            _write(other, data)
            taken[other] = lost
    return taken


# ---- export / import --------------------------------------------------------------------------------------------
def _icon_files(node, out: set):
    if isinstance(node, dict):
        for k, v in node.items():
            if k in ("icon", "path", "image") and isinstance(v, str) and v and not os.path.isabs(v):
                out.add(v)
            else:
                _icon_files(v, out)
    elif isinstance(node, list):
        for v in node:
            _icon_files(v, out)


def export_bundle(name: str, dest: str) -> str:
    """A single file with the scene and the pictures it uses."""
    data = _read(name)
    files: set[str] = set(); _icon_files(data, files)
    assets = os.path.join(profiles.CONFIG, "assets")
    if not dest.endswith(BUNDLE_EXT):
        dest += BUNDLE_EXT
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("scene.yaml", yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
        for rel in sorted(files):
            full = os.path.realpath(os.path.join(assets, rel))
            if full.startswith(os.path.realpath(assets) + os.sep) and os.path.isfile(full):
                zf.write(full, "assets/" + rel)
    return dest


def import_bundle(src: str) -> str:
    """Add the scene in `src` (an exported file, or a plain profile .yaml). Never overwrites: a clash gets a new name,
    and the scene arrives unbound from applications (so it cannot steal them from yours)."""
    assets = os.path.join(profiles.CONFIG, "assets")
    try:
        if zipfile.is_zipfile(src):
            with zipfile.ZipFile(src) as zf:
                data = yaml.safe_load(zf.read("scene.yaml")) or {}
                for info in zf.infolist():
                    if not info.filename.startswith("assets/") or info.is_dir():
                        continue
                    rel = info.filename[len("assets/"):]
                    target = os.path.realpath(os.path.join(assets, rel))
                    if not target.startswith(os.path.realpath(assets) + os.sep):
                        raise SceneError("unsafe path in the file")
                    if not os.path.exists(target):
                        os.makedirs(os.path.dirname(target), exist_ok=True)
                        with zf.open(info) as fi, open(target, "wb") as fo:
                            shutil.copyfileobj(fi, fo)
        else:
            with open(src) as fh:
                data = yaml.safe_load(fh) or {}
    except (OSError, KeyError, yaml.YAMLError, zipfile.BadZipFile) as exc:
        raise SceneError(str(exc)) from exc
    if not isinstance(data, dict):
        raise SceneError("not a scene")
    name = unique(valid_name(str(data.get("name") or os.path.splitext(os.path.basename(src))[0])))
    data["name"] = name; data.pop("match", None)
    _write(name, data)
    _save_order(names())
    return name
