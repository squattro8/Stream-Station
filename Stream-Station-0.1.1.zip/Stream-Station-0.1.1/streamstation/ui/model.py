"""Editable profile model. Reads the same YAML the service uses and writes it back, keeping any
field the editor does not know about. Saves always go to the user's own config directory."""
from __future__ import annotations

import hashlib
import copy
import os
import re

import yaml

from .. import profiles
from ..i18n import tr


def user_profiles_dir() -> str:
    return os.path.join(profiles.CONFIG, "profiles")


def user_icons_dir() -> str:
    return os.path.join(profiles.CONFIG, "assets", "icons", "user")


def slug(text: str) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", text).strip("-").lower()[:40] or "icon"
    return f"{s}-{hashlib.sha1(text.encode()).hexdigest()[:6]}"


class ProfileModel:
    def __init__(self, name: str = "General"):
        self.name = name
        self.raw = self._read(name)
        self.dirty = False

    @staticmethod
    def _read(name: str) -> dict:
        for d in profiles.search_dirs("profiles"):
            path = os.path.join(d, f"{name}.yaml")
            if os.path.isfile(path):
                with open(path) as fh:
                    return yaml.safe_load(fh) or {"name": name}
        return {"name": name}

    @staticmethod
    def list_profiles() -> list[str]:
        from .. import scenes
        return scenes.names() or profiles.available()

    # --- pages / keys ------------------------------------------------------
    def page_count(self) -> int:
        return 1 + len(self.raw.get("pages") or [])

    def _keys(self, page: int, create=False) -> dict:
        if page == 0:
            return self.raw.setdefault("keys", {}) if create else (self.raw.get("keys") or {})
        pages = self.raw.get("pages") or []
        if page - 1 >= len(pages):
            if not create:
                return {}
            pages = self.raw.setdefault("pages", [])
            while len(pages) < page:
                pages.append({"keys": {}})
        entry = pages[page - 1]
        if entry is None:
            entry = pages[page - 1] = {"keys": {}} if create else {}
        if "keys" in entry:
            if entry["keys"] is None and create:
                entry["keys"] = {}
            return entry["keys"] if entry["keys"] is not None else {}   # never a throw-away copy of an empty dict
        return entry     # legacy flat form {'0': {...}}

    def get(self, index: int, page: int = 0):
        return self._keys(page).get(str(index))

    def set(self, index: int, page: int, entry: dict | None):
        keys = self._keys(page, create=True)
        if entry:
            keys[str(index)] = entry
        else:
            keys.pop(str(index), None)
        self.dirty = True

    def add_page(self) -> int:
        entry = {"keys": {}}
        if self.strip_mode() == "per_page":
            entry["strip"] = {}                                    # a new page starts with an empty (black) strip, not a copy of page 1's
        self.raw.setdefault("pages", []).append(entry)
        self.dirty = True
        return self.page_count() - 1

    def page_has_keys(self, page: int) -> bool:
        return any(self._keys(page).values())

    def remove_page(self, page: int) -> bool:
        """Delete a page. The first page is `keys`, so removing it promotes the next page. The last page cannot go."""
        pages = self.raw.get("pages") or []
        if not pages or not 0 <= page <= len(pages):
            return False
        if page == 0:
            first = pages.pop(0) or {}
            self.raw["keys"] = dict(first.get("keys") if "keys" in first else {k: v for k, v in first.items() if k != "strip"}) if first else {}
            if self.strip_mode() == "per_page":
                if first.get("strip"):
                    self.raw["strip"] = first["strip"]            # the next page's strip becomes page 1's
                else:
                    self.raw.pop("strip", None)
        else:
            pages.pop(page - 1)
        if not pages:
            self.raw.pop("pages", None)
        self.dirty = True
        return True

    # --- applications that activate this profile -------------------------------------
    def match(self) -> list[dict]:
        return [r for r in (self.raw.get("match") or []) if isinstance(r, dict)]

    def set_match(self, rules: list[dict]):
        if rules:
            self.raw["match"] = [dict(r) for r in rules]
        else:
            self.raw.pop("match", None)
        self.dirty = True

    # --- knobs -----------------------------------------------------------------
    def knob(self, i: int) -> dict:
        return (self.raw.get("knobs") or {}).get(str(i)) or {}

    def set_knob_field(self, i: int, field: str, action):
        """field: cw | ccw (turn right / left) | press."""
        k = self.raw.setdefault("knobs", {}).setdefault(str(i), {})
        if field == "press":
            target, key = k, "press"
        else:
            target, key = k.setdefault("rotate", {}), field
        if action:
            target[key] = action
        else:
            target.pop(key, None)
        if not k.get("rotate"):
            k.pop("rotate", None)
        if not k:
            self.raw["knobs"].pop(str(i), None)
        self.dirty = True

    # --- touch strip ---------------------------------------------------------
    view_page = 0          # the page the editor is showing; the strip helpers below act on it when the strip is per page

    def strip_mode(self) -> str:
        return "per_page" if self.raw.get("strip_mode") == "per_page" else "fixed"

    def page_swipe(self) -> bool:
        return self.raw.get("page_swipe") is True

    def set_page_swipe(self, on: bool):
        if on:
            self.raw["page_swipe"] = True
        else:
            self.raw.pop("page_swipe", None)
        self.dirty = True

    def set_strip_mode(self, mode: str):
        """fixed -> per_page copies the current strip to the pages that have none yet, so no page turns blank by surprise."""
        mode = "per_page" if mode == "per_page" else "fixed"
        if mode == self.strip_mode():
            return
        if mode == "per_page":
            self.raw["strip_mode"] = "per_page"
            base = self.raw.get("strip")
            if base:
                for n in range(1, self.page_count()):
                    if not self._page_strip(n):
                        self._page_strip(n, create=True).update(copy.deepcopy(base))
        else:
            self.raw.pop("strip_mode", None)
        self.dirty = True

    def _page_entry(self, n: int) -> dict:
        """The dict of extra page n (n >= 1), converting the legacy flat form {'0': {...}} to {'keys': {...}}."""
        pages = self.raw.setdefault("pages", [])
        while len(pages) < n:
            pages.append({"keys": {}})
        entry = pages[n - 1]
        if not isinstance(entry, dict):
            entry = pages[n - 1] = {"keys": {}}
        elif "keys" not in entry:
            entry = pages[n - 1] = {"keys": dict(entry)}
        return entry

    def _page_strip(self, n: int, create=False) -> dict:
        pages = self.raw.get("pages") or []
        if not create:
            e = pages[n - 1] if n - 1 < len(pages) else None
            return (e.get("strip") or {}) if isinstance(e, dict) else {}
        return self._page_entry(n).setdefault("strip", {})

    def _strip(self, create=False) -> dict:
        if self.strip_mode() == "per_page" and self.view_page > 0:
            return self._page_strip(self.view_page, create)
        return self.raw.setdefault("strip", {}) if create else (self.raw.get("strip") or {})

    def segments(self) -> list[dict | None]:
        """The 4 panel specs. Falls back to the legacy `dashboard` list (metrics)."""
        st = self._strip()
        segs = st.get("segments")
        if segs is None:
            segs = [{"type": "metric", "kind": k} for k in (st.get("dashboard") or [])[:4]]
        segs = list(segs)[:4]
        return segs + [None] * (4 - len(segs))

    def set_segment(self, i: int, spec: dict | None):
        segs = self.segments()
        segs[i] = spec or None
        self._strip(True)["segments"] = segs
        self.dirty = True

    def full(self) -> dict | None:
        return self._strip().get("full") or None

    def set_full(self, spec: dict | None):
        st = self._strip(True)
        if spec:
            st["full"] = spec
        else:
            st.pop("full", None)
        self.dirty = True

    def touch(self, i: int):
        return (self._strip().get("touch") or {}).get(str(i))

    def set_touch(self, i: int, action):
        touch = self._strip(True).setdefault("touch", {})
        if action:
            touch[str(i)] = action
        else:
            touch.pop(str(i), None)
        self.dirty = True

    # --- persistence ---------------------------------------------------------
    def path(self) -> str:
        return os.path.join(user_profiles_dir(), f"{self.name}.yaml")

    def save(self) -> str:
        os.makedirs(user_profiles_dir(), exist_ok=True)
        self.raw.setdefault("name", self.name)
        tmp = self.path() + ".tmp"
        with open(tmp, "w") as fh:
            yaml.safe_dump(self.raw, fh, sort_keys=False, allow_unicode=True)
        os.replace(tmp, self.path())
        self.dirty = False
        return self.path()


def describe_action(action) -> str:
    """What an action does, in plain Spanish (for the hover tip): catalog name when it is one, else a readable form."""
    from . import catalog
    if isinstance(action, list):
        return tr("Secuencia de {n} pasos", n=len(action))
    if isinstance(action, dict):
        return tr("Alternar entre acciones") if "toggle" in action else (tr("Acción aleatoria") if "random" in action else tr("Multiacción"))
    if not isinstance(action, str) or not action:
        return tr("Sin acción")
    for _group, items in catalog.CATALOG:
        for label, template, _plugin in items:
            if "{}" in template:
                head = template.split("{}")[0]
                if head and action.startswith(head) and action != head:
                    return f"{tr(label).rstrip('…')}: {action[len(head):]}"
            elif template == action:
                return tr(label)
    if action.startswith("xp:cmd:"):
        return tr("Comando de X-Plane: {name}", name=action[7:])
    if action.startswith("open:"):
        return tr("Abrir: {name}", name=action[5:])
    return f"Ejecutar: {action}"


def tooltip(entry: dict | None) -> str:
    """HTML for the floating description of a configured key."""
    import html
    if not entry:
        return ""
    if "profile" in entry:
        what = tr("Cambiar al perfil «{name}»", name=entry["profile"])
    elif "layer_toggle" in entry:
        what = tr("Alternar la capa «{name}»", name=entry["layer_toggle"])
    else:
        what = describe_action(entry.get("action"))
    lines = []
    if entry.get("label"):
        lines.append(f"<b>{html.escape(str(entry['label']))}</b>")
    lines.append(html.escape(what))
    xp = entry.get("xp") if isinstance(entry.get("xp"), dict) else None
    if xp:
        def refs(h):
            r = (h or {}).get("dataref")
            return ", ".join(r) if isinstance(r, list) else (r or "")
        if "top" in xp or "bottom" in xp:
            lines.append(tr("Luz de arriba: {top}", top=html.escape(refs(xp.get("top")) or "—")) + "<br>"
                         + tr("Luz de abajo: {bottom}", bottom=html.escape(refs(xp.get("bottom")) or "—")))
        elif refs(xp):
            lines.append(tr("Luz de estado: {name}", name=html.escape(refs(xp))))
    return "<br>".join(lines)


def summary(entry: dict | None) -> str:
    """One line describing what a key does (for the configuration panel)."""
    if not entry:
        return tr("Sin acción")
    if "profile" in entry:
        return tr("Cambiar al perfil «{name}»", name=entry["profile"])
    if "layer_toggle" in entry:
        return tr("Alternar la capa «{name}»", name=entry["layer_toggle"])
    act = entry.get("action")
    if isinstance(act, list):
        return tr("Secuencia de {n} pasos", n=len(act))
    if isinstance(act, dict):
        return tr("Alternar / aleatoria: ") + ", ".join(k for k in act)
    text = str(act or tr("Sin acción"))
    if isinstance(act, str) and act.startswith("xp:cmd:"):
        xp = entry.get("xp") or {}
        if "top" in xp or "bottom" in xp:
            names = lambda h: ", ".join(r if isinstance(r, str) else "" for r in ([(h or {}).get("dataref")] if not isinstance((h or {}).get("dataref"), list) else h["dataref"])) or "—"
            text = tr("Comando de X-Plane: {name}", name=act[7:]) + tr("  ·  luz arriba: {top}  ·  luz abajo: {bottom}", top=names(xp.get("top")), bottom=names(xp.get("bottom")))
        else:
            text = tr("Comando de X-Plane: {name}", name=act[7:]) + (tr("  ·  estado: {name}", name=", ".join(xp["dataref"]) if isinstance(xp["dataref"], list) else xp["dataref"]) if xp.get("dataref") else tr("  ·  sin dataref de estado"))
    return text
