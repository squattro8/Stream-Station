"""Byte-exact vectors derived from the vendor DLL pseudo-code (NOTES.md)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from streamstation import protocol as P


def head(pkt, n):
    return pkt[:n]


def test_sizes():
    for pkt in (P.connect(), P.wake(), P.stop(), P.sleep(), P.clear(1), P.brightness(5)):
        assert len(pkt) == P.PACKET_OUT
        assert pkt[:3] == b"CRT" and pkt[3:5] == b"\x00\x00"


def test_connect_heartbeat():  # addHeartbeatPack: CRT at 0-2, "CONNECT" at 5-11
    assert head(P.connect(), 12) == b"CRT\x00\x00CONNECT"


def test_wake_and_stop_and_sleep():
    assert head(P.wake(), 8) == b"CRT\x00\x00DIS"
    assert head(P.stop(), 8) == b"CRT\x00\x00STP"
    assert head(P.sleep(), 8) == b"CRT\x00\x00HAN"


def test_clear_index_at_byte_11():  # addClearCommand
    p = P.clear(0x07)
    assert p[5:8] == b"CLE" and p[8:11] == b"\x00\x00\x00" and p[11] == 7
    assert P.clear(0xFF)[11] == 0xFF


def test_brightness_at_byte_10_clamped():  # addAdjustBrightnessPack
    assert P.brightness(60)[5:8] == b"LIG" and P.brightness(60)[10] == 60
    assert P.brightness(-5)[10] == 0
    assert P.brightness(500)[10] == 100


def test_bat_header():  # sendPicSizeCommand
    p = P.image_header(slot=6, size=0x1234)
    assert p[5:8] == b"BAT"
    assert (p[10], p[11], p[12]) == (0x12, 0x34, 6)


def test_bat_size_limit():
    try:
        P.image_header(1, 0x10000)
    except ValueError:
        return
    raise AssertionError("must reject >16-bit length")


def test_chunks_cover_payload():
    data = bytes(range(256)) * 10
    chunks = P.image_chunks(data)
    assert all(len(c) == P.PACKET_OUT for c in chunks)
    assert b"".join(chunks)[:len(data)] == data


def test_parse_report():
    frame = bytearray(b"ACK\x00\x00OK\x00\x00\x00\x00").ljust(512, b"\x00")
    assert P.parse_report(bytes(frame)) == ("ack",)
    frame[9], frame[10] = 0x05, 1
    assert P.parse_report(bytes(frame)) == ("event", 5, 1)
    assert P.parse_report(b"junk") is None


def test_draw_stream_header_matches_getSecondaryScreenPicInfo():
    jpeg = bytes(range(200)) * 3                                     # 600 bytes
    st = P.draw_stream(jpeg, x=0x0102, y=0x0304, w=0x0340, h=0x007C, index=5)
    assert st[:3] == b"CRT" and st[3:5] == b"\x00\x00" and st[5:8] == b"DRA"
    assert int.from_bytes(st[8:12], "big") == len(jpeg) + 0x20        # size field = payload + 0x20
    assert st[12] == 5
    assert st[13:15] == b"\x03\x40" and st[15:17] == b"\x00\x7c"      # width, height
    assert st[17:19] == b"\x01\x02" and st[19:21] == b"\x03\x04"      # x, y
    assert st[21:32] == bytes(11) and st[32:] == jpeg                 # zero padded header, then the image
    for bad in (dict(w=0), dict(x=70000)):
        try: P.draw_stream(jpeg, **{**dict(x=0, y=0, w=10, h=10), **bad})
        except ValueError: continue
        raise AssertionError("invalid rectangle must be refused")


def test_draw_stream_is_chunked_like_any_other_image():
    st = P.draw_stream(bytes(5000), 0, 0, 832, 124)
    chunks = P.image_chunks(st)
    assert len(chunks) == -(-len(st) // P.PACKET_OUT) and chunks[0][:8] == b"CRT\x00\x00DRA"


def test_change_direction_layout():  # sendChangeDirectionCommand
    p = P.change_direction(1, 2)
    assert p[5:8] == b"SET" and (p[10], p[11]) == (1, 2)
