"""Software updates from the project's GitHub releases.

    check(repo)      asks GitHub which release is the latest and compares it with the installed version
    install(info)    downloads that release, runs its installer and restarts Stream Station (in the background)

Only HTTPS requests to GitHub are made, and they carry nothing about the user: a plain GET with a generic client name.
"""
from __future__ import annotations

import io
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from dataclasses import dataclass, field

from . import __version__

API = "https://api.github.com/repos/{repo}/releases/latest"
REPO_RE = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
ALLOWED_HOSTS = ("api.github.com", "github.com", "codeload.github.com", "objects.githubusercontent.com")
USER_AGENT = "StreamStation-updater"
MAX_BYTES = 80 * 1024 * 1024


class UpdateError(RuntimeError):
    pass


@dataclass
class Release:
    version: str                    # "1.2.0"
    notes: str = ""                 # the changelog (the release description)
    url: str = ""                   # where the zip comes from
    page: str = ""                  # the release page, for the curious
    current: str = __version__
    newer: bool = False
    extra: dict = field(default_factory=dict)


def parse_version(text: str) -> tuple:
    """"v1.2.3-beta" -> (1, 2, 3). Anything that is not a number counts as 0, so odd tags never crash a comparison."""
    nums = re.findall(r"\d+", str(text).split("-")[0])
    return tuple(int(n) for n in nums[:4]) or (0,)


def is_newer(candidate: str, current: str = __version__) -> bool:
    a, b = parse_version(candidate), parse_version(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def _safe_url(url: str) -> str:
    m = re.match(r"^https://([^/:]+)(/|$)", url or "")
    if not m or m.group(1) not in ALLOWED_HOSTS:
        raise UpdateError(f"refusing to download from {url!r}")
    return url


def _get(url: str, opener=urllib.request.urlopen, timeout: int = 15) -> bytes:
    req = urllib.request.Request(_safe_url(url), headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
    with opener(req, timeout=timeout) as resp:
        data = resp.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise UpdateError("the download is unreasonably large")
    return data


def check(repo: str, opener=urllib.request.urlopen, current: str = __version__) -> Release:
    """The latest published release of `repo` ("user/name"), flagged `newer` when it is ahead of the installed version."""
    if not REPO_RE.match(repo or ""):
        raise UpdateError("no repository configured")
    try:
        data = json.loads(_get(API.format(repo=repo), opener))
    except UpdateError:
        raise
    except Exception as exc:                                  # no connection, 404 (no releases yet), bad JSON...
        raise UpdateError(str(exc)) from exc
    tag = str(data.get("tag_name") or "").strip()
    if not tag:
        raise UpdateError("the repository has no published release")
    asset = next((a.get("browser_download_url") for a in data.get("assets") or []
                  if str(a.get("name", "")).lower().endswith(".zip")), None)
    return Release(version=tag.lstrip("vV"), notes=str(data.get("body") or ""), url=asset or str(data.get("zipball_url") or ""),
                   page=str(data.get("html_url") or ""), current=current, newer=is_newer(tag, current))


def _find_root(folder: str) -> str:
    for base, dirs, files in os.walk(folder):
        if "install.sh" in files and os.path.isfile(os.path.join(base, "streamstation", "__init__.py")):
            return base
        dirs[:] = [d for d in dirs if not d.startswith(".")]
    raise UpdateError("the download is not a Stream Station release")


def _extract(data: bytes, dest: str):
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            target = os.path.realpath(os.path.join(dest, name))
            if not target.startswith(os.path.realpath(dest) + os.sep) and target != os.path.realpath(dest):
                raise UpdateError(f"unsafe path in the archive: {name}")
        zf.extractall(dest)


def prepare(release: Release, opener=urllib.request.urlopen, workdir: str | None = None) -> str:
    """Download the release and unpack it; returns the folder that holds its install.sh."""
    if not release.url:
        raise UpdateError("the release has no download")
    work = workdir or tempfile.mkdtemp(prefix="streamstation-update-")
    _extract(_get(release.url, opener, timeout=120), work)
    return _find_root(work)


def install_command(root: str, launcher: str, work: str) -> list[str]:
    """What runs, detached, once the editor lets go: install the new files, restart the service, reopen the editor."""
    q = shlex.quote
    script = (f"sleep 1; bash {q(os.path.join(root, 'install.sh'))} --apply >/dev/null 2>&1 && "
              f"systemctl --user restart streamstation.service; rm -rf {q(work)}; exec {q(launcher)} ui")
    return ["sh", "-c", script]


def install(release: Release, launcher: str, opener=urllib.request.urlopen, spawn=subprocess.Popen) -> list[str]:
    """Download, then hand the installation to a detached process (the caller closes the editor right after)."""
    work = tempfile.mkdtemp(prefix="streamstation-update-")
    try:
        root = prepare(release, opener, work)
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise
    cmd = install_command(root, launcher, work)
    spawn(cmd, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return cmd


def cleanup(root: str):
    shutil.rmtree(root, ignore_errors=True)
