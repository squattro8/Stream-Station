"""Graphical editor for the deck (PySide6). Visual language follows Redragon Stream Station."""
