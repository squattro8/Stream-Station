"""Installed applications (.desktop entries) and their icons, for 'add an app as a button'."""
from __future__ import annotations

import configparser
import os
from dataclasses import dataclass


@dataclass
class App:
    id: str          # desktop file id, what `gtk-launch` / the open: action takes
    name: str
    icon: str
    comment: str = ""


def desktop_dirs() -> list[str]:
    data = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"
    home = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    return [os.path.join(d, "applications") for d in [home] + data.split(":") if d]


def parse_desktop(path: str) -> App | None:
    cp = configparser.RawConfigParser(strict=False, interpolation=None)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8")
    except (configparser.Error, OSError, UnicodeDecodeError):
        return None
    if not cp.has_section("Desktop Entry"):
        return None
    g = lambda k: cp.get("Desktop Entry", k, fallback="")
    if g("Type") != "Application" or g("NoDisplay").lower() == "true" or g("Hidden").lower() == "true":
        return None
    if not g("Name") or not g("Exec"):
        return None
    return App(os.path.basename(path)[:-8], g("Name"), g("Icon"), g("Comment"))


def list_apps(dirs: list[str] | None = None) -> list[App]:
    seen: dict[str, App] = {}
    for d in dirs or desktop_dirs():
        if not os.path.isdir(d):
            continue
        for root, _, files in os.walk(d):
            for f in files:
                if f.endswith(".desktop"):
                    rel = os.path.relpath(os.path.join(root, f), d).replace(os.sep, "-")[:-8]
                    app = parse_desktop(os.path.join(root, f))
                    if app and rel not in seen:       # earlier dirs win (user overrides system)
                        app.id = rel
                        seen[rel] = app
    return sorted(seen.values(), key=lambda a: a.name.lower())


def app_key_image(icon: str, size: int = 128):
    """PIL image: the app's own icon centred on a dark tile; None if the theme has no icon."""
    from PIL import Image
    from PySide6.QtCore import QBuffer, QIODevice
    from PySide6.QtGui import QIcon, QPixmap
    import io
    if icon and os.path.isabs(icon) and os.path.isfile(icon):
        pm = QPixmap(icon)
    else:
        ic = QIcon.fromTheme(icon) if icon else QIcon()
        pm = ic.pixmap(size, size) if not ic.isNull() else QPixmap()
    if pm.isNull():
        return None
    buf = QBuffer(); buf.open(QIODevice.WriteOnly); pm.save(buf, "PNG")
    from . import actionicons
    return actionicons.app_tile(Image.open(io.BytesIO(bytes(buf.data()))), size)


_FIELD_CODES = ("%f", "%F", "%u", "%U", "%d", "%D", "%n", "%N", "%i", "%c", "%k", "%v", "%m")


def exec_command(path: str) -> str | None:
    """The command line of a .desktop file with the %-field codes removed (for files that are not
    in a standard applications directory, where `gtk-launch <id>` cannot find them)."""
    cp = configparser.RawConfigParser(strict=False, interpolation=None)
    cp.optionxform = str
    try:
        cp.read(path, encoding="utf-8")
        cmd = cp.get("Desktop Entry", "Exec")
    except (configparser.Error, OSError, UnicodeDecodeError):
        return None
    cmd = cmd.replace("%%", "\0")
    for code in _FIELD_CODES:
        cmd = cmd.replace(code, "")
    return " ".join(cmd.replace("\0", "%").split())


def in_standard_dirs(path: str) -> str | None:
    """The desktop-file id when `path` lives in a standard applications dir, else None."""
    real = os.path.realpath(path)
    for d in desktop_dirs():
        base = os.path.realpath(d)
        if real.startswith(base + os.sep):
            return os.path.relpath(real, base).replace(os.sep, "-")[:-8]
    return None
