"""Find the buttons and lamps of an installed X-Plane aircraft, so the editor can offer them.

Only the user's own installed files are read (nothing is downloaded or sent anywhere). Two sources:

  1. The aircraft's own documentation, when it ships one (``*Datarefs*.txt`` / ``*Commands*.txt`` next to
     the .acf). Sections such as "AUTOPILOT LIGHTS (read only)" list ``label <tab> dataref``; command
     files list ``command <tab> description``.
  2. The 3D cockpit objects (``*.obj``): every ``ATTR_manip_*`` line names the command (or dataref) a
     click runs and often a tooltip; the ``ANIM_*`` lines of the surrounding ``ANIM_begin`` blocks name
     the datarefs that move or light that part.

A command and a lamp are paired when they share their last name component once the usual suffixes
(_press, _status, _toggle...) are removed and live in the same folder of the name, e.g.
``laminar/B738/autopilot/n1_press`` + ``laminar/B738/autopilot/n1_status``. Pairs are SUGGESTIONS with a
confidence; the user can always correct them in the editor.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field

NAME = r"[A-Za-z0-9_]+(?:/[A-Za-z0-9_\[\]]+)+"
_NAME_RE = re.compile(rf"^{NAME}$")
_SUFFIX = re.compile(r"(?:_|^)(?:press|release|status\d*|light\d*|lamp|annun\w*|toggle|tog|on|off|up|down|switch|sw|button|btn|"
                     r"push|cmd|command|set|pos|state|ratio|ind\w*|disp\w*|\d+)$")


@dataclass
class DocEntry:
    name: str
    label: str = ""
    values: str = ""
    section: str = ""
    readonly: bool = False


@dataclass
class DocCommand:
    name: str
    description: str = ""
    section: str = ""


@dataclass
class Manip:
    kind: str                 # command | toggle | radio | ...
    commands: list[str]
    dataref: str = ""         # the dataref a toggle/radio manipulator writes
    tooltip: str = ""
    anim: list[str] = field(default_factory=list)   # datarefs that animate the part (own block first)
    source: str = ""


@dataclass
class Control:
    """One thing the user may want on a key: what a press runs and what shows its state."""
    title: str
    command: str = ""
    state: str = ""           # dataref of the lamp / switch position
    readonly_state: bool = True
    values: str = ""
    section: str = ""
    confidence: float = 0.0
    source: str = ""          # docs | obj


def stem(name: str) -> str:
    """Last name component without the usual role suffixes: n1_press -> n1, hdg_sel_status -> hdg_sel."""
    last = name.rsplit("/", 1)[-1]
    last = re.sub(r"\[\d+\]$", "", last)
    for _ in range(3):
        new = _SUFFIX.sub("", last)
        if new == last or not new:
            break
        last = new
    return last.lower()


def _folder(name: str) -> str:
    """Name without its last component and without the role folders (buttons, switches...)."""
    parts = name.split("/")[:-1]
    skip = {"buttons", "button", "switches", "switch", "toggle_switch", "annunciator", "rotary", "knobs", "lights"}
    return "/".join(p.lower() for p in parts if p.lower() not in skip)


# --- aircraft on disk -------------------------------------------------------------------------------------
def list_aircraft(install: str) -> list[dict]:
    """Every folder under <install>/Aircraft that holds an .acf: {name, path, acf: [...]}."""
    out, root = [], os.path.join(install, "Aircraft")
    for dp, dirs, files in os.walk(root):
        acf = sorted(f for f in files if f.lower().endswith(".acf"))
        if acf:
            out.append({"name": os.path.basename(dp), "path": dp, "acf": acf})
            dirs[:] = []                    # an aircraft folder does not contain other aircraft
    return sorted(out, key=lambda a: a["name"].lower())


def _read(path: str) -> list[str]:
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as fh:
            return fh.read().splitlines()
    except OSError:
        return []


def doc_files(folder: str) -> tuple[list[str], list[str]]:
    """(dataref docs, command docs) shipped next to the .acf (any *.txt whose name says so)."""
    drs, cmds = [], []
    for f in sorted(os.listdir(folder)):
        low = f.lower()
        if not low.endswith(".txt"):
            continue
        if "dataref" in low:
            drs.append(os.path.join(folder, f))
        elif "command" in low:
            cmds.append(os.path.join(folder, f))
    return drs, cmds


# --- documentation parsers ---------------------------------------------------------------------------------
def parse_dataref_doc(path: str) -> list[DocEntry]:
    lines, out, section, ro = _read(path), [], "", False
    for i, line in enumerate(lines):
        nxt = lines[i + 1].strip() if i + 1 < len(lines) else ""
        if line.strip() and nxt and set(nxt) <= {"-", "="} and len(nxt) >= 3:     # a title underlined with dashes
            section = line.strip()
            ro = "read only" in section.lower() or "(read)" in section.lower()
            continue
        if set(line.strip()) <= {"-", "="}:
            continue
        cols = [c.strip() for c in line.split("\t") if c.strip()]
        if not cols:
            continue
        name = next((c for c in reversed(cols) if _NAME_RE.match(c)), None)
        if not name:
            continue
        rest = [c for c in cols if c != name]
        out.append(DocEntry(name=name, label=rest[0] if rest else "", values=rest[1] if len(rest) > 1 else "",
                            section=section, readonly=ro))
    return out


def parse_command_doc(path: str) -> list[DocCommand]:
    out, section = [], ""
    for line in _read(path):
        s = line.strip()
        if s.startswith("--"):
            section = s.lstrip("- ").strip()
            continue
        parts = [c.strip() for c in re.split(r"\t+|\s{3,}", s) if c.strip()]
        if parts and _NAME_RE.match(parts[0]):
            out.append(DocCommand(parts[0], parts[1] if len(parts) > 1 else "", section))
    return out


# --- 3D cockpit objects ------------------------------------------------------------------------------------
_ANIM_REF = re.compile(NAME)


def parse_obj(path: str) -> list[Manip]:
    """The manipulators of one .obj with the datarefs of their enclosing ANIM_begin blocks."""
    out: list[Manip] = []
    stack: list[list[str]] = []
    base = os.path.basename(path)
    for raw in _read(path):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        key = line.split(None, 1)[0]
        if key == "ANIM_begin":
            stack.append([])
        elif key == "ANIM_end":
            if stack:
                stack.pop()
        elif key.startswith("ANIM_") and stack:
            for ref in _ANIM_REF.findall(line):
                if ref not in stack[-1] and not ref.startswith("sim/graphics"):
                    stack[-1].append(ref)
        elif key.startswith("ATTR_manip_") and key not in ("ATTR_manip_none", "ATTR_manip_noop"):
            toks = line.split()[1:]
            kind = key[len("ATTR_manip_"):]
            anim = [r for blk in reversed(stack) for r in blk]
            cmds = [t for t in toks[1:] if _NAME_RE.match(t) and not t.replace(".", "").isdigit()]
            if kind.startswith("command"):
                n = 2 if any(s in kind for s in ("axis", "knob", "switch")) else 1
                use = cmds[:n]
                tip = " ".join(toks[1 + len(use):]) if toks else ""
                out.append(Manip(kind="command", commands=use, tooltip=_tip(toks, use), anim=anim, source=base))
            elif kind in ("toggle", "radio", "delta", "wrap", "push", "axis", "axis_knob", "axis_switch_up_down", "axis_switch_left_right"):
                ref = cmds[0] if cmds else ""
                out.append(Manip(kind=kind, commands=[], dataref=ref, tooltip=_tip(toks, [ref] if ref else []), anim=anim, source=base))
    return out


def _tip(toks: list[str], used: list[str]) -> str:
    """Tooltip = the words after the last command/dataref token (those before are cursor and numbers)."""
    last = max((i for i, t in enumerate(toks) if t in used), default=-1)
    words = toks[last + 1:] if last >= 0 else []
    return " ".join(w for w in words if not re.fullmatch(r"-?[\d.]+", w))


def scan_objs(folder: str, limit: int = 400) -> list[Manip]:
    out: list[Manip] = []
    seen = 0
    for dp, _, files in os.walk(folder):
        for f in sorted(files):
            if f.lower().endswith(".obj"):
                out += parse_obj(os.path.join(dp, f)); seen += 1
                if seen >= limit:
                    return out
    return out


# --- putting it together -----------------------------------------------------------------------------------
def controls_from_docs(entries: list[DocEntry], commands: list[DocCommand]) -> list[Control]:
    lamps: dict[tuple[str, str], DocEntry] = {}
    for e in entries:
        key = (_folder(e.name), stem(e.name))
        better = lamps.get(key)
        if better is None or (e.readonly and not better.readonly):
            lamps[key] = e                                  # prefer the read-only "status" lamp over a writable button
    out, paired = [], set()
    for c in commands:
        lamp = lamps.get((_folder(c.name), stem(c.name)))
        title = c.description or (lamp.label if lamp else stem(c.name))
        if lamp:
            paired.add((_folder(c.name), stem(c.name)))
            out.append(Control(title=lamp.label or title, command=c.name, state=lamp.name, readonly_state=lamp.readonly,
                               values=lamp.values, section=lamp.section or c.section, confidence=0.85, source="docs"))
        else:
            out.append(Control(title=title, command=c.name, section=c.section, confidence=0.4, source="docs"))
    # second pass: same stem (digits ignored: master_caution1 ~ master_caution_light) in a different folder
    loose = {}
    for key, lamp in lamps.items():
        if key not in paired:
            loose.setdefault(re.sub(r"\d+$", "", key[1]), []).append((key, lamp))
    for i, ctl in enumerate(out):
        if ctl.state or not ctl.command:
            continue
        base = re.sub(r"\d+$", "", stem(ctl.command))
        cand = loose.get(base) if len(base) >= 4 else None
        if cand and len(cand) == 1:                       # only when unambiguous
            key, lamp = cand[0]
            paired.add(key)
            out[i] = Control(title=lamp.label or ctl.title, command=ctl.command, state=lamp.name, readonly_state=lamp.readonly,
                             values=lamp.values, section=lamp.section or ctl.section, confidence=0.6, source="docs")
    for key, lamp in lamps.items():                      # lamps/switches with no command of their own
        if key not in paired:
            out.append(Control(title=lamp.label or stem(lamp.name), state=lamp.name, readonly_state=lamp.readonly,
                               values=lamp.values, section=lamp.section, confidence=0.3, source="docs"))
    return out


def controls_from_objs(manips: list[Manip]) -> list[Control]:
    out, seen = [], set()
    for m in manips:
        state = m.dataref or next((a for a in m.anim if not a.startswith("sim/graphics")), "")
        for cmd in m.commands or [""]:
            key = (cmd, state)
            if key in seen or not (cmd or state):
                continue
            seen.add(key)
            conf = 0.7 if m.dataref else (0.5 if state else 0.3)
            out.append(Control(title=m.tooltip or stem(cmd or state), command=cmd, state=state, readonly_state=not m.dataref,
                               confidence=conf, source="obj"))
    return out


def scan(folder: str) -> dict:
    """Everything useful found in one aircraft folder."""
    drs, cmds = doc_files(folder)
    entries = [e for p in drs for e in parse_dataref_doc(p)]
    commands = [c for p in cmds for c in parse_command_doc(p)]
    controls = controls_from_docs(entries, commands)
    have = {c.command for c in controls if c.command}
    manips = scan_objs(folder)
    controls += [c for c in controls_from_objs(manips) if c.command not in have or not c.command]
    return {"folder": folder, "datarefs_documented": len(entries), "commands_documented": len(commands),
            "manipulators": len(manips), "controls": controls}


def search(controls: list[Control], text: str, limit: int = 300) -> list[Control]:
    t = text.strip().lower()
    hits = [c for c in controls if not t or t in c.title.lower() or t in c.command.lower() or t in c.state.lower() or t in c.section.lower()]
    return sorted(hits, key=lambda c: (-c.confidence, c.section, c.title))[:limit]


def detect_folder(acf_path: str, listing: list[dict]) -> dict | None:
    """The installed aircraft that owns `acf_path` (what X-Plane reports as sim/aircraft/view/acf_relative_path,
    e.g. "Aircraft/Other Aircraft/737NG Series_v2.S1.50/737_70NG.acf"). The longest matching folder name wins."""
    norm = "/" + acf_path.replace("\\", "/").replace(":", "/").strip("/") + "/"
    best = None
    for a in listing:
        if f"/{a['name']}/" in norm and (best is None or len(a["name"]) > len(best["name"])):
            best = a
    return best
