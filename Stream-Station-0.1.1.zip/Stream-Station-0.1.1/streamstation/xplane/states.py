"""Turn a dataref value into what a key shows: off / on / standby (armed) / warning / unknown.

A key's `xp.state` block:
    dataref:  sim/cockpit/electrical/landing_lights_on
    index:    0                   (only for array datarefs)
    template: onoff               (or `states:` with your own rules)

`dataref` may also be a list (with `index` a list of the same length): the rules then pick a value with
`ref: N` (0 = the first), and `all: [rule, ...]` / `any: [rule, ...]` combine several conditions in one rule, e.g.
an autopilot switch lit when the servos are on but red when its disconnect annunciator is up:
    dataref: [sim/cockpit2/autopilot/autopilot_on, sim/cockpit2/annunciators/autopilot_disconnect]
    states: [{ref: 1, ne: 0, name: warn, label: DESCONECTADO}, {ref: 0, ne: 0, name: on}, {name: off, ge: -1e9}]
With a template, `combine: any|all|first` (default any) reduces the list to one value first.

A rule is {eq|ne|gt|ge|lt|le|between: ..., name: off|on|standby|armed|warn, label: "TEXT {pct:.0f}%", color: "#rrggbb"}.
The first rule that matches wins. `label` may use {value} and {pct} (value * 100).
"""
from __future__ import annotations

import copy
from dataclasses import dataclass

COLORS = {"off": "#3d3d44", "on": "#27ae60", "standby": "#d4a017", "armed": "#2980b9", "warn": "#c0392b",
          "unknown": "#2b2b30", "offline": "#2b2b30"}

TEMPLATES: dict[str, list[dict]] = {
    "onoff": [{"eq": 0, "name": "off", "label": "APAGADO"}, {"ne": 0, "name": "on", "label": "ENCENDIDO"}],
    # autopilot statuses: 0 off, 1 armed (waiting to capture), 2 captured (active)
    "off_armed_on": [{"eq": 0, "name": "off", "label": "APAGADO"}, {"eq": 1, "name": "standby", "label": "EN ESPERA"},
                     {"ge": 2, "name": "on", "label": "ACTIVO"}],
    "gear": [{"eq": 0, "name": "off", "label": "ARRIBA"}, {"ne": 0, "name": "on", "label": "ABAJO"}],
    "ratio_pct": [{"lt": 0.02, "name": "off", "label": "0%"}, {"gt": 0.98, "name": "on", "label": "100%"},
                  {"between": [0.02, 0.98], "name": "standby", "label": "{pct:.0f}%"}],
    "paused": [{"eq": 0, "name": "off", "label": "EN MARCHA"}, {"ne": 0, "name": "warn", "label": "PAUSADO"}],
    "flight_director": [{"eq": 0, "name": "off", "label": "APAGADO"}, {"eq": 1, "name": "standby", "label": "DIRECTOR"},
                        {"ge": 2, "name": "on", "label": "ACOPLADO"}],
    # annunciators: the light that a switch such as Master Caution shows while the condition is present
    "caution": [{"eq": 0, "name": "off", "label": ""}, {"ne": 0, "name": "standby", "label": "CAUTION"}],
    "warning": [{"eq": 0, "name": "off", "label": ""}, {"ne": 0, "name": "warn", "label": "WARNING"}],
}
TEMPLATE_TITLES = {"onoff": "Apagado / Encendido", "off_armed_on": "Apagado / En espera / Activo", "gear": "Arriba / Abajo",
                   "ratio_pct": "Porcentaje (0–1)", "paused": "En marcha / Pausado", "flight_director": "Apagado / Director / Acoplado",
                   "caution": "Anunciador ámbar (se ilumina al haber aviso)", "warning": "Anunciador rojo (se ilumina al haber alarma)"}


@dataclass(frozen=True)
class StateView:
    name: str            # off | on | standby | armed | warn | unknown | offline
    label: str
    color: str
    value: float | None = None


_OPS = {"eq": lambda v, a: abs(v - a) < 1e-6, "ne": lambda v, a: abs(v - a) >= 1e-6, "gt": lambda v, a: v > a,
        "ge": lambda v, a: v >= a - 1e-9, "lt": lambda v, a: v < a, "le": lambda v, a: v <= a + 1e-9,
        "between": lambda v, a: a[0] <= v <= a[1]}


def _match(rule: dict, vals: list[float]) -> bool:
    """All conditions of the rule hold. `ref` picks which value the comparisons use; all/any nest rules."""
    ref = int(rule.get("ref", 0))
    v = vals[ref]
    keys = [k for k in _OPS if k in rule]
    ok = all(_OPS[k](v, rule[k]) for k in keys)
    if "all" in rule:
        ok = ok and all(_match(r, vals) for r in rule["all"])
    if "any" in rule:
        ok = ok and any(_match(r, vals) for r in rule["any"])
    return ok and bool(keys or "all" in rule or "any" in rule)


def rules_for(spec: dict) -> list[dict]:
    if spec.get("states"):
        return list(spec["states"])
    return TEMPLATES.get(spec.get("template") or "onoff", TEMPLATES["onoff"])


def halves(xp: dict | None) -> list[dict] | None:
    """[top, bottom] when the key is a two-lamp switch (`top:` / `bottom:` blocks), else None.
    A missing half is an empty dict (a lamp that never lights)."""
    if isinstance(xp, dict) and ("top" in xp or "bottom" in xp):
        return [xp.get("top") or {}, xp.get("bottom") or {}]
    return None


def refs(spec: dict | None) -> list[tuple[str, int | None]]:
    """The (dataref, array index) pairs a key's state needs, in order."""
    two = halves(spec)
    if two is not None:
        out: list[tuple[str, int | None]] = []
        for half in two:
            out += [r for r in refs(half) if r not in out]
        return out
    if not isinstance(spec, dict) or not spec.get("dataref"):
        return []
    names, idx = spec["dataref"], spec.get("index")
    names = names if isinstance(names, list) else [names]
    idx = idx if isinstance(idx, list) else [idx] * len(names)
    idx = (list(idx) + [None] * len(names))[: len(names)]
    return [(str(n), i) for n, i in zip(names, idx) if n]


def evaluate(spec: dict | None, value, online: bool = True) -> StateView:
    """What to show for `value` (a number, or a list for several datarefs; None = not read yet). Never raises."""
    if not refs(spec):
        return StateView("unknown", "", COLORS["unknown"])
    vals = value if isinstance(value, (list, tuple)) else [value]
    if not online or not vals or any(x is None for x in vals):
        return StateView("offline", "SIN SIM", COLORS["offline"])
    try:
        vals = [float(x) for x in vals]
    except (TypeError, ValueError):
        return StateView("unknown", "?", COLORS["unknown"])
    if not spec.get("states") and len(vals) > 1:
        mode = spec.get("combine", "any")
        vals = [vals[0] if mode == "first" else (min(vals) if mode == "all" else max(vals))]
    v = vals[0]
    for rule in rules_for(spec):
        try:
            if isinstance(rule, dict) and _match(rule, vals):
                name = str(rule.get("name") or "on")
                try:
                    label = str(rule.get("label", name.upper())).format(value=v, pct=v * 100)
                except (KeyError, IndexError, ValueError):
                    label = str(rule.get("label", ""))
                return StateView(name, label, rule.get("color") or COLORS.get(name, COLORS["on"]), v)
        except (TypeError, ValueError, IndexError, KeyError):
            continue
    return StateView("unknown", f"{v:g}", COLORS["unknown"], v)


def views(xp: dict | None, getter, online: bool = True) -> list[StateView]:
    """One StateView for a single-lamp key, two (top, bottom) for a two-lamp switch.
    `getter(dataref, index)` returns the current value or None."""
    def one(spec):
        return evaluate(spec, [getter(n, i) for n, i in refs(spec)], online)
    two = halves(xp)
    return [one(h) for h in two] if two is not None else [one(xp)]


# --- curated table: command -> state, verified against the user's own Commands.txt / DataRefs.txt by the tests ----------
_SUFFIXES = ("_toggle", "_tog", "_on", "_off")

BASES: dict[str, tuple[str, int | None, str]] = {
    "sim/lights/landing_lights": ("sim/cockpit/electrical/landing_lights_on", None, "onoff"),
    "sim/lights/taxi_lights": ("sim/cockpit/electrical/taxi_light_on", None, "onoff"),
    "sim/lights/beacon_lights": ("sim/cockpit/electrical/beacon_lights_on", None, "onoff"),
    "sim/lights/strobe_lights": ("sim/cockpit/electrical/strobe_lights_on", None, "onoff"),
    "sim/lights/nav_lights": ("sim/cockpit/electrical/nav_lights_on", None, "onoff"),
    "sim/electrical/battery_1": ("sim/cockpit/electrical/battery_on", None, "onoff"),
    "sim/electrical/generator_1": ("sim/cockpit/electrical/generator_on", 0, "onoff"),
    "sim/systems/avionics": ("sim/cockpit/electrical/avionics_on", None, "onoff"),
    "sim/ice/pitot_heat0": ("sim/cockpit2/ice/ice_pitot_heat_on_pilot", None, "onoff"),
    "sim/autopilot/servos": ("sim/cockpit2/autopilot/servos_on", None, "onoff"),
}
EXACT: dict[str, tuple[str, int | None, str]] = {
    "sim/flight_controls/landing_gear_down": ("sim/cockpit2/controls/gear_handle_down", None, "gear"),
    "sim/flight_controls/landing_gear_up": ("sim/cockpit2/controls/gear_handle_down", None, "gear"),
    "sim/flight_controls/landing_gear_toggle": ("sim/cockpit2/controls/gear_handle_down", None, "gear"),
    "sim/flight_controls/flaps_up": ("sim/cockpit2/controls/flap_ratio", None, "ratio_pct"),
    "sim/flight_controls/flaps_down": ("sim/cockpit2/controls/flap_ratio", None, "ratio_pct"),
    "sim/flight_controls/speed_brakes_up_all": ("sim/cockpit2/controls/speedbrake_ratio", None, "ratio_pct"),
    "sim/flight_controls/speed_brakes_down_all": ("sim/cockpit2/controls/speedbrake_ratio", None, "ratio_pct"),
    "sim/flight_controls/speed_brakes_toggle": ("sim/cockpit2/controls/speedbrake_ratio", None, "ratio_pct"),
    "sim/flight_controls/brakes_toggle_max": ("sim/cockpit2/controls/parking_brake_ratio", None, "onoff"),
    "sim/operation/pause_toggle": ("sim/time/paused", None, "paused"),
    "sim/autopilot/fdir_toggle": ("sim/cockpit2/autopilot/flight_director_mode", None, "flight_director"),
    "sim/autopilot/heading": ("sim/cockpit2/autopilot/heading_status", None, "off_armed_on"),
    "sim/autopilot/altitude_hold": ("sim/cockpit2/autopilot/altitude_hold_status", None, "off_armed_on"),
    "sim/autopilot/NAV": ("sim/cockpit2/autopilot/nav_status", None, "off_armed_on"),
    "sim/autopilot/vnav": ("sim/cockpit2/autopilot/vnav_status", None, "off_armed_on"),
    "sim/autopilot/approach": ("sim/cockpit2/autopilot/approach_status", None, "off_armed_on"),
}


# Commands whose key needs more than one dataref (a switch plus its annunciator). Checked by the tests.
SPECS: dict[str, dict] = {
    "sim/annunciator/clear_master_caution": {"dataref": "sim/cockpit2/annunciators/master_caution", "template": "caution"},
    "sim/annunciator/clear_master_warning": {"dataref": "sim/cockpit2/annunciators/master_warning", "template": "warning"},
    # a real autopilot button: the bottom lamp is the engaged state, the top lamp the disconnect annunciator
    "sim/autopilot/servos_toggle": {
        "top": {"dataref": "sim/cockpit2/annunciators/autopilot_disconnect",
                "states": [{"eq": 0, "name": "off", "label": "DESC"}, {"ne": 0, "name": "warn", "label": "DESC"}]},
        "bottom": {"dataref": "sim/cockpit2/autopilot/servos_on",
                   "states": [{"eq": 0, "name": "off", "label": "OFF"}, {"ne": 0, "name": "on", "label": "ON"}]}},
}


def suggest(command: str) -> dict | None:
    """The state block for a command when the curated table knows it, else None (the user can set one by hand)."""
    if command in SPECS:
        return copy.deepcopy(SPECS[command])
    hit = EXACT.get(command)
    if hit is None:
        base = command
        for suf in _SUFFIXES:
            if command.endswith(suf):
                base = command[: -len(suf)]
                break
        hit = BASES.get(base)
    if hit is None:
        return None
    dataref, index, template = hit
    state = {"dataref": dataref, "template": template}
    if index is not None:
        state["index"] = index
    return state
