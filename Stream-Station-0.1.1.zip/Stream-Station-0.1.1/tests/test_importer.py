import os, sys, pathlib, tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import yaml
from PIL import Image
from streamstation import importer, profiles

OLD = {
    "name": "General",
    "keys": {
        "0": {"icon": "icons/user/fake.png", "action": "gtk-launch fakeapp"},
        "1": {"icon": "icons/lock.png", "action": "loginctl lock-session"},
        "2": {"icon": "icons/media_play.png", "action": "playerctl play-pause"},
        "3": {"icon": "icons/dashboard.png", "action": "dashboard"},
        "4": {"icon": "icons/x.png", "action": "/opt/fake/run"},
        "5": {"icon": "icons/layers.png", "layer_toggle": "media"},
        "6": {"label": "Mis notas", "action": "kate ~/notas.txt"},
    },
    "knobs": {
        "0": {"rotate": {"cw": "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%+", "ccw": "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"},
              "press": "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"},
        "1": {"rotate": {"cw": "playerctl volume 0.05+", "ccw": "playerctl volume 0.05-"}, "press": "playerctl play-pause"},
    },
    "layers": {"media": {"keys": {"0": {"icon": "icons/media_next.png", "action": "playerctl next"}}}},
    "strip": {"dashboard": ["clock", "cpu"]},
}


def _env(tmp):
    from PySide6.QtWidgets import QApplication
    from streamstation.ui import apps
    QApplication.instance() or QApplication([])
    cfg = os.path.join(tmp, "cfg")
    profiles.CONFIG = cfg
    profiles.search_dirs = lambda sub: [os.path.join(cfg, sub)] if os.path.isdir(os.path.join(cfg, sub)) else []
    icon = os.path.join(tmp, "fake-icon.png"); Image.new("RGB", (64, 64), (200, 30, 30)).save(icon)
    ad = os.path.join(tmp, "apps"); os.makedirs(ad)
    open(os.path.join(ad, "fakeapp.desktop"), "w").write(f"[Desktop Entry]\nType=Application\nName=Fake\nExec=/opt/fake/run %U\nIcon={icon}\n")
    apps.desktop_dirs = lambda: [ad]
    old = os.path.join(tmp, "old", "profiles"); os.makedirs(old)
    yaml.safe_dump(OLD, open(os.path.join(old, "General.yaml"), "w"))
    return cfg, os.path.join(tmp, "old")


def test_action_translation_table_only_rewrites_known_commands():
    t = importer.translate_action
    assert t("playerctl play-pause") == "media:play-pause" and t("playerctl previous") == "media:prev"
    assert t("wpctl set-volume @DEFAULT_AUDIO_SINK@ 10%+") == "volume:up:10"
    assert t("wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%-") == "volume:down:5"
    assert t("wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle") == "volume:mute"
    assert t("loginctl lock-session") == "lock" and t("gtk-launch firefox") == "open:firefox"
    assert t("playerctl volume 0.05+") == "media:volume-up:5" and t("playerctl volume 0.1-") == "media:volume-down:10"
    for keep in ("kate ~/notas.txt", "brightnessctl set 5%+", "layer:media", None, {"x": 1}):
        assert t(keep) == keep


def test_import_translates_actions_rebuilds_every_icon_and_copies_no_old_art():
    with tempfile.TemporaryDirectory() as tmp:
        cfg, old = _env(tmp)
        lines = []
        assert importer.import_profiles(old, out=lines.append) == ["General"]
        new = yaml.safe_load(open(os.path.join(cfg, "profiles", "General.yaml")))
        k = new["keys"]
        assert k["0"]["action"] == "open:fakeapp" and k["1"]["action"] == "lock" and k["2"]["action"] == "media:play-pause"
        assert k["6"]["action"] == "kate ~/notas.txt" and new["knobs"]["0"]["rotate"]["cw"] == "volume:up:5"
        assert new["knobs"]["0"]["press"] == "volume:mute" and new["knobs"]["1"]["rotate"]["cw"] == "media:volume-up:5"
        assert new["layers"]["media"]["keys"]["0"]["action"] == "media:next"
        assert new["strip"] == {"dashboard": ["clock", "cpu"]}                              # untouched data survives
        old_names = {"icons/user/fake.png", "icons/lock.png", "icons/media_play.png", "icons/dashboard.png", "icons/x.png",
                     "icons/layers.png", "icons/media_next.png"}
        icons = [e["icon"] for e in list(k.values()) + [new["layers"]["media"]["keys"]["0"]]]
        assert not old_names & set(icons) and all(i.startswith("icons/user/") for i in icons)
        assert all(os.path.isfile(os.path.join(cfg, "assets", i)) for i in icons)             # every icon was generated here
        tile = Image.open(os.path.join(cfg, "assets", k["0"]["icon"])).convert("RGB")
        assert tile.getpixel((64, 64))[0] > 150 and tile.getpixel((64, 64))[2] < 90           # the app's own (red) icon
        assert k["4"]["icon"] != k["6"]["icon"]
        files = [f for _, _, fs in os.walk(os.path.join(cfg, "assets")) for f in fs]
        assert len(files) == len(set(icons))                                                  # nothing else was copied
        assert any("perilla 2" in l and "media:volume-up:5" in l for l in lines) and any("importado General" in l for l in lines)


def test_import_backs_up_an_existing_profile_and_refuses_a_missing_folder():
    with tempfile.TemporaryDirectory() as tmp:
        cfg, old = _env(tmp)
        os.makedirs(os.path.join(cfg, "profiles"))
        open(os.path.join(cfg, "profiles", "General.yaml"), "w").write("name: General\nkeys: {}\n")
        importer.import_profiles(old, out=lambda l: None)
        assert open(os.path.join(cfg, "profiles", "General.yaml.bak")).read() == "name: General\nkeys: {}\n"
        try: importer.import_profiles(os.path.join(tmp, "nada"))
        except FileNotFoundError: pass
        else: raise AssertionError("missing folder must be reported")


def test_rebuild_icons_in_place_and_prune_only_unreferenced_assets():
    with tempfile.TemporaryDirectory() as tmp:
        cfg, old = _env(tmp)
        importer.import_profiles(old, out=lambda l: None)
        base = os.path.join(cfg, "assets")
        os.makedirs(os.path.join(base, "icons"), exist_ok=True); os.makedirs(os.path.join(base, "gifs"), exist_ok=True)
        for rel in ("icons/leftover.png", "gifs/leftover.gif"):
            open(os.path.join(base, rel), "wb").write(b"x")
        before = set(importer.referenced_assets())
        assert importer.rebuild_icons(["General"], out=lambda l: None) == ["General"]
        assert os.path.isfile(os.path.join(cfg, "profiles", "General.yaml.bak"))
        assert set(importer.referenced_assets()) == before                                     # deterministic: same files again
        listed = importer.prune_assets(apply=False, out=lambda l: None)
        assert sorted(listed) == ["gifs/leftover.gif", "icons/leftover.png"] and os.path.isfile(os.path.join(base, "icons/leftover.png"))
        importer.prune_assets(apply=True, out=lambda l: None)
        assert not os.path.exists(os.path.join(base, "icons/leftover.png")) and not os.path.exists(os.path.join(base, "gifs"))
        assert all(os.path.isfile(os.path.join(base, r)) for r in before if not os.path.isabs(r))   # referenced ones kept


def test_no_runtime_path_points_at_the_old_installation():
    import inspect
    from streamstation import profiles as pr
    src = inspect.getsource(pr)
    assert "ragnaros" not in src.lower() and not hasattr(pr, "LEGACY")


def test_rebuilding_icons_keeps_the_glyph_of_x_plane_keys_and_uses_no_text():
    from streamstation import importer
    from streamstation.ui import icons
    from PIL import ImageChops
    lib = icons.IconLibrary(root="/nonexistent")
    e = {"label": "AP", "action": "xp:cmd:sim/autopilot/servos_toggle", "xp": {"glyph": "autopilot"}}
    img = importer.icon_for(e, lib, [], {})
    from streamstation.xplane import glyphs
    assert ImageChops.difference(img.convert("RGB"), glyphs.neutral_tile("autopilot").convert("RGB")).getbbox() is None
    plain = importer.icon_for({"label": "algo", "action": "echo x"}, lib, [], {})
    assert ImageChops.difference(plain.convert("RGB"), icons.fallback_tile("", "lilac").convert("RGB")).getbbox() is None


def test_rebuilt_open_keys_get_an_app_file_or_folder_icon_never_the_wrong_one():
    import tempfile
    from streamstation import importer
    from streamstation.ui import icons
    from PIL import ImageChops
    lib = icons.IconLibrary(root="/nonexistent")
    same = lambda a, b: ImageChops.difference(a.convert("RGB"), b.convert("RGB")).getbbox() is None
    with tempfile.TemporaryDirectory() as tmp:
        f = os.path.join(tmp, "a.txt"); open(f, "w").write("x")
        assert same(importer.icon_for({"action": f"open:{tmp}"}, lib, [], {}), icons.fallback_tile("", "lilac", "folder"))
        assert same(importer.icon_for({"action": f"open:{f}"}, lib, [], {}), icons.fallback_tile("", "lilac", "file"))
        assert same(importer.icon_for({"action": "open:noexiste"}, lib, [], {}), icons.fallback_tile("", "lilac", "app"))
        from streamstation.ui import actionicons
        assert same(importer.icon_for({"action": "text:hola"}, lib, [], {}), actionicons.tile("text", "Herramientas"))
        assert same(importer.icon_for({"action": "volume:up:5"}, lib, [], {}), actionicons.tile("vol_up", "Audio"))
