"""The program's own key icons: simple shapes drawn by code, no text and no borrowed artwork.

Every icon is one bold white shape on a 100x100 design grid. `glyph(name)` returns it on a transparent
background; `tile(name, category)` puts it, in near-black, on the pastel gradient used for every key
(the "unified" recipe of icons.py), at 128x128 -- the size the deck shows.

`name_for(action, plugin)` maps an action string of the catalog (or any action) to the icon that says what it does.
"""
from __future__ import annotations

import math

from PIL import Image, ImageDraw

SS = 4            # supersampling
G = 100           # design grid
W = (255, 255, 255, 255)
CUT = (0, 0, 0, 0)


class _P:
    """Tiny drawing helper in grid units."""

    def __init__(self, size: int):
        self.img = Image.new("RGBA", (size * SS, size * SS), CUT)
        self.d = ImageDraw.Draw(self.img)
        self.k = size * SS / G

    def _w(self, v):
        return max(1, round(v * self.k))

    def line(self, pts, w=8, c=W):
        k = self.k
        self.d.line([(x * k, y * k) for x, y in pts], fill=c, width=self._w(w), joint="curve")
        for x, y in (pts[0], pts[-1]):
            self.d.ellipse([(x - w / 2) * k, (y - w / 2) * k, (x + w / 2) * k, (y + w / 2) * k], fill=c)

    def rect(self, box, r=6, fill=None, outline=None, w=7, c=W):
        k = self.k
        x0, y0, x1, y1 = box
        self.d.rounded_rectangle([x0 * k, y0 * k, x1 * k, y1 * k], radius=r * k,
                                 fill=(c if fill is True else fill), outline=(c if outline else None), width=self._w(w))

    def circ(self, cx, cy, r, fill=None, outline=None, w=7, c=W):
        k = self.k
        self.d.ellipse([(cx - r) * k, (cy - r) * k, (cx + r) * k, (cy + r) * k],
                       fill=(c if fill is True else fill), outline=(c if outline else None), width=self._w(w))

    def ell(self, box, outline=True, w=6, c=W):
        k = self.k
        x0, y0, x1, y1 = box
        self.d.ellipse([x0 * k, y0 * k, x1 * k, y1 * k], outline=c, width=self._w(w))

    def poly(self, pts, c=W):
        self.d.polygon([(x * self.k, y * self.k) for x, y in pts], fill=c)

    def arc(self, box, a0, a1, w=8, c=W):
        k = self.k
        x0, y0, x1, y1 = box
        self.d.arc([x0 * k, y0 * k, x1 * k, y1 * k], a0, a1, fill=c, width=self._w(w))

    def head(self, tip, ang, size=18, c=W):
        """Arrow head with its tip at `tip`, pointing in direction `ang` (degrees, 0 = right)."""
        a = math.radians(ang)
        x, y = tip
        b = [(x - size * math.cos(a) + s * size * 0.62 * math.sin(a), y - size * math.sin(a) - s * size * 0.62 * math.cos(a)) for s in (1, -1)]
        self.poly([tip, b[0], b[1]], c)

    def done(self, size: int) -> Image.Image:
        return self.img.resize((size, size), Image.LANCZOS)


# --- the glyphs ---------------------------------------------------------------------------------------------
def _sun(p, sign):
    p.circ(50, 50, 21, fill=True)
    for i in range(8):
        a = math.radians(i * 45)
        p.line([(50 + 32 * math.cos(a), 50 + 32 * math.sin(a)), (50 + 44 * math.cos(a), 50 + 44 * math.sin(a))], w=7)
    p.line([(40, 50), (60, 50)], w=7, c=CUT)
    if sign > 0:
        p.line([(50, 40), (50, 60)], w=7, c=CUT)


def _monitor(p, box=(10, 16, 90, 66), stand=True):
    p.rect(box, r=7, outline=True, w=7)
    if stand:
        p.line([(50, box[3] + 2), (50, box[3] + 14)], w=7)
        p.line([(32, box[3] + 15), (68, box[3] + 15)], w=7)


def _screen_off(p):
    _monitor(p)
    p.arc((36, 29, 64, 57), -50, 230, w=6)
    p.line([(50, 25), (50, 43)], w=6)


def _page(p, x=12, shift=0):
    p.rect((x, 14, x + 44, 86), r=7, outline=True, w=7)
    p.line([(x + 12, 36), (x + 32, 36)], w=6)
    p.line([(x + 12, 52), (x + 32, 52)], w=6)


def _page_next(p):
    _page(p, 10)
    p.line([(58, 50), (84, 50)], w=9)
    p.head((94, 50), 0, 22)


def _page_goto(p):
    p.rect((20, 10, 80, 90), r=8, outline=True, w=7)
    p.poly([(52, 10), (70, 10), (70, 44), (61, 36), (52, 44)])
    p.line([(32, 62), (68, 62)], w=7)
    p.line([(32, 76), (56, 76)], w=7)


def _person(p, cx, top, s=1.0, fill=True):
    p.circ(cx, top + 14 * s, 13 * s, fill=True)
    p.arc((cx - 28 * s, top + 34 * s, cx + 28 * s, top + 34 * s + 56 * s), 180, 360, w=11 * s)
    p.rect((cx - 28 * s, top + 62 * s, cx + 28 * s, top + 70 * s), r=2, fill=True)


def _profile(p):
    p.circ(66, 28, 11, fill=True)
    p.arc((40, 44, 92, 96), 180, 360, w=10)
    p.circ(36, 34, 15, fill=True)
    p.arc((6, 54, 66, 114), 180, 360, w=11)
    p.rect((6, 84, 66, 92), r=2, fill=True)


def _globe(p):
    p.circ(50, 50, 40, outline=True, w=7)
    p.ell((32, 10, 68, 90), w=6)
    p.line([(10, 50), (90, 50)], w=6)
    p.line([(18, 28), (82, 28)], w=5)
    p.line([(18, 72), (82, 72)], w=5)


def _keyboard(p):
    p.rect((6, 26, 94, 76), r=9, outline=True, w=7)
    for row, y in enumerate((38, 50)):
        for i in range(5):
            p.rect((16 + i * 15, y, 24 + i * 15, y + 6), r=2, fill=True)
    p.rect((26, 62, 74, 68), r=3, fill=True)


def _text(p):
    p.line([(14, 28), (86, 28)], w=9)
    p.line([(14, 50), (62, 50)], w=9)
    p.line([(14, 72), (76, 72)], w=9)


def _folder(p):
    p.poly([(8, 28), (8, 22), (38, 22), (46, 32), (46, 28)])
    p.rect((8, 30, 92, 82), r=8, fill=True)
    p.rect((16, 44, 84, 74), r=4, fill=CUT)
    p.rect((16, 44, 84, 74), r=4, outline=True, w=0)


def _terminal(p):
    p.rect((8, 16, 92, 84), r=9, outline=True, w=7)
    p.line([(26, 38), (42, 50), (26, 62)], w=8)
    p.line([(50, 64), (72, 64)], w=8)


def _speaker(p, dx=0):
    p.rect((8 + dx, 38, 24 + dx, 62), r=3, fill=True)
    p.poly([(24 + dx, 38), (48 + dx, 18), (48 + dx, 82), (24 + dx, 62)])


def _vol(p, waves):
    _speaker(p, 0)
    for i in range(waves):
        r = 20 + i * 18
        p.arc((48 - r, 50 - r, 48 + r, 50 + r), -42, 42, w=8)


def _mute(p):
    _speaker(p)
    p.line([(62, 38), (88, 62)], w=8)
    p.line([(88, 38), (62, 62)], w=8)


def _mic(p):
    p.rect((36, 8, 64, 56), r=14, fill=True)
    p.arc((24, 30, 76, 76), 0, 180, w=7)
    p.line([(50, 76), (50, 90)], w=7)
    p.line([(34, 90), (66, 90)], w=7)


def _play_pause(p):
    p.poly([(8, 18), (8, 82), (50, 50)])
    p.rect((60, 20, 72, 80), r=3, fill=True)
    p.rect((80, 20, 92, 80), r=3, fill=True)


def _next(p):
    p.poly([(12, 18), (12, 82), (64, 50)])
    p.rect((72, 18, 88, 82), r=3, fill=True)


def _sound(p, kind):
    _speaker(p, -4)
    if kind == "play":
        p.poly([(58, 32), (58, 68), (90, 50)])
    else:
        p.rect((60, 34, 86, 66), r=4, fill=True)


def _toggle(p):
    p.rect((8, 28, 92, 72), r=22, outline=True, w=7)
    p.circ(68, 50, 14, fill=True)


def _dice(p):
    p.rect((12, 12, 88, 88), r=16, outline=True, w=7)
    for x, y in ((32, 32), (68, 32), (50, 50), (32, 68), (68, 68)):
        p.circ(x, y, 6.5, fill=True)


def _steps(p):
    for i, y in enumerate((24, 50, 76)):
        p.circ(20, y, 8, fill=True)
        p.line([(38, y), (88 - i * 10, y)], w=9)
    p.line([(20, 30), (20, 44)], w=5)
    p.line([(20, 56), (20, 70)], w=5)


def _lock(p):
    p.arc((26, 8, 74, 62), 180, 360, w=9)
    p.line([(30, 36), (30, 48)], w=9)
    p.line([(70, 36), (70, 48)], w=9)
    p.rect((16, 44, 84, 90), r=9, fill=True)
    p.circ(50, 63, 7, fill=CUT)
    p.rect((46.5, 63, 53.5, 78), r=3, fill=CUT)


def _moon(p):
    p.circ(46, 52, 36, fill=True)
    p.circ(66, 40, 31, fill=CUT)
    p.circ(80, 22, 4, fill=True)
    p.circ(90, 44, 3, fill=True)


def _sliders(p):
    for y, x in ((26, 34), (50, 66), (74, 44)):
        p.line([(10, y), (90, y)], w=7)
        p.circ(x, y, 11, fill=True)
        p.circ(x, y, 5, fill=CUT)


def _desktop(p):
    _monitor(p, (8, 14, 92, 68), stand=False)
    p.rect((16, 22, 48, 44), r=3, fill=True)
    p.rect((16, 52, 84, 58), r=2, fill=True)
    p.line([(30, 86), (70, 86)], w=7)


def _overview(p):
    for x, y in ((10, 10), (54, 10), (10, 54), (54, 54)):
        p.rect((x, y, x + 36, y + 36), r=8, fill=True)


def _search(p):
    p.circ(42, 42, 28, outline=True, w=9)
    p.line([(63, 63), (88, 88)], w=12)


def _emoji(p):
    p.circ(50, 50, 40, outline=True, w=7)
    p.circ(36, 40, 6, fill=True)
    p.circ(64, 40, 6, fill=True)
    p.arc((28, 34, 72, 74), 20, 160, w=7)


def _bell_off(p):
    p.circ(50, 38, 24, fill=True)
    p.poly([(26, 40), (74, 40), (82, 70), (18, 70)])
    p.rect((12, 66, 88, 78), r=6, fill=True)
    p.circ(50, 86, 8, fill=True)
    p.line([(14, 12), (86, 88)], w=15, c=CUT)
    p.line([(14, 12), (86, 88)], w=8)


def _two_screens(p):
    p.rect((6, 48, 46, 80), r=5, outline=True, w=6)
    p.rect((54, 48, 94, 80), r=5, outline=True, w=6)
    p.line([(20, 88), (32, 88)], w=6)
    p.line([(68, 88), (80, 88)], w=6)
    p.line([(20, 28), (70, 28)], w=7)
    p.head((88, 28), 0, 22)


def _pulse(p):
    p.rect((8, 14, 92, 86), r=9, outline=True, w=7)
    p.line([(18, 54), (34, 54), (42, 34), (54, 70), (62, 48), (82, 48)], w=7)


def _gear(p):
    for i in range(8):
        a = i * 45
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        pts = [(50 + 30 * c - 8 * s, 50 + 30 * s + 8 * c), (50 + 44 * c - 7 * s, 50 + 44 * s + 7 * c),
               (50 + 44 * c + 7 * s, 50 + 44 * s - 7 * c), (50 + 30 * c + 8 * s, 50 + 30 * s - 8 * c)]
        p.poly(pts)
    p.circ(50, 50, 33, fill=True)
    p.circ(50, 50, 14, fill=CUT)


def _calculator(p):
    p.rect((16, 8, 84, 92), r=10, outline=True, w=7)
    p.rect((26, 18, 74, 36), r=3, fill=True)
    for r_ in range(3):
        for c_ in range(3):
            p.circ(34 + c_ * 16, 52 + r_ * 14, 4.5, fill=True)


def _mail(p):
    p.rect((8, 22, 92, 78), r=9, outline=True, w=7)
    p.line([(14, 30), (50, 56), (86, 30)], w=7)


def _arrow(p, direction):
    p.line([(18, 50), (80, 50)], w=10)
    p.head((8, 50), 180, 28)


def _refresh(p):
    p.arc((14, 14, 86, 86), 40, 330, w=10)
    ex, ey = 50 + 36 * math.cos(math.radians(330)), 50 + 36 * math.sin(math.radians(330))
    p.head((ex + 8, ey + 14), 60, 26)


def _star(p):
    pts = []
    for i in range(10):
        r = 44 if i % 2 == 0 else 19
        a = math.radians(-90 + i * 36)
        pts.append((50 + r * math.cos(a), 54 + r * math.sin(a)))
    p.poly(pts)


def _send(p):
    p.poly([(8, 46), (92, 12), (62, 88), (46, 58)])
    p.line([(46, 58), (92, 12)], w=5, c=CUT)


def _file(p):
    p.poly([(18, 8), (60, 8), (82, 30), (82, 92), (18, 92)])
    p.poly([(60, 8), (60, 30), (82, 30)], c=CUT)
    p.line([(32, 54), (68, 54)], w=6, c=CUT)
    p.line([(32, 70), (68, 70)], w=6, c=CUT)


def _app(p):
    p.rect((8, 14, 92, 86), r=9, outline=True, w=7)
    p.line([(8, 34), (92, 34)], w=7)
    p.circ(22, 24, 3.5, fill=True)
    p.circ(34, 24, 3.5, fill=True)


def _layers(p):
    p.poly([(50, 10), (92, 34), (50, 58), (8, 34)])
    p.line([(8, 52), (50, 76), (92, 52)], w=8)
    p.line([(8, 70), (50, 94), (92, 70)], w=8)


def _bolt(p):
    p.poly([(56, 6), (20, 56), (46, 56), (38, 94), (80, 40), (54, 40)])


# --- service pictograms (original drawings; no logos) ---------------------------------------------------------
def _svc_youtube(p):
    p.rect((6, 22, 94, 78), r=20, fill=True)
    p.poly([(41, 36), (41, 64), (66, 50)], CUT)


def _svc_ytmusic(p):
    p.circ(50, 50, 42, outline=True, w=7)
    p.circ(50, 50, 33, fill=True)
    p.poly([(42, 36), (42, 64), (66, 50)], CUT)


def _svc_spotify(p):
    p.circ(50, 50, 42, fill=True)
    for dy, half, w in ((-13, 26, 8), (2, 21, 7), (16, 15, 6)):
        p.arc((50 - half - 6, 52 + dy - half, 50 + half + 6, 52 + dy + half + 20), 205, 335, w=w, c=CUT)


def _svc_twitch(p):
    p.poly([(14, 6), (90, 6), (90, 58), (70, 78), (52, 78), (38, 92), (38, 78), (14, 78)])
    p.rect((38, 22, 46, 46), r=2, fill=CUT)
    p.rect((62, 22, 70, 46), r=2, fill=CUT)


def _svc_discord(p):
    # a game controller: voice-and-gaming, not the brand's mascot
    p.poly([(8, 64), (14, 38), (28, 28), (72, 28), (86, 38), (92, 64), (84, 76), (70, 70), (60, 60), (40, 60), (30, 70), (16, 76)])
    p.line([(28, 44), (28, 58)], w=7, c=CUT)
    p.line([(21, 51), (35, 51)], w=7, c=CUT)
    p.circ(66, 44, 4.5, fill=CUT)
    p.circ(76, 54, 4.5, fill=CUT)

def _svc_whatsapp(p):
    p.circ(50, 48, 40, outline=True, w=8)
    p.poly([(10, 94), (18, 64), (34, 80)])
    p.line([(36, 32), (34, 40), (46, 58), (60, 66), (68, 64)], w=10)

def _svc_telegram(p):
    p.circ(50, 50, 42, fill=True)
    p.poly([(20, 48), (78, 26), (66, 74), (50, 60)], CUT)
    p.line([(50, 60), (78, 26)], w=4, c=W)


def _svc_gmail(p):
    p.rect((6, 20, 94, 80), r=8, outline=True, w=8)
    p.line([(22, 66), (22, 34), (50, 56), (78, 34), (78, 66)], w=9)

def _svc_calendar(p):
    p.rect((10, 16, 90, 90), r=10, outline=True, w=8)
    p.rect((10, 16, 90, 38), r=6, fill=True)
    p.line([(30, 6), (30, 24)], w=8)
    p.line([(70, 6), (70, 24)], w=8)
    for r_ in range(2):
        for c_ in range(3):
            p.rect((22 + c_ * 20, 48 + r_ * 18, 32 + c_ * 20, 58 + r_ * 18), r=2, fill=True)


def _svc_drive(p):
    p.line([(50, 14), (10, 82)], w=14)
    p.line([(50, 14), (90, 82)], w=14)
    p.line([(10, 82), (90, 82)], w=14)
    p.line([(30, 52), (70, 52)], w=6, c=CUT)

def _svc_maps(p):
    p.circ(50, 38, 30, fill=True)
    p.poly([(26, 52), (74, 52), (50, 94)])
    p.circ(50, 38, 12, fill=CUT)


def _svc_github(p):
    for x, y in ((26, 20), (26, 80), (72, 40)):
        p.circ(x, y, 12, outline=True, w=8)
    p.line([(26, 32), (26, 68)], w=8)
    p.line([(72, 52), (72, 56), (60, 62), (26, 68)], w=8)


GLYPHS = {
    "sun_plus": lambda p: _sun(p, 1), "sun_minus": lambda p: _sun(p, -1), "screen_off": _screen_off,
    "page_next": _page_next, "page_prev": lambda p: _flip(_page_next, p), "page_goto": _page_goto,
    "profile": _profile, "globe": _globe, "keyboard": _keyboard, "text": _text, "folder": _folder, "terminal": _terminal,
    "vol_up": lambda p: _vol(p, 2), "vol_down": lambda p: _vol(p, 1), "vol_mute": _mute, "mic": _mic,
    "play_pause": _play_pause, "next": _next, "prev": lambda p: _flip(_next, p),
    "sound_play": lambda p: _sound(p, "play"), "sound_stop": lambda p: _sound(p, "stop"),
    "toggle": _toggle, "dice": _dice, "steps": _steps, "lock": _lock, "moon": _moon, "sliders": _sliders,
    "desktop": _desktop, "overview": _overview, "search": _search, "emoji": _emoji, "bell_off": _bell_off,
    "two_screens": _two_screens, "pulse": _pulse, "gear": _gear, "calculator": _calculator, "mail": _mail,
    "arrow_left": lambda p: _arrow(p, "left"), "arrow_right": lambda p: _flip(lambda q: _arrow(q, "left"), p),
    "refresh": _refresh, "star": _star, "send": _send, "file": _file, "app": _app, "layers": _layers, "bolt": _bolt,
    "svc_youtube": _svc_youtube, "svc_youtube-music": _svc_ytmusic, "svc_spotify": _svc_spotify, "svc_twitch": _svc_twitch,
    "svc_discord": _svc_discord, "svc_whatsapp": _svc_whatsapp, "svc_telegram": _svc_telegram, "svc_gmail": _svc_gmail,
    "svc_calendar": _svc_calendar, "svc_drive": _svc_drive, "svc_maps": _svc_maps, "svc_github": _svc_github,
}


def _flip(fn, p):
    """Draw `fn` mirrored left-right."""
    q = _P(p.img.width // SS)
    fn(q)
    p.img.paste(q.img.transpose(Image.FLIP_LEFT_RIGHT), (0, 0))


def glyph(name: str, size: int = 128, color=W, style: str | None = None) -> Image.Image:
    """The icon as a white-on-transparent RGBA picture (tint it with `color`). The Industrial style has its own,
    separately drawn set of pictograms; every other style shares the rounded one."""
    p = _P(size)
    if (style or current_style()) == "industrial":
        from . import industrial
        industrial.GLYPHS.get(name, industrial.bolt)(p)
    else:
        GLYPHS.get(name, _bolt)(p)
    img = p.done(size)
    if color != W:
        solid = Image.new("RGBA", img.size, color)
        solid.putalpha(img.getchannel("A"))
        return solid
    return img


# --- which icon says what an action does ---------------------------------------------------------------------
BY_ACTION = {
    "brightness+": "sun_plus", "brightness-": "sun_minus", "screen-off": "screen_off", "page:next": "page_next",
    "page:prev": "page_prev", "scene:next": "page_next", "scene:prev": "page_prev", "lock": "lock", "suspend": "moon", "volume:up": "vol_up", "volume:down": "vol_down",
    "volume:mute": "vol_mute", "mic:mute": "mic", "media:play-pause": "play_pause", "media:next": "next",
    "media:prev": "prev", "sound:stop": "sound_stop", "{toggle}": "toggle", "{random}": "dice", "{sequence}": "steps",
    "desktop:show": "desktop", "desktop:overview": "overview", "desktop:search": "search", "desktop:emoji": "emoji",
    "desktop:dnd": "bell_off", "desktop:switch-screen": "two_screens", "tool:taskmanager": "pulse",
    "tool:controlpanel": "gear", "tool:calculator": "calculator", "tool:mail": "mail", "browser:back": "arrow_left",
    "browser:forward": "arrow_right", "browser:refresh": "refresh", "browser:collect": "star",
}
BY_PREFIX = (("brightness+", "sun_plus"), ("brightness-", "sun_minus"), ("page:", "page_goto"), ("profile:", "profile"),
             ("layer:", "layers"), ("url:", "globe"), ("key:", "keyboard"), ("text:", "text"), ("sound:play", "sound_play"),
             ("udp:", "send"), ("volume:", "vol_up"), ("media:", "play_pause"), ("desktop:", "desktop"),
             ("tool:", "gear"), ("browser:", "globe"), ("open:", "folder"), ("xp:", "bolt"))


def name_for(action: str | None) -> str | None:   # noqa: C901
    """The icon for an action string, or None when nothing fits (the caller then shows the generic command icon)."""
    if not action:
        return None
    if action in BY_ACTION:
        return BY_ACTION[action]
    if action.endswith("streamstation ui"):
        return "sliders"
    if action.startswith("service:"):
        name = "svc_" + action[8:]
        return name if name in GLYPHS else "globe"
    for prefix, name in BY_PREFIX:
        if name and action.startswith(prefix):
            return name
    return None


# --- icon styles --------------------------------------------------------------------------------------------
STYLES = {
    "pastel": "Pastel: fondo de color, icono negro",
    "neon": "Neón: fondo negro, icono luminoso",
    "line": "Contorno: fondo negro, cristal de color",
    "miami": "Miami 80s: atardecer, rosa y turquesa",
    "industrial": "Industrial: chapa de acero, señalética de planta",
}
# Miami: (top, bottom) of the sunset gradient and the colour of the icon's offset shadow, per category
MIAMI = {
    "Dispositivo": ("#2a0a5e", "#ff5fa8", "#00f0e0"), "Herramientas": ("#3a0f6e", "#ff3d8e", "#00e5ff"),
    "Audio": ("#0b2a6b", "#00d9c0", "#ff4fa3"), "Flujo de operación": ("#431a78", "#ff7a59", "#00f0e0"),
    "Sistema": ("#4a0a4f", "#ff2e63", "#ffe14d"), "Escritorio (KDE)": ("#1a1a6e", "#b44cff", "#00f0e0"),
    "Navegador": ("#0a3a7a", "#37e6e0", "#ff5fa8"), "Red": ("#5a1450", "#ff9a4d", "#00e5ff"),
    "Aplicaciones": ("#2a0a5e", "#ff5fa8", "#00f0e0"), "Servicios": ("#2a0a5e", "#ff5fa8", "#00f0e0"),
}
# one bright colour per category (the pastel style has its own palette in icons.py)
NEON = {
    "Aplicaciones": "#8f9bff",
    "Dispositivo": "#ffb84d", "Herramientas": "#b48cff", "Audio": "#3de8ff", "Flujo de operación": "#4dffb0",
    "Sistema": "#ff4d7a", "Escritorio (KDE)": "#5c8cff", "Navegador": "#4dd2ff", "Red": "#ff8a4d", "Servicios": "#ff6bd6",
}
BLACK = (8, 8, 12, 255)

_style_cache: dict = {"stamp": None, "value": "pastel"}


def current_style() -> str:
    """The icon style chosen in the settings (cached by the config file's modification time)."""
    import os
    from .. import profiles
    try:
        stamp = os.stat(os.path.join(profiles.CONFIG, "config.yaml")).st_mtime_ns
    except OSError:
        stamp = None
    if _style_cache["stamp"] != stamp or _style_cache.get("config") != profiles.CONFIG:
        value = str(profiles.load_settings().get("icon_style") or "pastel")
        _style_cache.update(stamp=stamp, config=profiles.CONFIG, value=value if value in STYLES else "pastel")
    return _style_cache["value"]


def _fit(g: Image.Image, size: int, fill: float) -> Image.Image:
    """The glyph's alpha cropped to its bounds and scaled to `fill` of the tile, centred on a transparent canvas."""
    alpha = g.convert("RGBA").getchannel("A")
    bbox = alpha.getbbox()
    out = Image.new("L", (size, size), 0)
    if bbox:
        a = alpha.crop(bbox)
        k = size * fill / max(a.size)
        a = a.resize((max(1, round(a.width * k)), max(1, round(a.height * k))), Image.LANCZOS)
        out.paste(a, ((size - a.width) // 2, (size - a.height) // 2))
    return out


def _glow(mask: Image.Image, color: str, size: int) -> Image.Image:
    """`mask` painted in `color` with a soft halo, on a plain black tile."""
    from PIL import ImageFilter
    from .icons import _hex
    rgb = _hex(color)
    tile = Image.new("RGBA", (size, size), BLACK)
    halo = mask.filter(ImageFilter.GaussianBlur(size * 0.045)).point(lambda v: min(255, int(v * 1.1)))
    tile.paste(Image.new("RGBA", (size, size), rgb + (255,)), (0, 0), halo.point(lambda v: int(v * 0.85)))
    tile.paste(Image.new("RGBA", (size, size), rgb + (255,)), (0, 0), mask)
    return tile                                              # just the icon on black: no frame around the key


GRAPHITE_TOP, GRAPHITE_BOTTOM = (52, 55, 60), (30, 32, 36)
WARM_WHITE = (238, 234, 224)
SAFETY_ORANGE = (255, 106, 0)


def _plate(size: int) -> Image.Image:
    """Matte graphite plate: a soft light from the top left and a small orange tag at the bottom. No frame or border lines."""
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        t = y / (size - 1)
        for x in range(size):
            dist = math.hypot(x - size * 0.28, y - size * 0.22) / size                 # a gentle highlight, top left
            lift = max(0.0, 1 - dist * 1.7) * 22
            px[x, y] = tuple(max(0, min(255, round(GRAPHITE_TOP[i] + (GRAPHITE_BOTTOM[i] - GRAPHITE_TOP[i]) * t + lift)))
                             for i in range(3)) + (255,)
    d = ImageDraw.Draw(img)
    tw, th = size * 0.2, max(2, size // 36)
    d.rectangle([(size - tw) / 2, size - size * 0.085 - th, (size + tw) / 2, size - size * 0.085], fill=SAFETY_ORANGE + (255,))
    return img


def _fit_rgba(g: Image.Image, size: int, fill: float) -> Image.Image:
    g = g.convert("RGBA")
    bbox = g.getchannel("A").getbbox()
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    if bbox:
        c = g.crop(bbox)
        k = size * fill / max(c.size)
        c = c.resize((max(1, round(c.width * k)), max(1, round(c.height * k))), Image.LANCZOS)
        out.paste(c, ((size - c.width) // 2, (size - c.height) // 2 - int(size * 0.02)), c)
    return out


def _industrial(g: Image.Image, category: str, size: int) -> Image.Image:
    """The pictogram on the plate: white parts become warm white, orange parts stay safety orange, with a hard shadow."""
    img = _plate(size)
    fitted = _fit_rgba(g, size, 0.64)
    alpha = fitted.getchannel("A")
    blue = fitted.getchannel("B")                                   # 255 on the white parts, ~0 on the orange ones
    colour = Image.merge("RGB", tuple(
        Image.eval(blue, lambda v, a=SAFETY_ORANGE[i], w=WARM_WHITE[i]: round(a + (w - a) * v / 255)) for i in range(3)))
    off = max(1, size // 56)
    shadow = Image.new("L", (size, size), 0)
    shadow.paste(alpha, (off, off))
    img.paste(Image.new("RGBA", (size, size), (8, 9, 11, 255)), (0, 0), shadow.point(lambda v: int(v * 0.75)))
    img.paste(colour.convert("RGBA"), (0, 0), alpha)
    return img


def ImageChops_offset(m: Image.Image, dx: int, dy: int) -> Image.Image:
    out = Image.new("L", m.size, 0)
    out.paste(m, (dx, dy))
    return out


def _miami_bg(category: str, size: int) -> tuple[Image.Image, tuple]:
    """Sunset gradient with a few dark retro bands low on the tile, and the category's accent colour."""
    from .icons import _hex
    top, bottom, accent = (_hex(c) for c in MIAMI.get(category, MIAMI["Herramientas"]))
    bg = Image.new("RGBA", (size, size))
    px = bg.load()
    for y in range(size):
        t = (y / (size - 1)) ** 1.15
        row = tuple(round(top[i] + (bottom[i] - top[i]) * t) for i in range(3)) + (255,)
        for x in range(size):
            px[x, y] = row
    d = ImageDraw.Draw(bg)
    y = int(size * 0.62)
    gap, thick = size * 0.045, max(1, size * 0.012)
    while y < size:                                           # the sun's slats: bands that thicken towards the bottom
        d.rectangle([0, y, size, y + thick], fill=tuple(int(c * 0.45) for c in top) + (255,))
        y += gap + thick
        thick += size * 0.006
    return bg, accent


def _miami(g: Image.Image, category: str, size: int, tint: str | None = None) -> Image.Image:
    from PIL import ImageFilter
    from .icons import _hex
    bg, accent = _miami_bg(category, size)
    if tint:
        accent = _hex(tint)
    mask = _fit(g, size, 0.58)
    off = max(2, round(size / 36))
    shadow = Image.new("L", (size, size), 0)
    shadow.paste(mask, (off, off))
    glow = shadow.filter(ImageFilter.GaussianBlur(size * 0.03))
    bg.paste(Image.new("RGBA", (size, size), accent + (255,)), (0, 0), glow.point(lambda v: int(v * 0.9)))
    bg.paste(Image.new("RGBA", (size, size), accent + (255,)), (0, 0), shadow)
    bg.paste(Image.new("RGBA", (size, size), (255, 255, 255, 255)), (0, 0), mask)
    return bg


def service_tint(name: str) -> str | None:
    """The brand-ish tint of a service pictogram ('svc_youtube' -> red), used by the styles that colour keys."""
    from .. import services
    svc = services.BY_ID.get(name[4:]) if name.startswith("svc_") else None
    return svc.color if svc else None


def _mix(hex_color: str, toward=(255, 255, 255), k: float = 0.5) -> str:
    from .icons import _hex
    c = _hex(hex_color)
    return "#%02x%02x%02x" % tuple(round(c[i] + (toward[i] - c[i]) * k) for i in range(3))


def styled_tile(g: Image.Image, category: str = "Herramientas", size: int = 128, style: str | None = None,
                palette: str | None = None, tint: str | None = None) -> Image.Image:
    """A key from a white glyph, in the chosen style. `palette` forces a pastel palette (used by X-Plane keys);
    `tint` colours the key for one specific thing (a service) in the styles that colour keys."""
    from PIL import ImageFilter
    from . import icons
    style = style or current_style()
    if style == "industrial":
        return _industrial(g, category, size)
    if style == "miami":
        return _miami(g, category, size, tint)
    if style == "neon":
        return _glow(_fit(g, size, 0.60), tint or NEON.get(category, "#b48cff"), size)
    if style == "line":
        from PIL import ImageChops
        m = _fit(g, size, 0.62)
        t = 2 * max(1, round(size / 64)) + 1                       # ~2 px of contour at 128
        edge = ImageChops.subtract(m, m.filter(ImageFilter.MinFilter(t)))
        glass = ImageChops.add(edge, m.point(lambda v: int(v * 0.20)))   # bright contour over a faint body
        return _glow(glass, tint or NEON.get(category, "#b48cff"), size)
    if tint and not palette:
        palette = (_mix(tint, (255, 255, 255), 0.62), _mix(tint, (255, 255, 255), 0.38))
    return icons.make_tile(g, palette or icons.CATEGORY_COLOR.get(category, "lilac"), fill=0.62, size=size)


def tile(name: str, category: str = "Herramientas", size: int = 128, style: str | None = None) -> Image.Image:
    """The key for an icon name in the chosen style (pastel by default)."""
    style = style or current_style()
    if name.startswith("svc_"):                                   # the service's real mark, when the user has downloaded it
        from .. import logos
        mark = logos.logo_image(name[4:], 256)
        if mark is not None:
            return app_tile(mark, size, style, fill=0.68)
    return styled_tile(glyph(name, 128, style=style), category, size, style, tint=service_tint(name))


def app_tile(icon: Image.Image, size: int = 128, style: str | None = None, fill: float = 0.78) -> Image.Image:
    """A key for an application (or file): its own coloured icon centred on a tile that follows the style."""
    from PIL import ImageFilter
    from .icons import _hex
    style = style or current_style()
    icon = icon.convert("RGBA")
    inner = int(size * fill)
    icon.thumbnail((inner, inner), Image.LANCZOS)
    pos = ((size - icon.width) // 2, (size - icon.height) // 2)
    if style == "pastel":
        tile = Image.new("RGBA", (size, size), (27, 27, 31, 255))
        tile.paste(icon, pos, icon)
        return tile
    if style == "industrial":                                     # the app's icon on the graphite plate
        plate = _plate(size)
        small = icon.copy()
        small.thumbnail((int(size * fill * 0.85), int(size * fill * 0.85)), Image.LANCZOS)
        spos = ((size - small.width) // 2, int(size * 0.47 - small.height / 2))
        sh = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        sh.paste(Image.new("RGBA", small.size, (8, 9, 10, 255)), (spos[0] + 2, spos[1] + 2), small)
        plate.alpha_composite(sh)
        plate.paste(small, spos, small)
        return plate
    if style == "miami":                                          # the icon, in its own colours, over the sunset
        bg, accent = _miami_bg("Aplicaciones", size)
        shadow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        shadow.paste(Image.new("RGBA", icon.size, accent + (255,)), (pos[0] + max(2, size // 36), pos[1] + max(2, size // 36)), icon)
        shadow = shadow.filter(ImageFilter.GaussianBlur(size * 0.02))
        bg.alpha_composite(shadow)
        bg.paste(icon, pos, icon)
        return bg
    tile = Image.new("RGBA", (size, size), BLACK)
    if style == "neon":                                           # a soft glow in the icon's own colours behind it
        halo = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        halo.paste(icon, pos, icon)
        halo = halo.filter(ImageFilter.GaussianBlur(size * 0.05))
        halo.putalpha(halo.getchannel("A").point(lambda v: int(v * 0.8)))
        tile.alpha_composite(halo)
    tile.paste(icon, pos, icon)
    return tile


CATEGORY_OF_PREFIX = (("volume:", "Audio"), ("mic:", "Audio"), ("media:", "Audio"), ("sound:", "Audio"),
                      ("desktop:", "Escritorio (KDE)"), ("tool:", "Escritorio (KDE)"), ("browser:", "Navegador"),
                      ("udp:", "Red"), ("brightness", "Dispositivo"), ("page:", "Dispositivo"), ("profile:", "Dispositivo"),
                      ("screen-off", "Dispositivo"), ("lock", "Sistema"), ("suspend", "Sistema"), ("{", "Flujo de operación"),
                      ("service:", "Servicios"), ("url:", "Herramientas"), ("key:", "Herramientas"), ("text:", "Herramientas"), ("open:", "Herramientas"))


def category_for(action: str | None) -> str:
    """The catalog group an action belongs to (decides the icon's colour)."""
    for prefix, cat in CATEGORY_OF_PREFIX:
        if action and action.startswith(prefix):
            return cat
    return "Herramientas"
