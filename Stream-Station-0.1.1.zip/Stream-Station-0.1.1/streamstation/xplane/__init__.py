"""X-Plane 12 integration: the simulator's own command list, key icons, live state from datarefs."""
