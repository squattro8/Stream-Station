"""The start-up picture: what the strip shows when Stream Station connects to the deck (at login, or when it is plugged in again).

The deck's own picture (the factory dragon) shows until the program takes over; from then on the picture chosen here is drawn on
the whole strip (800 x 128) for a moment, before the profile appears. The picture is stored already scaled to the strip.
"""
from __future__ import annotations

import os

from PIL import Image, ImageOps

from . import profiles, strip

TARGET = strip.FULL                       # 800 x 128
FITS = ("fill", "fit", "stretch")         # crop the excess | keep it whole with black borders | distort to cover


def path() -> str:
    return os.path.join(profiles.CONFIG, "boot_logo.png")


def scale(img: Image.Image, fit: str = "fill") -> Image.Image:
    """`img` made exactly TARGET-sized."""
    img = img.convert("RGB")
    if fit == "stretch":
        return img.resize(TARGET, Image.LANCZOS)
    if fit == "fit":
        return ImageOps.pad(img, TARGET, Image.LANCZOS, color=(0, 0, 0))
    return ImageOps.fit(img, TARGET, Image.LANCZOS)


def describe(img: Image.Image) -> str:
    """"1920 x 1080 -> 800 x 128" for the dialog."""
    return f"{img.width} × {img.height}  →  {TARGET[0]} × {TARGET[1]}"


def save(img: Image.Image, fit: str = "fill") -> str:
    out = scale(img, fit)
    os.makedirs(profiles.CONFIG, exist_ok=True)
    out.save(path() + ".tmp.png")
    os.replace(path() + ".tmp.png", path())
    return path()


def load() -> Image.Image | None:
    try:
        img = Image.open(path()); img.load()
    except (OSError, ValueError):
        return None
    return img.convert("RGB") if img.size == TARGET else scale(img)


def remove() -> None:
    try:
        os.remove(path())
    except FileNotFoundError:
        pass
