"""What can be read about the connected deck without touching it: its USB serial number."""
from __future__ import annotations

import glob
import os

from . import protocol as P


def serial_number(root: str = "/sys/bus/usb/devices") -> str | None:
    """The deck's USB serial string, read from sysfs (no permissions needed); None when it is not plugged in or has none."""
    want = (f"{P.VID:04x}", f"{P.PID:04x}")
    for dev in sorted(glob.glob(os.path.join(root, "*"))):
        try:
            vid = open(os.path.join(dev, "idVendor")).read().strip().lower()
            pid = open(os.path.join(dev, "idProduct")).read().strip().lower()
        except OSError:
            continue
        if (vid, pid) == want:
            try:
                value = open(os.path.join(dev, "serial")).read().strip()
            except OSError:
                return None
            return value or None
    return None
