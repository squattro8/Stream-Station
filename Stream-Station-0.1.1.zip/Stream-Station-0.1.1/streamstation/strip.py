"""Touch strip: ONE 800x128 canvas.

Content is composed in the coordinates the viewer sees. `StripEngine.plan()` returns the regions that
make up the strip now, each as (signature, rect, render function); the service sends a region only when
its signature changed. The four touch zones are 200 px wide, but nothing forces content to respect them:
an image or GIF may cover the whole canvas.
"""
from __future__ import annotations

import glob
import os
import shutil
import subprocess
import time
from typing import Callable

from PIL import Image, ImageDraw, ImageFont, ImageSequence

from .i18n import tr_strip
from . import fonts, protocol as P

SEG = (P.ZONE_W, P.STRIP_H)          # one touch zone: 200 x 128
FULL = (P.STRIP_W, P.STRIP_H)        # the whole canvas: 800 x 128
BG = (0, 0, 0)                       # pure black: the deck's factory picture must never show through
MIN_FRAME_MS = 250                   # animation speed cap: the deck re-decodes every JPEG we send
MAX_FRAMES = 120
TITLES = {"clock": "HORA", "date": "FECHA", "cpu": "CPU", "ram": "RAM", "temp": "TEMP",
          "volume": "VOLUMEN", "disk": "DISCO"}
METRIC_KINDS = tuple(TITLES)


def _font(size: int, family: str | None = None):
    return fonts.font(size, False, family)


class Metrics:
    def __init__(self):
        self._cpu = self._read_cpu()

    @staticmethod
    def _read_cpu():
        with open("/proc/stat") as fh:
            f = [int(x) for x in fh.readline().split()[1:]]
        return sum(f), f[3] + f[4]  # total, idle+iowait

    def cpu(self) -> float:
        total, idle = self._read_cpu()
        dt, di = total - self._cpu[0], idle - self._cpu[1]
        self._cpu = (total, idle)
        return 0.0 if dt <= 0 else 100.0 * (dt - di) / dt

    @staticmethod
    def ram() -> float:
        info = {}
        with open("/proc/meminfo") as fh:
            for line in fh:
                k, v = line.split(":")
                info[k] = int(v.split()[0])
        return 100.0 * (1 - info["MemAvailable"] / info["MemTotal"])

    @staticmethod
    def temp() -> float | None:
        for name in ("coretemp", "k10temp", "zenpower", "acpitz"):
            for d in glob.glob("/sys/class/hwmon/hwmon*"):
                try:
                    if open(os.path.join(d, "name")).read().strip() == name:
                        return int(open(os.path.join(d, "temp1_input")).read()) / 1000
                except OSError:
                    continue
        return None

    @staticmethod
    def disk(path: str = "/") -> float:
        u = shutil.disk_usage(path)
        return 100.0 * u.used / u.total

    @staticmethod
    def volume() -> tuple[int, bool] | None:
        """(percent, muted) of the default sink via wpctl; None when unavailable."""
        try:
            out = subprocess.run(["wpctl", "get-volume", "@DEFAULT_AUDIO_SINK@"],
                                 capture_output=True, text=True, timeout=1).stdout
            return round(float(out.split()[1]) * 100), "[MUTED]" in out
        except (OSError, subprocess.SubprocessError, ValueError, IndexError):
            return None


def value_text(kind: str, m: Metrics) -> tuple[str, str]:
    if kind == "clock":
        now = time.localtime()
        return time.strftime("%H:%M", now), time.strftime("%a %d %b", now)
    if kind == "date":
        now = time.localtime()
        return time.strftime("%d %b", now), time.strftime("%A", now)
    if kind == "cpu":
        return f"{m.cpu():.0f}%", ""
    if kind == "ram":
        return f"{m.ram():.0f}%", ""
    if kind == "disk":
        return f"{m.disk():.0f}%", tr_strip("usado")
    if kind == "volume":
        v = m.volume()
        return ("--", "") if v is None else (f"{v[0]}%", tr_strip("silenciado") if v[1] else "")
    if kind == "temp":
        t = m.temp()
        return ("--" if t is None else f"{t:.0f}°C"), ""
    return "", ""


# --- rendering (unrotated 208x124 RGB images) ---------------------------------------------------
def metric_image(kind: str, m: Metrics, texts: tuple[str, str] | None = None, family: str | None = None) -> Image.Image:
    big, small = texts if texts is not None else value_text(kind, m)
    img = Image.new("RGB", SEG, BG)
    d = ImageDraw.Draw(img)
    w, h = SEG
    d.text((w // 2, 18), tr_strip(TITLES.get(kind, kind.upper())), fill=(120, 130, 150), font=_font(20, family), anchor="mm")
    d.text((w // 2, h // 2 + 4), big, fill=(240, 240, 245), font=_font(52, family), anchor="mm")
    if small:
        d.text((w // 2, h - 18), small, fill=(120, 130, 150), font=_font(16, family), anchor="mm")
    return img


def _wrap(text: str, font, width: int) -> list[str]:
    lines: list[str] = []
    for para in text.split("\n"):
        cur = ""
        for word in para.split(" "):
            trial = (cur + " " + word).strip()
            if font.getlength(trial) <= width or not cur:
                cur = trial
            else:
                lines.append(cur)
                cur = word
        lines.append(cur)
    return lines


def text_image(spec: dict, size: tuple[int, int] = SEG) -> Image.Image:
    """Centered, word-wrapped text; the size is chosen to fit unless the spec fixes it."""
    bg = spec.get("bg") or "#141414"
    color = spec.get("color") or "#ffffff"
    text = str(spec.get("text") or "")
    img = Image.new("RGB", size, bg)
    if not text:
        return img
    d = ImageDraw.Draw(img)
    pad = 8
    sizes = [int(spec["size"])] if spec.get("size") else list(range(48, 11, -2))
    chosen = None
    for s in sizes:
        f = _font(s, spec.get("font"))
        lines = _wrap(text, f, size[0] - 2 * pad)
        height = len(lines) * int(s * 1.2)
        if height <= size[1] - 2 * pad or s == sizes[-1]:
            chosen = (f, lines, s)
            break
    f, lines, s = chosen
    lh = int(s * 1.2)
    y = (size[1] - lh * len(lines)) / 2 + lh / 2
    for line in lines:
        d.text((size[0] / 2, y), line, fill=color, font=f, anchor="mm")
        y += lh
    return img


def fit_image(img: Image.Image, size: tuple[int, int], mode: str = "cover") -> Image.Image:
    img = img.convert("RGBA")
    bg = Image.new("RGBA", size, (0, 0, 0, 255))
    if mode == "stretch":
        out = img.resize(size, Image.LANCZOS)
        bg.alpha_composite(out)
    elif mode == "contain":
        k = min(size[0] / img.width, size[1] / img.height)
        out = img.resize((max(1, round(img.width * k)), max(1, round(img.height * k))), Image.LANCZOS)
        bg.alpha_composite(out, ((size[0] - out.width) // 2, (size[1] - out.height) // 2))
    else:  # cover: fill the panel, crop the excess
        k = max(size[0] / img.width, size[1] / img.height)
        out = img.resize((max(1, round(img.width * k)), max(1, round(img.height * k))), Image.LANCZOS)
        left, top = (out.width - size[0]) // 2, (out.height - size[1]) // 2
        bg.alpha_composite(out.crop((left, top, left + size[0], top + size[1])))
    return bg.convert("RGB")


class Animation:
    """Decoded frames already fitted to a size, with the delay of each (ms, capped)."""
    def __init__(self, frames: list[Image.Image], delays: list[int]):
        self.frames, self.delays = frames, delays
        self.total = sum(delays) or MIN_FRAME_MS

    def index_at(self, t_ms: float) -> int:
        if len(self.frames) == 1:
            return 0
        t = t_ms % self.total
        acc = 0
        for i, d in enumerate(self.delays):
            acc += d
            if t < acc:
                return i
        return len(self.frames) - 1


def load_animation(path: str, size: tuple[int, int], mode: str = "cover") -> Animation:
    with Image.open(path) as im:
        raw = []
        for fr in ImageSequence.Iterator(im):
            raw.append((fr.copy(), int(fr.info.get("duration", 100) or 100)))
    if len(raw) > MAX_FRAMES:           # keep memory and send rate bounded: take every k-th frame
        k = -(-len(raw) // MAX_FRAMES)
        raw = [(raw[i][0], sum(d for _, d in raw[i:i + k])) for i in range(0, len(raw), k)]
    return Animation([fit_image(f, size, mode) for f, _ in raw], [max(MIN_FRAME_MS, d) for _, d in raw])


# --- engine -------------------------------------------------------------------------------------
Region = tuple[tuple, tuple[int, int, int, int], Callable[[], Image.Image]]


class StripEngine:
    def __init__(self, metrics: Metrics | None = None):
        self.metrics = metrics or Metrics()
        self._t0 = time.monotonic()
        self._texts: dict[str, tuple[float, tuple[str, str]]] = {}
        self._anims: dict[tuple, Animation] = {}

    def restart(self):
        """Restart animations (profile change)."""
        self._t0 = time.monotonic()

    def _metric(self, kind: str, now: float) -> tuple[str, str]:
        hit = self._texts.get(kind)
        if hit and now - hit[0] < 1.0:
            return hit[1]
        val = value_text(kind, self.metrics)
        self._texts[kind] = (now, val)
        return val

    def _animation(self, path: str, size, mode) -> Animation:
        key = (path, os.path.getmtime(path), size, mode)
        if key not in self._anims:
            if len(self._anims) > 6:
                self._anims.clear()
            self._anims[key] = load_animation(path, size, mode)
        return self._anims[key]

    def _missing(self, name: str, size):
        return lambda: text_image({"text": tr_strip("No se encuentra\n{name}", name=os.path.basename(name)), "color": "#ff9a9a", "size": 14}, size)

    def _media(self, spec: dict, size, now: float):
        path = os.path.expanduser(str(spec.get("path") or ""))
        if not path or not os.path.isfile(path):
            return ("missing", path), self._missing(path or tr_strip("(sin archivo)"), size)
        mode = spec.get("fit") or "cover"
        try:
            anim = self._animation(path, size, mode)
        except (OSError, ValueError, SyntaxError) as exc:
            return ("error", path, str(exc)[:40]), self._missing(path, size)
        idx = anim.index_at((now - self._t0) * 1000)
        return ("media", path, os.path.getmtime(path), mode, idx, size), (lambda anim=anim, idx=idx: anim.frames[idx])

    def plan(self, content: dict, now: float | None = None) -> list[Region]:
        """content = {"mode": "segments", "segments": [spec|None]*4} or {"mode": "full", "full": spec}."""
        now = time.monotonic() if now is None else now
        if content.get("mode") == "full" and content.get("full"):
            sig, draw = self._media(content["full"], FULL, now)
            return [(sig, (0, 0, FULL[0], FULL[1]), draw)]
        segs = list(content.get("segments") or [])[:4]
        segs += [None] * (4 - len(segs))
        out: list[Region] = []
        for i, spec in enumerate(segs):
            sig, draw = self._one(spec, now)
            out.append((sig, (i * SEG[0], 0, SEG[0], SEG[1]), draw))
        return out

    def _one(self, spec, now: float):
        if not spec or spec.get("type") in (None, "empty"):
            return ("empty",), lambda: Image.new("RGB", SEG, BG)
        kind = spec["type"]
        if kind == "metric":
            m = spec.get("kind", "clock")
            texts = self._metric(m, now)
            family = spec.get("font") or None
            return ("metric", m, texts, family), lambda m=m, texts=texts, family=family: metric_image(m, self.metrics, texts, family)
        if kind == "weather":
            from . import weather, weatherart
            place = spec.get("place") or {}
            units = "f" if spec.get("units") == "f" else "c"
            family = spec.get("font") or None
            lat, lon = place.get("lat"), place.get("lon")
            reading = weather.SERVICE.get(lat, lon) if lat is not None and lon is not None else None
            state = weather.SERVICE.state(lat, lon) if reading is None and lat is not None and lon is not None else "ok"
            sig = ("weather", lat, lon, place.get("name"), units, family, state,
                   (round(weather.to_unit(reading.temp_c, units)), reading.code, reading.is_day) if reading else None)
            return sig, lambda: weatherart.widget_image(reading, place, units, family, state)
        if kind == "text":
            key = tuple(sorted((k, str(v)) for k, v in spec.items()))
            return ("text", key), lambda spec=spec: text_image(spec)
        if kind in ("image", "gif"):
            return self._media(spec, SEG, now)
        return ("error", str(kind)), lambda: text_image({"text": tr_strip("Tipo desconocido\n{kind}", kind=kind), "color": "#ff9a9a", "size": 14})


def compose(plan: list[Region]) -> Image.Image:
    """The regions pasted onto one 800x128 canvas (what the viewer should see; used for previews)."""
    canvas = Image.new("RGB", FULL, BG)
    for _, (x, y, w, h), draw in plan:
        img = draw()
        canvas.paste(img if img.size == (w, h) else img.resize((w, h)), (x, y))
    return canvas
