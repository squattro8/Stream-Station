import os, sys, json, pathlib, tempfile
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

import yaml
from streamstation import profiles, plugins, system, render
from streamstation.ui import catalog


def isolate(tmp):
    """Point every config lookup at a temp dir so tests never touch the real ~/.config."""
    cfg = os.path.join(tmp, "cfg")
    profiles.CONFIG = cfg
    profiles.search_dirs = lambda sub: [os.path.join(cfg, sub)] if os.path.isdir(os.path.join(cfg, sub)) else []
    return cfg


def write_profile(cfg, name, data):
    d = os.path.join(cfg, "profiles"); os.makedirs(d, exist_ok=True)
    yaml.safe_dump(data, open(os.path.join(d, f"{name}.yaml"), "w"))


def test_every_fixed_catalog_action_is_something_the_service_runs():
    p = plugins.Plugins()
    known_prefix = ("layer:", "profile:", "page:", "scene:", "brightness")
    known_exact = set(system.VERBS) | {"screen-off", "lock", "suspend"}
    for group, items in catalog.CATALOG:
        for label, action, _ in items:
            if "{" in action or action.startswith("$HOME/"):      # needs a value / is a plain shell command
                continue
            assert (action in known_exact or action.startswith(known_prefix) or p.handles(action)), (group, label, action)


def test_catalog_search_filters_by_label_and_action():
    assert catalog.search("volumen")[0][0] == "Audio"
    assert any(a == "desktop:dnd" for _, items in catalog.search("molestar") for _, a, _ in items)
    assert catalog.search("zzzz") == []


def test_profile_model_roundtrip_keeps_unknown_fields_and_legacy_pages():
    from streamstation.ui import model
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        write_profile(cfg, "G", {"name": "G", "custom": {"x": 1}, "keys": {"0": {"action": "a"}},
                                 "pages": [{"1": {"action": "legacy"}}], "layers": {"m": {"keys": {}}}})
        m = model.ProfileModel("G")
        assert m.page_count() == 2 and m.get(1, 1)["action"] == "legacy"      # legacy flat page form
        m.set(4, 0, {"label": "L", "action": "x"}); m.set(0, 0, None); m.add_page(); m.set(2, 2, {"action": "p3"})
        path = m.save()
        again = model.ProfileModel("G")
        assert again.get(4, 0)["action"] == "x" and again.get(0, 0) is None and again.get(2, 2)["action"] == "p3"
        assert again.raw["custom"] == {"x": 1} and "m" in again.raw["layers"] and not again.dirty
        assert path.startswith(cfg)
        assert model.summary({"profile": "work"}).startswith("Cambiar al perfil")


def test_desktop_parsing_skips_hidden_and_actions():
    from streamstation.ui import apps
    with tempfile.TemporaryDirectory() as tmp:
        d1, d2 = os.path.join(tmp, "user"), os.path.join(tmp, "sys")
        os.makedirs(d1); os.makedirs(d2)
        open(os.path.join(d2, "ff.desktop"), "w").write("[Desktop Entry]\nType=Application\nName=Firefox\nExec=ff %u\nIcon=firefox\n\n[Desktop Action new]\nName=Ventana nueva\nExec=ff -n\n")
        open(os.path.join(d1, "ff.desktop"), "w").write("[Desktop Entry]\nType=Application\nName=Firefox (usuario)\nExec=ff\nIcon=x\n")
        open(os.path.join(d2, "hid.desktop"), "w").write("[Desktop Entry]\nType=Application\nName=Oculta\nExec=h\nNoDisplay=true\n")
        open(os.path.join(d2, "link.desktop"), "w").write("[Desktop Entry]\nType=Link\nName=Enlace\nURL=http://x\n")
        open(os.path.join(d2, "bad.desktop"), "wb").write(b"\xff\xfe not a desktop file")
        found = apps.list_apps([d1, d2])
        assert [(a.id, a.name) for a in found] == [("ff", "Firefox (usuario)")]   # user dir wins, no actions/hidden/links


def _window(tmp, ctl=None):
    from PySide6.QtWidgets import QApplication
    from streamstation.ui import theme
    from streamstation.ui.mainwindow import MainWindow
    cfg = isolate(tmp)
    write_profile(cfg, "General", {"name": "General", "keys": {"0": {"label": "Uno", "action": "echo 1"}}})
    app = QApplication.instance() or QApplication([])
    app.setStyleSheet(theme.qss())
    calls = []
    w = MainWindow("General", ctl=ctl or (lambda a: calls.append(a) or '{"ok": true}'))
    w.show(); app.processEvents()
    return w, calls, cfg


def test_assign_catalog_app_and_value_actions_then_save_and_apply():
    from streamstation.ui import theme
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        assert w.size().width() == theme.WINDOW[0] and w.scenes.count() == 1
        mute = {"kind": "catalog", "label": "Silenciar", "action": "volume:mute", "plugin": "quickcontrol.mute", "group": "Audio"}
        w.board.dropped.emit(3, mute)                                   # same path as a drag & drop
        e = w.model.get(3)
        assert e["action"] == "volume:mute" and w.model.dirty
        assert os.path.isfile(os.path.join(cfg, "assets", e["icon"]))     # unified tile written for the service
        w.ask_value = lambda title: "https://example.org"
        w.assign(4, {"kind": "catalog", "label": "Sitio web…", "action": "url:{}", "plugin": "system.website", "group": "Herramientas"})
        assert w.model.get(4)["action"] == "url:https://example.org"
        w.assign(5, {"kind": "catalog", "label": "Alternar entre acciones", "action": "{toggle}", "plugin": "multiactions.toggle", "group": "Flujo de operación"})
        assert w.model.get(5) is None and "multi-acciones" in w.panel.status.text()
        w.assign(6, {"kind": "app", "id": "org.kde.dolphin", "name": "Dolphin", "icon": "org.kde.dolphin"})
        assert w.model.get(6)["action"] == "open:org.kde.dolphin" and os.path.isfile(os.path.join(cfg, "assets", w.model.get(6)["icon"]))
        w.save_and_apply()
        assert calls[-1] == ["apply", "General"] and not w.model.dirty and "aplicado" in w.panel.status.text()
        # the real servicio can read what the editor saved and render its icons
        prof = profiles.load("General")
        assert prof.key(3)["action"] == "volume:mute"
        jpg = render.key_image(prof.key(3)["icon"], "x", profiles.search_dirs("assets"))
        assert jpg[:2] == b"\xff\xd8"
        w.close()


def test_shortcut_validation_and_entry():
    from streamstation.ui import configpanel, icons
    with tempfile.TemporaryDirectory() as tmp:
        isolate(tmp)
        lib = icons.IconLibrary()
        e = configpanel.entry_from_shortcut("Refrescar página", "ctrl+r", lib)
        assert e["action"] == "key:ctrl+r" and e["label"] == "Refrescar página"
        try: configpanel.entry_from_shortcut("x", "hyper+q", lib)
        except ValueError: pass
        else: raise AssertionError("invalid combo must be refused")


def test_pages_selection_panel_and_unreachable_service():
    with tempfile.TemporaryDirectory() as tmp:
        def down(_): raise OSError("no service")
        w, _, _ = _window(tmp, ctl=down)
        w.add_page()
        assert w.page == 1 and w.model.page_count() == 2
        w._on_selected("key", 2)
        assert "página 2" in w.panel.title.text()
        w.panel.action.setText("echo hola"); w.panel.label.setText("Hola")
        w.panel.action.textEdited.emit("echo hola")
        assert w.model.get(2, 1) == {"label": "Hola", "action": "echo hola"}
        w.panel.clear_btn.click()
        assert w.model.get(2, 1) is None
        w._on_selected("knob", 1)
        assert w.editors.currentIndex() == 2 and "Perilla 2" in w.knob_panel.title.text()   # knobs now have their own editor
        w.save_and_apply()
        assert "servicio no está corriendo" in w.panel.status.text()
        w.set_page(0); assert w.page == 0
        w.search.setText("calculadora"); assert w.tree.topLevelItemCount() >= 1
        w.close()


def test_new_profile_and_drag_mime():
    from PySide6.QtCore import Qt
    from streamstation.ui.board import Board
    with tempfile.TemporaryDirectory() as tmp:
        w, _, cfg = _window(tmp)
        w.ask_value = lambda t: "Juegos"
        w.new_profile()
        assert w.model.name == "Juegos" and w.model.dirty and "Juegos" in w._scene_names
        w.save_and_apply()
        assert os.path.isfile(os.path.join(cfg, "profiles", "Juegos.yaml"))
        item = None
        for i in range(w.tree.topLevelItemCount()):
            top = w.tree.topLevelItem(i)
            for j in range(top.childCount()):
                if (top.child(j).data(0, Qt.UserRole) or {}).get("kind") == "catalog":
                    item = top.child(j); break
            if item: break
        md = w.tree.mimeData([item])
        assert md.hasFormat(Board.MIME) and json.loads(bytes(md.data(Board.MIME)).decode())["kind"] == "catalog"
        w.close()


def test_keys_on_a_brand_new_page_are_not_lost():
    from streamstation.ui import model
    with tempfile.TemporaryDirectory() as tmp:
        isolate(tmp)
        m = model.ProfileModel("N")
        p = m.add_page()
        m.set(0, p, {"action": "a"}); m.set(1, p, {"action": "b"})
        assert m.get(0, p)["action"] == "a" and m.get(1, p)["action"] == "b"
        m.save()
        assert model.ProfileModel("N").get(1, p)["action"] == "b"


def _qapp():
    from PySide6.QtWidgets import QApplication
    return QApplication.instance() or QApplication([])


def test_entry_from_path_for_each_kind_of_thing():
    import shlex, stat
    from streamstation.ui import configpanel, apps
    _qapp()
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        std = os.path.join(tmp, "share", "applications"); os.makedirs(std)
        apps.desktop_dirs = lambda: [std]
        # a launcher inside a standard dir -> by id
        std_desktop = os.path.join(std, "mi-app.desktop")
        open(std_desktop, "w").write("[Desktop Entry]\nType=Application\nName=Mi App\nExec=mi-app %U\nIcon=nope\n")
        e = configpanel.entry_from_path(std_desktop)
        assert e["action"] == "open:mi-app" and e["label"] == "Mi App"
        # a launcher outside the standard dirs -> its Exec line without field codes
        loose = os.path.join(tmp, "suelto.desktop")
        open(loose, "w").write("[Desktop Entry]\nType=Application\nName=Suelto\nExec=/opt/x/run --flag %F %%\n")
        assert configpanel.entry_from_path(loose)["action"] == "/opt/x/run --flag %"
        # an executable with spaces in its path: must survive the shell
        exe = os.path.join(tmp, "mi programa.sh"); open(exe, "w").write("#!/bin/sh\n"); os.chmod(exe, 0o755)
        e = configpanel.entry_from_path(exe)
        assert shlex.split(e["action"]) == [exe]
        # folder and plain file -> opened with the default application
        folder = os.path.join(tmp, "mis docs"); os.makedirs(folder)
        assert configpanel.entry_from_path(folder)["action"] == f"open:{folder}"
        txt = os.path.join(tmp, "nota.txt"); open(txt, "w").write("x")
        e = configpanel.entry_from_path(txt)
        assert e["action"] == f"open:{txt}" and os.path.isfile(os.path.join(cfg, "assets", e["icon"]))
        # errors are reported, not raised as crashes
        for bad in (os.path.join(tmp, "no-existe"),):
            try: configpanel.entry_from_path(bad)
            except ValueError: pass
            else: raise AssertionError("missing path must be refused")
        junk = os.path.join(tmp, "malo.desktop"); open(junk, "w").write("esto no es un lanzador")
        try: configpanel.entry_from_path(junk)
        except ValueError: pass
        else: raise AssertionError("invalid launcher must be refused")


def test_open_action_with_spaces_reaches_xdg_open_intact():
    from streamstation import plugins
    spawned = []
    p = plugins.Plugins(sys_run=lambda a, timeout=3: "", sys_spawn=lambda a: spawned.append(a))
    with tempfile.TemporaryDirectory() as tmp:
        f = os.path.join(tmp, "dos palabras.txt"); open(f, "w").write("x")
        p.run(f"open:{f}")
    assert spawned == [["xdg-open", f]]


def test_browse_button_flow():
    with tempfile.TemporaryDirectory() as tmp:
        w, _, _ = _window(tmp)
        picked = []
        target = os.path.join(tmp, "carpeta de prueba"); os.makedirs(target)
        w.pick_path = lambda mode: picked.append(mode) or target
        assert not w.panel.browse_btn.isEnabled()                       # nothing selected yet
        w.browse("folder")
        assert picked == [] and "Selecciona primero una tecla" in w.panel.status.text()
        w._on_selected("key", 7)
        assert w.panel.browse_btn.isEnabled()
        w.browse("folder")
        e = w.model.get(7)
        assert picked == ["folder"] and e["action"] == f"open:{target}" and w.model.dirty
        w.pick_path = lambda mode: None                                 # user cancels the dialog
        before = dict(w.model.get(7)); w.browse("file")
        assert w.model.get(7) == before
        w.pick_path = lambda mode: os.path.join(tmp, "no-existe")       # vanished between pick and use
        w.browse("file")
        assert w.model.get(7) == before and "no existe" in w.panel.status.text()
        w.close()


def test_strip_editor_segments_full_width_touch_and_roundtrip_with_the_service():
    from PIL import Image
    from streamstation import strip as stripmod
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        sp = w.strip_panel
        img = os.path.join(tmp, "foto.png"); Image.new("RGB", (832, 124), (10, 120, 200)).save(img)
        gif = os.path.join(tmp, "anim.gif")
        fr = [Image.new("RGB", (32, 32), (i * 100, 50, 50)) for i in range(3)]
        fr[0].save(gif, save_all=True, append_images=fr[1:], duration=300, loop=0)

        w._on_selected("strip", 1)
        assert w.editors.currentIndex() == 1 and "Segmento 2" in sp.title.text()
        sp.type.setCurrentIndex(sp.type.findData("text")); sp.text.setPlainText("Hola\nmundo")
        assert w.model.segments()[1] == {"type": "text", "text": "Hola\nmundo"} and w.model.dirty
        sp.type.setCurrentIndex(sp.type.findData("metric")); sp.metric_box.setCurrentIndex(sp.metric_box.findData("volume"))
        assert w.model.segments()[1] == {"type": "metric", "kind": "volume"}
        sp.type.setCurrentIndex(sp.type.findData("gif")); sp.set_path(gif)
        assert w.model.segments()[1] == {"type": "gif", "path": gif, "fit": "cover"}
        assert w.board.strip_pix[1] is not None                                      # preview rendered
        # one image across the whole strip
        w._on_selected("strip", 0)
        sp.type.setCurrentIndex(sp.type.findData("image")); sp.set_path(img); sp.span.setChecked(True)
        assert w.model.full()["path"] == img
        w._on_selected("strip", 3)                                                     # any segment shows the shared image
        assert sp.type.currentData() == "image" and sp.span.isChecked()
        sp.span.setChecked(False)
        assert w.model.full() is None
        # touch action typed + dropped from the tree
        w._on_selected("strip", 2)
        sp.touch.setText("playerctl next"); sp.touch.textEdited.emit("playerctl next")
        assert w.model.touch(2) == "playerctl next"
        w.board.dropped_strip.emit(0, {"kind": "catalog", "label": "Silenciar", "action": "volume:mute", "plugin": "x", "group": "Audio"})
        assert w.model.touch(0) == "volume:mute" and sp.touch.text() == "volume:mute"
        w.ask_value = lambda t: None                                                   # cancelled value prompt (set BEFORE the drop)
        w.board.dropped_strip.emit(1, {"kind": "catalog", "label": "Atajo de teclado…", "action": "key:{}", "plugin": "x", "group": "Herramientas"})
        assert w.model.touch(1) is None
        # save, then the real servicio-side loader/engine understand it
        w.save_and_apply()
        prof = profiles.load("General")
        content = prof.strip_content()
        assert content["mode"] == "segments" and content["segments"][1]["type"] == "gif"
        assert prof.strip["touch"] == {"2": "playerctl next", "0": "volume:mute"}
        plan = stripmod.StripEngine().plan(content, now=0.0)
        # seg 1: image (set before going full-width), seg 2: gif, seg 4: the image stays where full-width was switched off
        assert [s[0] for s, _, _ in plan] == ["media", "media", "empty", "media"]
        w.close()


def test_legacy_dashboard_opens_as_metric_segments_and_full_width_wins():
    from streamstation.ui import model
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        write_profile(cfg, "L", {"name": "L", "strip": {"dashboard": ["clock", "cpu"]}})
        m = model.ProfileModel("L")
        assert m.segments() == [{"type": "metric", "kind": "clock"}, {"type": "metric", "kind": "cpu"}, None, None]
        m.set_full({"type": "image", "path": "/x.png"})
        m.save()
        assert profiles.load("L").strip_content() == {"mode": "full", "full": {"type": "image", "path": "/x.png"}}


def test_knob_model_sets_clears_and_keeps_the_service_format():
    from streamstation.ui import model
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        write_profile(cfg, "K", {"name": "K", "knobs": {"0": {"rotate": {"cw": "a", "ccw": "b"}, "press": "c"}}})
        m = model.ProfileModel("K")
        assert m.knob(0)["press"] == "c" and m.knob(5) == {}
        m.set_knob_field(1, "cw", "volume:up:5"); m.set_knob_field(1, "press", "volume:mute")
        assert m.raw["knobs"]["1"] == {"rotate": {"cw": "volume:up:5"}, "press": "volume:mute"}
        m.set_knob_field(0, "ccw", None); m.set_knob_field(0, "cw", None); m.set_knob_field(0, "press", None)
        assert "0" not in m.raw["knobs"]                                           # empty knob removed, not left as {}
        m.save()
        again = model.ProfileModel("K")
        assert again.knob(1) == {"rotate": {"cw": "volume:up:5"}, "press": "volume:mute"}


def test_knob_editor_template_drop_doubleclick_save_and_the_service_runs_it():
    from streamstation.service import Service
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w._on_selected("knob", 2)
        kp = w.knob_panel
        assert w.editors.currentIndex() == 2 and "Perilla 3" in kp.title.text()
        kp.templates.setCurrentIndex(1)                                           # "Volumen del sistema"
        assert w.model.knob(2) == {"rotate": {"cw": "volume:up:5", "ccw": "volume:down:5"}, "press": "volume:mute"}
        kp.edits["ccw"].setFocus(); kp.active = "ccw"
        w.board.dropped_knob.emit(2, {"kind": "catalog", "label": "Bajar volumen", "action": "volume:down:10", "plugin": "x", "group": "Audio"})
        assert w.model.knob(2)["rotate"]["ccw"] == "volume:down:10"
        kp.active = "cw"
        w._activate_payload = None
        item_payload = {"kind": "catalog", "label": "Sitio web…", "action": "url:{}", "plugin": "x", "group": "Herramientas"}
        w.ask_value = lambda t: None
        w._knob_apply(item_payload)                                                # cancelled prompt: nothing changes
        assert w.model.knob(2)["rotate"]["cw"] == "volume:up:5"
        w.ask_value = lambda t: "https://x.org"
        w._knob_apply(item_payload)
        assert w.model.knob(2)["rotate"]["cw"] == "url:https://x.org"
        w.board.dropped_knob.emit(2, {"kind": "catalog", "label": "Alternar", "action": "{toggle}", "plugin": "x", "group": "Flujo de operación"})
        assert "multi-acciones" in kp.status.text()
        kp.edits["press"].setText(""); kp.edits["press"].textEdited.emit("")
        assert "press" not in w.model.knob(2)
        w.save_and_apply()
        assert calls[-1] == ["apply", "General"]
        # the service runs exactly what the editor saved
        d = Service(profile="General", sock_path=os.path.join(tmp, "k.sock"))
        seen = []; d.run_action = seen.append
        d.handle(("knob", 2, 1)); d._last_knob.clear(); d.handle(("knob", 2, -1)); d.handle(("knob_press", 2, True))
        assert [a for a in seen if a] == ["url:https://x.org", "volume:down:10"]   # press was cleared: nothing to run
        d.close_sockets(); w.close()



def test_app_icon_is_drawn_at_every_size_with_a_transparent_corner():
    from streamstation.ui import appicon
    for size in (16, 48, 256):
        img = appicon.draw(size)
        assert img.size == (size, size) and img.getpixel((0, 0))[3] == 0 and img.getpixel((size // 2, size // 2))[3] == 255


def test_service_status_indicator_and_start_button():
    import json
    with tempfile.TemporaryDirectory() as tmp:
        states = iter([
            lambda: json.dumps({"ok": True, "profile": "Juegos", "connected": True}),
            lambda: json.dumps({"ok": True, "profile": "Juegos", "connected": False}),
            lambda: (_ for _ in ()).throw(OSError("no service")),
        ])
        w, _, _ = _window(tmp)
        w._timer.stop()
        for expect in ("connected", "nodeck", "stopped"):
            nxt = next(states)
            w.ctl = lambda a, f=nxt: f()
            w.poll_service()
            assert w.service_state == expect
        assert not w.service_btn.isHidden() and "detenido" in w.service_text.text()      # stopped: offer to start it
        w.ctl = lambda a: json.dumps({"ok": True, "profile": "Juegos", "connected": True})
        w.poll_service()
        assert "Juegos" in w.service_text.text() and w.service_btn.isHidden()
        w.close()


def test_second_launch_asks_the_running_window_to_come_forward_instead_of_opening_another():
    from PySide6.QtNetwork import QLocalServer
    from streamstation.ui import __main__ as entry
    _qapp()
    QLocalServer.removeServer(entry.SERVER)
    server = QLocalServer(); assert server.listen(entry.SERVER)
    try:
        assert entry.main([]) == 0                    # returns at once: no second window, no event loop
    finally:
        server.close(); QLocalServer.removeServer(entry.SERVER)
        from streamstation import i18n; i18n.set_language(i18n.SOURCE)      # the entry point applied the saved language


def test_match_rules_roundtrip_through_the_model_the_profile_loader_and_the_service_index():
    from streamstation.ui import model
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        write_profile(cfg, "Juego", {"name": "Juego", "keys": {}})
        write_profile(cfg, "Otro", {"name": "Otro", "keys": {}, "match": ["not a dict", {"class": "konsole"}, {}]})
        m = model.ProfileModel("Juego")
        assert m.match() == []
        m.set_match([{"class": "X-Plane*"}, {"class": "steam_app_*", "title": "Flight"}]); m.save()
        assert profiles.load("Juego").match == [{"class": "X-Plane*"}, {"class": "steam_app_*", "title": "Flight"}]
        rules = profiles.match_rules()
        assert set(rules) == {"Juego", "Otro"} and rules["Otro"] == [{"class": "konsole"}]      # junk entries dropped
        m.set_match([]); m.save()
        assert "match" not in model.ProfileModel("Juego").raw and "Juego" not in profiles.match_rules()


def test_match_dialog_adds_from_recent_windows_by_hand_refuses_junk_and_removes():
    from streamstation.ui import matchdialog
    _qapp()
    recent = [{"class": "X-Plane", "title": "X-Plane 12", "name": ""}, {"class": "", "name": "resource-only", "title": ""}]
    dlg = matchdialog.MatchDialog([{"class": "konsole"}], recent, auto=False)
    assert dlg.auto() is False and dlg.recent_list.count() == 2
    dlg.add_window(0); dlg.add_window(0)                                  # the duplicate is refused
    assert dlg.rules() == [{"class": "konsole"}, {"class": "X-Plane"}] and "ya existe" in dlg.msg.text()
    dlg.add_window(1); assert dlg.rules()[-1] == {"class": "resource-only"}    # falls back to the resource name
    dlg.add_manual("steam_app_*", "Flight (Sim|Gear)"); assert dlg.rules()[-1] == {"class": "steam_app_*", "title": "Flight (Sim|Gear)"}
    n = len(dlg.rules())
    dlg.add_manual("", "(unclosed"); assert len(dlg.rules()) == n and "no válida" in dlg.msg.text()
    dlg.add_manual("  ", "  "); assert len(dlg.rules()) == n and "Escribe" in dlg.msg.text()
    dlg.add_window(99); dlg.remove(99); dlg.remove(-1); assert len(dlg.rules()) == n               # out-of-range is harmless
    dlg.remove(0); assert {"class": "konsole"} not in dlg.rules()
    assert matchdialog.describe({"class": "a", "title": "b"}) == "clase: a  ·  título: b"


def test_editor_associates_a_profile_with_applications_and_marks_it_in_the_list():
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)

        class FakeDialog:
            def exec(self): return True
            def rules(self): return [{"class": "X-Plane*"}]
            def auto(self): return False
        w.make_match_dialog = lambda: FakeDialog()
        w.edit_matches()
        assert w.model.match() == [{"class": "X-Plane*"}] and w.model.dirty
        assert ["auto", "off"] in calls
        assert "🎮" in w.scenes.item(0).text() and "X-Plane*" in w.scenes.item(0).toolTip()
        w.save_and_apply()
        assert profiles.match_rules()["General"] == [{"class": "X-Plane*"}]
        class Cancel:
            def exec(self): return False
        w.make_match_dialog = lambda: Cancel(); before = list(w.model.match()); w.edit_matches()
        assert w.model.match() == before                                                  # cancelling changes nothing
        w.close()


def test_auto_profile_setting_is_persisted_and_validated():
    from streamstation.service import Service
    with tempfile.TemporaryDirectory() as tmp:
        cfg = isolate(tmp)
        assert profiles.load_settings()["auto_profile"] is True
        profiles.save_setting("auto_profile", False)
        assert profiles.load_settings()["auto_profile"] is False
        try: profiles.save_setting("nope", 1)
        except KeyError: pass
        else: raise AssertionError
        write_profile(cfg, "General", {"name": "General", "keys": {}})
        d = Service(profile="General", sock_path=os.path.join(tmp, "s.sock"))
        assert d.auto is False                                                            # read at start
        d.command(["auto", "on"])
        assert yaml.safe_load(open(os.path.join(cfg, "config.yaml")))["auto_profile"] is True
        d.close_sockets()


def test_xplane_commands_appear_in_the_tree_and_become_keys_with_a_state():
    from streamstation.xplane import catalog as xc
    with tempfile.TemporaryDirectory() as tmp:
        d = os.path.join(tmp, "X-Plane 12", "Resources", "plugins"); os.makedirs(d)
        open(os.path.join(d, "Commands.txt"), "w").write(
            "sim/lights/landing_lights_toggle    Landing lights toggle.\nsim/flight_controls/landing_gear_down    Gear down.\nsim/view/chase    Chase view.\n")
        open(os.path.join(d, "DataRefs.txt"), "w").write("2 1\nsim/cockpit/electrical/landing_lights_on\tint\ty\tboolean\tLights\t\n")
        w, calls, cfg = _window(tmp)
        profiles.save_setting("xplane_dir", os.path.join(tmp, "X-Plane 12"))
        w._xp = None
        w._fill_tree("")
        tops = [w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount())]
        assert any("X-Plane · Luces" in t for t in tops)
        item = next(w.tree.topLevelItem(i).child(0) for i in range(w.tree.topLevelItemCount()) if "X-Plane · Luces" in w.tree.topLevelItem(i).text(0))
        payload = item.data(0, 256)
        assert payload["kind"] == "xplane" and not item.icon(0).isNull()
        w.board.dropped.emit(2, payload)
        e = w.model.get(2)
        assert e["action"] == "xp:cmd:sim/lights/landing_lights_toggle" and e["xp"]["dataref"] == "sim/cockpit/electrical/landing_lights_on"
        assert e["xp"]["glyph"] == "bulb" and os.path.isfile(os.path.join(cfg, "assets", e["icon"]))
        w._on_selected("key", 2)
        assert not w.panel.xp_box.isHidden() and w.panel.xp_dataref.text() == e["xp"]["dataref"]
        w.panel.xp_template.setCurrentText("off_armed_on"); w.panel._xp_changed()
        assert w.model.get(2)["xp"]["template"] == "off_armed_on"
        w._fill_tree("chase")                                       # search narrows the X-Plane list
        assert [w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount())][-1:] != [] 
        w.close()


def test_xplane_key_can_be_split_into_two_lamps_and_back():
    from streamstation.ui import configpanel
    single = {"glyph": "bulb", "dataref": "sim/cockpit/electrical/landing_lights_on", "template": "onoff"}
    two = configpanel.xp_to_split(single)
    assert two["bottom"]["dataref"] == single["dataref"] and two["top"] == {"template": "warning"} and "dataref" not in two
    assert configpanel.xp_to_single(two) == single
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.model.set(0, 0, {"label": "AP", "action": "xp:cmd:sim/autopilot/servos_toggle", "xp": dict(single)})
        w._on_selected("key", 0)
        assert not w.panel.xp_two.isHidden() and not w.panel.xp_two.isChecked() and w.panel.xp_lamps.isHidden()
        w.panel.xp_two.setChecked(True)
        e = w.model.get(0)
        assert "bottom" in e["xp"] and not w.panel.xp_lamps.isHidden() and w.panel.xp_bottom.text() == single["dataref"]
        w.panel.xp_top.setText("sim/cockpit2/annunciators/autopilot_disconnect"); w.panel._xp_changed()
        assert w.model.get(0)["xp"]["top"]["dataref"] == "sim/cockpit2/annunciators/autopilot_disconnect"
        assert "luz arriba" in w.panel.what.text()
        w.panel.xp_two.setChecked(False)
        assert w.model.get(0)["xp"]["dataref"] == single["dataref"] and "top" not in w.model.get(0)["xp"]
        w.close()


def test_aircraft_picker_lists_controls_and_a_control_becomes_a_key_with_its_lamp():
    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, "X-Plane 12"); pl = os.path.join(root, "Resources", "plugins"); os.makedirs(pl)
        open(os.path.join(pl, "Commands.txt"), "w").write("sim/lights/nav_lights_on    Nav lights on.\n")
        open(os.path.join(pl, "DataRefs.txt"), "w").write("2 1\nsim/a/b\tint\ty\tboolean\tx\t\n")
        ac = os.path.join(root, "Aircraft", "Other Aircraft", "Fake 737"); os.makedirs(ac)
        open(os.path.join(ac, "f.acf"), "w").write("I\n")
        open(os.path.join(ac, "F_Datarefs.txt"), "w").write("AUTOPILOT LIGHTS (read only)\n----------------------------\nN1\t\tfake/ap/n1_status\n")
        open(os.path.join(ac, "F_Commands.txt"), "w").write("fake/ap/n1_press\tAutopilot N1 press\n")
        w, calls, cfg = _window(tmp)
        profiles.save_setting("xplane_dir", root)
        w._xp = None; w.__dict__.pop("_ac_cache", None)
        w._fill_tree("")
        tops = [w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount())]
        assert any("Elegir avión de X-Plane" in t for t in tops) and not any("Fake 737 ·" in t for t in tops)
        picker = next(w.tree.topLevelItem(i) for i in range(w.tree.topLevelItemCount()) if "Elegir avión" in w.tree.topLevelItem(i).text(0))
        assert "Detectar" in picker.child(0).text(0)
        w._activate(picker.child(1), 0)                                   # choose the aircraft
        assert profiles.load_settings()["xplane_aircraft"] == "Fake 737"
        group = next(w.tree.topLevelItem(i) for i in range(w.tree.topLevelItemCount()) if "Fake 737 · AUTOPILOT LIGHTS" in w.tree.topLevelItem(i).text(0))
        payload = group.child(0).data(0, 256)
        assert payload["kind"] == "xplane_ctl" and payload["command"] == "fake/ap/n1_press" and payload["state"] == "fake/ap/n1_status"
        assert "85%" in group.child(0).toolTip(0)
        w.board.dropped.emit(1, payload)
        e = w.model.get(1)
        assert e["action"] == "xp:cmd:fake/ap/n1_press" and e["xp"]["dataref"] == "fake/ap/n1_status" and e["label"] == "N1"
        assert os.path.isfile(os.path.join(cfg, "assets", e["icon"]))
        w._fill_tree("n1"); assert any("Fake 737 ·" in w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount()))
        w._fill_tree("zzzz"); assert not any("Fake 737 ·" in w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount()))
        w.close()


def test_editor_follows_the_detected_aircraft_unless_one_was_chosen_by_hand():
    with tempfile.TemporaryDirectory() as tmp:
        root = os.path.join(tmp, "X-Plane 12"); pl = os.path.join(root, "Resources", "plugins"); os.makedirs(pl)
        open(os.path.join(pl, "Commands.txt"), "w").write("sim/lights/nav_lights_on    Nav lights on.\n")
        for n, cmd in (("Plane A", "a/ap/go_press"), ("Plane B", "b/ap/go_press")):
            d = os.path.join(root, "Aircraft", "Other Aircraft", n); os.makedirs(d)
            open(os.path.join(d, "x.acf"), "w").write("I\n")
            open(os.path.join(d, "X_Commands.txt"), "w").write(f"{cmd}\tGo {n}\n")
        w, calls, cfg = _window(tmp)
        profiles.save_setting("xplane_dir", root)
        w._xp = None; w.__dict__.pop("_ac_cache", None)
        titles = lambda: [w.tree.topLevelItem(i).text(0) for i in range(w.tree.topLevelItemCount())]
        w._detected, w._detected_shown = "Aircraft/Other Aircraft/Plane A/x.acf", None
        w._detected_changed()
        assert any("detectado: Plane A" in t for t in titles()) and any(t.endswith("Plane A · Controles") or "Plane A ·" in t for t in titles())
        w._detected = "Aircraft/Other Aircraft/Plane B/x.acf"; w._detected_changed()
        assert any("detectado: Plane B" in t for t in titles())                       # follows the simulator
        w._detected = None; w._detected_changed()
        assert not any("Plane B ·" in t for t in titles())                            # sim closed: nothing to list
        profiles.save_setting("xplane_aircraft", "Plane A"); w._fill_tree("")
        w._detected = "Aircraft/Other Aircraft/Plane B/x.acf"; w._detected_changed()
        assert any("elegido: Plane A" in t for t in titles()) and not any("Plane B ·" in t for t in titles())   # a manual choice wins
        picker = next(w.tree.topLevelItem(i) for i in range(w.tree.topLevelItemCount()) if "Elegir avión" in w.tree.topLevelItem(i).text(0))
        w._activate(picker.child(0), 0)                                               # "Detectar automáticamente"
        assert profiles.load_settings()["xplane_aircraft"] == "" and any("detectado: Plane B" in t for t in titles())
        w.close()


def test_pages_can_be_removed_from_the_editor_and_the_model():
    from streamstation.ui import model as M
    m = M.ProfileModel.__new__(M.ProfileModel)
    m.raw = {"keys": {"0": {"label": "P1"}}, "pages": [{"keys": {"0": {"label": "P2"}}}, {"keys": {}}]}; m.dirty = False
    assert m.page_count() == 3 and m.page_has_keys(1) and not m.page_has_keys(2)
    assert m.remove_page(2) and m.page_count() == 2 and m.get(0, 1)["label"] == "P2" and m.dirty        # an empty last page
    assert m.remove_page(0) and m.page_count() == 1 and m.get(0, 0)["label"] == "P2"                        # removing page 1 promotes page 2
    assert "pages" not in m.raw and not m.remove_page(0)                                                    # the last page stays
    assert not m.remove_page(5)
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.add_page(); w.add_page()
        assert w.model.page_count() == 3 and w.page == 2
        w.model.set(0, 2, {"label": "X", "action": "echo"})
        asked = []
        QM = sys.modules["streamstation.ui.mainwindow"].QMessageBox
        QM.question = staticmethod(lambda *a, **k: asked.append(a[2]) or QM.No)
        w.remove_page(2); assert w.model.page_count() == 3 and asked                                        # declined: kept
        QM.question = staticmethod(lambda *a, **k: QM.Yes)
        w.remove_page(2); assert w.model.page_count() == 2 and w.page == 1 and "eliminada" in w.panel.status.text()
        w.remove_page(1); assert w.model.page_count() == 1 and w.page == 0                                  # empty page: no question
        w.remove_page(0); assert w.model.page_count() == 1 and "única" in w.panel.status.text()
        b = w.pages_row.itemAt(1).widget()
        assert b.contextMenuPolicy() == 2 or b.contextMenuPolicy().name == "CustomContextMenu"
        w.close()


def test_strip_per_page_model_and_editor_switch():
    from streamstation.ui import model as M
    m = M.ProfileModel.__new__(M.ProfileModel)
    m.dirty = False; m.view_page = 0
    m.raw = {"keys": {}, "strip": {"segments": [{"type": "text", "text": "UNO"}, None, None, None]},
             "pages": [{"keys": {}}, {"0": {"label": "legacy flat page"}}]}
    assert m.strip_mode() == "fixed" and m.segments()[0]["text"] == "UNO"
    m.view_page = 1
    assert m.segments()[0]["text"] == "UNO"                         # fixed: every page edits the same strip
    m.set_strip_mode("per_page")
    assert m.strip_mode() == "per_page" and m.dirty
    assert m.raw["pages"][0]["strip"]["segments"][0]["text"] == "UNO"          # existing pages got a copy, none turned blank
    assert m.raw["pages"][1]["keys"]["0"]["label"] == "legacy flat page" and "strip" in m.raw["pages"][1]   # legacy page was wrapped, its keys kept
    m.set_segment(0, {"type": "text", "text": "DOS"})
    assert m.segments()[0]["text"] == "DOS" and m.raw["strip"]["segments"][0]["text"] == "UNO"   # page 2 changed, page 1 did not
    m.view_page = 0; assert m.segments()[0]["text"] == "UNO"
    m.set_touch(2, "echo x"); assert m.touch(2) == "echo x" and "touch" not in m.raw["pages"][0]["strip"]
    n = m.add_page(); assert m.raw["pages"][n - 1]["strip"] == {}                                 # a new page starts with a black strip
    m.view_page = n; assert m.segments() == [None] * 4 and m.full() is None; m.view_page = 1
    m.remove_page(0)                                                                              # page 2 becomes page 1, with its strip
    assert m.raw["strip"]["segments"][0]["text"] == "DOS" and m.raw["keys"] == {}
    m.set_strip_mode("fixed"); assert m.strip_mode() == "fixed" and "strip_mode" not in m.raw
    assert m.raw["pages"][0]["strip"]                                                             # per-page strips are kept, just unused


def test_editor_mode_selector_changes_the_profile_and_follows_the_page():
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.add_page()                                                    # page 2
        w.set_page(0); w._on_selected("strip", 0)
        assert w.strip_panel.mode_fixed.isChecked() and not w.strip_panel.mode_page.isChecked() and "página" not in w.strip_panel.title.text()
        w.strip_panel.mode_page.click()
        assert w.model.strip_mode() == "per_page" and "Sin guardar" in w.strip_panel.status.text()
        assert w.strip_panel.mode_page.isChecked() and not w.strip_panel.mode_fixed.isChecked()
        w.strip_panel.mode_page.click(); assert w.strip_panel.mode_page.isChecked()               # clicking the ticked one never leaves both empty
        w.set_page(1); w._on_selected("strip", 0)
        assert "página 2" in w.strip_panel.title.text() and w.strip_panel.mode_page.isChecked()
        w.strip_panel.text.setPlainText("solo pag 2"); w.strip_panel.type.setCurrentIndex(w.strip_panel.type.findData("text"))
        assert w.model.view_page == 1 and w.model.raw["pages"][0].get("strip") is not None
        w.save_and_apply()
        prof = profiles.load("General")
        assert prof.strip_mode == "per_page" and prof.strip_for(1) is not None
        w.close()


def test_strip_panel_offers_fonts_for_text_and_data_and_keeps_the_choice():
    from streamstation import fonts
    usable = fonts.usable()
    if not usable:
        return
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        p = w.strip_panel
        assert p.text_font.itemText(0) == "Predeterminada" and p.text_font.count() == len(usable) + 1
        fam = usable[min(2, len(usable) - 1)]["family"]
        w._on_selected("strip", 0)
        p.type.setCurrentIndex(p.type.findData("text")); p.text.setPlainText("Hola")
        p.text_font.setCurrentIndex(p.text_font.findData(fam))
        assert w.model.segments()[0]["font"] == fam and w.model.segments()[0]["text"] == "Hola"
        p.type.setCurrentIndex(p.type.findData("metric"))
        p.metric_font.setCurrentIndex(p.metric_font.findData(fam))
        assert w.model.segments()[0] == {"type": "metric", "kind": p.metric_box.currentData(), "font": fam}
        p.metric_font.setCurrentIndex(0)
        assert "font" not in w.model.segments()[0]                              # "Predeterminada" stores nothing
        w.model.set_segment(1, {"type": "text", "text": "x", "font": "Fuente Que No Existe"})
        w._on_selected("strip", 1)
        assert "no instalada" in p.text_font.currentText() and p.current_spec()["font"] == "Fuente Que No Existe"   # kept, not lost
        w.close()


def test_gear_opens_settings_and_a_new_icon_style_remakes_the_profile_icons():
    from streamstation.ui import actionicons, settingsdialog
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.assign(0, {"kind": "catalog", "label": "Silenciar", "action": "volume:mute", "plugin": "quickcontrol.mute", "group": "Audio"})
        w.save_and_apply()
        old_icon = w.model.get(0)["icon"]
        assert actionicons.current_style() == "pastel"
        dlg = settingsdialog.SettingsDialog("pastel", w)
        assert set(dlg.radios) == {"pastel", "neon", "line", "miami", "industrial"} and dlg.style() == "pastel" and not hasattr(dlg, "apply_existing")
        dlg.radios["neon"].click(); assert dlg.style() == "neon" and not dlg.radios["pastel"].isChecked()    # one style at a time
        w.make_settings_dialog = lambda: type("D", (), {"exec": lambda s: True, "style": lambda s: "neon"})()
        assert w.settings_btn.toolTip() == "Configuración"
        w.settings_btn.click()
        assert actionicons.current_style() == "neon" and profiles.load_settings()["icon_style"] == "neon"
        new_icon = w.model.get(0)["icon"]
        assert new_icon != old_icon and "neon" in new_icon                                                  # a separate file per style
        assert os.path.isfile(os.path.join(cfg, "assets", new_icon)) and os.path.isfile(os.path.join(cfg, "assets", old_icon))
        assert "Neón" in w.panel.status.text() and "todos los iconos" in w.panel.status.text()
        assert w.tree.topLevelItemCount() > 3                                                              # the list was redrawn
        # unsaved edits no longer block it: the icons change everywhere and the edits stay pending
        w.model.set(1, 0, {"label": "x", "action": "echo x", "icon": new_icon}); w.model.dirty = True
        w.make_settings_dialog = lambda: type("D", (), {"exec": lambda s: True, "style": lambda s: "line"})()
        w.settings_btn.click()
        assert actionicons.current_style() == "line" and w.model.dirty and "todos los iconos" in w.panel.status.text()
        assert "line" in w.model.get(0)["icon"] and "line" in w.model.get(1)["icon"]            # in memory, with the pending key
        on_disk = profiles.load("General")
        assert "line" in on_disk.key(0)["icon"] and on_disk.key(1) is None                      # on disk too; the unsaved key is not saved
        w.close()


def test_changing_the_icon_style_changes_every_configured_key_including_applications():
    from PIL import Image, ImageChops
    from streamstation.ui import actionicons, configpanel
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.assign(0, {"kind": "catalog", "label": "Silenciar", "action": "volume:mute", "plugin": "quickcontrol.mute", "group": "Audio"})
        w.assign(1, {"kind": "app", "id": "org.kde.dolphin", "name": "Dolphin", "icon": "org.kde.dolphin"})
        os.makedirs(os.path.join(cfg, "assets", "icons", "user"), exist_ok=True)
        for n in ("vieja.png", "vieja2.png"):                       # old icons from before the style change (generic grey squares)
            Image.new("RGB", (128, 128), (120, 120, 120)).save(os.path.join(cfg, "assets", "icons", "user", n))
        w.model.set(2, 0, {"label": "Texto", "action": "text:Prueba", "icon": "icons/user/vieja.png"})
        w.model.set(3, 0, {"label": "Carpeta", "action": "open:/tmp", "icon": "icons/user/vieja2.png"})
        w.assign(4, {"kind": "xplane", "name": "sim/lights/landing_lights_toggle", "title": "Landing lights", "description": ""})
        w.save_and_apply()
        base = {i: w.model.get(i)["icon"] for i in range(5)}
        pixels = lambda i: Image.open(os.path.join(cfg, "assets", w.model.get(i)["icon"])).convert("RGB")
        before = {i: pixels(i) for i in range(5)}
        w.make_settings_dialog = lambda: type("D", (), {"exec": lambda s: True, "style": lambda s: "neon"})()
        w.settings_btn.click()
        for i in range(5):
            assert w.model.get(i)["icon"] != base[i], i                                    # a new file for every key
            assert ImageChops.difference(pixels(i), before[i]).getbbox() is not None, i    # and a different picture, apps too
            assert pixels(i).getpixel((1, 1)) == (8, 8, 12), i                              # all on the neon black
        assert w.model.get(2)["action"] == "text:Prueba" and w.model.get(1)["action"] == "open:org.kde.dolphin"   # nothing else changed
        saved = profiles.load("General")
        assert saved.key(2)["icon"] == w.model.get(2)["icon"]                               # and it was saved to the profile file
        w.close()


def test_configured_keys_show_a_floating_description_on_hover():
    from PySide6.QtCore import QEvent, QPoint, QPointF
    from PySide6.QtGui import QHelpEvent
    from PySide6.QtWidgets import QApplication, QToolTip
    from streamstation.ui import model as M
    assert M.describe_action("volume:mute") == "Silenciar" and M.describe_action("volume:up:5") == "Subir volumen"
    assert M.describe_action("url:https://example.org") == "Sitio web: https://example.org"
    assert M.describe_action("key:ctrl+r") == "Atajo de teclado: ctrl+r" and M.describe_action("text:hola") == "Texto: hola"
    assert M.describe_action("open:firefox") == "Abrir app o archivo: firefox" and M.describe_action("echo hi") == "Ejecutar: echo hi"
    assert M.describe_action("xp:cmd:sim/a/b") == "Comando de X-Plane: sim/a/b" and "3 pasos" in M.describe_action([1, 2, 3])
    assert M.describe_action({"toggle": [1, 2]}) == "Alternar entre acciones" and M.describe_action(None) == "Sin acción"
    tip = M.tooltip({"label": "Silenciar <b>", "action": "volume:mute"})
    assert tip == "<b>Silenciar &lt;b&gt;</b><br>Silenciar" and M.tooltip(None) == ""                   # escaped, nothing for empty keys
    assert "Cambiar al perfil «X»" in M.tooltip({"label": "p", "profile": "X"})
    xp = M.tooltip({"label": "AP", "action": "xp:cmd:c", "xp": {"top": {"dataref": "a/fault"}, "bottom": {"dataref": ["b/on", "b/x"]}}})
    assert "Luz de arriba: a/fault" in xp and "Luz de abajo: b/on, b/x" in xp
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.assign(0, {"kind": "catalog", "label": "Silenciar", "action": "volume:mute", "plugin": "quickcontrol.mute", "group": "Audio"})
        w.show(); QApplication.processEvents()
        rect = w.board._key_rect(0); empty = w.board._key_rect(1)
        assert "Silenciar" in w.board.tip_at(rect.center()) and w.board.tip_at(empty.center()) == ""     # only configured keys
        assert w.board.tip_at(w.board._strip_rect().center()) == ""
        QToolTip.hideText()
        ev = QHelpEvent(QEvent.ToolTip, rect.center().toPoint(), w.board.mapToGlobal(rect.center().toPoint()))
        QApplication.sendEvent(w.board, ev)
        assert "Silenciar" in QToolTip.text()                                                           # the real tooltip appears
        QToolTip.hideText()
        w.close()


def test_a_service_dragged_to_a_key_gets_its_action_its_own_icon_and_a_description():
    from PIL import Image
    from streamstation.ui import actionicons, model as M
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w._fill_tree("")
        group = next(w.tree.topLevelItem(i) for i in range(w.tree.topLevelItemCount()) if w.tree.topLevelItem(i).text(0).endswith("Servicios"))
        titles = [group.child(i).text(0).strip() for i in range(group.childCount())]
        assert titles[:3] == ["YouTube", "YouTube Music", "Spotify"] and not group.child(0).icon(0).isNull()   # with its key preview
        payload = group.child(2).data(0, 256)
        assert payload["action"] == "service:spotify"
        w.board.dropped.emit(0, payload)
        e = w.model.get(0)
        assert e["action"] == "service:spotify" and e["label"] == "Spotify"
        icon = Image.open(os.path.join(cfg, "assets", e["icon"])).convert("RGB")
        assert icon.size == (128, 128) and icon.getpixel((64, 64)) != icon.getpixel((4, 4))
        expect = actionicons.tile("svc_spotify", "Servicios", 128, "pastel").convert("RGB")
        assert list(icon.getdata()) == list(expect.getdata())                     # exactly the Spotify pictogram in the current style
        assert M.tooltip(e) == "<b>Spotify</b><br>Spotify"
        w._fill_tree("youtube")
        names = [w.tree.topLevelItem(i).child(j).text(0).strip() for i in range(w.tree.topLevelItemCount())
                 for j in range(w.tree.topLevelItem(i).childCount()) if w.tree.topLevelItem(i).text(0).endswith("Servicios")]
        assert names == ["YouTube", "YouTube Music"]                               # the search finds both
        w.close()


def test_settings_button_downloads_the_logos_and_redraws_the_service_keys():
    from streamstation import logos
    from streamstation.ui import settingsdialog
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.assign(0, {"kind": "catalog", "label": "YouTube", "action": "service:youtube", "plugin": "—", "group": "Servicios"})
        w.save_and_apply()
        before = w.model.get(0)["icon"]
        dlg = settingsdialog.SettingsDialog("pastel", w)
        assert dlg.logos_btn.text() == "Descargar los logos de los servicios" and "Faltan" in dlg.logos_note.text()
        svg = b'<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M2 2h20v20H2z"/></svg>'

        class R:
            def __enter__(s): return s
            def __exit__(s, *a): return False
            def read(s): return svg
        real = logos.fetch
        logos.fetch = lambda ids=None, opener=None, out=print: real(ids, lambda req, timeout=0: R(), out)
        try:
            dlg.fetch_logos_requested.connect(lambda: w.fetch_logos(dlg))
            dlg.logos_btn.click()
        finally:
            logos.fetch = real
        assert "12 logos descargados" in dlg.logos_note.text() and dlg.logos_btn.text() == "Volver a descargar los logos"
        assert logos.missing() == [] and os.path.isfile(logos.path("youtube"))
        assert w.model.get(0)["icon"] != before                                      # the key was redrawn with the real mark
        assert "12 logos descargados" in w.panel.status.text()
        w.close()


def test_weather_panel_searches_a_city_picks_it_and_saves_the_spec():
    from streamstation import weather
    GEO = {"results": [{"name": "Rosario", "latitude": -32.94682, "longitude": -60.63932, "admin1": "Santa Fe", "country": "Argentina"},
                       {"name": "Rosario", "latitude": 10.3, "longitude": -72.3, "admin1": "Zulia", "country": "Venezuela"}]}
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        p = w.strip_panel
        assert p.type.findData("weather") >= 0 and p.type.itemText(p.type.findData("weather")) == "Clima"
        w._on_selected("strip", 1)
        p.type.setCurrentIndex(p.type.findData("weather"))
        assert w.model.segments()[1] == {"type": "weather"} and "Ninguna" in p.place_current.text()      # no city yet
        real = weather.search
        weather.search = lambda q, count=6, opener=None, lang="es": real(q, opener=_FakeGeo(GEO))
        try:
            p.place_query.setText("Rosario"); p.place_search.click()
        finally:
            weather.search = real
        assert not p.place_results.isHidden() and p.place_results.count() == 2 and "2 resultado" in p.status.text()
        assert p.place_results.itemText(0) == "Rosario, Santa Fe, Argentina"
        p.place_results.setCurrentIndex(0); p._place_picked()
        spec = w.model.segments()[1]
        assert spec["place"] == {"name": "Rosario", "lat": -32.9468, "lon": -60.6393, "label": "Rosario, Santa Fe, Argentina"} and "units" not in spec
        assert "Rosario, Santa Fe" in p.place_current.text()
        p.unit_f.click(); assert w.model.segments()[1]["units"] == "f" and p.unit_f.isChecked() and not p.unit_c.isChecked()   # one unit at a time
        p.unit_c.click(); assert "units" not in w.model.segments()[1]
        from streamstation import fonts
        if fonts.usable():
            fam = fonts.usable()[0]["family"]
            p.weather_font.setCurrentIndex(p.weather_font.findData(fam)); assert w.model.segments()[1]["font"] == fam
        w.save_and_apply()
        saved = profiles.load("General").strip_content(0)["segments"][1]
        assert saved["type"] == "weather" and saved["place"]["name"] == "Rosario"                      # and the service's profile reads it
        w._on_selected("strip", 0); w._on_selected("strip", 1)                                          # reselecting loads the spec back
        assert "Rosario, Santa Fe" in p.place_current.text() and p.type.currentData() == "weather"
        # errors and empty results are told, not hidden
        weather.search = lambda *a, **k: (_ for _ in ()).throw(weather.WeatherError("sin red"))
        try:
            p.place_query.setText("x"); p.place_search.click()
            assert "conexión" in p.status.text()
            weather.search = lambda *a, **k: []
            p.place_query.setText("Zzzz"); p.place_search.click()
            assert "No encontré" in p.status.text()
            p.place_query.setText("  "); w._search_place("  "); assert "Escribe" in p.status.text()
        finally:
            weather.search = real
        w.close()


class _FakeGeo:
    def __init__(self, payload): self.payload = payload
    def __call__(self, req, timeout=0):
        import io, json
        class R(io.BytesIO):
            def __enter__(s): return s
            def __exit__(s, *a): return False
        return R(json.dumps(self.payload).encode())


def test_choosing_a_theme_in_settings_shows_it_before_ok_and_cancel_puts_the_old_one_back():
    from streamstation.ui import theme, settingsdialog
    from PySide6.QtWidgets import QDialog
    with tempfile.TemporaryDirectory() as tmp:
        w, _calls, _cfg = _window(tmp)
        try:
            theme.apply("dark")
            for outcome, expected, saved in ((False, "dark", "dark"), (True, "light", "light")):
                def make(outcome=outcome):
                    d = settingsdialog.SettingsDialog("line", w, "es", "dark")
                    def run():
                        d.theme_buttons["light"].click()                  # the mere choice...
                        assert theme.current == "light"                   # ...already changes the whole interface
                        return outcome
                    d.exec = run
                    return d
                w.make_settings_dialog = make
                w.open_settings()
                assert theme.current == expected and str(profiles.load_settings().get("theme")) == saved
        finally:
            theme.apply("dark"); _qapp().setStyleSheet(theme.qss())


def test_strip_panel_page_swipe_option_is_saved_in_the_profile_and_read_back():
    with tempfile.TemporaryDirectory() as tmp:
        w, calls, cfg = _window(tmp)
        w.on_select = None
        w._on_selected("strip", 1)
        box = w.strip_panel.swipe_box
        assert not box.isChecked() and "deslizamiento" in box.text() and box.toolTip()
        box.click()
        assert w.model.page_swipe() and w.model.raw["page_swipe"] is True and w.model.dirty
        w.model.save()
        assert profiles.load("General").page_swipe is True
        w._on_selected("strip", 2); assert w.strip_panel.swipe_box.isChecked()      # still ticked on another segment
        w.strip_panel.swipe_box.click()
        w.model.save(); assert profiles.load("General").page_swipe is False and "page_swipe" not in w.model.raw
