"""The three icons of the theme chooser, drawn by code: a sun, a moon and a computer.

The computer follows the desktop: its screen is light or dark like the desktop's own theme, so the option shows
what "System" means right now.
"""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap, QPolygonF


def _canvas(size: int):
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    return pm, p


def sun(size: int = 96, color: str = "#f5b21b") -> QIcon:
    pm, p = _canvas(size)
    c, u = size / 2, size / 100
    p.setPen(Qt.NoPen); p.setBrush(QColor(color))
    p.drawEllipse(QPointF(c, c), 19 * u, 19 * u)
    pen = QPen(QColor(color), 7 * u, Qt.SolidLine, Qt.RoundCap)
    p.setPen(pen)
    for a in range(0, 360, 45):
        ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
        p.drawLine(QPointF(c + 30 * u * ca, c + 30 * u * sa), QPointF(c + 43 * u * ca, c + 43 * u * sa))
    p.end()
    return QIcon(pm)


def moon(size: int = 96, color: str = "#c9d3ff") -> QIcon:
    pm, p = _canvas(size)
    u = size / 100
    p.setPen(Qt.NoPen); p.setBrush(QColor(color))
    p.drawEllipse(QPointF(46 * u, 52 * u), 33 * u, 33 * u)
    p.setCompositionMode(QPainter.CompositionMode_Clear)
    p.drawEllipse(QPointF(64 * u, 40 * u), 29 * u, 29 * u)
    p.setCompositionMode(QPainter.CompositionMode_SourceOver)
    p.drawEllipse(QPointF(80 * u, 22 * u), 3.5 * u, 3.5 * u)
    p.drawEllipse(QPointF(88 * u, 46 * u), 2.6 * u, 2.6 * u)
    p.end()
    return QIcon(pm)


def computer(scheme: str, size: int = 96, ink: str | None = None) -> QIcon:
    """A monitor whose screen shows the desktop's scheme ("light" or "dark"), with a sun or moon on it."""
    pm, p = _canvas(size)
    u = size / 100
    dark = scheme == "dark"
    ink = ink or ("#d0d0d0" if dark else "#555555")
    screen = QColor("#1f2430" if dark else "#f4f6fb")
    p.setPen(QPen(QColor(ink), 6 * u, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)); p.setBrush(screen)
    p.drawRoundedRect(QRectF(10 * u, 14 * u, 80 * u, 54 * u), 7 * u, 7 * u)
    p.setBrush(QColor(ink)); p.setPen(Qt.NoPen)
    p.drawRect(QRectF(44 * u, 68 * u, 12 * u, 10 * u))
    p.drawRoundedRect(QRectF(28 * u, 78 * u, 44 * u, 7 * u), 3 * u, 3 * u)
    # what is on the screen: a small moon on a dark desktop, a small sun on a light one
    cx, cy = 50 * u, 41 * u
    if dark:
        p.setBrush(QColor("#c9d3ff")); p.drawEllipse(QPointF(cx, cy), 12 * u, 12 * u)
        p.setBrush(screen); p.drawEllipse(QPointF(cx + 6 * u, cy - 4 * u), 10 * u, 10 * u)
    else:
        p.setBrush(QColor("#f5b21b")); p.drawEllipse(QPointF(cx, cy), 9 * u, 9 * u)
        p.setPen(QPen(QColor("#f5b21b"), 3 * u, Qt.SolidLine, Qt.RoundCap))
        for a in range(0, 360, 45):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            p.drawLine(QPointF(cx + 13 * u * ca, cy + 13 * u * sa), QPointF(cx + 18 * u * ca, cy + 18 * u * sa))
    p.end()
    return QIcon(pm)
