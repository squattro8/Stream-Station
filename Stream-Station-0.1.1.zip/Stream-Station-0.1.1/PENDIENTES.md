# Pendientes para la versión de distribución

- **Detección de VT-Ragnaros al instalar (paquete Linux).** Si el instalador encuentra VT-Ragnaros
  (servicio `ragnarosd.service`, carpeta `~/.config/ragnaros`, etc.), debe mostrar este mensaje y CANCELAR la instalación:
  «Se ha detectado la instalación del servicio VT-Ragnaros. Esto puede generar conflictos al utilizar este programa.
  Se recomienda desinstalar VT-Ragnaros para poder utilizar todas sus funciones.»
  (El instalador actual ya no toca servicios de VT-Ragnaros; el modo `--retire-old` fue eliminado.)

- **Logo de arranque en la memoria del equipo** (comando `LOG`, ver traspaso): decodificado desde la DLL original, sin probar en vivo; requiere permiso explícito y una prueba controlada (límite 512 KB según la interfaz original, resolución por confirmar).
- **Probar la actualización contra un repositorio real** (publicar un release con un zip del proyecto y comprobar descarga + reinicio).
