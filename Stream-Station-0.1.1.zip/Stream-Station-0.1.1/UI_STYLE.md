# Guía visual (derivada de Redragon Stream Station)

Fuente: las 5 capturas de la guía de la propia app (`Guidance/0N english.gif`, 1200×800) y las cadenas de
estilo del exe (393 fragmentos QSS). Solo análisis estático; la app no se ejecutó.
No es una copia: se reproducen colores, proporciones y estructura para que quien conozca la app original se oriente.

## Estructura (medida)
| Zona | Medida | Contenido en la original → en este proyecto |
|---|---|---|
| Columna izquierda | 202 px, fondo `#2d2d2d` | 4 botones (inicio, tablero, ayuda, ajustes); lista de **escenas** con punto blanco (hueco = activa); `+`/`−`; panel **Dispositivo** con esquema blanco del equipo → perfiles |
| Centro | ~736 px, `#2d2d2d` | barra superior (avisos, tienda, avatar); **dispositivo dibujado** (2×5 teclas, franja, 4 perillas); chips de **página** `1` y `+`; línea divisoria a y=510; zona de configuración con el texto «Select the key whose action you want to configure» |
| Columna derecha | 262 px, `#232323` | buscador; pestañas **Key / Knob** (subrayado azul); árbol de categorías (Stream Dock, Toolbox, Audio Player, Operation Flow, OBS Studio, Useful notes, Weather query, Calendar, Switch audio devices, Time Options); pie «SUPPORT» |
| Interacción descrita por la app | texto de `用户指引.txt` | arrastrar un plugin del árbol al tablero; varias teclas se copian y pegan entre escenas/páginas; escenas ordenables y **ligadas a aplicaciones** |

## Paleta (muestreada de las capturas; coincide con el exe donde se indica)
| Token | Valor | Dónde | En el exe |
|---|---|---|---|
| Fondo base | `#2d2d2d` | 73 % de la ventana | `rgb(45,45,45)` (QScrollArea) |
| Fondo profundo | `#232323` | columna derecha, relleno de tecla vacía, divisores | — |
| Pantalla de franja | `#141414` | franja | — |
| Contorno / perilla | `#474747` | borde de teclas y franja, perilla, menús | `rgb(71,71,71)` |
| Campo de búsqueda | `#3b3b3b` | buscador | `rgb(59,59,59)` |
| Hover | `#3c3c3c` | botones | `rgb(60,60,60)` |
| **Acento** | `#0078ff` | subrayado de pestaña activa, selección de menú | `rgb(0,120,255)` |
| Pulsado | `#1f77b4` + borde `#1c6691` | botón pulsado | `#1f77b4`, `#1c6691` |
| Texto | `#ffffff` / `#e5e5e5` (categorías) / `#969696` (sub-ítems, `+`) | | `rgb(255,255,255)`, `rgb(150,150,150)` |
| Chip de página | `#c8c8c8` | página activa | — |
| Iconos de tecla | degradados pastel (p. ej. `#be9beb→#e998ce`, `#fdd9a1`, verde `#34a540`, rojo `#bc6a69`) | paquetes de iconos | — |

## Formas (px)
Tecla **64×64**, borde 3, radio ≈12; paso 87 × 80. Franja **420×68**, borde 2, radio ≈10. Perilla ≈64 con aro. Chip de página 26.
Radios de control en el exe: 3–12 (el más frecuente, 5). Escenas y sub-ítems 36–40 de alto; categorías 50.

## Límites
- **Tipografía:** la app no incluye ninguna fuente (solo aparecen avisos de licencia de HarmonyOS Sans, Archivo, Comfortaa y Merienda en `Licenses/`, y su tienda web pide `Microsoft YaHei, sans-serif`). Aquí se usa la fuente del sistema.
- Las capturas son de una guía (modo oscuro); no se vio ningún tema claro, aunque existen `skin/z-white` y `skin/z-black` (fotos del equipo).
- Los iconos de la original son propios; aquí se pintan placeholders hasta usar los iconos de las apps instaladas.
- Radios (≈12, ≈10) y tamaños de texto se midieron sobre una captura escalada: son aproximados.

Referencias: `docs/ui-comparacion-original-vs-maqueta.png` (izquierda original, derecha maqueta), `streamstation/ui/theme.py`.


## Iconos (importados de la app, uso personal)
Origen: `plugins/*.sdPlugin` (100 acciones), `icons/*.sdIconPack` (2 paquetes) de la instalación. Importador reproducible: `tools/import_vendor_icons.py`
(deja `assets/vendor/redragon/manifest.json` con origen y SHA-256 de cada archivo). **Son del fabricante: no redistribuir** (`assets/vendor/README.md`, `.gitignore`).

| Tipo | Medida en la app | Criterio adoptado |
|---|---|---|
| Imagen de tecla | 126×126 (57), 128×128 (14), 256×256 (11) | **128×128 PNG**, sin esquinas redondeadas (las pone la interfaz / el equipo) |
| Icono de lista | 20×20 (58), 24×24 (20), 40/48 (11); 39 con `@2x` | blanco, 20 px (usa el `@2x` cuando existe) |
| Paquetes de iconos | 256×256 | se mantienen a 256 |

**Tamaño: uniforme. Diseño: no lo era.** Las imágenes de tecla del fabricante son de cuatro familias: glifos blancos sobre transparente, cuadros pastel del paquete *Windows Controller*
(el estilo de las capturas de su guía), azulejos neón morado/magenta tipo macOS y logos de marca. Receta unificada (`ui/icons.py`), medida en los 18 iconos del paquete pastel:
fondo a sangre completa, sólido o degradado diagonal de dos tonos (paleta: `#ae9bf5→#f198c8`, `#a0a2fa→#96c0eb`, `#8cddd7→#92cce2`, `#a19bfd`, `#fcd9a1`, `#f9b09f`, `#e47379`, `#7488ba`, `#fb96c2`) y glifo casi negro al 60 %.
El color por categoría es **decisión de diseño**, no medida: la original asigna el color icono a icono.

Límites conocidos: «Alternar», «Secuencia» y «Aleatoria» comparten el mismo glifo (el fabricante solo tiene uno para *Operation Flow*); «Vista general», «Bloquear» y «Aleatoria»
usan el icono más parecido (`ALIAS_BY_ACTION`); los logos de marca (OBS, vMix, YouTube) se conservan tal cual; 2 entradas solo existían como GIF y se omitieron.
