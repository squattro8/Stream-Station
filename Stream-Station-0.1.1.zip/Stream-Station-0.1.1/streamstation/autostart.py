"""Start Stream Station when the computer starts: an XDG autostart entry for the editor plus the user service for the deck.

    status()                       -> {"enabled": bool, "minimized": bool}
    set_enabled(True, minimized)   creates the entry (and enables the service);  set_enabled(False) removes both
"""
from __future__ import annotations

import os
import subprocess

DESKTOP = "streamstation.desktop"


def autostart_dir() -> str:
    return os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "autostart")


def launcher() -> str:
    return os.path.expanduser("~/.local/bin/streamstation")


def entry_path() -> str:
    return os.path.join(autostart_dir(), DESKTOP)


def entry_text(minimized: bool, exe: str | None = None) -> str:
    exe = exe or launcher()
    return ("[Desktop Entry]\nType=Application\nName=Stream Station\nComment=Redragon Ragnaros SS-552\n"
            f"Exec={exe} ui{' --minimized' if minimized else ''}\nIcon=streamstation\nTerminal=false\n"
            "X-GNOME-Autostart-enabled=true\n")


def status() -> dict:
    try:
        text = open(entry_path()).read()
    except OSError:
        return {"enabled": False, "minimized": False}
    exec_line = next((l for l in text.splitlines() if l.startswith("Exec=")), "")
    return {"enabled": "Hidden=true" not in text, "minimized": "--minimized" in exec_line}


def set_enabled(enabled: bool, minimized: bool = False, run=subprocess.run) -> None:
    path = entry_path()
    if enabled:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w") as fh:
            fh.write(entry_text(minimized))
        os.replace(tmp, path)
    else:
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
    try:                                                    # the deck itself is driven by the user service
        run(["systemctl", "--user", "enable" if enabled else "disable", "streamstation.service"],
            capture_output=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        pass
