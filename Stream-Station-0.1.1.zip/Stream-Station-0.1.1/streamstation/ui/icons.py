"""Icon library built on the imported vendor icons (assets/vendor/redragon, personal use only).

Unified criterion, measured on the installed app:
  * key images are full-bleed 128x128 squares (no rounded corners: the UI/device rounds them)
  * background: solid or 2-stop diagonal gradient from the pastel palette below
  * glyph: near-black, centred, ~60 % of the tile
  * list icons: white glyph, 20x20 (+ @2x 40x40)
Vendor tiles that already follow this (the "Windows Controller" pack) are used as they are.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache

from PIL import Image, ImageDraw

ROOT = os.path.join(os.path.dirname(__file__), "..", "..", "assets", "vendor", "redragon")
SIZE = 128

# measured on the 18 icons of the "Windows Controller" pack (corner pixels)
PALETTE = {
    "violet": ("#ae9bf5", "#f198c8"),   # violet -> pink
    "sky":    ("#a0a2fa", "#96c0eb"),   # periwinkle -> sky
    "teal":   ("#8cddd7", "#92cce2"),   # teal -> light blue
    "lilac":  ("#a19bfd", "#a19bfd"),   # solid
    "peach":  ("#fcd9a1", "#fcd9a1"),   # solid
    "salmon": ("#f9b09f", "#f9b09f"),   # solid
    "red":    ("#e57277", "#e47379"),   # solid-ish
    "slate":  ("#7488ba", "#7488ba"),   # solid
    "pink":   ("#fb96c2", "#fb96c2"),   # solid
}
# category -> palette (design choice, not measured: the original assigns colours per icon)
CATEGORY_COLOR = {
    "Dispositivo": "peach", "Herramientas": "lilac", "Audio": "teal", "Flujo de operación": "slate",
    "Sistema": "red", "Escritorio (KDE)": "violet", "Navegador": "sky", "Red": "salmon", "Servicios": "pink",
}


# no vendor icon for these actions: borrow the closest one (design choice, listed in UI_STYLE.md)
ALIAS_BY_ACTION = {
    "lock": "system.password",                 # padlock
    "desktop:overview": "touchbar.dispatchcenter",
    "{random}": "multiactions.routine",
}
# vendor tiles in a different style: rebuild from their white list glyph (40 px @2x) instead
FROM_LIST_GLYPH = {"system.text", "system.website", "multiactions.toggle", "multiactions.routine",
                   "soundboard.playaudio", "soundboard.stopaudioplay", "network.udp",
                   "system.password", "touchbar.dispatchcenter", "system.hotkey", "system.open"}


def _hex(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def gradient(pair, size=SIZE) -> Image.Image:
    a, b = _hex(pair[0]), _hex(pair[1])
    if a == b:
        return Image.new("RGBA", (size, size), a + (255,))
    img = Image.new("RGBA", (size, size))
    px = img.load()
    for y in range(size):
        for x in range(size):
            t = (x + y) / (2 * (size - 1))
            px[x, y] = tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)
    return img


def is_glyph(img: Image.Image) -> bool:
    """A single-colour shape on a mostly transparent background (browser/quickcontrol style):
    white or grey (low saturation) or one hue (e.g. the blue wifi). Multicolour logos are kept."""
    import colorsys
    im = img.convert("RGBA")
    px = [p for p in im.getdata() if p[3] > 40]
    if not px or len(px) / (im.width * im.height) > 0.6:
        return False
    hsv = [colorsys.rgb_to_hsv(p[0] / 255, p[1] / 255, p[2] / 255) for p in px[:: max(1, len(px) // 2000)]]
    if sum(h[1] for h in hsv) / len(hsv) < 0.25:
        return True
    hues = [h[0] for h in hsv if h[1] > 0.25]
    mean = sum(hues) / len(hues)
    return max(abs(h - mean) for h in hues) < 0.08


def make_tile(glyph: Image.Image, palette: str, fill=0.6, size=SIZE) -> Image.Image:
    """Recolour a white glyph to near-black and place it on a pastel tile."""
    g = glyph.convert("RGBA")
    alpha = g.getchannel("A")
    bbox = alpha.getbbox()
    if bbox:
        g, alpha = g.crop(bbox), alpha.crop(bbox)
    scale = size * fill / max(g.size)
    new = (max(1, round(g.width * scale)), max(1, round(g.height * scale)))
    alpha = alpha.resize(new, Image.LANCZOS)
    tile = gradient(PALETTE[palette] if isinstance(palette, str) else palette, size)
    black = Image.new("RGBA", new, (10, 10, 14, 255))
    tile.paste(black, ((size - new[0]) // 2, (size - new[1]) // 2), alpha)
    return tile


def fallback_tile(label: str, palette: str, glyph: str = "terminal", size=SIZE) -> Image.Image:
    """A key with a drawn icon and no text. `label` is kept for old callers and ignored: the icon says what it is."""
    from . import actionicons
    category = {"slate": "Flujo de operación", "violet": "Escritorio (KDE)", "lilac": "Herramientas", "sky": "Navegador",
                "teal": "Audio", "peach": "Dispositivo", "red": "Sistema", "salmon": "Red"}.get(palette, "Herramientas")
    return actionicons.styled_tile(actionicons.glyph(glyph, 128), category, size, palette=palette)


class IconLibrary:
    def __init__(self, root: str = ROOT):
        self.root = os.path.abspath(root)
        path = os.path.join(self.root, "manifest.json")
        self.entries = json.load(open(path))["entries"] if os.path.isfile(path) else []
        self._by_uuid: dict[tuple[str, str], str] = {}
        for e in self.entries:
            if e.get("uuid"):
                self._by_uuid[(e["uuid"], e["kind"])] = e["file"]

    @property
    def available(self) -> bool:
        return bool(self.entries)

    def _resolve(self, plugin_id: str, kind: str) -> str | None:
        """`plugin_id` is the tail of an action UUID (catalog column 3)."""
        for (uuid, k), f in self._by_uuid.items():
            if k == kind and (uuid == plugin_id or uuid.endswith("." + plugin_id)):
                return os.path.join(self.root, f)
        return None

    def list_icon_path(self, plugin_id: str, hires=True) -> str | None:
        return (hires and self._resolve(plugin_id, "action-list@2x")) or self._resolve(plugin_id, "action-list")

    def key_image(self, plugin_id: str, label: str = "", category: str = "Herramientas",
                  style: str = "unified", action: str | None = None) -> Image.Image:
        """128x128 RGBA key image. style='vendor' returns the original; 'unified' applies the recipe."""
        palette = CATEGORY_COLOR.get(category, "lilac")
        if style == "unified":
            from . import actionicons
            name = actionicons.name_for(action) if action else None
            if name or not self._resolve(plugin_id, "action-key"):
                return actionicons.tile(name or "terminal", category)      # the program's own icon, drawn by code
        plugin_id = ALIAS_BY_ACTION.get(action, plugin_id)
        if style == "unified" and plugin_id in FROM_LIST_GLYPH:
            lp = self.list_icon_path(plugin_id)
            if lp:
                return make_tile(Image.open(lp), palette)
        path = self._resolve(plugin_id, "action-key")
        if not path:
            lp = self.list_icon_path(plugin_id)
            if lp and style == "unified":
                return make_tile(Image.open(lp), palette)
            return fallback_tile(label, palette)
        img = Image.open(path).convert("RGBA")
        if style == "unified" and is_glyph(img):
            return make_tile(img, palette)
        return img


def to_qpixmap(img: Image.Image):
    """PIL RGBA -> QPixmap (imported lazily so tools without Qt can use this module)."""
    from PySide6.QtGui import QImage, QPixmap
    img = img.convert("RGBA")
    q = QImage(img.tobytes("raw", "RGBA"), img.width, img.height, QImage.Format_RGBA8888)
    return QPixmap.fromImage(q.copy())
