import time
import os, sys, pathlib, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from streamstation import protocol as P, profiles
from streamstation.service import Service
from streamstation import service

PROFILE = """name: T
keys:
  '0': {label: A, action: "echo hi"}
  '9': {label: B, layer_toggle: media}
knobs:
  '0': {rotate: {cw: up, ccw: down}, press: tap}
layers:
  media:
    keys:
      '0': {label: M, action: "echo media"}
"""


def make(tmp):
    d = pathlib.Path(tmp, "profiles"); d.mkdir()
    (d / "T.yaml").write_text(PROFILE)
    profiles.search_dirs = lambda sub: [str(d)] if sub == "profiles" else []
    return Service(profile="T", sock_path=os.path.join(tmp, "s.sock"))


def test_decode_events():
    assert P.decode_event(1, 1) == ("key", 0, True)
    assert P.decode_event(10, 0) == ("key", 9, False)
    assert P.decode_event(0xA1, 0) == ("knob", 0, 1)
    assert P.decode_event(0xA0, 0) == ("knob", 0, -1)
    assert P.decode_event(0x35, 1) == ("knob_press", 1, True)
    assert P.decode_event(0x38, 0) == ("strip_swipe", 1, None) and P.decode_event(0x39, 0) == ("strip_swipe", -1, None)
    assert P.decode_event(0x7F, 0)[0] == "unknown"


def test_slot_map_is_a_bijection_onto_confirmed_key_slots():
    assert sorted(P.KEY_TO_SLOT.values()) == list(P.KEY_SLOTS)


def test_profile_layers_and_commands():
    with tempfile.TemporaryDirectory() as tmp:
        d = make(tmp)
        assert d.profile.key(0)["label"] == "A"
        assert d.command(["layer", "media"])["ok"]
        assert d.profile.key(0, d.layer)["label"] == "M"
        assert d.profile.key(9, d.layer)["label"] == "B"   # falls through to base
        assert not d.command(["layer", "nope"])["ok"]
        assert d.command(["layer", "off"])["layer"] is None
        assert d.command(["status"])["profile"] == "T"
        assert not d.command(["bogus"])["ok"]
        d.close_sockets()


def test_handle_layer_toggle_and_knob_debounce():
    with tempfile.TemporaryDirectory() as tmp:
        d = make(tmp)
        calls = []
        d.run_action = calls.append
        d.handle(("key", 9, True))
        assert d.layer == "media"
        d.handle(("key", 9, True))
        assert d.layer is None
        d.handle(("knob", 0, 1)); d.handle(("knob", 0, 1))   # burst -> one action
        d.handle(("knob_press", 0, True))
        assert calls == ["up", "tap"]
        d.close_sockets()


class FakeDeck:
    def __init__(self):
        self.sent = []

    def send(self, packet, timeout=1000):
        self.sent.append(packet)

    def cmds(self):
        return [p[5:8] for p in self.sent if p[:3] == b"CRT"]


def make_with(tmp, text):
    d = pathlib.Path(tmp, "profiles"); d.mkdir(exist_ok=True)
    (d / "T.yaml").write_text(text)
    profiles.search_dirs = lambda sub: [str(d)] if sub == "profiles" else []
    profiles.CONFIG = os.path.join(tmp, "cfg")             # settings the service saves (brightness) never reach the real config
    dm = Service(profile="T", sock_path=os.path.join(tmp, "s.sock"))
    dm.deck = FakeDeck()
    dm.settings = dict(profiles.DEFAULT_SETTINGS, follow_lock=False)
    return dm


def test_idle_screen_off_and_wake_swallows_press():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.settings["screen_off_s"] = 60
        d._last_input = 1000.0
        d.tick(now=1030.0)
        assert not d.sleeping
        d.tick(now=1061.0)
        assert d.sleeping and d.deck.cmds()[-1] == b"HAN"        # addScreenOffPack
        d.wake_deck()
        assert not d.sleeping and b"DIS" in d.deck.cmds()          # addWakeUpScreenPack
        d.close_sockets()


def test_follow_session_lock():
    from streamstation import system
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.settings["follow_lock"] = True
        state = {"locked": True}
        system.session_locked = lambda: state["locked"]
        d.tick(now=100.0)
        assert d.sleeping and d._sleep_reason == "lock"
        state["locked"] = False
        d.tick(now=110.0)
        assert not d.sleeping
        d.close_sockets()


def test_standby_not_woken_by_unlock_watch():
    from streamstation import system
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.settings["follow_lock"] = True
        system.session_locked = lambda: False
        d.run_action("screen-off")
        assert d.sleeping and d._sleep_reason == "standby"
        d.tick(now=500.0)
        assert d.sleeping            # only a lock-induced sleep is undone by unlocking
        d.close_sockets()


PAGES = """name: T
keys:
  '0': {label: P0, action: a}
pages:
  - keys:
      '0': {label: P1, action: b}
"""


def test_pages_and_system_verbs():
    from streamstation import system
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PAGES)
        assert d.profile.page_count() == 2
        d.run_action("page:next"); assert d.page == 1
        assert d.profile.key(0, None, d.page)["label"] == "P1"
        d.run_action("page:next"); assert d.page == 0         # wraps
        d.run_action("page:prev"); assert d.page == 1
        ran = []
        system.run_verb = lambda name: ran.append(name) or True
        d.run_action("lock"); d.run_action("suspend")
        assert ran == ["lock", "suspend"]
        d.close_sockets()


def test_brightness_actions_clamp():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.brightness = 95
        d.run_action("brightness+10"); assert d.brightness == 100
        d.run_action("brightness-30"); assert d.brightness == 70
        d.run_action("brightness=0"); assert d.brightness == 0
        assert [p[10] for p in d.deck.sent if p[5:8] == b"LIG"] == [100, 70, 0]
        d.close_sockets()


def test_brightness_is_remembered_for_the_next_session():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        assert d.brightness == 100                                    # nothing saved yet: full brightness
        d.run_action("brightness=30")
        assert profiles.load_settings()["brightness"] == 30
        assert d.command(["brightness", "20"])["brightness"] == 20 and profiles.load_settings()["brightness"] == 20
        d2 = Service(profile="T", sock_path=os.path.join(tmp, "s2.sock"))
        d2.deck = FakeDeck()
        assert d2.brightness == 20                                    # a new service (after a reboot) starts with it
        assert Service(profile="T", sock_path=os.path.join(tmp, "s3.sock"), brightness=80).brightness == 80   # explicit wins
        d.close_sockets(); d2.close_sockets()


def test_multi_action_runs_steps_with_delay():
    import time as _t
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        calls = []
        d.run_action = d.run_action  # real, but intercept leaf calls:
        real = d.run_action
        d._run_sequence([("x"), {"delay": 30}, "y"]) if False else None
        out = []
        orig = type(d).run_action
        d.run_action = lambda a: out.append(a)
        t0 = _t.monotonic()
        d._run_sequence(["a", {"delay": 80}, "b"])
        assert out == ["a", "b"] and _t.monotonic() - t0 >= 0.07
        d.close_sockets()


STRIP = """name: T
strip:
  touch: {'1': "echo t1", '3': "echo t3"}
  swipe: {left: "page:prev", right: "page:next"}
keys:
  '0': {label: A, action: a}
"""


def test_strip_touch_and_swipe_actions_with_debounce():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIP)
        calls = []
        d.run_action = calls.append
        assert P.decode_event(0x41, 0) == ("strip_touch", 1, None)
        d.handle(P.decode_event(0x41, 0))
        d.handle(P.decode_event(0x41, 0))          # burst -> ignored
        d._last_strip = 0.0
        d.handle(P.decode_event(0x38, 0))          # left-to-right
        d._last_strip = 0.0
        d.handle(P.decode_event(0x39, 0))          # right-to-left
        d._last_strip = 0.0
        d.handle(P.decode_event(0x40, 0))          # segment 0 has no action
        assert calls == ["echo t1", "page:next", "page:prev", None]
        d.close_sockets()


def test_swipe_any_wins_over_direction():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIP.replace("swipe: {left", "swipe: {any: 'page:next', left"))
        calls = []
        d.run_action = calls.append
        d.handle(P.decode_event(0x38, 0)); d._last_strip = 0.0
        d.handle(P.decode_event(0x39, 0))
        assert calls == ["page:next", "page:next"]
        d.close_sockets()


def test_swiping_the_strip_changes_page_when_the_profile_asks_for_it():
    with tempfile.TemporaryDirectory() as tmp:
        text = STRIP.replace("keys:", "page_swipe: true\npages:\n- keys: {'0': {label: B, action: b}}\n- keys: {'0': {label: C, action: c}}\nkeys:")
        d = make_with(tmp, text)
        calls = []
        d.run_action = calls.append                          # the swipe action of the strip must NOT run: the page changes instead
        assert d.profile.page_swipe and d.page == 0
        seen = []
        for code in (0x39, 0x39, 0x39, 0x38, 0x38, 0x38):    # right-to-left (0x39): next page; left-to-right (0x38): previous
            d._last_strip = 0.0; d.handle(P.decode_event(code, 0)); seen.append(d.page)
        assert seen == [1, 2, 0, 2, 1, 0] and calls == []    # both directions wrap around
        d._last_strip = 0.0; d.handle(P.decode_event(0x41, 0))
        assert calls == ["echo t1"]                          # touching still runs the zone's action
        d.page = 0; d._last_strip = 0.0
        d.handle(P.decode_event(0x39, 0)); d.handle(P.decode_event(0x39, 0))
        assert d.page == 1                                   # one gesture (a burst of reports) moves one page
        d.close_sockets()
        off = make_with(tmp, STRIP.replace("keys:", "pages:\n- keys: {}\nkeys:"))
        off.run_action = calls.clear() or calls.append
        off.handle(P.decode_event(0x39, 0)); assert off.page == 0 and calls == ["page:prev"]   # off: right-to-left runs swipe.left
        off.close_sockets()


def test_toggle_and_random_multiactions():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        seen = []
        real = d.run_action
        d.plugins.handles = lambda a: True
        d.plugins.run = lambda a: seen.append(a)
        tog = {"toggle": ["volume:mute", "mic:mute"]}
        for _ in range(3):
            d.run_action(tog)
        assert seen == ["volume:mute", "mic:mute", "volume:mute"]
        seen.clear()
        d.run_action({"random": ["key:a", "key:b"]})
        assert seen[0] in ("key:a", "key:b")
        d.close_sockets()


def test_failing_plugin_action_does_not_raise():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.run_action("volume:sideways")          # ValueError inside, must be contained
        d.run_action("text:ñ")
        d.close_sockets()


def _strip_slots_sent(deck):
    """Zones (0-3, left to right as the viewer sees them) or "full" for each DRA stream sent.
    Streams are aligned to 16 px so a zone's stream is 208 wide: the zone is where its centre falls."""
    out = []
    for p in deck.sent:
        if p[:3] == b"CRT" and p[5:8] == b"DRA":
            w, x = int.from_bytes(p[13:15], "big"), int.from_bytes(p[17:19], "big")
            out.append("full" if w == P.STRIP_W else int(((P.STRIP_W - x - w) + w / 2) // P.ZONE_W))
    return out


STRIPYAML = """name: T
keys:
  '0': {label: A, action: a}
strip:
  segments:
    - {type: text, text: uno}
    - {type: text, text: dos}
    - null
    - {type: text, text: tres}
"""


def test_strip_sends_only_what_changed():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIPYAML)
        d.paint_strip(force=True)
        assert _strip_slots_sent(d.deck) == [0, 1, 2, 3] and d.deck.cmds()[-1] == b"STP"
        d.deck.sent.clear()
        d.paint_strip()                                          # nothing changed -> nothing sent
        assert d.deck.sent == []
        d.profile.strip["segments"][1] = {"type": "text", "text": "DOS cambiado"}
        d.paint_strip()
        assert _strip_slots_sent(d.deck) == [1] and d.deck.cmds()[-1] == b"STP"
        d.close_sockets()


def test_strip_gif_advances_and_resends_only_the_animated_panel():
    from PIL import Image
    with tempfile.TemporaryDirectory() as tmp:
        gif = os.path.join(tmp, "a.gif")
        fr = [Image.new("RGB", (64, 32), (i * 90, 0, 0)) for i in range(3)]
        fr[0].save(gif, save_all=True, append_images=fr[1:], duration=300, loop=0)
        d = make_with(tmp, STRIPYAML)
        d.profile.strip["segments"][0] = {"type": "gif", "path": gif}
        clock = {"t": 0.0}
        real = d.strip_engine.plan
        d.strip_engine.plan = lambda c, now=None: real(c, now=clock["t"])
        d.strip_engine._t0 = 0.0
        d.paint_strip(force=True)
        d.deck.sent.clear()
        clock["t"] = 0.1; d.paint_strip(); assert d.deck.sent == []            # same frame
        clock["t"] = 0.35; d.paint_strip(); assert _strip_slots_sent(d.deck) == [0]   # next frame, panel 0 only
        d.close_sockets()


def test_strip_is_not_painted_while_the_deck_sleeps_and_repaints_on_wake():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIPYAML)
        d.paint_strip(force=True); d.deck.sent.clear()
        d.sleep_deck("manual"); d.deck.sent.clear()
        d.profile.strip["segments"][0] = {"type": "text", "text": "nuevo"}
        d.paint_strip()
        assert d.deck.sent == []
        d.wake_deck()
        assert _strip_slots_sent(d.deck) == ["full", 0, 1, 2, 3]       # wake repaints everything, black first
        d.close_sockets()


def test_profile_without_strip_config_leaves_the_strip_alone_and_dashboard_still_works():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.paint_strip(force=True); assert _strip_slots_sent(d.deck) == []
        d.close_sockets()
        d = make_with(tmp, "name: T\nstrip:\n  dashboard: [clock, cpu]\n")
        d.paint_strip(force=True)
        assert _strip_slots_sent(d.deck) == [0, 1, 2, 3]                       # 2 metrics + 2 panels cleared to dark
        plan = d.strip_engine.plan(d.profile.strip_content())
        assert plan[0][0][0] == "metric" and plan[1][0][0] == "metric" and plan[2][0] == ("empty",) == plan[3][0]
        d.close_sockets()


def test_a_changed_zone_stream_carries_its_neighbours_current_pixels():
    """The bug seen on the device: zone 4 looked bigger and zone 1 had a white stripe. When one zone
    changes, the 16 px aligned stream must show the neighbour's real colour in the extra columns."""
    import io
    from PIL import Image
    yaml_text = """name: T
strip:
  segments:
    - {type: text, text: a, bg: "#ff0000"}
    - {type: text, text: b, bg: "#00ff00"}
    - {type: text, text: c, bg: "#0000ff"}
    - {type: text, text: d, bg: "#ffff00"}
"""
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, yaml_text)
        d.paint_strip(force=True)
        d.deck.sent.clear()
        d.profile.strip["segments"][0] = {"type": "text", "text": "A!", "bg": "#ff0000"}      # only zone 1 changes
        d.paint_strip()
        stream = b"".join(p for p in d.deck.sent if p[:3] != b"CRT" or p[5:8] == b"DRA")
        head = [p for p in d.deck.sent if p[5:8] == b"DRA"]
        assert len(head) == 1
        x0, w = int.from_bytes(head[0][17:19], "big"), int.from_bytes(head[0][13:15], "big")
        total = int.from_bytes(head[0][8:12], "big")
        img = Image.open(io.BytesIO(stream[32:total])).convert("RGB")
        assert (x0 % 16, w % 16) == (0, 0) and w == 208 and x0 == 592
        spill = img.getpixel((3, 100))                      # device x=595 -> viewer x=204 -> zone 2 (green)
        assert spill[1] > 200 and spill[0] < 60 and spill[2] < 60, spill
        own = img.getpixel((w - 3, 100))                    # zone 1's own red
        assert own[0] > 200 and own[1] < 60, own
        d.close_sockets()


def _auto_service(tmp):
    """General (home), Otro, and Juego which activates for X-Plane / steam apps."""
    from streamstation import profiles as pr
    d = make_with(tmp, "name: General\nkeys:\n  '0': {label: A, action: a}\n")
    folder = pathlib.Path(tmp, "profiles")
    (folder / "General.yaml").write_text("name: General\nkeys:\n  '0': {label: A, action: a}\n")
    (folder / "Otro.yaml").write_text("name: Otro\nkeys:\n  '0': {label: O, action: o}\n")
    (folder / "Juego.yaml").write_text("name: Juego\nmatch:\n  - {class: 'X-Plane*'}\n  - {class: 'steam_app_*', title: 'Flight'}\nkeys:\n  '0': {label: J, action: j}\n")
    dm = Service(profile="General", sock_path=os.path.join(tmp, "a.sock"))
    dm.deck = FakeDeck()
    dm.settings = dict(pr.DEFAULT_SETTINGS, follow_lock=False)
    return dm


def _focus(d, cls, title="", now=0.0, name=""):
    from streamstation.windows import Window
    d._win_queue.put(Window(cls, name, title, 0, ""))
    d.process_windows(now)


def test_focus_on_a_game_switches_profile_after_the_debounce_and_returns_home():
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        _focus(d, "X-Plane", now=10.0)
        assert d.profile.name == "General"                       # not yet: focus has not settled
        d.process_windows(10.2); assert d.profile.name == "General"
        d.process_windows(10.4); assert d.profile.name == "Juego" # settled for 0.35 s
        assert d._base_profile == "General"                       # an automatic switch is not a new "home"
        _focus(d, "firefox", now=20.0); d.process_windows(20.4)
        assert d.profile.name == "General"                        # back where we came from
        d.close_sockets()


def test_a_fast_alt_tab_through_the_game_does_not_flicker():
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        _focus(d, "X-Plane", now=5.0)
        _focus(d, "firefox", now=5.1)                             # left again before it settled
        d.process_windows(5.6)
        assert d.profile.name == "General" and d._pending is None
        d.close_sockets()


def test_manual_choice_becomes_the_new_home_and_ignored_windows_change_nothing():
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        assert d.command(["profile", "Otro"])["ok"] and d._base_profile == "Otro"
        _focus(d, "steam_app_1", title="Flight Sim", now=1.0); d.process_windows(1.5)
        assert d.profile.name == "Juego"
        for ignored in ("plasmashell", "krunner", "streamstation"):
            _focus(d, ignored, now=2.0); d.process_windows(3.0)
            assert d.profile.name == "Juego", ignored             # the editor, the launcher and the shell are not "leaving"
        _focus(d, "dolphin", now=4.0); d.process_windows(4.5)
        assert d.profile.name == "Otro"                           # returns to the manual choice, not to General
        _focus(d, "steam_app_1", title="Other game", now=6.0); d.process_windows(6.5)
        assert d.profile.name == "Otro"                           # second rule needs the title too
        d.close_sockets()


def test_auto_switch_can_be_turned_off_and_recent_windows_are_still_listed():
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        assert d.command(["auto", "off"])["auto"] is False
        _focus(d, "X-Plane", now=1.0, title="Cessna"); d.process_windows(2.0)
        assert d.profile.name == "General"
        _focus(d, "firefox", now=3.0); _focus(d, "X-Plane", now=4.0)
        wins = d.command(["windows"])["windows"]
        assert [w["class"] for w in wins] == ["X-Plane", "firefox"]          # newest first, no duplicates
        st = d.command(["status"])
        assert st["auto"] is False and st["window"] == "X-Plane" and st["base"] == "General"
        assert d.command(["auto", "on"])["auto"] is True
        d.close_sockets()


def test_a_rule_pointing_at_a_missing_profile_is_ignored_and_profile_files_are_reread():
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        folder = pathlib.Path(tmp, "profiles")
        (folder / "Juego.yaml").unlink()
        _focus(d, "X-Plane", now=1.0); d.process_windows(2.0)
        assert d.profile.name == "General"                         # rules of a deleted profile are gone
        (folder / "Nuevo.yaml").write_text("name: Nuevo\nmatch:\n  - {class: konsole}\nkeys: {}\n")
        _focus(d, "konsole", now=3.0); d.process_windows(4.0)
        assert d.profile.name == "Nuevo"                           # a profile created while running is picked up
        d.close_sockets()


def test_rules_created_while_the_application_already_has_focus_take_effect():
    """Found live: a profile created for the window in front never activated until the user changed focus."""
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        folder = pathlib.Path(tmp, "profiles")
        (folder / "Juego.yaml").unlink()
        d.process_windows(0.0)                                            # first look at the rules: nothing to do
        _focus(d, "X-Plane", now=1.0); d.process_windows(2.0)
        assert d.profile.name == "General"
        (folder / "Juego.yaml").write_text("name: Juego\nmatch:\n  - {class: 'X-Plane*'}\nkeys: {}\n")
        d.process_windows(3.5)                                            # the change is noticed (checked every second)
        d.process_windows(4.0)                                            # ...and the debounce elapses
        assert d.profile.name == "Juego"
        (folder / "Juego.yaml").write_text("name: Juego\nmatch:\n  - {class: konsole}\nkeys: {}\n")
        d.process_windows(6.0); d.process_windows(7.0)
        assert d.profile.name == "General"                                # rule edited away: back to home
        d.close_sockets()


def test_apply_from_the_editor_shows_the_profile_without_making_it_the_new_home():
    """Found live: saving the X-Plane profile made it the 'home', so leaving the game stayed on X-Plane."""
    with tempfile.TemporaryDirectory() as tmp:
        d = _auto_service(tmp)
        assert d.command(["apply", "Juego"]) == {"ok": True, "profile": "Juego", "page": 1}
        assert d.profile.name == "Juego" and d._base_profile == "General"          # shown, home unchanged
        _focus(d, "firefox", now=1.0); d.process_windows(1.5)
        assert d.profile.name == "General"                                          # leaving the app goes home
        r = d.command(["apply", "NoExiste"])
        assert r["ok"] is False and "NoExiste" in r["error"] and d.profile.name == "General"
        d.command(["profile", "Otro"]); assert d._base_profile == "Otro"           # a deliberate choice still sets the home
        d.close_sockets()


def test_xplane_keys_repaint_only_when_state_changes_and_commands_run():
    from streamstation.xplane import link
    with tempfile.TemporaryDirectory() as tmp:
        d = pathlib.Path(tmp, "profiles"); d.mkdir()
        (d / "X.yaml").write_text("""name: X
keys:
  '0': {label: Luz, action: "xp:cmd:sim/lights/landing_lights_toggle", xp: {glyph: bulb, dataref: a/b, template: onoff}}
  '1': {label: Otro, action: "echo hi"}
""")
        profiles.search_dirs = lambda sub: [str(d)] if sub == "profiles" else []
        dm = Service(profile="X", sock_path=os.path.join(tmp, "s.sock"))
        sent = []
        dm.deck = object(); dm._send = sent.append
        values = {"v": 0}
        dm.xp.value = lambda ref, idx=None: values["v"]
        type(dm.xp).online = property(lambda self: True)
        dm._xp_watch = lambda: None
        dm.paint()
        sent.clear()
        dm.xp_tick(100.0); assert sent == []                      # nothing changed
        values["v"] = 1
        dm.xp_tick(101.0)
        headers = [p for p in sent if p[:8] == P.image_header(P.KEY_TO_SLOT[0] + 1, 1)[:8]]
        assert len(headers) == 1 and sent[-1] == P.stop()          # only key 0, then commit
        sent.clear(); dm.xp_tick(102.0); assert sent == []
        got = []
        dm.xp.command = got.append
        dm.run_action("xp:cmd:sim/lights/landing_lights_toggle")
        import time as _t
        for _ in range(40):
            if got: break
            _t.sleep(0.05)
        assert got == ["sim/lights/landing_lights_toggle"]
        dm.close_sockets()


def test_two_lamp_switch_repaints_when_either_lamp_changes():
    with tempfile.TemporaryDirectory() as tmp:
        d = pathlib.Path(tmp, "profiles"); d.mkdir()
        (d / "Y.yaml").write_text("""name: Y
keys:
  '0': {label: AP, action: "xp:cmd:sim/autopilot/servos_toggle", xp: {top: {dataref: a/fault, template: warning}, bottom: {dataref: a/on, template: onoff}}}
""")
        profiles.search_dirs = lambda sub: [str(d)] if sub == "profiles" else []
        dm = Service(profile="Y", sock_path=os.path.join(tmp, "s.sock"))
        sent = []
        dm.deck = object(); dm._send = sent.append
        vals = {"a/fault": 0, "a/on": 0}
        dm.xp.value = lambda ref, idx=None: vals[ref]
        type(dm.xp).online = property(lambda self: True)
        dm._xp_watch = lambda: None
        dm.paint(); sent.clear()
        dm.xp_tick(100.0); assert sent == []
        vals["a/on"] = 1; dm.xp_tick(101.0); assert sent and sent[-1] == P.stop()          # bottom lamp changed
        sent.clear(); vals["a/fault"] = 1; dm.xp_tick(102.0); assert sent                    # top lamp changed
        sent.clear(); dm.xp_tick(103.0); assert sent == []
        dm.close_sockets()


def test_every_full_repaint_first_blanks_the_whole_strip_to_black():
    with tempfile.TemporaryDirectory() as tmp:
        dm = make(tmp)
        sent = []
        dm.deck = object(); dm._send = sent.append
        dm.paint()
        draw = [p for p in sent if p[5:8] == b"DRA"]
        assert draw, "a DRA packet must be sent"
        first = draw[0]
        assert int.from_bytes(first[17:19], "big") == 0 and int.from_bytes(first[19:21], "big") == 0
        assert int.from_bytes(first[13:15], "big") == 800 and int.from_bytes(first[15:17], "big") == 128   # the whole canvas
        from PIL import Image
        import io
        total = int.from_bytes(first[8:12], "big") - 32
        data = b"".join(sent[sent.index(first):])  # header + chunks; the JPEG starts after the 32 byte header
        img = Image.open(io.BytesIO(first[32:32 + min(total, 1024 - 32)] + b"".join(sent[sent.index(first) + 1:sent.index(first) + 1 + (total + 31) // 1024])[: max(0, total - (1024 - 32))]))
        assert img.size == (800, 128) and max(img.convert("L").getextrema()) <= 3                      # black
        assert dm._strip_canvas.getpixel((400, 60)) == (0, 0, 0)
        dm.close_sockets()


def test_deck_is_wiped_once_per_connection_before_the_first_paint():
    with tempfile.TemporaryDirectory() as tmp:
        dm = make(tmp)
        sent = []
        dm.deck = object(); dm._send = sent.append
        dm.paint()
        cle = [i for i, p in enumerate(sent) if p[5:8] == b"CLE"]
        assert len(cle) == 1 and sent[cle[0]][11] == 0xFF and sent[cle[0] + 1][5:8] == b"STP"
        first_image = next(i for i, p in enumerate(sent) if p[5:8] in (b"BAT", b"DRA"))
        assert cle[0] < first_image                                          # wiped BEFORE anything is drawn
        sent.clear(); dm.paint()
        assert not any(p[5:8] == b"CLE" for p in sent)                       # a profile change must not flash the deck
        dm.sleeping = True; dm._sleep_reason = "idle"
        sent.clear(); dm.wake_deck()
        assert sum(p[5:8] == b"CLE" for p in sent) == 1                      # waking wipes again
        dm.close_sockets()


def test_strip_offset_moves_content_up_and_is_saved():
    with tempfile.TemporaryDirectory() as tmp:
        cfg = os.path.join(tmp, "cfg"); os.makedirs(cfg); profiles.CONFIG = cfg
        dm = make_with(tmp, STRIPYAML)
        dm.settings["strip_offset_y"] = 0
        dm.paint_strip(force=True)
        base = dm._strip_canvas.copy()
        r = dm.command(["strip-offset", "6"])
        assert r == {"ok": True, "strip_offset_y": 6, "unit": "px up"}
        assert profiles.load_settings([cfg])["strip_offset_y"] == 6                      # persisted
        moved = dm._strip_canvas
        from PIL import ImageChops, Image
        bb0 = ImageChops.difference(base, Image.new("RGB", base.size, (0, 0, 0))).getbbox()
        bb1 = ImageChops.difference(moved, Image.new("RGB", moved.size, (0, 0, 0))).getbbox()
        assert bb0 and bb1 and bb1[3] <= bb0[3] - 5                                       # the content's bottom edge went up
        assert dm.command(["strip-offset", "99"])["strip_offset_y"] == 24                  # clamped
        assert dm.command(["strip-offset"])["strip_offset_y"] == 24                        # no argument = report
        dm.close_sockets()


PAGES_YAML = """name: T
keys:
  '0': {label: A, action: a}
  '1': {label: B, action: b}
pages:
- keys:
    '0': {label: C, action: c}
"""


def test_page_changes_repaint_once_and_only_the_keys_that_differ():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PAGES_YAML)
        sent = []
        d._send = sent.append
        d.paint()
        images = lambda: [p for p in sent if p[5:8] == b"BAT"]
        assert len(images()) == 10                                    # a full paint draws every key
        sent.clear()
        for _ in range(5):                                            # a knob turning five detents fast
            d.run_action("page:next")
        assert d.page == 1 and sent == []                             # nothing is sent while the knob is still moving
        d.flush_paint(now=time.monotonic() + 0.01); assert sent == [] # not due yet
        d.flush_paint(now=time.monotonic() + 1)
        slots = sorted(p[12] - 1 for p in images())
        assert slots == sorted([P.KEY_TO_SLOT[0], P.KEY_TO_SLOT[1]])  # only key 1 (changed) and key 2 (now empty), not the other eight
        assert sent[-1][5:8] == b"STP"
        sent.clear(); d.flush_paint(now=time.monotonic() + 2); assert sent == []   # nothing pending
        d.run_action("page:prev"); d.flush_paint(now=time.monotonic() + 1)
        assert sorted(p[12] - 1 for p in images()) == sorted([P.KEY_TO_SLOT[0], P.KEY_TO_SLOT[1]]) and d.page == 0
        d.close_sockets()


STRIP_PAGES = """name: T
strip_mode: per_page
keys:
  '0': {label: A, action: a}
strip:
  segments: [{type: text, text: UNO}, null, null, null]
  touch: {'0': "echo p1"}
pages:
- keys: {}
  strip:
    segments: [null, {type: text, text: DOS}, null, null]
    touch: {'1': "echo p2"}
- keys: {}
"""


def test_strip_mode_fixed_keeps_one_strip_and_per_page_switches_with_the_page():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIP_PAGES)
        pr = d.profile
        assert pr.strip_mode == "per_page"
        assert pr.strip_content(0)["segments"][0]["text"] == "UNO"
        assert pr.strip_content(1)["segments"][1]["text"] == "DOS"
        assert pr.strip_content(2) is None and pr.strip_for(2) == {}          # a page without a strip shows an empty one
        pr.strip_mode = "fixed"
        assert pr.strip_content(1)["segments"][0]["text"] == "UNO"             # fixed: every page uses the profile's strip
        pr.strip_mode = "per_page"
        sent = []; d._send = sent.append
        d.paint(); sent.clear()
        d.run_action("page:next"); assert sent == []                           # still debounced
        d.flush_paint(now=time.monotonic() + 1)
        slots = _strip_slots_sent(type("D", (), {"sent": sent})())
        assert slots[0] == "full" and 1 in slots                               # old strip wiped, page 2's strip drawn
        sent.clear(); d.run_action("page:next"); d.flush_paint(now=time.monotonic() + 1)
        assert _strip_slots_sent(type("D", (), {"sent": sent})()) == ["full"]  # page 3 has no strip: just black
        calls = []; d.run_action = calls.append
        d.page = 1; d.handle(("strip_touch", 1, None)); assert calls == ["echo p2"]   # touch actions follow the page too
        d.page = 0; d._last_strip = 0; d.handle(("strip_touch", 0, None)); assert calls[-1] == "echo p1"
        d.close_sockets()


def test_fixed_mode_does_not_redraw_the_strip_when_the_page_changes():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIP_PAGES.replace("strip_mode: per_page\n", ""))
        sent = []; d._send = sent.append
        d.paint(); sent.clear()
        d.run_action("page:next"); d.flush_paint(now=time.monotonic() + 1)
        assert _strip_slots_sent(type("D", (), {"sent": sent})()) == []
        d.close_sockets()


def test_saving_a_strip_edit_of_one_page_never_changes_another_page_or_moves_the_deck():
    import yaml
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, STRIP_PAGES)
        path = os.path.join(tmp, "profiles", "T.yaml")
        sent = []; d._send = sent.append
        d.paint()
        d.run_action("page:next"); d.flush_paint(now=time.monotonic() + 1)
        assert d.page == 1 and d._strip_canvas.getpixel((300, 64)) != (0, 0, 0) or True
        page2_before = d._strip_canvas.copy()
        # the editor (showing page 1) saves a change to page 1's strip only
        raw = yaml.safe_load(open(path))
        raw["strip"]["segments"][0] = {"type": "text", "text": "CAMBIO P1"}
        yaml.safe_dump(raw, open(path, "w"), sort_keys=False)
        r = d.command(["apply", "T"])
        assert r["ok"] and r["page"] == 2 and d.page == 1                       # the deck stayed on page 2
        from PIL import ImageChops
        assert ImageChops.difference(d._strip_canvas, page2_before).getbbox() is None   # page 2's strip did not change at all
        assert d.profile.strip_content(0)["segments"][0]["text"] == "CAMBIO P1"          # page 1 has the change
        assert d.profile.strip_content(1)["segments"][1]["text"] == "DOS"
        assert d.command(["status"])["page"] == 2
        d.run_action("page:prev"); d.flush_paint(now=time.monotonic() + 1)
        assert d.page == 0 and d.profile.strip_for(0)["segments"][0]["text"] == "CAMBIO P1"
        # applying a different profile still starts at page 1; a shorter profile clamps the page
        raw["pages"] = []; yaml.safe_dump(raw, open(path, "w"), sort_keys=False)
        d.page = 1; d.command(["apply", "T"]); assert d.page == 0
        d.close_sockets()


def test_trace_records_raw_input_codes_with_relative_times():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        assert d.command(["trace", "dump"]) == {"ok": True, "events": []}
        assert d.command(["trace", "start"])["tracing"] and d._trace == []
        d._trace += [(10.0, 0x43, 0), (10.05, 0x42, 0)]
        out = d.command(["trace", "stop"])
        assert out["events"] == [[0.0, "0x43", 0], [0.05, "0x42", 0]] and d._trace is None
        d.close_sockets()


def _key_cmds(d):
    """(command, slot) of every image header sent: BAT packets carry the key slot."""
    return [p for p in d.deck.sent if p[5:8] == b"BAT"]


def test_standby_darkens_everything_and_only_the_pressed_key_wakes_it():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.profile.keys["3"] = {"label": "Zzz", "action": "screen-off"}
        d.paint(); d.deck.sent.clear()
        d._input(4, 1)                                         # press key 4 (index 3): code = index + 1
        assert d.sleeping and d._sleep_reason == "standby" and d._standby_key == 3
        assert b"CLE" in d.deck.cmds() and d.command(["status"])["standby"] is True
        assert not any(p[5:8] == b"HAN" for p in d.deck.sent)   # the screen is darkened, not put to sleep
        d._input(4, 0)                                         # releasing the press that came here does NOT wake it (the old bug)
        assert d.sleeping
        d._input(1, 1); d._input(2, 1)                         # other keys do nothing
        assert d.sleeping
        d.deck.sent.clear()
        d._input(4, 1)                                         # a fresh press of the same key
        assert not d.sleeping and d._sleep_reason is None and b"DIS" in d.deck.cmds()
        assert d.command(["status"])["standby"] is False
        d.close_sockets()


def test_standby_key_breathes_in_cyan_and_a_trigger_without_a_key_wakes_with_any_key():
    from streamstation import render
    import io
    from PIL import Image
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.enter_standby(2)
        d.deck.sent.clear(); d._breath_shown = -1
        levels = set()
        for t in [i * 0.2 for i in range(30)]:                 # one 6 s cycle sampled every 0.2 s
            d.standby_tick(t); levels.add(d._breath_shown)
        assert max(levels) == 16 and min(levels) == 0 and len(levels) > 6      # in and out, smoothly
        cycle = [Service.breath_level(i * 0.05) for i in range(120)]
        assert sum(1 for v in cycle if v <= 1) > 2 * sum(1 for v in cycle if v >= 8)   # much more time dark than lit
        assert service.BREATH_MAX <= 0.5                                                 # and never glaring
        assert any(p[5:8] == b"BAT" for p in d.deck.sent)
        bright = render.breathing_ring(1.0); dim = render.breathing_ring(0.12)
        r, g, b = bright.getpixel((60, 7))
        assert b > 200 and g > 200 and r < 30                  # cyan, on the border all around
        assert bright.getpixel((60, 60)) == (0, 0, 0)          # the centre stays dark
        assert sum(dim.getpixel((60, 7))) < sum(bright.getpixel((60, 7))) / 3
        for x, y in ((7, 60), (112, 60), (60, 112)):
            assert sum(bright.getpixel((x, y))) > 300          # a trace around the WHOLE key
        d.wake_deck()
        d.enter_standby(None)                                  # started by a knob / the strip / ctl: no key to light
        d.deck.sent.clear(); d.standby_tick(1.0); assert d.deck.sent == []    # nothing breathes
        d._input(0x37, 1); assert d.sleeping                   # a knob press does not wake it
        d._input(0x41, 0); assert d.sleeping                   # neither does touching the strip
        d._input(7, 1); assert not d.sleeping                  # any key press does
        d.close_sockets()


def test_the_idle_screen_off_still_wakes_with_any_input_but_standby_ignores_the_session_lock():
    with tempfile.TemporaryDirectory() as tmp:
        d = make_with(tmp, PROFILE)
        d.sleep_deck("idle"); d._input(9, 0); assert not d.sleeping       # the old behaviour is untouched
        d.enter_standby(1)
        from streamstation import system
        real = system.session_locked
        try:
            system.session_locked = lambda: False
            d.settings["follow_lock"] = True; d._lock_checked = 0.0
            d.tick(100.0); assert d.sleeping                    # unlocking the session does not end a standby
        finally:
            system.session_locked = real
        d.close_sockets()
