"""The settings window: a list of sections on the left, and the choices of the selected section on the right.

    General     software updates, interface language, start with the computer, installation folder, theme and icon style
    Device      serial number, brightness, start-up picture
    Scenes      add / rename / copy / delete / order scenes, default scene, applications, import and export
"""
from __future__ import annotations

import threading

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QCheckBox, QDialog, QDialogButtonBox, QFrame, QHBoxLayout, QLabel,
                               QLineEdit, QListWidget, QListWidgetItem, QPushButton, QRadioButton, QScrollArea, QStackedWidget,
                               QToolButton, QVBoxLayout, QWidget)

from .. import __version__, i18n, updater
from ..i18n import tr
from . import actionicons, icons, settingspages, theme, themeicons, updatedialog
from .settingshost import Host

SAMPLE = (("vol_up", "Audio"), ("lock", "Sistema"), ("globe", "Navegador"), ("desktop", "Escritorio (KDE)"),
          ("sun_plus", "Dispositivo"), ("keyboard", "Herramientas"), ("toggle", "Flujo de operación"))
SECTIONS = (("general", "General"), ("device", "Dispositivo"), ("scenes", "Escenas"))


def _title(text: str) -> QLabel:
    label = QLabel(text); label.setObjectName("heading"); return label


def _rule() -> QFrame:
    line = QFrame(); line.setFrameShape(QFrame.HLine); line.setObjectName("sep"); line.setFixedHeight(1); return line


def _note(text: str) -> QLabel:
    label = QLabel(text); label.setObjectName("muted"); label.setWordWrap(True); return label


class SettingsDialog(QDialog):
    fetch_logos_requested = Signal()
    theme_previewed = Signal(str)          # the theme was picked: the owner shows it at once, before OK
    restart_requested = Signal()           # an update was handed to the installer: the editor must close now
    _checked = Signal(object, str)         # (release or None, error text) from the thread that asked GitHub

    def __init__(self, style: str, parent=None, language: str = i18n.DEFAULT, theme_setting: str = "dark", host: Host | None = None):
        super().__init__(parent)
        self.host = host or Host()
        self.setWindowTitle(tr("Configuración"))
        self.resize(860, 600)
        root = QVBoxLayout(self)
        body = QHBoxLayout(); root.addLayout(body, 1)
        self.release = None                 # what the last check found

        # ---- the list of sections (left) ----
        self.sections = QListWidget(); self.sections.setFixedWidth(190)
        for key, label in SECTIONS:
            item = QListWidgetItem(tr(label)); item.setData(Qt.UserRole, key)
            item.setSizeHint(QSize(0, 40)); self.sections.addItem(item)
        body.addWidget(self.sections)

        # ---- the choices of the selected section (right) ----
        self.pages = QStackedWidget(); body.addWidget(self.pages, 1)
        self.pages.addWidget(self._general_page(style, language, theme_setting))
        self.device_page = settingspages.DevicePage(self.host); self.pages.addWidget(self.device_page)
        self.scenes_page = settingspages.ScenesPage(self.host); self.pages.addWidget(self.scenes_page)
        self.sections.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.sections.setCurrentRow(0)
        self._checked.connect(self._check_done)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); root.addWidget(buttons)
        buttons.button(QDialogButtonBox.Ok).setText(tr("Aceptar")); buttons.button(QDialogButtonBox.Cancel).setText(tr("Cancelar"))
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)

    # --- the General page: a column of blocks ----------------------------------------------------------------
    def _general_page(self, style: str, language: str, theme_setting: str) -> QWidget:
        scroll = QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(24, 8, 12, 8); lay.setSpacing(10)
        lay.addWidget(_title(tr("General")))
        self._software_block(lay)
        lay.addWidget(_rule())
        lay.addWidget(self._language_page(language))
        lay.addWidget(_rule())
        self._startup_block(lay)
        lay.addWidget(_rule())
        self._folder_block(lay)
        lay.addWidget(_rule())
        lay.addWidget(self._theme_page(theme_setting))
        lay.addWidget(_rule())
        lay.addWidget(self._icons_page(style))
        lay.addStretch()
        scroll.setWidget(inner)
        return scroll

    def _software_block(self, lay):
        lay.addWidget(_title(tr("Actualización de software")))
        row = QHBoxLayout()
        self.version_label = QLabel(tr("Versión instalada: {version}", version=self.host.version))
        self.check_btn = QPushButton(tr("Buscar actualizaciones…"))
        row.addWidget(self.version_label); row.addStretch(); row.addWidget(self.check_btn); lay.addLayout(row)
        self.update_status = QLabel(""); self.update_status.setObjectName("muted"); self.update_status.setWordWrap(True)
        lay.addWidget(self.update_status)
        settings = self.host.settings()
        row = QHBoxLayout(); row.addWidget(QLabel(tr("Repositorio de GitHub:")))
        self.repo_edit = QLineEdit(str(settings.get("update_repo") or "")); self.repo_edit.setPlaceholderText(tr("usuario/repositorio"))
        row.addWidget(self.repo_edit, 1); lay.addLayout(row)
        self.update_auto = QCheckBox(tr("Buscar actualizaciones al abrir el programa"))
        self.update_auto.setToolTip(tr("Hace una consulta a GitHub para saber cuál es la última versión publicada. No se envía ningún dato tuyo."))
        self.update_auto.setChecked(bool(settings.get("update_check", True)))
        lay.addWidget(self.update_auto)
        self.check_btn.clicked.connect(self.check_now)

    def _startup_block(self, lay):
        lay.addWidget(_title(tr("Inicio")))
        state = self.host.autostart_status()
        self.autostart_box = QCheckBox(tr("Iniciar Stream Station al encender el equipo")); self.autostart_box.setChecked(state["enabled"])
        self.minimized_box = QCheckBox(tr("Iniciar minimizado")); self.minimized_box.setChecked(state["minimized"])
        self.minimized_box.setEnabled(state["enabled"])
        self.autostart_box.toggled.connect(self.minimized_box.setEnabled)
        row = QHBoxLayout(); row.addWidget(self.autostart_box); row.addSpacing(16); row.addWidget(self.minimized_box); row.addStretch()
        lay.addLayout(row)

    def _folder_block(self, lay):
        lay.addWidget(_title(tr("Carpeta de instalación")))
        row = QHBoxLayout()
        self.folder_label = QLabel(self.host.install_dir()); self.folder_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.folder_btn = QPushButton(tr("Abrir carpeta de instalación"))
        row.addWidget(self.folder_label, 1); row.addWidget(self.folder_btn); lay.addLayout(row)
        self.folder_btn.clicked.connect(lambda: self.host.open_path(self.host.install_dir()))

    # --- software updates ------------------------------------------------------------------------------------
    def check_now(self):
        """Ask GitHub (in the background) which release is the latest."""
        repo = self.repo_edit.text().strip()
        self.check_btn.setEnabled(False)
        self.update_status.setText(tr("Buscando…"))
        host = self.host

        def work():
            try:
                self._checked.emit(host.check(repo), "")
            except Exception as exc:
                self._checked.emit(None, str(exc))
        threading.Thread(target=work, daemon=True).start()

    def _check_done(self, release, error: str):
        if error == "installing":
            self.update_status.setText(tr("Instalando la actualización: Stream Station se reiniciará."))
            self.restart_requested.emit(); return
        self.check_btn.setEnabled(True)
        if release is None:
            self.update_status.setText(tr("No se pudo consultar las versiones: {error}", error=error)); return
        self.release = release
        if not release.newer:
            self.update_status.setText(tr("Ya tienes la última versión ({version}).", version=release.current)); return
        self.update_status.setText(tr("Hay una versión nueva: {version}", version=release.version))
        self.show_update(release)

    def show_update(self, release):
        """The changelog window; then update now, later, or skip this version."""
        dlg = updatedialog.UpdateDialog(release, self)
        dlg.exec()
        if dlg.choice == updatedialog.SKIP:
            self.host.save("update_skip", release.version)
            self.update_status.setText(tr("Se omitirá la versión {version}.", version=release.version))
        elif dlg.choice == updatedialog.UPDATE:
            self.install_update(release)

    def install_update(self, release):
        """Download in the background, hand the installation over, and ask the editor to close (the installer reopens it)."""
        self.check_btn.setEnabled(False)
        self.update_status.setText(tr("Descargando la nueva versión, espera un momento…"))
        host = self.host

        def work():
            try:
                host.install(release)
                self._checked.emit(release, "installing")
            except Exception as exc:
                self._checked.emit(None, str(exc))
        threading.Thread(target=work, daemon=True).start()

    # --- pages -------------------------------------------------------------------------------------------
    def _page(self) -> tuple[QWidget, QVBoxLayout]:
        w = QWidget(); lay = QVBoxLayout(w); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(10)
        return w, lay

    def _language_page(self, current: str) -> QWidget:
        w, lay = self._page()
        lay.addWidget(_title(tr("Idioma de la interfaz")))
        self.language_list = QListWidget(); self.language_list.setSelectionMode(QAbstractItemView.SingleSelection)
        for code, name in i18n.LANGUAGES:
            item = QListWidgetItem(name); item.setData(Qt.UserRole, code)
            item.setSizeHint(QSize(0, 34)); self.language_list.addItem(item)
            if code == current:
                self.language_list.setCurrentItem(item)
        if self.language_list.currentItem() is None:
            self.language_list.setCurrentRow(0)
        self.language_list.setFixedHeight(150); lay.addWidget(self.language_list)
        lay.addWidget(_note(tr("Al cambiar el idioma la ventana se vuelve a abrir con los textos nuevos. "
                               "Lo que dibuja el equipo en la franja usa el mismo idioma cuando su tipografía puede escribirlo.")))
        return w

    def _theme_page(self, current: str) -> QWidget:
        w, lay = self._page()
        lay.addWidget(_title(tr("Tema de la interfaz")))
        row = QHBoxLayout(); row.setSpacing(16)
        self.theme_group = QButtonGroup(self); self.theme_group.setExclusive(True)
        self.theme_buttons: dict[str, QToolButton] = {}
        system_now = theme.system_scheme()                       # what the desktop looks like right now
        choices = (("light", tr("Claro"), themeicons.sun()), ("dark", tr("Oscuro"), themeicons.moon()),
                   ("system", tr("Sistema"), themeicons.computer(system_now)))
        for key, label, icon in choices:
            b = QToolButton(); b.setCheckable(True); b.setText(label); b.setIcon(icon); b.setIconSize(QSize(72, 72))
            b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon); b.setFixedSize(150, 130)
            b.setProperty("theme", key); b.setChecked(key == current)
            self.theme_group.addButton(b); self.theme_buttons[key] = b; row.addWidget(b)
            b.clicked.connect(lambda _=False, k=key: self.theme_previewed.emit(k))
        if not any(b.isChecked() for b in self.theme_buttons.values()):
            self.theme_buttons["dark"].setChecked(True)
        row.addStretch(); lay.addLayout(row)
        lay.addWidget(_note(tr("Sistema sigue el tema de tu escritorio y cambia solo cuando tú lo cambias en él.")))
        return w

    def _icons_page(self, style: str) -> QWidget:
        outer, olay = self._page()
        olay.addWidget(_title(tr("Estilo de los iconos de las teclas")))
        inner = QWidget(); lay = QVBoxLayout(inner); lay.setContentsMargins(0, 0, 8, 0)
        self.group = QButtonGroup(self); self.group.setExclusive(True)
        self.radios: dict[str, QRadioButton] = {}
        for key, label in actionicons.STYLES.items():
            radio = QRadioButton(tr(label)); radio.setChecked(key == style)
            self.group.addButton(radio); self.radios[key] = radio
            lay.addWidget(radio)
            row = QHBoxLayout(); row.setContentsMargins(26, 0, 0, 8)
            for name, cat in SAMPLE:                                   # what the style looks like
                pm = QLabel(); pm.setPixmap(icons.to_qpixmap(actionicons.tile(name, cat, 56, key)))
                row.addWidget(pm)
            row.addStretch(); lay.addLayout(row)
        lay.addWidget(_note(tr("Al aceptar cambian los iconos de todas las teclas ya configuradas "
                               "(se guarda una copia de cada perfil). Las aplicaciones conservan su propio icono dentro del estilo.")))
        from .. import logos
        miss = len(logos.missing())
        row = QHBoxLayout()
        self.logos_btn = QPushButton(tr("Descargar los logos de los servicios") if miss else tr("Volver a descargar los logos"))
        self.logos_btn.setToolTip(tr("Baja las marcas reales (YouTube, Spotify…) del conjunto abierto Simple Icons a tu carpeta de "
                                     "configuración. El programa no las incluye."))
        self.logos_note = QLabel(tr("Faltan {n} logos: sin ellos las teclas de servicios usan un dibujo propio.", n=miss) if miss
                                 else tr("Los logos de los servicios están descargados."))
        self.logos_note.setObjectName("muted"); self.logos_note.setWordWrap(True)
        row.addWidget(self.logos_btn); row.addWidget(self.logos_note, 1)
        lay.addLayout(row)
        self.logos_btn.clicked.connect(self.fetch_logos_requested)
        olay.addWidget(inner)
        return outer

    def set_logos_note(self, text: str):
        self.logos_note.setText(text)
        self.logos_btn.setText(tr("Volver a descargar los logos"))

    # --- what the user chose -----------------------------------------------------------------------------
    def style(self) -> str:
        return next((k for k, r in self.radios.items() if r.isChecked()), "pastel")

    def language(self) -> str:
        item = self.language_list.currentItem()
        return str(item.data(Qt.UserRole)) if item else i18n.DEFAULT

    def theme(self) -> str:
        return next((k for k, b in self.theme_buttons.items() if b.isChecked()), "dark")

    def autostart(self) -> tuple[bool, bool]:
        return self.autostart_box.isChecked(), self.minimized_box.isChecked()

    def update_repo(self) -> str:
        return self.repo_edit.text().strip()

    def apply_all(self):
        """Save what lives in the settings file or in the system (language, theme and icon style are applied by the editor)."""
        host = self.host
        host.save("update_repo", self.update_repo())
        host.save("update_check", bool(self.update_auto.isChecked()))
        enabled, minimized = self.autostart()
        host.save("autostart", enabled); host.save("autostart_minimized", minimized)
        if (host.autostart_status()["enabled"], host.autostart_status()["minimized"]) != (enabled, minimized):
            host.set_autostart(enabled, minimized)
        self.device_page.apply()
        self.scenes_page.apply()

    def accept(self):
        self.apply_all()
        super().accept()
