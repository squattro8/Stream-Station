"""What the settings window needs from the system, in one place so that tests can replace any of it."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

from .. import __version__, autostart, deviceinfo, profiles, service, updater


class Host:
    version = __version__

    # --- settings ---
    def settings(self) -> dict:
        return profiles.load_settings()

    def save(self, key: str, value):
        profiles.save_setting(key, value)

    # --- the running service ---
    def ctl(self, args: list[str]) -> dict | None:
        try:
            return json.loads(service.ctl(args))
        except (OSError, ValueError):
            return None

    def recent_windows(self) -> list[dict]:
        reply = self.ctl(["windows"]) or {}
        return reply.get("windows", [])

    # --- updates ---
    def check(self, repo: str) -> updater.Release:
        return updater.check(repo)

    def install(self, release: updater.Release):
        return updater.install(release, autostart.launcher())

    # --- start with the computer ---
    def autostart_status(self) -> dict:
        return autostart.status()

    def set_autostart(self, enabled: bool, minimized: bool):
        autostart.set_enabled(enabled, minimized)

    # --- files ---
    def install_dir(self) -> str:
        return str(Path(__file__).resolve().parents[2])

    def open_path(self, path: str):
        subprocess.Popen(["xdg-open", path], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def serial(self) -> str | None:
        return deviceinfo.serial_number()

    # --- questions to the user (replaced by the tests) ---
    def pick_image(self, parent) -> str | None:
        from PySide6.QtWidgets import QFileDialog
        from ..i18n import tr
        path, _ = QFileDialog.getOpenFileName(parent, tr("Elegir imagen"), os.path.expanduser("~"),
                                              tr("Imágenes") + " (*.png *.jpg *.jpeg *.bmp *.gif *.webp)")
        return path or None

    def pick_scene_file(self, parent) -> str | None:
        from PySide6.QtWidgets import QFileDialog
        from ..i18n import tr
        path, _ = QFileDialog.getOpenFileName(parent, tr("Importar escena"), os.path.expanduser("~"),
                                              tr("Escenas") + " (*.ssscene *.yaml)")
        return path or None

    def pick_scene_save(self, parent, name: str) -> str | None:
        from PySide6.QtWidgets import QFileDialog
        from ..i18n import tr
        path, _ = QFileDialog.getSaveFileName(parent, tr("Exportar escena"), os.path.join(os.path.expanduser("~"), name + ".ssscene"),
                                              tr("Escenas") + " (*.ssscene)")
        return path or None

    def ask_text(self, parent, title: str, label: str, text: str = "") -> str | None:
        from PySide6.QtWidgets import QInputDialog
        value, ok = QInputDialog.getText(parent, title, label, text=text)
        return value.strip() if ok and value.strip() else None

    def confirm(self, parent, text: str) -> bool:
        from PySide6.QtWidgets import QMessageBox
        return QMessageBox.question(parent, "Stream Station", text) == QMessageBox.Yes

    def inform(self, parent, text: str):
        from PySide6.QtWidgets import QMessageBox
        QMessageBox.information(parent, "Stream Station", text)

    # --- the editor's state, filled in by the main window ---
    open_scene: str = ""             # the scene open in the editor
    open_scene_dirty: bool = False   # with changes not saved yet
