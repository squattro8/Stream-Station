"""USB access for the deck through pyusb/libusb. Needs the usb access rules
(see ../udev/) and that no other program owns the interfaces."""
from __future__ import annotations

import usb.core
import usb.util

from . import protocol as P


class DeviceBusy(RuntimeError):
    pass


class Deck:
    def __init__(self):
        self.dev = usb.core.find(idVendor=P.VID, idProduct=P.PID)
        if self.dev is None:
            raise RuntimeError("deck 0200:3001 not found (plugged in? permissions?)")
        self.interfaces = (0, 1)
        self._detached: list[int] = []
        self._claimed: list[int] = []

    def open(self):
        for i in self.interfaces:
            if self.dev.is_kernel_driver_active(i):
                self.dev.detach_kernel_driver(i)
                self._detached.append(i)
        try:
            for i in self.interfaces:
                usb.util.claim_interface(self.dev, i)
                self._claimed.append(i)
        except usb.core.USBError as exc:
            self.close()
            raise DeviceBusy(f"cannot claim interface: {exc}") from exc
        return self

    def close(self):
        for i in reversed(self._claimed):
            usb.util.release_interface(self.dev, i)
        for i in reversed(self._detached):
            try:
                self.dev.attach_kernel_driver(i)
            except usb.core.USBError:
                pass
        usb.util.dispose_resources(self.dev)
        self._claimed, self._detached = [], []

    def __enter__(self):
        return self.open()

    def __exit__(self, *exc):
        self.close()

    def send(self, packet: bytes, timeout=1000):
        n = self.dev.write(P.EP_OUT, packet, timeout)
        if n != len(packet):
            raise RuntimeError(f"short write {n}/{len(packet)}")

    def read(self, timeout=100):
        try:
            return bytes(self.dev.read(P.EP_IN, P.PACKET_IN, timeout))
        except usb.core.USBTimeoutError:
            return None
