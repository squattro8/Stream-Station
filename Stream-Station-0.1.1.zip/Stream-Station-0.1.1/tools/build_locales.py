#!/usr/bin/env python3
"""Turn the translators' files into the JSON tables the program loads.

    streamstation/locales/_keys.json      the Spanish originals, in a fixed order (python3 tools/i18n_keys.py makes it)
    streamstation/locales/src/<code>.txt  one line per text:  <number>|<translation>   (a line break is written \\n)
    streamstation/locales/<code>.json     the result: {"<Spanish original>": "<translation>"}

Checks, per language: every number appears once, nothing is empty, and the {placeholders} are exactly the original's.
Whitespace at the ends of an original (leading "  ·  ", a trailing ": ") is copied onto the translation.
"""
from __future__ import annotations

import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LOCALES = os.path.join(HERE, "..", "streamstation", "locales")
PLACEHOLDER = re.compile(r"\{[a-z_]+\}")


def build(code: str, keys: list[str]) -> dict[str, str]:
    path = os.path.join(LOCALES, "src", f"{code}.txt")
    lines = {}
    for raw in open(path, encoding="utf-8").read().split("\n"):
        if not raw.strip() or raw.startswith("#"):
            continue
        num, _sep, text = raw.partition("|")
        lines[int(num)] = text.replace("\\n", "\n")
    problems = []
    out = {}
    for i, key in enumerate(keys, 1):
        text = lines.get(i)
        if not text or not text.strip():
            problems.append(f"{code} #{i} falta: {key!r}")
            continue
        lead = key[: len(key) - len(key.lstrip())]
        trail = key[len(key.rstrip()):]
        text = lead + text.strip() + trail
        if sorted(PLACEHOLDER.findall(text)) != sorted(PLACEHOLDER.findall(key)):
            problems.append(f"{code} #{i} marcadores distintos: {key!r} -> {text!r}")
        out[key] = text
    extra = sorted(set(lines) - set(range(1, len(keys) + 1)))
    if extra:
        problems.append(f"{code} números sobrantes: {extra[:5]}")
    if problems:
        raise SystemExit("\n".join(problems[:15]))
    return out


if __name__ == "__main__":
    keys = json.load(open(os.path.join(LOCALES, "_keys.json"), encoding="utf-8"))
    codes = sys.argv[1:] or sorted(f[:-4] for f in os.listdir(os.path.join(LOCALES, "src")) if f.endswith(".txt"))
    for code in codes:
        table = build(code, keys)
        with open(os.path.join(LOCALES, f"{code}.json"), "w", encoding="utf-8") as fh:
            json.dump(table, fh, ensure_ascii=False, indent=0, sort_keys=True)
        print(f"{code}: {len(table)} textos")
