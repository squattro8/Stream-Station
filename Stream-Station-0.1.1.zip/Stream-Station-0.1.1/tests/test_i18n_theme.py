import json, os, types
from pathlib import Path
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
from streamstation import i18n
from streamstation.ui import theme


def _reset():
    i18n.set_language(i18n.SOURCE)


def test_defaults():
    assert i18n.DEFAULT == "en" and len(i18n.LANGUAGES) == 20
    assert i18n.CODES[0] == "en"


def test_all_locales_complete_and_placeholders():
    import re
    keys = json.load(open(Path(i18n.LOCALES_DIR) / "_keys.json"))
    ph = lambda s: sorted(re.findall(r"\{\w+\}", s))
    for code in i18n.CODES:
        if code == "es":
            continue
        data = json.load(open(Path(i18n.LOCALES_DIR) / f"{code}.json"))
        for k in keys:
            assert data.get(k), (code, k)
            assert ph(data[k]) == ph(k), (code, k)


def test_tr_lookup_and_fallback():
    try:
        i18n.set_language("en")
        assert i18n.tr("Guardar y aplicar") == "Save and apply"
        assert "3" in i18n.tr("Página {n} eliminada · sin guardar", n=3)
        assert i18n.tr("texto inexistente {n}", n=1) == "texto inexistente 1"
        i18n.set_language("es")
        assert i18n.tr("Guardar y aplicar") == "Guardar y aplicar"
    finally:
        _reset()


def test_rtl_and_strip_language():
    try:
        i18n.set_language("ar"); assert i18n.is_rtl() and i18n.strip_language() == "en"
        i18n.set_language("fr"); assert not i18n.is_rtl() and i18n.strip_language() == "fr"
    finally:
        _reset()


def test_palettes_and_qss_differ():
    try:
        theme.apply("dark"); d = theme.qss()
        theme.apply("light"); l = theme.qss()
        assert d != l and "#ffffff" in l.lower()
    finally:
        theme.apply("dark")


def test_portal_scheme_parsing():
    run = lambda out: (lambda *a, **k: types.SimpleNamespace(stdout=out))
    assert theme.portal_scheme(run("v v u 1")) == "dark"
    assert theme.portal_scheme(run("v v u 2")) == "light"
    assert theme.portal_scheme(run("v v u 0")) is None
    def boom(*a, **k): raise OSError
    assert theme.portal_scheme(boom) is None


def test_appearance_and_settings_dialog():
    from PySide6.QtWidgets import QApplication
    from streamstation.ui.appearance import Appearance
    from streamstation.ui.settingsdialog import SettingsDialog
    app = QApplication.instance() or QApplication([])
    try:
        look = Appearance(app)
        got = []
        look.language_changed.connect(got.append)
        look.set_language("ar"); assert got == ["ar"] and app.layoutDirection().name == "RightToLeft"
        look.set_language("en"); assert app.layoutDirection().name == "LeftToRight"
        look.set_theme("light"); assert theme.current == "light"
        look.set_theme("dark"); assert theme.current == "dark"
        dlg = SettingsDialog("neon", language="de", theme_setting="light")
        assert dlg.language() == "de" and dlg.theme() == "light"
        assert dlg.language_list.count() == 20 and len(dlg.theme_buttons) == 3
        assert dlg.sections.count() == 3 and dlg.pages.count() == 3
    finally:
        _reset(); theme.apply("dark")


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("ok", n)


def test_theme_change_fades_instead_of_jumping_and_the_device_schematic_follows_the_text_colour():
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication, QLabel, QWidget
    from streamstation.ui.appearance import Appearance
    from streamstation.ui import mainwindow
    app = QApplication.instance() or QApplication([])
    look = Appearance(app); look.animate_offscreen = True; look.FADE_MS = 60
    w = QWidget(); w.resize(120, 80); w.show(); app.processEvents()
    try:
        look.set_theme("dark")
        look.set_theme("light")
        covers = w.findChildren(QLabel)
        assert covers and covers[0].pixmap() is not None               # the previous look is laid over the new one
        loop_end = __import__("time").time() + 1.5
        while w.findChildren(QLabel) and __import__("time").time() < loop_end:
            app.processEvents()
        assert not w.findChildren(QLabel)                              # ...and it dissolves away
        dev = mainwindow.MiniDevice(); dev.show(); app.processEvents()
        img = dev.grab().toImage()
        assert img.pixelColor(2, 90).lightness() < 128                 # black outline on the light theme
        look.set_theme("dark")
        end = __import__("time").time() + 1.5
        while dev.findChildren(QLabel) and __import__("time").time() < end:
            app.processEvents()
        assert dev.grab().toImage().pixelColor(2, 90).lightness() > 128
    finally:
        look.animate_offscreen = False; theme.apply("dark"); app.setStyleSheet(theme.qss())
