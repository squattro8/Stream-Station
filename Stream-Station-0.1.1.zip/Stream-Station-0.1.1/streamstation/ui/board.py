"""The painted device: 2x5 keys, the touch strip and 4 knobs, in the original app's shapes."""
from __future__ import annotations

import json

from PySide6.QtCore import QEvent, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QLinearGradient, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QToolTip, QWidget

from . import theme as T


class Board(QWidget):
    """Selectable keys / strip segments / knobs. Emits ``selected(kind, index)``."""
    selected = Signal(str, int)
    dropped = Signal(int, dict)         # key index, payload dragged from the action tree
    dropped_strip = Signal(int, dict)   # strip segment, payload (becomes its touch action)
    dropped_knob = Signal(int, dict)    # knob, payload (goes to the field being edited)
    MIME = "application/x-streamstation-action"

    def __init__(self, parent=None):
        super().__init__(parent)
        gap_x, gap_y = T.KEY_PITCH
        self._w = T.KEY + gap_x * 4
        self.setFixedSize(T.STRIP[0] + 8, 322)
        self.keys: dict[int, dict] = {}       # index -> {"label": str, "colors": (c1, c2)}
        self.strip: list[str] = ["", "", "", ""]
        self.strip_pix: list = [None, None, None, None]   # rendered previews of the 4 panels
        self.sel: tuple[str, int] | None = None
        self.setMouseTracking(True)
        self.setAcceptDrops(True)

    def tip_at(self, pos) -> str:
        """The floating description of the configured key under `pos` (empty for empty keys and everything else)."""
        hit = self._hit(QPointF(pos))
        if hit and hit[0] == "key":
            return (self.keys.get(hit[1]) or {}).get("tip", "")
        return ""

    def event(self, e):
        if e.type() == QEvent.ToolTip:
            tip = self.tip_at(e.pos())
            if tip:
                QToolTip.showText(e.globalPos(), tip, self)
            else:
                QToolTip.hideText(); e.ignore()
            return True
        return super().event(e)

    # --- geometry --------------------------------------------------------
    def _key_rect(self, i):
        r, c = divmod(i, 5)
        ox = (self.width() - self._w) / 2
        return QRectF(ox + c * T.KEY_PITCH[0], 4 + r * T.KEY_PITCH[1], T.KEY, T.KEY)

    def _strip_rect(self):
        return QRectF((self.width() - T.STRIP[0]) / 2, 4 + 2 * T.KEY_PITCH[1] + 0, *T.STRIP)

    def _knob_rect(self, i):
        sr = self._strip_rect()
        step = (T.STRIP[0] - T.KNOB) / 3 + 0.5
        return QRectF(sr.x() + i * (sr.width() - T.KNOB) / 3, sr.bottom() + 14, T.KNOB, T.KNOB)

    def _hit(self, p):
        for i in range(10):
            if self._key_rect(i).contains(p):
                return "key", i
        sr = self._strip_rect()
        if sr.contains(p):
            return "strip", min(3, int((p.x() - sr.x()) / (sr.width() / 4)))
        for i in range(4):
            if self._knob_rect(i).contains(p):
                return "knob", i
        return None

    def dragEnterEvent(self, e):
        if e.mimeData().hasFormat(self.MIME):
            e.acceptProposedAction()

    dragMoveEvent = dragEnterEvent

    def dropEvent(self, e):
        hit = self._hit(e.position())
        if hit and hit[0] in ("key", "strip", "knob") and e.mimeData().hasFormat(self.MIME):
            try:
                payload = json.loads(bytes(e.mimeData().data(self.MIME)).decode())
            except ValueError:
                return
            self.sel = hit
            self.selected.emit(*hit)
            {"key": self.dropped, "strip": self.dropped_strip, "knob": self.dropped_knob}[hit[0]].emit(hit[1], payload)
            e.acceptProposedAction()
            self.update()

    def mousePressEvent(self, e):
        hit = self._hit(e.position())
        if hit:
            self.sel = hit
            self.selected.emit(*hit)
            self.update()

    # --- painting --------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        for i in range(10):
            self._paint_key(p, i)
        self._paint_strip(p)
        self._paint_strip_selection(p)
        for i in range(4):
            self._paint_knob(p, i)

    def _outline(self, kind, i):
        return QColor(T.ACCENT if self.sel == (kind, i) else T.OUTLINE)

    def _paint_key(self, p, i):
        r = self._key_rect(i)
        data = self.keys.get(i)
        pen = QPen(self._outline("key", i), T.KEY_BORDER)
        inner = r.adjusted(T.KEY_BORDER / 2, T.KEY_BORDER / 2, -T.KEY_BORDER / 2, -T.KEY_BORDER / 2)
        p.setPen(pen)
        if data and data.get("colors"):
            g = QLinearGradient(inner.topLeft(), inner.bottomRight())
            g.setColorAt(0, QColor(data["colors"][0]))
            g.setColorAt(1, QColor(data["colors"][1]))
            p.setBrush(g)
        else:
            p.setBrush(QColor(T.BG_DEEP))
        p.drawRoundedRect(inner, T.KEY_RADIUS, T.KEY_RADIUS)
        if data and data.get("pixmap") is not None:
            from PySide6.QtGui import QPainterPath
            clip = QPainterPath(); clip.addRoundedRect(inner.adjusted(1, 1, -1, -1), T.KEY_RADIUS - 1, T.KEY_RADIUS - 1)
            p.save(); p.setClipPath(clip)
            p.drawPixmap(inner.adjusted(1, 1, -1, -1).toRect(), data["pixmap"]); p.restore()
        elif data and data.get("label"):
            p.setPen(QColor("#2b2b3a"))
            f = QFont(self.font()); f.setPixelSize(11); f.setBold(True); p.setFont(f)
            p.drawText(inner.adjusted(3, 3, -3, -3), Qt.AlignCenter | Qt.TextWordWrap, data["label"])

    def _paint_strip(self, p):
        r = self._strip_rect()
        inner = r.adjusted(1, 1, -1, -1)
        p.setPen(QPen(QColor(T.OUTLINE), 2))
        p.setBrush(QColor(T.BG_STRIP))
        p.drawRoundedRect(inner, T.STRIP_RADIUS, T.STRIP_RADIUS)
        seg = r.width() / 4
        for i in range(4):
            cell = QRectF(r.x() + i * seg, r.y(), seg, r.height())
            if self.strip_pix[i] is not None:
                from PySide6.QtGui import QPainterPath
                clip = QPainterPath(); clip.addRoundedRect(inner, T.STRIP_RADIUS, T.STRIP_RADIUS)
                p.save(); p.setClipPath(clip)
                p.drawPixmap(cell.adjusted(1, 1, -1, -1).toRect(), self.strip_pix[i]); p.restore()
            elif self.strip[i]:
                p.setPen(QColor(T.TEXT))
                f = QFont(self.font()); f.setPixelSize(15); p.setFont(f)
                p.drawText(cell, Qt.AlignCenter, self.strip[i])

    def _paint_strip_selection(self, p):
        if self.sel and self.sel[0] == "strip":
            r = self._strip_rect(); seg = r.width() / 4
            cell = QRectF(r.x() + self.sel[1] * seg, r.y(), seg, r.height())
            p.setPen(QPen(QColor(T.ACCENT), 2)); p.setBrush(Qt.NoBrush)
            p.drawRoundedRect(cell.adjusted(2, 2, -2, -2), 8, 8)

    def _paint_knob(self, p, i):
        r = self._knob_rect(i)
        c = r.center()
        ring = QRadialGradient(c, r.width() / 2)
        ring.setColorAt(0.0, QColor("#474747")); ring.setColorAt(0.80, QColor("#3b3b3b"))
        ring.setColorAt(0.92, QColor("#1c1c1c")); ring.setColorAt(1.0, QColor("#4d4d4d"))
        p.setPen(QPen(QColor(T.ACCENT), 2) if self.sel == ("knob", i) else QPen(Qt.NoPen))
        p.setBrush(ring)
        p.drawEllipse(r)
        p.setPen(Qt.NoPen); p.setBrush(QColor("#474747"))
        p.drawEllipse(c, r.width() * 0.34, r.width() * 0.34)
