"""Theme and language of the running editor.

    Appearance(app).set_theme("system")   light | dark | system (follows the desktop's colour scheme, live)
    Appearance(app).set_language("de")    the language; the window asks to be rebuilt (all its texts change)
"""
from __future__ import annotations

from PySide6.QtCore import QObject, Qt, Signal

from .. import i18n
from . import theme


class Appearance(QObject):
    theme_changed = Signal(str)          # the palette now in use: "light" | "dark"
    language_changed = Signal(str)

    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.setting = "dark"
        self._busy = False
        app.styleHints().colorSchemeChanged.connect(self._desktop_scheme_changed)

    def set_theme(self, setting: str) -> str:
        """Apply "light", "dark" or "system". Native dialogs get the same scheme as our own widgets."""
        self.setting = setting if setting in theme.THEMES else "dark"
        before = self._snapshots()
        self._busy = True
        try:
            hints = self.app.styleHints()
            if self.setting == "system":
                hints.setColorScheme(Qt.ColorScheme.Unknown)        # give control back to the desktop, then ask it
            name = theme.apply(theme.resolve(self.setting))
            if self.setting != "system":
                hints.setColorScheme(Qt.ColorScheme.Light if name == "light" else Qt.ColorScheme.Dark)
            self.app.setStyleSheet(theme.qss())
        finally:
            self._busy = False
        self.theme_changed.emit(name)
        self._fade(before)
        return name

    FADE_MS = 280

    def _snapshots(self):
        """What each visible window looks like right now, to fade out once the new theme is applied."""
        from PySide6.QtWidgets import QApplication
        if QApplication.instance() is None or QApplication.platformName() == "offscreen" and not self.animate_offscreen:
            return []
        return [(w, w.grab()) for w in QApplication.topLevelWidgets() if w.isVisible() and w.width() > 1]

    animate_offscreen = False

    def _fade(self, before):
        """Cross-fade: the old look is laid over the new one and dissolves, instead of the colours jumping."""
        from PySide6.QtCore import QPropertyAnimation
        from PySide6.QtWidgets import QGraphicsOpacityEffect, QLabel
        for w, pix in before:
            cover = QLabel(w); cover.setPixmap(pix); cover.setGeometry(0, 0, w.width(), w.height())
            cover.setAttribute(Qt.WA_TransparentForMouseEvents); cover.show(); cover.raise_()
            fx = QGraphicsOpacityEffect(cover); cover.setGraphicsEffect(fx)
            anim = QPropertyAnimation(fx, b"opacity", cover)
            anim.setDuration(self.FADE_MS); anim.setStartValue(1.0); anim.setEndValue(0.0)
            anim.finished.connect(cover.deleteLater)
            anim.start()
            cover._anim = anim

    def _desktop_scheme_changed(self, *_):
        if self.setting == "system" and not self._busy:             # the user changed their desktop's theme
            self.set_theme("system")

    def set_language(self, code: str) -> str:
        code = i18n.set_language(code)
        self.app.setLayoutDirection(Qt.RightToLeft if i18n.is_rtl(code) else Qt.LeftToRight)
        self.language_changed.emit(code)
        return code
