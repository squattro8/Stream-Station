import os, sys, pathlib, time
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from PIL import Image
from PySide6.QtWidgets import QApplication
from streamstation import bootlogo, profiles, scenes, updater
from streamstation.ui import settingsdialog
from streamstation.ui.settingshost import Host
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from test_settings_backend import Sandbox

app = QApplication.instance() or QApplication([])


class Fake(Host):
    """No GitHub, no systemd, no real dialogs."""
    def __init__(self, tmp):
        self.store = {}; self.sent = []; self.auto = {"enabled": False, "minimized": False}
        self.release = updater.Release(version="9.0.0", notes="- novedades", url="https://github.com/a.zip", current="0.1.0", newer=True)
        self.installed = []; self.answers = {}; self.tmp = tmp; self.opened = []
    def settings(self): return {**profiles.DEFAULT_SETTINGS, **self.store}
    def save(self, k, v): self.store[k] = v
    def ctl(self, args): self.sent.append(args); return {"brightness": 40, "ok": True}
    def recent_windows(self): return []
    def check(self, repo): self.checked = repo; return self.release
    def install(self, rel): self.installed.append(rel)
    def autostart_status(self): return dict(self.auto)
    def set_autostart(self, e, m): self.auto = {"enabled": e, "minimized": m}
    def serial(self): return "SN123"
    def open_path(self, p): self.opened.append(p)
    def pick_image(self, parent): return self.answers.get("image")
    def pick_scene_file(self, parent): return self.answers.get("scene_file")
    def pick_scene_save(self, parent, name): return self.answers.get("scene_save")
    def ask_text(self, parent, title, label, text=""): return self.answers.get("text")
    def confirm(self, parent, text): return self.answers.get("confirm", True)
    def inform(self, parent, text): self.answers["informed"] = text


def test_sections_and_general_page():
    with Sandbox() as sb:
        host = Fake(sb.tmp.name)
        d = settingsdialog.SettingsDialog("line", host=host)
        assert d.sections.count() == 3 and d.pages.count() == 3
        assert not d.minimized_box.isEnabled()
        d.autostart_box.setChecked(True); assert d.minimized_box.isEnabled()
        d.minimized_box.setChecked(True)
        d.repo_edit.setText("me/repo"); d.update_auto.setChecked(False)
        d.folder_btn.click(); assert host.opened == [host.install_dir()]
        d.accept()
        assert host.store["update_repo"] == "me/repo" and host.store["update_check"] is False
        assert host.auto == {"enabled": True, "minimized": True}


def test_check_for_updates_flow():
    with Sandbox() as sb:
        host = Fake(sb.tmp.name)
        d = settingsdialog.SettingsDialog("line", host=host)
        shown = []
        d.show_update = lambda rel: shown.append(rel)           # the changelog window is modal: not opened in tests
        d.repo_edit.setText("me/repo"); d.check_now()
        for _ in range(100):
            app.processEvents(); time.sleep(0.02)
            if shown: break
        assert shown and host.checked == "me/repo" and "9.0.0" in d.update_status.text()
        host.release = updater.Release(version="0.1.0", current="0.1.0", newer=False)
        d.check_now()
        for _ in range(100):
            app.processEvents(); time.sleep(0.02)
            if d.check_btn.isEnabled(): break
        assert "0.1.0" in d.update_status.text() and len(shown) == 1
        d.restart_requested.connect(lambda: shown.append("restart"))
        d.install_update(host.release)
        for _ in range(100):
            app.processEvents(); time.sleep(0.02)
            if "restart" in shown: break
        assert host.installed and shown[-1] == "restart"


def test_device_page_brightness_and_logo():
    with Sandbox() as sb:
        host = Fake(sb.tmp.name)
        d = settingsdialog.SettingsDialog("line", host=host)
        p = d.device_page
        assert p.serial_label.text() == "SN123" and p.brightness.value() == 40
        p.brightness.setValue(70)
        for _ in range(20):
            app.processEvents(); time.sleep(0.02)
        assert ["brightness", "70"] in host.sent
        assert not p.logo_clear.isEnabled()
        png = os.path.join(sb.tmp.name, "big.png"); Image.new("RGB", (1600, 900), (0, 200, 0)).save(png)
        host.answers["image"] = png
        p._pick()
        assert p.logo_enabled.isChecked() and "1600" in p.logo_info.text()
        d.accept()
        assert host.store["boot_logo"] is True and bootlogo.load().size == (800, 128)
        d2 = settingsdialog.SettingsDialog("line", host=host)
        assert d2.device_page.logo_enabled.isChecked()
        d2.device_page._clear(); d2.accept()
        assert host.store["boot_logo"] is False and bootlogo.load() is None


def test_scenes_page_actions():
    with Sandbox() as sb:
        host = Fake(sb.tmp.name)
        scenes.create("General"); scenes.create("Otra")
        d = settingsdialog.SettingsDialog("line", host=host)
        p = d.scenes_page
        assert p.list.count() == 2
        host.answers["text"] = "Nueva"; p.create()
        assert "Nueva" in scenes.names() and p.changed and p.selected() == "Nueva"
        host.answers["text"] = "Vuelo"; p.rename()
        assert "Vuelo" in scenes.names() and "Nueva" not in scenes.names()
        p.make_default(); assert scenes.default() == "Vuelo"
        p.move(-1); assert scenes.names().index("Vuelo") == 1
        p.duplicate(); assert any(n.startswith("Vuelo (") for n in scenes.names())
        host.answers["scene_save"] = os.path.join(sb.tmp.name, "out.ssscene"); p.export_scene()
        assert os.path.isfile(host.answers["scene_save"])
        host.answers["scene_file"] = host.answers["scene_save"]; before = len(scenes.names()); p.import_scene()
        assert len(scenes.names()) == before + 1
        host.answers["confirm"] = False; n = len(scenes.names()); p.remove(); assert len(scenes.names()) == n
        host.answers["confirm"] = True; p.remove(); assert len(scenes.names()) == n - 1
        p.swipe.setChecked(True); d.accept(); assert host.store["scene_swipe"] is True


def test_open_scene_with_unsaved_changes_is_protected():
    with Sandbox() as sb:
        host = Fake(sb.tmp.name); host.open_scene = "General"; host.open_scene_dirty = True
        scenes.create("General"); scenes.create("Otra")
        d = settingsdialog.SettingsDialog("line", host=host)
        p = d.scenes_page; p.refresh("General")
        host.answers["text"] = "X"; p.rename()
        assert "General" in scenes.names() and "X" not in scenes.names()
