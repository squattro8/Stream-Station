"""Talk to a running X-Plane 12 through its built-in web API (default http://localhost:8086).

    GET  /api/capabilities                               which API versions the sim offers
    GET  /api/<v>/datarefs?filter[name]=NAME             -> {"data": [{"id": 123, ...}]}
    GET  /api/<v>/datarefs/<id>/value                    -> {"data": 1}   (a list for array datarefs)
    GET  /api/<v>/commands?filter[name]=NAME             -> {"data": [{"id": 456, ...}]}
    POST /api/<v>/command/<id>/activate  {"duration": 0} runs the command once

Reads happen on a background thread and are cached, so the service's loop never waits for the network.
`online` is False when the sim is not running (nothing listening) or stopped answering.
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_URL = "http://127.0.0.1:8086"
POLL_S = 0.25
ONLINE_GRACE_S = 2.0


class XPlaneError(RuntimeError):
    pass


class XPlaneLink:
    def __init__(self, url: str = DEFAULT_URL, timeout: float = 0.6, opener=None):
        self.url = url.rstrip("/")
        self.timeout = timeout
        self._open = opener or urllib.request.urlopen
        self._version = "v2"
        self._ids: dict[tuple[str, str], int] = {}            # ("datarefs"|"commands", name) -> id
        self._watch: set[tuple[str, int | None]] = set()
        self._values: dict[tuple[str, int | None], float | None] = {}
        self._last_ok = 0.0
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    # --- HTTP ---------------------------------------------------------------------------------
    def _request(self, method: str, path: str, body: dict | None = None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.url + path, data=data, method=method,
                                     headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with self._open(req, timeout=self.timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as exc:
            raise XPlaneError(f"HTTP {exc.code} for {path}") from exc
        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            raise XPlaneError(f"X-Plane not reachable: {exc}") from exc
        if not raw:
            return None
        try:
            return json.loads(raw)
        except ValueError as exc:
            raise XPlaneError(f"unreadable answer for {path}") from exc

    def capabilities(self) -> dict:
        caps = self._request("GET", "/api/capabilities") or {}
        versions = (caps.get("api") or {}).get("versions") or []
        pick = sorted((v for v in versions if isinstance(v, str) and v.startswith("v")), key=lambda v: int(v[1:] or 0))
        if pick:
            self._version = pick[-1]
        return caps

    def _lookup(self, kind: str, name: str) -> int:
        key = (kind, name)
        if key not in self._ids:
            q = urllib.parse.quote(name, safe="/")
            found = (self._request("GET", f"/api/{self._version}/{kind}?filter[name]={q}") or {}).get("data") or []
            hit = next((d for d in found if d.get("name") == name), None)
            if not hit:
                raise XPlaneError(f"{kind[:-1]} {name!r} is not known to this X-Plane")
            self._ids[key] = int(hit["id"])
        return self._ids[key]

    # --- datarefs -----------------------------------------------------------------------------
    def read(self, dataref: str, index: int | None = None):
        """The current value (an element for array datarefs), or raises XPlaneError."""
        ident = self._lookup("datarefs", dataref)
        value = (self._request("GET", f"/api/{self._version}/datarefs/{ident}/value") or {}).get("data")
        if isinstance(value, list):
            value = value[index or 0] if value else None
        return value

    def read_text(self, dataref: str) -> str:
        """A string dataref (X-Plane sends those base64 encoded, zero padded)."""
        import base64
        raw = self.read(dataref)
        if isinstance(raw, list):
            return bytes(int(x) for x in raw if x).decode(errors="replace")
        try:
            return base64.b64decode(str(raw), validate=True).split(b"\0")[0].decode(errors="replace")
        except (ValueError, TypeError):
            return str(raw or "")

    def set_watch(self, items) -> None:
        """Which (dataref, index) pairs the polling thread keeps fresh."""
        with self._lock:
            self._watch = set(items)
            self._values = {k: v for k, v in self._values.items() if k in self._watch}
        if self._watch and (self._thread is None or not self._thread.is_alive()):
            self._stop.clear()
            self._thread = threading.Thread(target=self._poll, daemon=True, name="streamstation-xplane")
            self._thread.start()

    def value(self, dataref: str, index: int | None = None):
        with self._lock:
            return self._values.get((dataref, index))

    @property
    def online(self) -> bool:
        return time.monotonic() - self._last_ok < ONLINE_GRACE_S

    def _poll(self):
        while not self._stop.is_set():
            with self._lock:
                items = list(self._watch)
            for key in items:
                if self._stop.is_set():
                    return
                try:
                    v = self.read(*key)
                    with self._lock:
                        self._values[key] = v
                    self._last_ok = time.monotonic()
                except XPlaneError:
                    with self._lock:
                        self._values[key] = None
                    self._ids.pop(("datarefs", key[0]), None) if not self.online else None
            self._stop.wait(POLL_S)

    def close(self):
        self._stop.set()

    # --- commands -----------------------------------------------------------------------------
    def command(self, name: str) -> None:
        ident = self._lookup("commands", name)
        self._request("POST", f"/api/{self._version}/command/{ident}/activate", {"duration": 0})
