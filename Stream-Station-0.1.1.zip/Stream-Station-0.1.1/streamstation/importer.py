"""Bring profiles from an older layout into this program, with this program's own icons.

Only the user's DATA (the YAML of their profiles) is read. Every key icon is rebuilt from what the key
does, using this program's icon pipeline, so nothing visual is copied from the old installation, and
actions that relied on external tools are rewritten as this program's own verbs.

    streamstation import-profiles DIR       import <DIR>/profiles/*.yaml (DIR is the config folder of the older layout)
    streamstation rebuild-icons [NAME|--all] regenerate the icons of profiles already in this program
    streamstation prune-assets [--apply]    list (or delete) icon files no profile uses
"""
from __future__ import annotations

import copy
import os
import re
import shutil

import yaml

from . import profiles

# (regex, replacement) applied to a whole action string; \1 \2 are captured groups
ACTION_RULES = [
    (r"^playerctl\s+play-pause$", r"media:play-pause"),
    (r"^playerctl\s+next$", r"media:next"),
    (r"^playerctl\s+(previous|prev)$", r"media:prev"),
    (r"^wpctl\s+set-mute\s+@DEFAULT_AUDIO_SINK@\s+toggle$", r"volume:mute"),
    (r"^wpctl\s+set-mute\s+@DEFAULT_AUDIO_SOURCE@\s+toggle$", r"mic:mute"),
    (r"^wpctl\s+set-volume\s+(?:-l\s+\S+\s+)?@DEFAULT_AUDIO_SINK@\s+(\d+)%\+$", r"volume:up:\1"),
    (r"^wpctl\s+set-volume\s+(?:-l\s+\S+\s+)?@DEFAULT_AUDIO_SINK@\s+(\d+)%-$", r"volume:down:\1"),
    (r"^loginctl\s+lock-session$", r"lock"),
    (r"^systemctl\s+suspend$", r"suspend"),
    (r"^gtk-launch\s+(\S+)$", r"open:\1"),
    (r"^playerctl\s+volume\s+([0-9.]+)\+$", lambda m: f"media:volume-up:{round(float(m.group(1)) * 100)}"),
    (r"^playerctl\s+volume\s+([0-9.]+)-$", lambda m: f"media:volume-down:{round(float(m.group(1)) * 100)}"),
]


def translate_action(action):
    """Rewrite a known external-tool command as one of this program's verbs; anything else is kept."""
    if not isinstance(action, str):
        return action
    text = action.strip()
    for pattern, repl in ACTION_RULES:
        new, n = re.subn(pattern, repl, text)
        if n:
            return new
    return action


def _catalog_index():
    from .ui import catalog
    return {a: (label, plugin, group) for group, items in catalog.CATALOG for label, a, plugin in items if "{" not in a}


def _find_app(action: str, apps_list):
    if action.startswith("open:"):
        ident = action[5:]
        for a in apps_list:
            if a.id == ident or a.id == ident.removesuffix(".desktop"):
                return a
    if action.startswith("/"):                         # an absolute command: the launcher whose Exec starts with it
        from . import ui  # noqa: F401  (keeps the import graph explicit)
        from .ui import apps as appsmod
        for a in apps_list:
            cmd = appsmod.exec_command(_desktop_path(a)) or ""
            if cmd.split(" ")[0] == action.split(" ")[0]:
                return a
    return None


def _desktop_path(app) -> str:
    from .ui import apps as appsmod
    for d in appsmod.desktop_dirs():
        for rel in (app.id + ".desktop", app.id.replace("-", "/") + ".desktop"):
            p = os.path.join(d, rel)
            if os.path.isfile(p):
                return p
    return ""


def icon_for(entry: dict, lib, apps_list, catalog_index):
    """A 128x128 PIL tile for what this key does, or None when it only deserves a label tile."""
    from .ui import icons
    from .ui.apps import app_key_image
    action = entry.get("action") if isinstance(entry.get("action"), str) else None
    label = str(entry.get("label") or "")
    if isinstance(entry.get("xp"), dict):                    # an X-Plane key keeps its own glyph (the deck draws its state live)
        from .xplane import glyphs
        return glyphs.neutral_tile(str(entry["xp"].get("glyph") or glyphs.pick_glyph(action or label)))
    if action:
        app = _find_app(action, apps_list)
        if app:
            img = app_key_image(app.icon)
            if img is not None:
                return img
            return icons.fallback_tile("", "lilac", "app")          # an installed app whose icon the theme does not have
        if action.startswith("open:"):
            target = os.path.expanduser(action[5:])
            return icons.fallback_tile("", "lilac", "folder" if os.path.isdir(target) else ("file" if os.path.isfile(target) else "app"))
        if action in catalog_index:
            lbl, plugin, group = catalog_index[action]
            return lib.key_image("" if plugin == "—" else plugin, lbl, group, "unified", action=action)
        from .ui import actionicons
        name = actionicons.name_for(action)                  # any other known action: its own drawn icon
        if name:
            return actionicons.tile(name, actionicons.category_for(action))
        if action.startswith("layer:") or action == "dashboard":
            return icons.fallback_tile("", "slate", "layers" if action.startswith("layer:") else "overview")
    if "layer_toggle" in entry:
        return icons.fallback_tile("", "slate", "layers")
    if "profile" in entry:
        return icons.fallback_tile("", "violet", "profile")
    return icons.fallback_tile("", "lilac", "terminal")


def convert_profile(raw: dict, lib=None, apps_list=None, rebuild=True):
    """(new_raw, notes). Translates actions and rebuilds every key icon."""
    from .ui import configpanel, icons
    from .ui.apps import list_apps
    lib = lib or icons.IconLibrary()
    apps_list = list_apps() if apps_list is None else apps_list
    index = _catalog_index()
    out, notes = copy.deepcopy(raw), []

    def fix_keys(keys: dict, where: str):
        for k, entry in list((keys or {}).items()):
            if not isinstance(entry, dict):
                continue
            old = entry.get("action")
            new = translate_action(old)
            if new != old:
                entry["action"] = new
                notes.append(f"{where} tecla {k}: «{old}» → «{new}»")
            if isinstance(entry.get("action"), str) and entry["action"].split(" ")[0] == "playerctl":
                notes.append(f"{where} tecla {k}: usa playerctl, que no está instalado")
            if rebuild:
                img = icon_for(entry, lib, apps_list, index)
                entry["icon"] = configpanel.save_tile(img, f"{where}:{k}:{entry.get('action') or entry.get('label')}")

    fix_keys(out.get("keys"), "base")
    for name, layer in (out.get("layers") or {}).items():
        fix_keys((layer or {}).get("keys"), f"capa {name}")
    for n, page in enumerate(out.get("pages") or [], 1):
        fix_keys((page or {}).get("keys", page), f"página {n + 1}")
    for i, knob in (out.get("knobs") or {}).items():
        knob = knob or {}
        rot = knob.get("rotate") or {}
        for field, holder in (("cw", rot), ("ccw", rot), ("press", knob)):
            old = holder.get(field)
            new = translate_action(old)
            if new != old:
                holder[field] = new
                notes.append(f"perilla {int(i) + 1} {field}: «{old}» → «{new}»")
            if isinstance(holder.get(field), str) and holder[field].split(" ")[0] == "playerctl":
                notes.append(f"perilla {int(i) + 1} {field}: usa playerctl, que no está instalado")
    return out, notes


def import_profiles(src: str, out=print) -> list[str]:
    """Import every profile found in <src>/profiles (data only). Existing files get a .bak copy."""
    from .ui import model
    src = os.path.expanduser(src)
    folder = os.path.join(src, "profiles")
    if not os.path.isdir(folder):
        raise FileNotFoundError(f"no hay perfiles en {folder}")
    done = []
    for fname in sorted(os.listdir(folder)):
        if not fname.endswith(".yaml"):
            continue
        with open(os.path.join(folder, fname)) as fh:
            raw = yaml.safe_load(fh) or {}
        name = fname[:-5]
        new, notes = convert_profile(raw)
        dest = os.path.join(model.user_profiles_dir(), fname)
        os.makedirs(model.user_profiles_dir(), exist_ok=True)
        if os.path.exists(dest):
            shutil.copy2(dest, dest + ".bak")
        with open(dest, "w") as fh:
            yaml.safe_dump(new, fh, sort_keys=False, allow_unicode=True)
        out(f"importado {name}  ({len(notes)} cambios)")
        for n in notes:
            out("   · " + n)
        done.append(name)
    return done


def rebuild_icons(names=None, out=print) -> list[str]:
    """Regenerate the icons (and translate old actions) of profiles already in this program."""
    from .ui import model
    folder = model.user_profiles_dir()
    done = []
    for fname in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
        if not fname.endswith(".yaml") or (names and fname[:-5] not in names):
            continue
        path = os.path.join(folder, fname)
        with open(path) as fh:
            raw = yaml.safe_load(fh) or {}
        new, notes = convert_profile(raw)
        shutil.copy2(path, path + ".bak")
        with open(path, "w") as fh:
            yaml.safe_dump(new, fh, sort_keys=False, allow_unicode=True)
        out(f"iconos reconstruidos en {fname[:-5]}  ({len(notes)} cambios de acción)")
        for n in notes:
            out("   · " + n)
        done.append(fname[:-5])
    return done


def referenced_assets() -> set[str]:
    """Relative paths of every icon/image any profile of this program points to."""
    from .ui import model
    refs: set[str] = set()

    def walk(node):
        if isinstance(node, dict):
            for k, v in node.items():
                if k in ("icon", "path") and isinstance(v, str):
                    refs.add(v)
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)
    folder = model.user_profiles_dir()
    for fname in os.listdir(folder) if os.path.isdir(folder) else []:
        if fname.endswith(".yaml"):
            with open(os.path.join(folder, fname)) as fh:
                walk(yaml.safe_load(fh) or {})
    return refs


def prune_assets(apply: bool = False, out=print) -> list[str]:
    """Files under the user's assets folder that no profile references (deleted only with apply=True)."""
    base = os.path.join(profiles.CONFIG, "assets")
    refs = {os.path.normpath(r) for r in referenced_assets() if not os.path.isabs(r)}
    unused = []
    for root, _, files in os.walk(base):
        for f in files:
            rel = os.path.normpath(os.path.relpath(os.path.join(root, f), base))
            if rel not in refs:
                unused.append(rel)
    for rel in sorted(unused):
        if apply:
            os.remove(os.path.join(base, rel))
    if apply:                       # drop folders left empty
        for root, dirs, files in os.walk(base, topdown=False):
            if root != base and not os.listdir(root):
                os.rmdir(root)
    out(f"{'borrados' if apply else 'sin usar'}: {len(unused)} archivos en {base}")
    return sorted(unused)
