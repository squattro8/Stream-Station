"""Native Linux replacement for Redragon Stream Station (SS-552)."""
__version__ = "0.1.1"
