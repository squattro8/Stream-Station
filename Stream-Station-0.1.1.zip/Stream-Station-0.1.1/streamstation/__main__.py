"""python -m streamstation <command>

  run [P]    the service (profile P, default General)
  ui         the graphical editor
  import-profiles DIR   import profiles from an older layout (data only, icons rebuilt)
  rebuild-icons [NAME|--all]   regenerate key icons with this program's own pipeline
  prune-assets [--apply]   list / delete icon files no profile uses
  fetch-logos   download the real marks of the services (YouTube, Spotify...) to your config folder, then rebuild icons
  ctl ...    talk to the running service (status, profile X, layer X, reload)
  listen     print decoded input reports (read-only on the display)
  init       wake + full brightness
  clear      clear all displays
  draw IMG [x y w h [index]]   one region of the strip canvas (800x128, as the viewer sees it)
  paint N P  paint image P (any format) on slot N
"""
from __future__ import annotations

import io
import sys
import time

from . import protocol as P
from .device import Deck, DeviceBusy


def jpeg(path: str, size: tuple[int, int], rotate=180) -> bytes:
    from PIL import Image
    img = Image.open(path).convert("RGB").resize(size).rotate(rotate)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=90)
    return buf.getvalue()


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    cmd, args = argv[0], argv[1:]
    if cmd == "run":
        import logging
        from .service import Service
        logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
        Service(profile=args[0] if args else "General").run()
        return 0
    if cmd in ("import-profiles", "rebuild-icons", "prune-assets"):
        from . import importer
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication(sys.argv[:1])      # icons are read through Qt
        try:
            if cmd == "import-profiles":
                if not args:
                    print("uso: streamstation import-profiles CARPETA   (la carpeta de configuración de la instalación anterior)", file=sys.stderr)
                    return 2
                importer.import_profiles(args[0])
            elif cmd == "rebuild-icons":
                importer.rebuild_icons(None if (not args or args[0] == "--all") else args)
            else:
                importer.prune_assets(apply="--apply" in args)
        except FileNotFoundError as exc:
            print(f"streamstation: {exc}", file=sys.stderr)
            return 1
        return 0
    if cmd == "fetch-logos":
        from . import importer, logos
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication(sys.argv[:1])
        result = logos.fetch()
        if result["done"]:
            importer.rebuild_icons(out=lambda *_: None)
            print(f"{len(result['done'])} logos descargados; iconos rehechos en tus perfiles")
        return 0 if not result["failed"] else 1
    if cmd == "ui":
        from .ui.__main__ import main as ui_main
        return ui_main(args)
    if cmd == "ctl":
        from .service import ctl
        try:
            print(ctl(args))
            return 0
        except OSError as exc:
            print(f"streamstation: service not reachable: {exc}", file=sys.stderr)
            return 1
    try:
        with Deck() as deck:
            if cmd == "init":
                deck.send(P.wake())
                deck.send(P.brightness(100))
            elif cmd == "clear":
                deck.send(P.clear(0xFF))
                deck.send(P.stop())
            elif cmd == "paint":
                slot, path = int(args[0]), args[1]
                size = (208, 124) if slot < 4 else (120, 120)  # [LIVE] unverified
                data = jpeg(path, size)
                deck.send(P.image_header(slot + 1, len(data)))
                for chunk in P.image_chunks(data):
                    deck.send(chunk)
                deck.send(P.stop())
            elif cmd == "draw":
                # draw <image> [x y w h [index]]: one region of the strip canvas (800x128, viewer coordinates)
                a = [v for v in args if not v.startswith("--")]
                x, y, w, h = (int(v) for v in a[1:5]) if len(a) >= 5 else (0, 0, P.STRIP_W, P.STRIP_H)
                index = int(a[5]) if len(a) >= 6 else 0
                from PIL import Image
                from . import render
                stream = render.strip_region_stream(Image.open(a[0]).convert("RGB"), x, y, w, h, index)
                print(f"DRA region x={x} y={y} {w}x{h} index={index} stream={len(stream)} B")
                for chunk in P.image_chunks(stream):
                    deck.send(chunk)
                deck.send(P.stop())
            elif cmd == "listen":
                last = time.monotonic()
                while True:
                    raw = deck.read(200)
                    if raw is not None:
                        print(P.parse_report(raw), raw[:12].hex(" "), flush=True)
                    if time.monotonic() - last > 10:
                        deck.send(P.connect())
                        last = time.monotonic()
            else:
                print(__doc__)
                return 2
    except DeviceBusy as exc:
        print(f"streamstation: {exc}\nStop whatever owns the deck (another driver or this service: systemctl --user stop streamstation).", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
