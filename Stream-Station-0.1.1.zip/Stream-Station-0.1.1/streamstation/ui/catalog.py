"""Action catalog shown in the right sidebar, grouped like the original app's plugin tree.

Each item: (label, action string, original plugin action). `action` is exactly what the
service runs; items with a ``{}`` placeholder need a value from the user ("Atajo", "Sitio web"...).
"""
from __future__ import annotations

from ..i18n import tr
from ..services import SERVICES

CATALOG = [
    ("Dispositivo", [
        ("Brillo +", "brightness+10", "device.brightness"),
        ("Brillo −", "brightness-10", "device.brightness"),
        ("Ragnaros en standby", "screen-off", "device.devsleep"),
        ("Página siguiente", "page:next", "page.next"),
        ("Página anterior", "page:prev", "page.previous"),
        ("Ir a página…", "page:{}", "page.goto"),
        ("Escena siguiente", "scene:next", "page.next"),
        ("Escena anterior", "scene:prev", "page.previous"),
        ("Cambiar de perfil…", "profile:{}", "profile.rotate"),
    ]),
    ("Herramientas", [
        ("Sitio web…", "url:{}", "system.website"),
        ("Atajo de teclado…", "key:{}", "system.hotkey"),
        ("Texto…", "text:{}", "system.text"),
        ("Abrir app o archivo…", "open:{}", "system.open"),
        ("Comando…", "{}", "system.open"),
    ]),
    ("Audio", [
        ("Subir volumen", "volume:up:5", "quickcontrol.volumeup"),
        ("Bajar volumen", "volume:down:5", "quickcontrol.volumedown"),
        ("Silenciar", "volume:mute", "quickcontrol.mute"),
        ("Micrófono", "mic:mute", "quickcontrol.microphone"),
        ("Reproducir / pausa", "media:play-pause", "system.multimedia"),
        ("Siguiente pista", "media:next", "system.multimedia"),
        ("Pista anterior", "media:prev", "system.multimedia"),
        ("Reproducir sonido…", "sound:play:{}", "soundboard.playaudio"),
        ("Detener sonido", "sound:stop", "soundboard.stopaudioplay"),
    ]),
    ("Flujo de operación", [
        ("Alternar entre acciones", "{toggle}", "multiactions.toggle"),
        ("Acción aleatoria", "{random}", "multiactions.random"),
        ("Secuencia con retardo", "{sequence}", "multiactions.routine"),
    ]),
    ("Sistema", [
        ("Bloquear equipo", "lock", "SimulatedKeyboardEvent.computerLockWorkStation"),
        ("Suspender", "suspend", "quickcontrol.sleep"),
        ("Abrir este editor", "$HOME/.local/bin/streamstation ui", "—"),
    ]),
    ("Escritorio (KDE)", [
        ("Mostrar escritorio", "desktop:show", "quickcontrol.displaydesktop"),
        ("Vista general", "desktop:overview", "—"),
        ("Buscar", "desktop:search", "quicktool.searchbar"),
        ("Emojis", "desktop:emoji", "quicktool.emoticons"),
        ("No molestar", "desktop:dnd", "quicktool.notification"),
        ("Cambiar de pantalla", "desktop:switch-screen", "quickcontrol.switchscreen"),
        ("Monitor del sistema", "tool:taskmanager", "quicktool.taskmanager"),
        ("Ajustes", "tool:controlpanel", "quicktool.controlpanel"),
        ("Calculadora", "tool:calculator", "quicktool.calculator"),
        ("Correo", "tool:mail", "quicktool.mail"),
    ]),
    ("Navegador", [
        ("Atrás", "browser:back", "browser.back"),
        ("Adelante", "browser:forward", "browser.forward"),
        ("Recargar", "browser:refresh", "browser.refresh"),
        ("Favorito", "browser:collect", "browser.collect"),
    ]),
    ("Servicios", [(svc.name, f"service:{svc.id}", "—") for svc in SERVICES]),
    ("Red", [
        ("Enviar UDP…", "udp:{}", "network.udp"),
    ]),
]


def search(text: str):
    """Groups filtered by a search string (case-insensitive, matches label or action)."""
    t = text.strip().lower()
    if not t:
        return CATALOG
    out = []
    for group, items in CATALOG:
        hit = [i for i in items if t in i[0].lower() or t in tr(i[0]).lower() or t in i[1].lower() or t in tr(group).lower()]
        if hit:
            out.append((group, hit))
    return out
