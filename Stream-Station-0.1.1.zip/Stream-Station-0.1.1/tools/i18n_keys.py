#!/usr/bin/env python3
"""Every text of the program that has to exist in each language file (streamstation/locales/<code>.json).

    python3 tools/i18n_keys.py            list them
    python3 tools/i18n_keys.py --check    report, per language, what is missing

It reads the code: the first argument of tr()/tr_strip() calls, plus the fixed tables whose entries are translated
where they are shown (catalog, panels' drop-downs, X-Plane categories, weather names...).
"""
from __future__ import annotations

import ast
import os
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, ROOT)


def from_calls() -> set[str]:
    keys = set()
    for dp, _d, fs in os.walk(os.path.join(ROOT, "streamstation")):
        for f in fs:
            if not f.endswith(".py"):
                continue
            tree = ast.parse(open(os.path.join(dp, f), encoding="utf-8").read())
            for n in ast.walk(tree):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("tr", "tr_strip") \
                        and n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str):
                    keys.add(n.args[0].value)
    return keys


def from_tables() -> set[str]:
    from streamstation import services, strip, weather
    from streamstation.ui import actionicons, catalog, configpanel, knobpanel, strippanel
    from streamstation.xplane import catalog as xcat
    keys = set()
    for group, items in catalog.CATALOG:
        keys.add(group)
        keys.update(label for label, _a, _p in items if label not in {s.name for s in services.SERVICES if s.name == label and label.isascii() and " " not in label})
    keys.update(s.name for s in services.SERVICES if "Calendario" in s.name)
    for table in (strippanel.TYPES, strippanel.METRICS, strippanel.FITS, configpanel.SHORTCUT_PRESETS):
        keys.update(label for label, _v in table)
    keys.update(label for _k, label in knobpanel.FIELDS)
    keys.update(label for label, _t in knobpanel.TEMPLATES)
    keys.update(xcat.CATEGORY_NAMES.values())
    keys.update(actionicons.STYLES.values())
    keys.update(strip.TITLES.values())
    keys.update(weather.describe(c)[1] for c in (0, 1, 2, 3, 45, 51, 61, 65, 71, 95))
    from streamstation.ui import settingsdialog, settingspages
    keys.update(label for _k, label in settingspages.FIT_LABELS)
    keys.update(label for _k, label in settingspages.SCENE_BUTTONS)
    keys.update(label for _k, label in settingsdialog.SECTIONS)
    keys.update(("Inicio", "Escenas", "Ayuda", "Configuración", "Nuevo perfil", "Quitar perfil (aún no disponible)",
                 "Aplicaciones o juegos que activan este perfil", "Idioma", "Tema", "Iconos", "Aceptar", "Cancelar"))
    return keys


def all_keys() -> list[str]:
    keys = from_calls() | from_tables()
    keys -= {"CPU", "RAM", "GPS", "FMS", "FMS 2", "ATC", "Joystick", "°C", "°F", "Google Drive", "Google Maps", "YouTube Music"}          # the same in every language
    return sorted(k for k in keys if k.strip())


if __name__ == "__main__":
    ks = all_keys()
    if "--check" in sys.argv:
        from streamstation import i18n
        for code in i18n.CODES:
            miss = i18n.missing(code, ks) if code != i18n.SOURCE else []
            print(f"{code}: {len(ks) - len(miss)}/{len(ks)}" + (f"  faltan {len(miss)}" if miss else ""))
    else:
        print("\n".join(ks)); print(f"# {len(ks)} textos", file=sys.stderr)
