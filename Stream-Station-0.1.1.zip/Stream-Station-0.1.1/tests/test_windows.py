import os, sys, pathlib, queue
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from streamstation import windows as W


def win(cls="", name="", title="", pid=0, desktop=""):
    return W.Window(cls, name, title, pid, desktop)


def test_rule_needs_every_key_and_ignores_case_and_supports_wildcards():
    w = win(cls="steam_app_2014780", title="X-Plane 12 - Main", desktop="steam_app_2014780")
    assert W.rule_matches({"class": "STEAM_APP_*"}, w)
    assert W.rule_matches({"class": "steam_app_2014780", "title": r"x-plane\s+12"}, w)
    assert not W.rule_matches({"class": "steam_app_2014780", "title": "Minecraft"}, w)     # one key fails -> no match
    assert not W.rule_matches({}, w) and not W.rule_matches("class", w) and not W.rule_matches({"bogus": "x"}, w)
    assert not W.rule_matches({"title": "(unclosed"}, w)                                    # bad regex is "no match", not a crash
    assert not W.rule_matches({"exe": "xplane"}, win(cls="a", pid=0))                       # unknown exe never matches


def test_exe_rule_uses_the_process_executable():
    me = win(cls="x", pid=os.getpid())
    assert me.exe and W.rule_matches({"exe": me.exe}, me)
    assert not W.rule_matches({"exe": "definitely-not-this"}, me)
    assert win(pid=999999999).exe == ""                                                     # vanished process


def test_find_profile_prefers_the_most_specific_rule_then_name_order():
    rules = {"Steam": [{"class": "steam*"}], "XPlane": [{"class": "steam_app_2014780", "title": "X-Plane"}],
             "Aviones": [{"class": "steam*"}]}
    assert W.find_profile(win(cls="steam_app_2014780", title="X-Plane 12"), rules) == "XPlane"   # 2 keys beat 1 key
    assert W.find_profile(win(cls="steam_app_1"), rules) == "Aviones"                           # tie: alphabetical
    assert W.find_profile(win(cls="firefox"), rules) is None
    assert W.find_profile(win(cls="steam"), {"A": None, "B": []}) is None


def test_ignored_windows_never_trigger_a_switch():
    for cls in ("plasmashell", "KRunner", "streamstation", ""):
        assert W.is_ignored(win(cls=cls, name="")), cls
    assert not W.is_ignored(win(cls="firefox")) and not W.is_ignored(win(name="resource-only"))


def test_dbus_service_delivers_what_kwin_would_send():
    import gi
    gi.require_version("Gio", "2.0")
    from gi.repository import Gio, GLib
    got = queue.Queue()
    service = f"org.streamstation.Test{os.getpid()}"
    watcher = W.WindowWatcher(got.put, service=service, load_kwin=False)
    assert watcher.start(), watcher.error
    try:
        bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
        call = lambda variant: bus.call_sync(service, W.PATH, W.IFACE, "ActiveWindow", variant, None, Gio.DBusCallFlags.NONE, 3000, None)
        call(GLib.Variant("(sssis)", ("X-Plane", "x-plane", "X-Plane 12 — ¡Vuelo!", 4242, "steam_app_2014780.desktop")))
        w = got.get(timeout=3)
        assert (w.cls, w.name, w.title, w.pid, w.desktop) == ("X-Plane", "x-plane", "X-Plane 12 — ¡Vuelo!", 4242, "steam_app_2014780.desktop")
        try: call(GLib.Variant("(s)", ("wrong signature",)))
        except Exception: pass                                                          # a malformed call must not kill the service
        call(GLib.Variant("(sssis)", ("firefox", "", "", 1, "")))
        assert got.get(timeout=3).cls == "firefox"
    finally:
        watcher.stop()


def test_the_kwin_script_is_valid_text_with_the_right_names():
    js = W.SCRIPT_JS % {"service": W.SERVICE, "path": W.PATH, "iface": W.IFACE}
    assert W.SERVICE in js and "ActiveWindow" in js and "windowActivated" in js and "%" not in js
