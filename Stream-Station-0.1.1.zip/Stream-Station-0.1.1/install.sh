#!/usr/bin/env bash
# Installs the Stream Station service and editor for the current user. Nothing outside $HOME is touched.
#   ./install.sh              dry run: prints what would change
#   ./install.sh --apply      install / update the program (icon, menu entry, wrapper, service file)
#   ./install.sh --uninstall  remove this program (profiles in ~/.config/streamstation are kept)
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
mode=dry
case "${1:-}" in --apply) mode=apply;; --uninstall) mode=uninstall;; "") ;; *) echo "opción desconocida: $1"; exit 2;; esac
apply=0; if [ "$mode" != dry ]; then apply=1; fi

share="$HOME/.local/share/streamstation"
bin="$HOME/.local/bin/streamstation"
units="$HOME/.config/systemd/user"
unit="$units/streamstation.service"
desk="$HOME/.local/share/applications/streamstation.desktop"
icons="$HOME/.local/share/icons/hicolor"
cfg="$HOME/.config/streamstation"

run() { if [ "$apply" = 1 ]; then echo "+ $*"; "$@"; else echo "[dry-run] $*"; fi; }

if [ "$mode" = uninstall ]; then
  run systemctl --user disable --now streamstation.service || true
  run rm -rf "$share" "$unit" "$bin" "$desk" "$icons/256x256/apps/streamstation.png" "$icons/48x48/apps/streamstation.png"
  run systemctl --user daemon-reload
  echo "Desinstalado. Tus perfiles siguen en $cfg."; exit 0
fi

run mkdir -p "$share" "$units" "$(dirname "$bin")" "$(dirname "$desk")" "$icons/256x256/apps" "$icons/48x48/apps" "$cfg"
run rm -rf "$share/streamstation"
run cp -r "$here/streamstation" "$share/"
run find "$share" -name __pycache__ -type d -prune -exec rm -rf {} +
run cp "$here/systemd/streamstation.service" "$unit"
if [ "$apply" = 1 ]; then
  printf '#!/bin/sh\nexport PYTHONPATH="$HOME/.local/share/streamstation${PYTHONPATH:+:$PYTHONPATH}"\nexec python3 -m streamstation "$@"\n' > "$bin"; chmod +x "$bin"; echo "+ escrito $bin"
  PYTHONPATH="$share" python3 -c "
from streamstation.ui import appicon
appicon.save('$icons/256x256/apps/streamstation.png', 256); appicon.save('$icons/48x48/apps/streamstation.png', 48)"
  echo "+ iconos en $icons"
  cat > "$desk" <<DESK
[Desktop Entry]
Type=Application
Name=Stream Station
GenericName=Editor del Ragnaros SS-552
Comment=Teclas, perillas y franja táctil del Redragon Ragnaros
Exec=$bin ui
Icon=streamstation
Terminal=false
StartupWMClass=streamstation
Categories=Settings;HardwareSettings;
Keywords=ragnaros;redragon;stream;deck;teclas;franja;perillas;
DESK
  echo "+ escrito $desk"
  command -v update-desktop-database >/dev/null && update-desktop-database "$HOME/.local/share/applications" || true
  command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q "$icons" 2>/dev/null || true
else
  echo "[dry-run] escribir $bin, $desk e iconos"
fi
run systemctl --user daemon-reload
echo
echo "Servicio: systemctl --user enable --now streamstation.service   (arranca con tu sesión)"
echo "Editor:   busca «Stream Station» en el menú de aplicaciones, o ejecuta: $bin ui"
