"""The application icon, drawn by code (no external artwork): the deck seen from above."""
from __future__ import annotations

from PIL import Image, ImageDraw

from . import theme as T

PASTELS = ["#be9beb", "#9b9cf2", "#7fd8cf", "#a79cf5", "#8fb4f5", "#fdd9a1", "#e49be0", "#6fa0ee", "#ec7f7f", "#3ba84a"]


def draw(size: int = 256) -> Image.Image:
    k = size / 256
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([8 * k, 8 * k, 248 * k, 248 * k], radius=40 * k, fill=T.BG_DEEP, outline=T.OUTLINE, width=max(2, round(6 * k)))
    for i, color in enumerate(PASTELS):                                        # 2 x 5 keys
        r, c = divmod(i, 5)
        x, y = (34 + c * 38) * k, (36 + r * 38) * k
        d.rounded_rectangle([x, y, x + 30 * k, y + 30 * k], radius=7 * k, fill=color)
    d.rounded_rectangle([30 * k, 120 * k, 226 * k, 150 * k], radius=9 * k, fill=T.BG_STRIP, outline=T.ACCENT, width=max(1, round(3 * k)))
    for i in range(4):                                                         # knobs
        cx = (58 + i * 46) * k
        d.ellipse([cx - 17 * k, 172 * k, cx + 17 * k, 206 * k], fill=T.OUTLINE, outline="#6a6a6a", width=max(1, round(2 * k)))
        d.ellipse([cx - 7 * k, 182 * k, cx + 7 * k, 196 * k], fill="#2a2a2a")
    return img


def qicon():
    from PySide6.QtGui import QIcon
    from .icons import to_qpixmap
    icon = QIcon()
    for s in (16, 32, 48, 64, 128, 256):
        icon.addPixmap(to_qpixmap(draw(s)))
    return icon


def save(path: str, size: int = 256) -> str:
    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)
    draw(size).save(path)
    return path
