"""Profiles: YAML files mapping keys / knobs to actions.

Schema of a profile file:
  name: General
  keys:   {'0': {icon: icons/x.png, action: <shell> | profile: <name> | layer_toggle: <layer>}}
  knobs:  {'0': {rotate: {cw: <cmd>, ccw: <cmd>}, press: <cmd>}}
  layers: {<name>: {keys: {...}}}
Special action strings: ``layer:<name>`` toggles a layer, ``profile:<name>``
switches profile. ``page:*`` and ``dashboard`` are accepted but not implemented.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

import yaml

CONFIG = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "streamstation")


def search_dirs(sub: str) -> list[str]:
    d = os.path.join(CONFIG, sub)
    return [d] if os.path.isdir(d) else []


@dataclass
class Profile:
    name: str
    keys: dict = field(default_factory=dict)
    knobs: dict = field(default_factory=dict)
    layers: dict = field(default_factory=dict)
    strip: dict = field(default_factory=dict)
    pages: list = field(default_factory=list)   # extra key maps; page 0 is `keys`
    match: list = field(default_factory=list)   # rules that activate this profile when an application has focus
    strip_mode: str = "fixed"                   # "fixed": one strip for every page | "per_page": each page has its own
    page_swipe: bool = False                    # a swipe along the strip goes to the next page (the deck cannot tell the direction)

    def dashboard(self) -> list[str]:
        return list((self.strip or {}).get("dashboard") or [])

    def strip_for(self, page: int = 0) -> dict:
        """The strip block that applies on `page`: always `strip` when fixed; the page's own one when per_page
        (a page without one shows an empty strip)."""
        if self.strip_mode == "per_page" and page > 0:
            entry = self.pages[page - 1] if page - 1 < len(self.pages) else None
            return (entry or {}).get("strip") or {} if isinstance(entry, dict) else {}
        return self.strip or {}

    def strip_content(self, page: int = 0) -> dict | None:
        """What the strip should show, or None to leave it alone.
        `full` (one image/GIF across all panels) > `segments` (4 specs) > legacy `dashboard` (metrics)."""
        s = self.strip_for(page)
        if s.get("full"):
            return {"mode": "full", "full": s["full"]}
        if s.get("segments"):
            return {"mode": "segments", "segments": list(s["segments"])}
        if s.get("dashboard"):
            return {"mode": "segments", "segments": [{"type": "metric", "kind": k} for k in s["dashboard"][:4]]}
        return None

    def page_count(self) -> int:
        return 1 + len(self.pages)

    def key(self, index: int, layer: str | None = None, page: int = 0):
        if layer and layer in self.layers:
            entry = (self.layers[layer].get("keys") or {}).get(str(index))
            if entry is not None:
                return entry
        if page > 0 and page - 1 < len(self.pages):
            return ((self.pages[page - 1] or {}).get("keys") or self.pages[page - 1] or {}).get(str(index))
        return self.keys.get(str(index))

    def knob(self, index: int):
        return self.knobs.get(str(index)) or {}


def load(name: str, dirs: list[str] | None = None) -> Profile:
    for d in dirs or search_dirs("profiles"):
        path = os.path.join(d, f"{name}.yaml")
        if os.path.isfile(path):
            with open(path) as fh:
                raw = yaml.safe_load(fh) or {}
            return Profile(raw.get("name", name), raw.get("keys") or {},
                           raw.get("knobs") or {}, raw.get("layers") or {},
                           raw.get("strip") or {}, raw.get("pages") or [], _rules(raw.get("match")),
                           "per_page" if raw.get("strip_mode") == "per_page" else "fixed",
                           raw.get("page_swipe") is True)
    raise FileNotFoundError(f"profile {name!r} not found")


def _rules(value) -> list:
    return [r for r in value if isinstance(r, dict) and r] if isinstance(value, list) else []


_rules_cache: dict = {"stamp": None, "rules": {}}


def match_rules() -> dict[str, list]:
    """{profile name: its `match` rules}, re-read only when a profile file changed."""
    files = {}
    for d in search_dirs("profiles"):
        for f in os.listdir(d):
            if f.endswith(".yaml"):
                files.setdefault(f[:-5], os.path.join(d, f))
    stamp = tuple(sorted((n, p, os.path.getmtime(p)) for n, p in files.items()))
    if _rules_cache["stamp"] != stamp:
        rules = {}
        for name, path in files.items():
            try:
                with open(path) as fh:
                    raw = yaml.safe_load(fh) or {}
            except (OSError, yaml.YAMLError):
                continue
            found = _rules(raw.get("match") if isinstance(raw, dict) else None)
            if found:
                rules[name] = found
        _rules_cache.update(stamp=stamp, rules=rules)
    return _rules_cache["rules"]


DEFAULT_SETTINGS = {
    "screen_off_s": 0,        # 0 = never; original: setScreenOffTime
    "screen_off_action": "off",   # original ScreenOffAction: software-off / HAN / disconnect
    "follow_lock": True,      # turn the deck off while the desktop session is locked
    "auto_profile": True,     # switch profile when an application with `match:` rules gets focus
    "brightness": 100,        # key brightness in percent; the last one used is kept for the next session
    "boot_logo": False,       # draw the user's start-up picture on the strip when the deck connects
    "boot_logo_seconds": 3,   # how long it stays before the profile appears
    "autostart": False,       # open Stream Station when the computer starts
    "autostart_minimized": False,
    "update_repo": "squattro8/Stream-Station",        # GitHub "user/name" whose releases are checked for new versions
    "update_check": True,     # look for a new version when the editor opens (one plain request to GitHub)
    "update_skip": "",        # a version the user chose to ignore
    "scene_order": [],        # the order of the scenes (profiles) in the list; the rest follow alphabetically
    "default_profile": "",    # the scene shown when the application in front has none of its own
    "scene_swipe": False,     # a swipe along the strip changes scene (when it is not already changing page)
    "language": "en",         # interface language (a new installation starts in English)
    "theme": "dark",          # interface theme: light | dark | system
    "icon_style": "pastel",   # look of the key icons: pastel | neon | line
    "strip_offset_y": 4,      # pixels the strip content is moved UP (the screen looks lower from above the deck)
    "xplane_dir": "",         # X-Plane folder; empty = look in the usual Steam / home locations
    "xplane_aircraft": "",    # name of the aircraft folder whose controls the editor lists
    "xplane_url": "",         # X-Plane web API; empty = http://127.0.0.1:8086
}


def load_settings(dirs: list[str] | None = None) -> dict:
    out = dict(DEFAULT_SETTINGS)
    for d in dirs or [CONFIG]:
        path = os.path.join(d, "config.yaml")
        if os.path.isfile(path):
            with open(path) as fh:
                raw = yaml.safe_load(fh) or {}
            if isinstance(raw, dict):
                out.update({k: v for k, v in raw.items() if k in DEFAULT_SETTINGS})
            break
    return out


def save_setting(key: str, value) -> None:
    """Persist one setting in the user's config.yaml (creating it if needed)."""
    if key not in DEFAULT_SETTINGS:
        raise KeyError(key)
    path = os.path.join(CONFIG, "config.yaml")
    data = {}
    if os.path.isfile(path):
        with open(path) as fh:
            data = yaml.safe_load(fh) or {}
    data[key] = value
    os.makedirs(CONFIG, exist_ok=True)
    with open(path + ".tmp", "w") as fh:
        yaml.safe_dump(data, fh)
    os.replace(path + ".tmp", path)


def available(dirs: list[str] | None = None) -> list[str]:
    names = set()
    for d in dirs or search_dirs("profiles"):
        names.update(f[:-5] for f in os.listdir(d) if f.endswith(".yaml"))
    return sorted(names)
