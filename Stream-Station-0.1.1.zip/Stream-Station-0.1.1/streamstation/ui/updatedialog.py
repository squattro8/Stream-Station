"""The window that announces a new version: what changed (the release notes), and the choice to update now, later or never."""
from __future__ import annotations

from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QTextBrowser, QVBoxLayout

from ..i18n import tr

UPDATE, LATER, SKIP = "update", "later", "skip"


class UpdateDialog(QDialog):
    def __init__(self, release, parent=None):
        super().__init__(parent)
        self.release = release
        self.choice = LATER
        self.setWindowTitle(tr("Actualización disponible"))
        self.resize(560, 460)
        lay = QVBoxLayout(self)
        head = QLabel(tr("Nueva versión detectada: {new} (instalada: {current})", new=release.version, current=release.current))
        head.setObjectName("heading"); lay.addWidget(head)
        lay.addWidget(QLabel(tr("Novedades:")))
        self.notes = QTextBrowser(); self.notes.setOpenExternalLinks(True)
        self.notes.setMarkdown(release.notes or tr("No se pudo obtener la información de la nueva versión."))
        lay.addWidget(self.notes, 1)
        row = QHBoxLayout()
        self.skip_btn = QPushButton(tr("Omitir esta versión")); self.later_btn = QPushButton(tr("Más tarde"))
        self.update_btn = QPushButton(tr("Actualizar ahora")); self.update_btn.setDefault(True)
        row.addWidget(self.skip_btn); row.addStretch(); row.addWidget(self.later_btn); row.addWidget(self.update_btn)
        lay.addLayout(row)
        self.update_btn.clicked.connect(lambda: self._done(UPDATE))
        self.later_btn.clicked.connect(lambda: self._done(LATER))
        self.skip_btn.clicked.connect(lambda: self._done(SKIP))

    def _done(self, choice: str):
        self.choice = choice
        self.accept() if choice == UPDATE else self.reject()
