"""The long running service: paints the profile, runs actions, serves a control socket."""
from __future__ import annotations

import json
import math
import logging
import os
import shlex
import signal
import socket
import subprocess
import time

import collections
import queue
import random
import threading

from PIL import Image

from . import bootlogo, i18n, plugins, profiles, scenes, protocol as P, render, strip, system, windows
from .xplane import glyphs as xp_glyphs, link as xp_link, states as xp_states
from .device import Deck, DeviceBusy

log = logging.getLogger("streamstation")

HEARTBEAT_S = 10          # DLL has a CONNECT heartbeat; its interval is not known statically
AUTO_DEBOUNCE_S = 0.35    # focus must settle this long before the profile changes (fast Alt+Tab must not flicker)
BREATH_SHARPNESS = 5      # >1: longer dark, shorter glow
BREATH_MAX = 0.4          # the brightest the outline gets (of full cyan): low, it is a night light
BREATH_PERIOD_S = 6.0     # one in-and-out of the standby outline: slow, so it is calm at night
STRIP_TICK_S = 0.2        # how often the strip plan is re-evaluated; only changed panels are sent
STRIP_DEBOUNCE_S = 0.35   # a touch/swipe is a burst of reports [LIVE]
KEYS_SETTLE_S = 0.12      # page/layer changes repaint once, this long after the last one (a knob turns several detents)
KNOB_DEBOUNCE_S = 0.06   # one physical detent emits a burst of identical reports [LIVE]


def socket_path() -> str:
    runtime = os.environ.get("XDG_RUNTIME_DIR") or f"/run/user/{os.getuid()}"
    return os.path.join(runtime, "streamstation.sock")


class Service:
    def __init__(self, profile="General", sock_path=None, brightness=None):
        self.profile = profiles.load(profile)
        self.layer: str | None = None
        self.settings = profiles.load_settings()
        self.brightness = self._clamp(self.settings.get("brightness", 100) if brightness is None else brightness)   # the last session's, unless told
        self.sock_path = sock_path or socket_path()
        self.deck: Deck | None = None
        self.running = True
        self.auto = bool(self.settings.get("auto_profile", True))
        self._base_profile = self.profile.name            # where to go back to when no rule matches
        self._win_queue: "queue.Queue[windows.Window]" = queue.Queue()
        self.recent_windows: "collections.OrderedDict[str, windows.Window]" = collections.OrderedDict()
        self.last_window: windows.Window | None = None
        self._pending: tuple[str, float] | None = None
        self._rules_seen: dict | None = None
        self._rules_checked = 0.0
        self.watcher: windows.WindowWatcher | None = None
        self.page = 0
        self._trace: list | None = None
        self._standby_key: int | None = None             # the key that leaves standby (None: any key)
        self._action_key: int | None = None              # the key whose press is running its action right now
        self._breath_shown = -1                          # brightness step of the breathing ring on the deck
        self.sleeping = False
        self._sleep_reason: str | None = None   # "idle" | "lock" | "manual"
        self._last_input = time.monotonic()
        self._lock_checked = 0.0
        self._paint_lock = threading.RLock()    # multi-actions run in threads
        self._last_knob: dict[int, float] = {}
        self._last_strip = 0.0
        self.plugins = plugins.Plugins()
        self._toggle: dict[str, int] = {}
        self.strip_engine = strip.StripEngine()
        self._strip_sent: dict[tuple, tuple] = {}     # rect -> signature of what the deck shows there
        self._strip_rects: tuple = ()
        self._strip_canvas = Image.new("RGB", strip.FULL, strip.BG)   # what the deck currently shows (viewer space)
        self._strip_at = 0.0
        self._assets = profiles.search_dirs("assets")
        self.xp = xp_link.XPlaneLink(str(self.settings.get("xplane_url") or xp_link.DEFAULT_URL))
        self._needs_clear = True                       # wipe the deck's own picture (factory dragon) before the first paint
        self._keys_shown: dict[int, int] = {}          # key -> hash of the image the deck shows there
        self._repaint_due: float | None = None
        self._strip_page = 0                            # the page whose strip the deck shows
        self._xp_shown: dict[int, tuple] = {}          # key -> (state name, label) currently on the deck
        self._xp_at = 0.0
        self._servers = [self._bind(self.sock_path)]
        if os.environ.get("STREAMSTATION_COMPAT_SOCKET") == "1":
            # old scripts talk to ragnaros.sock with `layer <name>` lines
            self._servers.append(self._bind(os.path.join(os.path.dirname(self.sock_path), "ragnaros.sock")))

    # --- control socket -------------------------------------------------
    def _bind(self, path):
        if os.path.exists(path):
            os.unlink(path)
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.bind(path)
        os.chmod(path, 0o600)
        s.listen(8)
        s.setblocking(False)
        return s

    def _serve(self):
        for server in self._servers:
            self._serve_one(server)

    def close_sockets(self):
        for server in self._servers:
            try:
                path = server.getsockname()
                server.close()
                os.unlink(path)
            except OSError:
                pass
        self._servers = []

    def _serve_one(self, server):
        for _ in range(8):
            try:
                conn, _ = server.accept()
            except (BlockingIOError, OSError):
                return
            conn.settimeout(0.5)
            try:
                req = conn.recv(8192).decode("utf-8", "replace").strip()
                reply = self.command(shlex.split(req)) if req else {"ok": False, "error": "empty"}
            except Exception as exc:  # a client must never kill the service
                reply = {"ok": False, "error": str(exc)}
            try:
                conn.sendall(json.dumps(reply).encode() + b"\n")
            except OSError:
                pass
            conn.close()

    def command(self, a: list[str]) -> dict:
        if not a:
            return {"ok": False, "error": "empty"}
        verb, rest = a[0], a[1:]
        if verb == "status":
            return {"ok": True, "profile": self.profile.name, "layer": self.layer, "page": self.page + 1,
                    "connected": self.deck is not None, "standby": self._sleep_reason == "standby", "brightness": self.brightness, "auto": self.auto,
                    "base": self._base_profile, "window": self.last_window.label() if self.last_window else None}
        if verb == "windows":
            return {"ok": True, "windows": [w.as_dict() for w in reversed(self.recent_windows.values())]}
        if verb == "auto" and rest:
            self.auto = rest[0] in ("on", "1", "true", "yes")
            self._pending = None
            try:
                profiles.save_setting("auto_profile", self.auto)
            except OSError:
                pass
            return {"ok": True, "auto": self.auto}
        if verb == "profiles":
            return {"ok": True, "profiles": profiles.available()}
        if verb == "profile" and rest:
            return self.set_profile(rest[0])
        if verb == "apply" and rest:
            # The editor saved a profile: show it now WITHOUT making it the new "home" (so it does not stick
            # after the application that activates it loses focus).
            if rest[0] not in profiles.available():
                return {"ok": False, "error": f"no profile {rest[0]!r}"}
            if rest[0] == self.profile.name:
                # same profile: the deck stays on the page (and layer) it shows; only what was saved is redrawn
                self.profile = profiles.load(rest[0])
                self.page = min(self.page, self.profile.page_count() - 1)
                if self.layer and self.layer not in self.profile.layers:
                    self.layer = None
                self.strip_engine.restart()
                self.paint()
                return {"ok": True, "profile": self.profile.name, "page": self.page + 1}
            self.set_profile(rest[0], auto=True)
            return {"ok": True, "profile": self.profile.name, "page": 1}
        if verb == "layer" and rest:
            return self.set_layer(None if rest[0] in ("off", "none", "default") else rest[0])
        if verb == "brightness" and rest:
            self._set_brightness(int(rest[0]))
            return {"ok": True, "brightness": self.brightness, "unit": "percent"}
        if verb == "trace":                      # diagnostic: trace start | trace dump (raw input codes with their times)
            if rest and rest[0] == "start":
                self._trace = []
                return {"ok": True, "tracing": True}
            events = self._trace or []
            if rest and rest[0] == "stop":
                self._trace = None
            t0 = events[0][0] if events else 0.0
            return {"ok": True, "events": [[round(t - t0, 3), f"0x{c:02x}", st] for t, c, st in events]}
        if verb == "strip-offset":
            if rest:
                value = max(0, min(24, int(rest[0])))
                profiles.save_setting("strip_offset_y", value)
                self.settings["strip_offset_y"] = value
                self.paint()
            return {"ok": True, "strip_offset_y": int(self.settings.get("strip_offset_y") or 0), "unit": "px up"}
        if verb == "reload":
            self._assets = profiles.search_dirs("assets")
            self.settings = profiles.load_settings()
            i18n.init_from_settings()                 # the editor may have changed the language: the strip text follows
            self.profile = profiles.load(self.profile.name)
            self.paint()
            return {"ok": True}
        return {"ok": False, "error": f"unknown command {' '.join(a)!r}"}

    def set_profile(self, name, auto: bool = False):
        self.profile = profiles.load(name)
        if not auto:
            self._base_profile = self.profile.name        # a manual choice is the new "home"
        self.layer, self.page = None, 0
        self.strip_engine.restart()
        self.paint()
        return {"ok": True, "profile": self.profile.name}

    def set_layer(self, name):
        if name is not None and name not in self.profile.layers:
            return {"ok": False, "error": f"no layer {name!r} in {self.profile.name}"}
        self.layer = name
        self.request_keys()
        return {"ok": True, "layer": self.layer}

    # --- device -----------------------------------------------------------
    def _send(self, packet):
        if self.deck:
            self.deck.send(packet)

    def paint(self):
        with self._paint_lock:
            self._paint()

    def _key_data(self, idx: int) -> bytes:
        entry = self.profile.key(idx, self.layer, self.page)
        if not entry:
            self._xp_shown.pop(idx, None)
            return render.blank_key()
        xp = entry.get("xp") if isinstance(entry.get("xp"), dict) else None
        if xp and xp_states.refs(xp):
            views = self._xp_views(xp)
            self._xp_shown[idx] = tuple((v.name, v.label) for v in views)
            if xp_states.halves(xp) is not None:
                tile = xp_glyphs.switch_tile(views, str(entry.get("label") or ""))
            else:
                tile = xp_glyphs.state_tile(str(xp.get("glyph") or "plane"), views[0])
            return render.to_jpeg(tile.convert("RGB"), P.KEY_SIZE)
        self._xp_shown.pop(idx, None)
        return render.key_image(entry.get("icon"), str(entry.get("label") or entry.get("action", idx))
                                if isinstance(entry.get("action"), str) else str(idx), self._assets)

    def _xp_views(self, xp: dict):
        return xp_states.views(xp, self.xp.value, self.xp.online)

    def _xp_watch(self):
        items = set()
        for idx in range(10):
            entry = self.profile.key(idx, self.layer, self.page) or {}
            xp = entry.get("xp")
            items.update(xp_states.refs(xp))
        self.xp.set_watch(items)

    def _send_key(self, idx: int, force: bool = False) -> bool:
        """Send one key's image unless the deck already shows exactly that. True when something was sent."""
        data = self._key_data(idx)
        digest = hash(data)
        if not force and self._keys_shown.get(idx) == digest:
            return False
        self._send(P.image_header(P.KEY_TO_SLOT[idx] + 1, len(data)))
        for chunk in P.image_chunks(data):
            self._send(chunk)
        self._keys_shown[idx] = digest
        return True

    def request_keys(self):
        """A page or layer changed: repaint the keys once things settle (not once per knob detent)."""
        self._repaint_due = time.monotonic() + KEYS_SETTLE_S

    def flush_paint(self, now: float | None = None, force: bool = False):
        """Repaint the keys that differ from what the deck shows, when a requested repaint is due."""
        now = time.monotonic() if now is None else now
        if self._repaint_due is None or (not force and now < self._repaint_due):
            return
        self._repaint_due = None
        if not self.deck or self.sleeping:
            return
        with self._paint_lock:
            self._xp_watch()
            sent = [self._send_key(idx) for idx in range(10)]
            if any(sent):
                self._send(P.stop())
            if self.profile.strip_mode == "per_page" and self._strip_page != self.page:
                self._strip_page = self.page             # each page has its own strip: wipe the old one, draw the new one
                self.strip_engine.restart()
                self._blank_strip()
                self.paint_strip(force=True)

    def _blank_strip(self):
        """Cover the whole strip with black. Whatever a profile does not paint (and the factory dragon picture
        the deck shows after power-up) would otherwise stay on the screen."""
        canvas = Image.new("RGB", strip.FULL, strip.BG)
        with self._paint_lock:
            for chunk in P.image_chunks(render.strip_stream(canvas, (0, 0) + strip.FULL)):
                self._send(chunk)
            self._send(P.stop())
            self._strip_canvas = canvas
            self._strip_sent.clear()
            self._strip_rects = ()

    def _paint(self):
        if not self.deck:
            return
        self._xp_watch()
        if self._needs_clear and not self.sleeping:
            self._needs_clear = False
            self._send(P.clear(0xFF))                  # [DLL] CLE, index 0xFF = every display
            self._send(P.stop())
        if not self.sleeping:
            self._blank_strip()
        self._repaint_due = None
        self._strip_page = self.page
        self._keys_shown.clear()
        for idx in range(10):
            self._send_key(idx, force=True)
        self._send(P.stop())
        self.paint_strip(force=True)

    def xp_tick(self, now: float):
        """Repaint only the keys whose X-Plane state changed since they were drawn."""
        if not self.deck or self.sleeping or now - self._xp_at < 0.3:
            return
        self._xp_at = now
        changed = []
        for idx in range(10):
            entry = self.profile.key(idx, self.layer, self.page) or {}
            xp = entry.get("xp")
            if not xp_states.refs(xp):
                continue
            if self._xp_shown.get(idx) != tuple((v.name, v.label) for v in self._xp_views(xp)):
                changed.append(idx)
        if changed:
            with self._paint_lock:
                for idx in changed:
                    self._send_key(idx)
                self._send(P.stop())

    def paint_strip(self, force: bool = False):
        """Send the strip regions whose content changed (all of them when `force`)."""
        self._strip_at = time.monotonic()
        content = self.profile.strip_content(self.page)
        if not self.deck or content is None or self.sleeping:
            return
        plan = self.strip_engine.plan(content)
        rects = tuple(rect for _, rect, _ in plan)
        if force or rects != self._strip_rects:          # e.g. full-width <-> zones: the old pieces are stale
            self._strip_sent.clear()
            self._strip_rects = rects
            self._strip_canvas = Image.new("RGB", strip.FULL, strip.BG)
        with self._paint_lock:
            sent = 0
            for sig, rect, draw in plan:
                if self._strip_sent.get(rect) == sig:
                    continue
                img = draw()
                img = img if img.size == rect[2:] else img.resize(rect[2:])
                up = max(0, min(24, int(self.settings.get("strip_offset_y") or 0)))
                if up:                                       # content moves up, the freed rows stay black
                    shifted = Image.new("RGB", img.size, strip.BG)
                    shifted.paste(img, (0, -up))
                    img = shifted
                self._strip_canvas.paste(img, rect[:2])
                for chunk in P.image_chunks(render.strip_stream(self._strip_canvas, rect)):
                    self._send(chunk)
                self._strip_sent[rect] = sig
                sent += 1
            if sent:
                self._send(P.stop())

    # --- active window -> profile -----------------------------------------------------------------
    def _consider(self, w: "windows.Window", now: float):
        self.last_window = w
        if windows.is_ignored(w):
            return
        key = w.label()
        self.recent_windows.pop(key, None)
        self.recent_windows[key] = w
        while len(self.recent_windows) > 40:
            self.recent_windows.popitem(last=False)
        if not self.auto:
            return
        target = windows.find_profile(w, profiles.match_rules()) or scenes.default() or self._base_profile
        if target == self.profile.name or target not in profiles.available():
            self._pending = None
            return
        self._pending = (target, now + AUTO_DEBOUNCE_S)

    def process_windows(self, now: float | None = None):
        """Called from the main loop: take the focus events queued by the D-Bus thread, then apply a settled one."""
        now = time.monotonic() if now is None else now
        while True:
            try:
                self._consider(self._win_queue.get_nowait(), now)
            except queue.Empty:
                break
        if now - self._rules_checked >= 1.0:              # rules edited while the app already has focus
            self._rules_checked = now
            rules = profiles.match_rules()
            if rules != self._rules_seen:
                first, self._rules_seen = self._rules_seen is None, dict(rules)
                if not first and self.last_window:
                    self._consider(self.last_window, now)
        if self._pending and now >= self._pending[1]:
            target, self._pending = self._pending[0], None
            if target != self.profile.name:
                try:
                    self.set_profile(target, auto=True)
                    log.info("profile %s (focus: %s)", target, self.last_window.label() if self.last_window else "?")
                except FileNotFoundError:
                    log.warning("profile %s disappeared", target)

    # --- power / screen off -----------------------------------------------
    def sleep_deck(self, reason: str):
        """Screen off. Original: addScreenOffPack ("HAN") and the sleeping flag."""
        if self.sleeping or not self.deck:
            return
        self._send(P.sleep())
        self.sleeping, self._sleep_reason = True, reason
        log.info("deck screen off (%s)", reason)

    def wake_deck(self):
        """Original: addWakeUpScreenPack ("DIS"), then the screen is repainted."""
        if not self.sleeping or not self.deck:
            return
        log.info("deck screen on (was: %s)", self._sleep_reason)
        self.sleeping, self._sleep_reason = False, None
        self._needs_clear = True
        self._send(P.wake())
        self._send(P.brightness(self.brightness))
        self.paint()

    def _show_boot_logo(self, sleep=time.sleep):
        """The user's start-up picture on the strip, held for a moment, before the profile is drawn (off when none is set)."""
        if not self.settings.get("boot_logo") or not self.deck:
            return False
        img = bootlogo.load()
        if img is None:
            return False
        with self._paint_lock:
            self._send(P.clear(0xFF)); self._send(P.stop())
            for chunk in P.image_chunks(render.strip_stream(img, (0, 0) + strip.FULL)):
                self._send(chunk)
            self._send(P.stop())
        hold = max(0.0, min(10.0, float(self.settings.get("boot_logo_seconds") or 3)))
        end = time.monotonic() + hold
        while self.running and time.monotonic() < end:
            sleep(0.05)
        return True

    # --- standby: everything dark, the key that was pressed breathes in cyan ----------------------
    def enter_standby(self, key: int | None):
        """Ragnaros in standby: keys and strip go dark; `key` (the one pressed to get here) shows a breathing cyan outline and is
        the only one that brings the deck back. Without a key (knob, strip, ctl) any key press wakes it."""
        if self.sleeping or not self.deck:
            return
        with self._paint_lock:
            self._send(P.clear(0xFF)); self._send(P.stop())         # every display wiped...
            self._blank_strip()                                      # ...and the strip covered in black
            self._keys_shown.clear()
        self.sleeping, self._sleep_reason = True, "standby"
        self._standby_key, self._breath_shown = key, -1
        log.info("deck standby (wake key: %s)", "any" if key is None else key + 1)
        self.standby_tick(time.monotonic())

    @staticmethod
    def breath_level(now: float, steps: int = 16, period: float = BREATH_PERIOD_S) -> int:
        """Where the breathing is (0..steps): a smooth in-out cycle that spends most of its time dark and only briefly lit."""
        wave = (1 - math.cos(2 * math.pi * (now % period) / period)) / 2
        return round(wave ** BREATH_SHARPNESS * steps)

    def standby_tick(self, now: float):
        """Draw the next step of the breathing outline around the wake key (only when the step changed)."""
        if not (self.sleeping and self._sleep_reason == "standby" and self.deck) or self._standby_key is None:
            return
        level = self.breath_level(now)
        if level == self._breath_shown:
            return
        self._breath_shown = level
        data = render.to_jpeg(render.breathing_ring(BREATH_MAX * level / 16), P.KEY_SIZE)
        with self._paint_lock:
            self._send(P.image_header(P.KEY_TO_SLOT[self._standby_key] + 1, len(data)))
            for chunk in P.image_chunks(data):
                self._send(chunk)
            self._send(P.stop())

    def _input(self, code: int, state: int):
        """One input report from the deck."""
        self._last_input = time.monotonic()
        if self._trace is not None and len(self._trace) < 2000:
            self._trace.append((round(self._last_input, 4), code, state))     # diagnostic recording
        event = P.decode_event(code, state)
        if not self.sleeping:
            self.handle(event)
        elif self._sleep_reason != "standby":
            self.wake_deck()                                   # the waking press is swallowed
        elif event[0] == "key" and event[2] and self._standby_key in (None, event[1]):
            self.wake_deck()       # only a fresh press of the wake key; the release of the press that came here is ignored

    def tick(self, now=None):
        """Idle screen-off and follow-the-session-lock; called from the main loop."""
        now = time.monotonic() if now is None else now
        limit = int(self.settings.get("screen_off_s") or 0)
        if limit and not self.sleeping and now - self._last_input > limit:
            self.sleep_deck("idle")
        if self.settings.get("follow_lock") and now - self._lock_checked >= 3:
            self._lock_checked = now
            locked = system.session_locked()
            if locked and not self.sleeping:
                self.sleep_deck("lock")
            elif not locked and self.sleeping and self._sleep_reason == "lock":
                self.wake_deck()

    # --- actions ----------------------------------------------------------
    def step_scene(self, delta: int):
        """The next (or previous) scene in the user's order; wraps around."""
        order = scenes.names()
        if len(order) < 2:
            return
        try:
            i = order.index(self.profile.name)
        except ValueError:
            i = 0 if delta > 0 else 0
        self.set_profile(order[(i + delta) % len(order)])

    def set_page(self, spec: str):
        count = self.profile.page_count()
        if spec == "next":
            self.page = (self.page + 1) % count
        elif spec in ("prev", "previous"):
            self.page = (self.page - 1) % count
        else:
            self.page = max(0, min(count - 1, int(spec)))
        self.request_keys()

    def run_action(self, action):
        if not action:
            return
        if isinstance(action, list):   # original "Multi Action": steps with delays
            threading.Thread(target=self._run_sequence, args=(action,), daemon=True).start()
            return
        if isinstance(action, dict):
            if "toggle" in action and action["toggle"]:      # multiactions.toggle: alternate each press
                steps = action["toggle"]
                key = json.dumps(steps, sort_keys=True, default=str)
                i = self._toggle.get(key, 0)
                self._toggle[key] = (i + 1) % len(steps)
                return self.run_action(steps[i])
            if "random" in action and action["random"]:     # multiactions.random
                return self.run_action(random.choice(action["random"]))
            action = action.get("action") or ""
        if action.startswith("layer:"):
            name = action[6:]
            self.set_layer(None if self.layer == name else name)
        elif action.startswith("profile:"):
            self.set_profile(action[8:])
        elif action.startswith("page:"):
            self.set_page(action[5:])
        elif action in ("scene:next", "scene:prev"):
            self.step_scene(1 if action.endswith("next") else -1)
        elif action in system.VERBS:
            system.run_verb(action)
        elif action in ("screen-off", "standby"):
            self.enter_standby(self._action_key)
        elif action.startswith("brightness"):   # brightness+10 / brightness-10 / brightness=50
            self._adjust_brightness(action[len("brightness"):])
        elif action.startswith("xp:cmd:"):
            threading.Thread(target=self._xp_command, args=(action[7:],), daemon=True).start()
        elif self.plugins.handles(action):
            try:
                if self.plugins.run(action) is False:
                    log.warning("action %s found nothing to act on", action)
            except Exception as exc:  # a bad action must never stop the service
                log.warning("action %s failed: %s", action, exc)
        elif action == "dashboard":
            log.info("action dashboard is not implemented yet")
        else:
            subprocess.Popen(action, shell=True, start_new_session=True,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def _xp_command(self, name: str):
        try:
            self.xp.command(name)
        except xp_link.XPlaneError as exc:
            log.warning("X-Plane command %s: %s", name, exc)

    def _run_sequence(self, steps):
        for step in steps:
            if isinstance(step, dict) and "delay" in step:
                time.sleep(max(0, float(step["delay"])) / 1000)
            else:
                self.run_action(step)

    def _adjust_brightness(self, spec: str):
        relative = spec[:1] in ("+", "-")
        try:
            value = int(spec[1:] if spec[:1] == "=" else spec)
        except ValueError:
            return
        self._set_brightness(self.brightness + value if relative else value)

    @staticmethod
    def _clamp(value) -> int:
        try:
            return max(0, min(100, int(value)))
        except (TypeError, ValueError):
            return 100

    def _set_brightness(self, value):
        """Use this brightness now and remember it, so the next session (after a reboot) starts with it."""
        self.brightness = self._clamp(value)
        self._send(P.brightness(self.brightness))
        try:
            profiles.save_setting("brightness", self.brightness)
        except OSError as exc:
            log.warning("could not remember the brightness: %s", exc)

    def handle(self, event):
        kind = event[0]
        if kind == "key" and event[2]:
            entry = self.profile.key(event[1], self.layer, self.page) or {}
            self._action_key = event[1]                          # an action that needs to know which key it came from
            try:
                if "layer_toggle" in entry:
                    self.set_layer(None if self.layer == entry["layer_toggle"] else entry["layer_toggle"])
                elif "profile" in entry:
                    self.set_profile(entry["profile"])
                else:
                    self.run_action(entry.get("action"))
            finally:
                self._action_key = None
        elif kind == "knob":
            now = time.monotonic()
            if now - self._last_knob.get(event[1], 0) < KNOB_DEBOUNCE_S:
                return
            self._last_knob[event[1]] = now
            rot = self.profile.knob(event[1]).get("rotate") or {}
            self.run_action(rot.get("cw" if event[2] > 0 else "ccw"))
        elif kind == "knob_press" and event[2]:
            self.run_action(self.profile.knob(event[1]).get("press"))
        elif kind in ("strip_touch", "strip_swipe"):
            # one gesture emits a burst of events; act once per STRIP_DEBOUNCE_S
            now = time.monotonic()
            if now - self._last_strip < STRIP_DEBOUNCE_S:
                return
            self._last_strip = now
            cfg = self.profile.strip_for(self.page)
            if kind == "strip_touch":
                self.run_action((cfg.get("touch") or {}).get(str(event[1])))
            elif self.profile.page_swipe and self.profile.page_count() > 1:
                self.set_page("next" if event[1] < 0 else "prev")      # finger to the left: next page; to the right: previous (both wrap)
            elif self.settings.get("scene_swipe"):
                self.step_scene(1 if event[1] < 0 else -1)            # same gesture, but between scenes
            else:
                swipe = cfg.get("swipe") or {}
                # `right` = the finger moved left-to-right (0x38), `left` = right-to-left (0x39) [LIVE]; `any` answers both
                self.run_action(swipe.get("any") or swipe.get("right" if event[1] > 0 else "left"))
        elif kind == "unknown":
            log.debug("unknown input %s", event)

    # --- main loop --------------------------------------------------------
    def run(self):
        i18n.init_from_settings()                     # the text drawn on the strip follows the chosen language
        for sig in (signal.SIGTERM, signal.SIGINT):
            signal.signal(sig, lambda *_: setattr(self, "running", False))
        self.watcher = windows.WindowWatcher(self._win_queue.put)
        if not self.watcher.start():
            log.info("active-window detection unavailable (%s); profiles will not follow applications", self.watcher.error)
        while self.running:
            try:
                with Deck() as deck:
                    self.deck = deck
                    log.info("deck connected")
                    deck.send(P.wake())
                    deck.send(P.brightness(self.brightness))
                    self.sleeping, self._sleep_reason = False, None
                    self._needs_clear = True
                    self._last_input = time.monotonic()
                    self._show_boot_logo()
                    self.paint()
                    beat = time.monotonic()
                    while self.running:
                        raw = deck.read(50)
                        if raw is not None:
                            frame = P.parse_report(raw)
                            if frame and frame[0] == "event":
                                self._input(frame[1], frame[2])
                        self.standby_tick(time.monotonic())
                        self._serve()
                        self.process_windows()
                        self.tick()
                        self.flush_paint()
                        self.xp_tick(time.monotonic())
                        if time.monotonic() - self._strip_at >= STRIP_TICK_S:
                            self.paint_strip()
                        if time.monotonic() - beat > HEARTBEAT_S:
                            deck.send(P.connect())
                            beat = time.monotonic()
                    try:
                        deck.send(P.sleep())
                    except Exception:
                        pass
            except (DeviceBusy, RuntimeError, OSError) as exc:
                log.warning("deck unavailable: %s", exc)
                self.deck = None
                end = time.monotonic() + 3
                while self.running and time.monotonic() < end:
                    self._serve()
                    time.sleep(0.2)
            except Exception as exc:  # usb.core.USBError and friends: reconnect
                log.warning("deck error: %s", exc)
                self.deck = None
                time.sleep(2)
        self.deck = None
        self.xp.close()
        if self.watcher:
            self.watcher.stop()
        self.close_sockets()


def ctl(args: list[str], path: str | None = None) -> str:
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2)
    s.connect(path or socket_path())
    s.sendall(" ".join(shlex.quote(a) for a in args).encode())
    return s.recv(65536).decode().strip()
