import io, json, os, sys, pathlib, tempfile, zipfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from PIL import Image
from streamstation import autostart, bootlogo, deviceinfo, profiles, scenes, updater


class Sandbox:
    """A private config folder, so nothing touches the user's real one."""
    def __enter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.old, self.old_dirs = profiles.CONFIG, profiles.search_dirs
        profiles.CONFIG = os.path.join(self.tmp.name, "cfg")
        os.makedirs(profiles.CONFIG)
        profiles.search_dirs = lambda sub: [d for d in [os.path.join(profiles.CONFIG, sub)] if sub == "profiles" and os.path.isdir(d)]
        return self
    def __exit__(self, *a):
        profiles.CONFIG, profiles.search_dirs = self.old, self.old_dirs
        self.tmp.cleanup()


class Resp:
    def __init__(self, data): self.data = data
    def __enter__(self): return self
    def __exit__(self, *a): pass
    def read(self, n=-1): return self.data[:n] if n >= 0 else self.data


def opener_for(routes):
    seen = []
    def op(req, timeout=0):
        seen.append(req)
        return Resp(routes[req.full_url])
    op.seen = seen
    return op


# ---- updater -----------------------------------------------------------------------------------------------
def test_versions():
    assert updater.is_newer("v0.2.0", "0.1.0") and updater.is_newer("1.0", "0.9.9")
    assert not updater.is_newer("0.1.0", "0.1.0") and not updater.is_newer("v0.1", "0.1.0")
    assert updater.parse_version("garbage") == (0,)


def test_check_reads_release_and_sends_nothing_personal():
    api = updater.API.format(repo="u/r")
    body = json.dumps({"tag_name": "v0.3.0", "body": "- cosas", "html_url": "https://github.com/u/r/releases/1",
                       "assets": [{"name": "x.zip", "browser_download_url": "https://github.com/u/r/a.zip"}]}).encode()
    op = opener_for({api: body})
    rel = updater.check("u/r", op, current="0.1.0")
    assert rel.newer and rel.version == "0.3.0" and rel.notes == "- cosas" and rel.url.endswith("a.zip")
    assert set(h.lower() for h in op.seen[0].headers) <= {"user-agent", "accept"}
    assert not updater.check("u/r", opener_for({api: body}), current="0.3.0").newer


def test_check_errors():
    for bad in ("", "no-slash", "a/b/c", "x y/z"):
        try:
            updater.check(bad); assert False
        except updater.UpdateError:
            pass
    def boom(req, timeout=0): raise OSError("offline")
    try:
        updater.check("u/r", boom); assert False
    except updater.UpdateError:
        pass


def test_download_only_from_github():
    try:
        updater._safe_url("https://evil.example/x.zip"); assert False
    except updater.UpdateError:
        pass
    try:
        updater._safe_url("http://github.com/x.zip"); assert False
    except updater.UpdateError:
        pass
    assert updater._safe_url("https://github.com/x.zip")


def make_release_zip(root="streamstation-0.3.0"):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(f"{root}/install.sh", "#!/bin/sh\n")
        zf.writestr(f"{root}/streamstation/__init__.py", "__version__='0.3.0'\n")
    return buf.getvalue()


def test_prepare_and_install_command():
    rel = updater.Release(version="0.3.0", url="https://github.com/u/r/a.zip")
    op = opener_for({rel.url: make_release_zip()})
    with tempfile.TemporaryDirectory() as work:
        root = updater.prepare(rel, op, work)
        assert root.endswith("streamstation-0.3.0")
        cmd = updater.install_command(root, "/home/x/.local/bin/streamstation", work)
        assert cmd[0] == "sh" and "install.sh" in cmd[2] and "--apply" in cmd[2]
        assert "restart streamstation.service" in cmd[2] and cmd[2].rstrip().endswith("streamstation ui")
    spawned = []
    updater.install(rel, "/l", op, spawn=lambda c, **k: spawned.append(c))
    assert len(spawned) == 1


def test_unsafe_archive_rejected():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("../escape.txt", "x")
    with tempfile.TemporaryDirectory() as work:
        try:
            updater._extract(buf.getvalue(), work); assert False
        except updater.UpdateError:
            pass
    rel = updater.Release(version="1", url="https://github.com/a.zip")
    try:
        updater.prepare(rel, opener_for({rel.url: b"not a zip"})); assert False
    except Exception:
        pass


# ---- autostart ---------------------------------------------------------------------------------------------
def test_autostart_roundtrip():
    with tempfile.TemporaryDirectory() as tmp:
        old = os.environ.get("XDG_CONFIG_HOME"); os.environ["XDG_CONFIG_HOME"] = tmp
        calls = []
        try:
            assert autostart.status() == {"enabled": False, "minimized": False}
            autostart.set_enabled(True, True, run=lambda c, **k: calls.append(c))
            assert autostart.status() == {"enabled": True, "minimized": True}
            assert calls[-1][:3] == ["systemctl", "--user", "enable"]
            autostart.set_enabled(True, False, run=lambda c, **k: calls.append(c))
            assert autostart.status() == {"enabled": True, "minimized": False}
            autostart.set_enabled(False, run=lambda c, **k: calls.append(c))
            assert autostart.status()["enabled"] is False and calls[-1][2] == "disable"
            autostart.set_enabled(False, run=lambda c, **k: (_ for _ in ()).throw(OSError()))   # no systemctl: no crash
        finally:
            if old is None: os.environ.pop("XDG_CONFIG_HOME")
            else: os.environ["XDG_CONFIG_HOME"] = old


# ---- device info -------------------------------------------------------------------------------------------
def test_serial_from_sysfs():
    with tempfile.TemporaryDirectory() as root:
        for name, vid, pid, serial in (("1-1", "046d", "c52b", "OTHER"), ("1-2", "0200", "3001", "ABC123\n")):
            d = os.path.join(root, name); os.makedirs(d)
            for f, v in (("idVendor", vid), ("idProduct", pid)):
                open(os.path.join(d, f), "w").write(v + "\n")
            open(os.path.join(d, "serial"), "w").write(serial)
        assert deviceinfo.serial_number(root) == "ABC123"
        os.remove(os.path.join(root, "1-2", "serial"))
        assert deviceinfo.serial_number(root) is None
    assert deviceinfo.serial_number("/nonexistent") is None


# ---- boot logo ---------------------------------------------------------------------------------------------
def test_bootlogo_scaling_and_storage():
    img = Image.new("RGB", (1000, 1000), (255, 0, 0))
    for fit in bootlogo.FITS:
        assert bootlogo.scale(img, fit).size == (800, 128)
    fitted = bootlogo.scale(img, "fit")
    assert fitted.getpixel((5, 64)) == (0, 0, 0) and fitted.getpixel((400, 64)) == (255, 0, 0)     # borders vs picture
    assert bootlogo.scale(img, "fill").getpixel((5, 64)) == (255, 0, 0)
    with Sandbox():
        assert bootlogo.load() is None
        bootlogo.save(img, "stretch")
        assert bootlogo.load().size == (800, 128)
        bootlogo.remove(); bootlogo.remove()
        assert bootlogo.load() is None
    assert "1000" in bootlogo.describe(img) and "800" in bootlogo.describe(img)


# ---- scenes ------------------------------------------------------------------------------------------------
def test_scene_management():
    with Sandbox():
        assert scenes.names() == []
        scenes.create("A"); scenes.create("B"); scenes.create("C")
        assert scenes.names() == ["A", "B", "C"]
        for bad in ("", "a/b", "..", "x" * 80):
            try:
                scenes.create(bad); assert False
            except scenes.SceneError:
                pass
        try:
            scenes.create("A"); assert False
        except scenes.SceneError:
            pass
        scenes.move("C", -2); assert scenes.names() == ["C", "A", "B"]
        scenes.move("C", -5); assert scenes.names()[0] == "C"
        scenes.set_default("A"); assert scenes.default() == "A"
        scenes.rename("A", "Vuelo"); assert scenes.default() == "Vuelo" and scenes.names() == ["C", "Vuelo", "B"]
        copy = scenes.duplicate("Vuelo"); assert copy in scenes.names()
        assert scenes.delete(copy) and copy not in scenes.names()
        assert os.path.isfile(scenes.path(copy) + ".eliminada")
        assert scenes.delete("Vuelo") and scenes.default() is None
        assert scenes.delete("B")
        assert not scenes.delete("C")                      # the last one stays


def test_binding_moves_an_application_between_scenes():
    with Sandbox():
        scenes.create("A"); scenes.create("B")
        rule = {"class": "firefox"}
        assert scenes.bind("A", [rule]) == {}
        d = scenes._read("A"); d["match"] = [rule]; scenes._write("A", d)
        taken = scenes.bind("B", [rule, {"class": "gimp"}])
        assert taken == {"A": [rule]}
        assert "match" not in scenes._read("A")


def test_export_import_bundle():
    with Sandbox() as sb:
        assets = os.path.join(profiles.CONFIG, "assets"); os.makedirs(assets)
        Image.new("RGB", (4, 4), (9, 9, 9)).save(os.path.join(assets, "ico.png"))
        scenes.create("A")
        d = scenes._read("A"); d["keys"] = {"1": {"icon": "ico.png"}}; d["match"] = [{"class": "x"}]; scenes._write("A", d)
        out = scenes.export_bundle("A", os.path.join(sb.tmp.name, "a"))
        assert out.endswith(".ssscene")
        with zipfile.ZipFile(out) as zf:
            assert "scene.yaml" in zf.namelist() and "assets/ico.png" in zf.namelist()
        os.remove(os.path.join(assets, "ico.png"))
        name = scenes.import_bundle(out)
        assert name == "A 2" and "match" not in scenes._read(name)         # no overwrite, no stolen applications
        assert os.path.isfile(os.path.join(assets, "ico.png"))
        bad = os.path.join(sb.tmp.name, "bad.ssscene"); open(bad, "w").write("a: [unclosed\n")
        try:
            scenes.import_bundle(bad); assert False
        except scenes.SceneError:
            pass
        evil = os.path.join(sb.tmp.name, "evil.ssscene")
        with zipfile.ZipFile(evil, "w") as zf:
            zf.writestr("scene.yaml", "name: E\nkeys: {}\n"); zf.writestr("assets/../../pwn", "x")
        try:
            scenes.import_bundle(evil); assert False
        except scenes.SceneError:
            pass
