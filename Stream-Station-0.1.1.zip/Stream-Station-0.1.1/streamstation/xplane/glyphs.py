"""Cockpit-style glyphs drawn by code (no artwork from anywhere), and the keys built from them.

`glyph_image(name, size, color)` -> RGBA glyph on a transparent background (used for the 20 px list icons).
`neutral_tile(name)`            -> the 128 px key in the program's pastel style (no live state).
`state_tile(name, state)`        -> the 128 px key coloured by a dataref state, with its label underneath.
"""
from __future__ import annotations

import math

from PIL import Image, ImageDraw

from .. import fonts
from .states import StateView

SS = 4          # supersampling for smooth edges
G = 100         # glyph design grid


def _canvas(size: int):
    img = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img), size * SS / G


def _bulb(d, k, c):
    d.ellipse([26*k, 12*k, 74*k, 60*k], fill=c)
    d.polygon([(36*k, 54*k), (64*k, 54*k), (60*k, 68*k), (40*k, 68*k)], fill=c)
    d.rounded_rectangle([38*k, 70*k, 62*k, 77*k], radius=3*k, fill=c)
    d.rounded_rectangle([43*k, 79*k, 57*k, 86*k], radius=3*k, fill=c)


def _gear(d, k, c):
    d.rounded_rectangle([45*k, 6*k, 55*k, 52*k], radius=3*k, fill=c)
    d.ellipse([27*k, 46*k, 73*k, 92*k], fill=c)
    d.ellipse([41*k, 60*k, 59*k, 78*k], fill=(0, 0, 0, 0))


def _flap(d, k, c):
    d.polygon([(8*k, 36*k), (70*k, 30*k), (92*k, 42*k), (70*k, 50*k), (8*k, 50*k)], fill=c)
    d.polygon([(66*k, 54*k), (92*k, 78*k), (84*k, 86*k), (58*k, 62*k)], fill=c)


def _speedbrake(d, k, c):
    d.rounded_rectangle([8*k, 62*k, 92*k, 72*k], radius=3*k, fill=c)
    for x in (24, 46, 68):
        d.polygon([((x-8)*k, 60*k), ((x+8)*k, 60*k), ((x+4)*k, 22*k), ((x-4)*k, 22*k)], fill=c)


def _brake(d, k, c):
    d.ellipse([10*k, 10*k, 90*k, 90*k], fill=c)
    d.ellipse([22*k, 22*k, 78*k, 78*k], fill=(0, 0, 0, 0))
    d.text((50*k, 52*k), "P", font=fonts.font(int(46*k), True), fill=c, anchor="mm")


def _battery(d, k, c):
    d.rounded_rectangle([10*k, 28*k, 80*k, 72*k], radius=7*k, fill=c)
    d.rounded_rectangle([80*k, 42*k, 91*k, 58*k], radius=3*k, fill=c)
    d.rectangle([24*k, 48*k, 46*k, 52*k], fill=(0, 0, 0, 0)); d.rectangle([33*k, 39*k, 37*k, 61*k], fill=(0, 0, 0, 0))
    d.rectangle([54*k, 48*k, 68*k, 52*k], fill=(0, 0, 0, 0))


def _power(d, k, c):
    d.arc([14*k, 16*k, 86*k, 88*k], start=-60, end=240, fill=c, width=int(9*k))
    d.rounded_rectangle([45*k, 6*k, 55*k, 52*k], radius=4*k, fill=c)


def _plane(d, k, c):
    d.polygon([(50*k, 4*k), (57*k, 34*k), (94*k, 58*k), (94*k, 68*k), (57*k, 56*k), (55*k, 80*k), (68*k, 90*k), (68*k, 96*k),
               (50*k, 91*k), (32*k, 96*k), (32*k, 90*k), (45*k, 80*k), (43*k, 56*k), (6*k, 68*k), (6*k, 58*k), (43*k, 34*k)], fill=c)


def _autopilot(d, k, c):
    d.rounded_rectangle([8*k, 22*k, 92*k, 78*k], radius=12*k, outline=c, width=int(7*k))
    d.text((50*k, 52*k), "AP", font=fonts.font(int(36*k), True), fill=c, anchor="mm")


def _engine(d, k, c):
    for a in (90, 210, 330):
        r = math.radians(a)
        cx, cy = 50 + 23 * math.cos(r), 50 - 23 * math.sin(r)
        d.ellipse([(cx-14)*k, (cy-14)*k, (cx+14)*k, (cy+14)*k], fill=c)
    d.ellipse([39*k, 39*k, 61*k, 61*k], fill=c)
    d.ellipse([46*k, 46*k, 54*k, 54*k], fill=(0, 0, 0, 0))


def _drop(d, k, c):
    d.polygon([(50*k, 6*k), (22*k, 54*k), (78*k, 54*k)], fill=c)
    d.ellipse([22*k, 36*k, 78*k, 92*k], fill=c)


def _pause(d, k, c):
    d.rounded_rectangle([24*k, 16*k, 44*k, 84*k], radius=5*k, fill=c)
    d.rounded_rectangle([56*k, 16*k, 76*k, 84*k], radius=5*k, fill=c)


def _camera(d, k, c):
    d.rounded_rectangle([8*k, 30*k, 92*k, 80*k], radius=9*k, fill=c)
    d.rounded_rectangle([32*k, 20*k, 60*k, 34*k], radius=4*k, fill=c)
    d.ellipse([34*k, 40*k, 66*k, 72*k], fill=(0, 0, 0, 0)); d.ellipse([40*k, 46*k, 60*k, 66*k], fill=c)


def _eye(d, k, c):
    d.ellipse([6*k, 26*k, 94*k, 74*k], fill=c)
    d.ellipse([34*k, 32*k, 66*k, 68*k], fill=(0, 0, 0, 0)); d.ellipse([41*k, 40*k, 59*k, 60*k], fill=c)


def _radio(d, k, c):
    d.ellipse([40*k, 40*k, 60*k, 60*k], fill=c)
    for r in (22, 36, 50):
        d.arc([(50-r)*k, (50-r)*k, (50+r)*k, (50+r)*k], start=-50, end=50, fill=c, width=int(7*k))
        d.arc([(50-r)*k, (50-r)*k, (50+r)*k, (50+r)*k], start=130, end=230, fill=c, width=int(7*k))


def _compass(d, k, c):
    d.ellipse([6*k, 6*k, 94*k, 94*k], outline=c, width=int(7*k))
    d.polygon([(50*k, 20*k), (62*k, 50*k), (50*k, 80*k), (38*k, 50*k)], fill=c)
    d.ellipse([44*k, 44*k, 56*k, 56*k], fill=(0, 0, 0, 0))


def _snow(d, k, c):
    for a in (0, 60, 120):
        r = math.radians(a)
        d.line([(50 - 42*math.cos(r))*k, (50 - 42*math.sin(r))*k, (50 + 42*math.cos(r))*k, (50 + 42*math.sin(r))*k], fill=c, width=int(7*k))
    d.ellipse([40*k, 40*k, 60*k, 60*k], fill=c)


def _warning(d, k, c):
    d.polygon([(50*k, 8*k), (95*k, 88*k), (5*k, 88*k)], fill=c)
    d.rounded_rectangle([46*k, 34*k, 54*k, 66*k], radius=3*k, fill=(0, 0, 0, 0))
    d.ellipse([45*k, 70*k, 55*k, 80*k], fill=(0, 0, 0, 0))


def _key(d, k, c):
    d.ellipse([8*k, 26*k, 48*k, 66*k], fill=c); d.ellipse([20*k, 38*k, 36*k, 54*k], fill=(0, 0, 0, 0))
    d.rectangle([44*k, 42*k, 92*k, 50*k], fill=c); d.rectangle([76*k, 50*k, 84*k, 62*k], fill=c); d.rectangle([62*k, 50*k, 68*k, 58*k], fill=c)


def _trim(d, k, c):
    d.polygon([(50*k, 6*k), (82*k, 44*k), (18*k, 44*k)], fill=c)
    d.polygon([(50*k, 94*k), (82*k, 56*k), (18*k, 56*k)], fill=c)


def _seatbelt(d, k, c):
    d.ellipse([34*k, 8*k, 66*k, 40*k], fill=c)
    d.rounded_rectangle([22*k, 46*k, 78*k, 92*k], radius=12*k, fill=c)
    d.line([30*k, 50*k, 74*k, 86*k], fill=(0, 0, 0, 0), width=int(7*k))


GLYPHS = {"bulb": _bulb, "gear": _gear, "flap": _flap, "speedbrake": _speedbrake, "brake": _brake, "battery": _battery,
          "power": _power, "plane": _plane, "autopilot": _autopilot, "engine": _engine, "drop": _drop, "pause": _pause,
          "camera": _camera, "eye": _eye, "radio": _radio, "compass": _compass, "snow": _snow, "warning": _warning,
          "key": _key, "trim": _trim, "seatbelt": _seatbelt}

# ordered: the first rule whose words appear in "<command name> <description>" wins
RULES = [
    (("landing_gear", "gear_handle", "gear "), "gear"), (("speed_brake", "speedbrake"), "speedbrake"), (("flaps", "flap_"), "flap"),
    (("fuel", "tank"), "drop"), (("parking", "brakes", "brake_"), "brake"), (("lights", "light_", "_light", "beacon", "strobe", "taxi"), "bulb"),
    (("battery", "generator", "inverter"), "battery"), (("avionics", "power", "_on ", "master"), "power"),
    (("autopilot", "servos", "fdir", "flight director", "heading", "altitude_hold", "vnav", "approach", "nav "), "autopilot"),
    (("starter", "ignition", "magneto", "engine", "throttle", "prop", "mixture", "feather", "reverse"), "engine"),
    (("pause",), "pause"), (("screenshot", "camera", "photo"), "camera"), (("view", "chase", "look_", "cockpit_"), "eye"),
    (("radio", "com1", "com2", "nav1", "nav2", "transponder", "audio_panel", "adf", "dme"), "radio"),
    (("gps", "fms", "compass", "hsi", "obs", "map"), "compass"), (("ice", "heat", "pitot", "defrost", "deice"), "snow"),
    (("annunciator", "warning", "alert", "caution", "fail"), "warning"), (("seatbelt", "no_smoking", "fasten"), "seatbelt"),
    (("trim", "pitch", "elevator"), "trim"), (("key", "ignition_key"), "key"),
]


def pick_glyph(name: str, description: str = "") -> str:
    text = f"{name.lower()} {description.lower()}"
    for words, glyph in RULES:
        if any(w in text for w in words):
            return glyph
    return "plane"


def abbreviation(name: str) -> str:
    last = name.rsplit("/", 1)[-1]
    parts = [p for p in last.replace("-", "_").split("_") if p and p not in ("on", "off", "toggle", "tog")]
    return "".join(p[0] for p in parts[:3]).upper() or last[:2].upper()


def glyph_image(name: str, size: int = 128, color=(255, 255, 255, 255)) -> Image.Image:
    img, d, k = _canvas(size)
    fn = GLYPHS.get(name)
    if fn:
        fn(d, k, color)
    else:
        d.text((size * SS / 2, size * SS / 2), name[:3].upper(), font=fonts.font(int(size * SS * 0.5), True), fill=color, anchor="mm")
    return img.resize((size, size), Image.LANCZOS)


def neutral_tile(glyph: str, palette: str = "sky", size: int = 128) -> Image.Image:
    from ..ui import actionicons
    return actionicons.styled_tile(glyph_image(glyph, 128), "Navegador", size, palette=palette)


_LIGHT_ON_DARK = {"off", "offline", "unknown"}


def state_tile(glyph: str, state: StateView, size: int = 128) -> Image.Image:
    """The key as the deck should show it for `state`."""
    from ..ui.icons import _hex
    bg = _hex(state.color)
    tile = Image.new("RGBA", (size, size), bg + (255,))
    ink = (150, 150, 158, 255) if state.name in _LIGHT_ON_DARK else ((255, 255, 255, 255) if state.name in ("warn", "armed") else (14, 14, 20, 255))
    gsize = int(size * (0.50 if state.label else 0.62))
    g = glyph_image(glyph, gsize, ink)
    top = int(size * (0.10 if state.label else 0.19))
    tile.alpha_composite(g, ((size - gsize) // 2, top))
    if state.label:
        d = ImageDraw.Draw(tile)
        fs = int(size * 0.15)
        font = fonts.font(fs, True)
        while font.getlength(state.label) > size - 10 and fs > 8:
            fs -= 1; font = fonts.font(fs, True)
        d.text((size // 2, int(size * 0.84)), state.label, font=font, fill=ink, anchor="mm")
    return tile


def _lamp(draw, box, view: StateView, size: int):
    from ..ui.icons import _hex
    x0, y0, x1, y1 = box
    off = view.name in _LIGHT_ON_DARK
    draw.rounded_rectangle(box, radius=int(size * 0.07), fill=_hex(view.color) + (255,),
                           outline=(90, 90, 98, 255) if off else (255, 255, 255, 120), width=2)
    if view.label:
        ink = (120, 120, 128, 255) if off else ((255, 255, 255, 255) if view.name in ("warn", "armed") else (14, 14, 20, 255))
        fs = int(size * 0.17)
        font = fonts.font(fs, True)
        while font.getlength(view.label) > (x1 - x0) - 10 and fs > 8:
            fs -= 1; font = fonts.font(fs, True)
        draw.text(((x0 + x1) // 2, (y0 + y1) // 2), view.label, font=font, fill=ink, anchor="mm")


def switch_tile(views: list[StateView], title: str = "", size: int = 128) -> Image.Image:
    """A two-lamp switch (top lamp, bottom lamp) on a dark plate, like an illuminated pushbutton."""
    tile = Image.new("RGBA", (size, size), (24, 24, 29, 255))
    d = ImageDraw.Draw(tile)
    pad, gap = int(size * 0.04), int(size * 0.19 if title else 0.07 * size)
    h = (size - 2 * pad - gap) // 2
    top = (pad, pad, size - pad, pad + h)
    bottom = (pad, size - pad - h, size - pad, size - pad)
    _lamp(d, top, views[0], size)
    _lamp(d, bottom, views[1] if len(views) > 1 else views[0], size)
    if title:
        d.text((size // 2, size // 2), title[:8], font=fonts.font(int(size * 0.15), True), fill=(225, 225, 232, 255), anchor="mm")
    return tile
