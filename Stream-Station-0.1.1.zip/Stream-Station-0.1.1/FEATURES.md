# Funciones de Redragon Stream Station y estado en el reemplazo nativo

Fuente: instalación en Wine (`Redragon Stream Station 3.10.194`), solo análisis estático.
Estado: ✅ hecho y probado · 🟡 hecho, sin probar en el dispositivo · ⬜ pendiente · ❌ no aplica en Linux

## Dispositivo (SDLibrary1.dll)
| Función original | Evidencia | Estado |
|---|---|---|
| Despertar (`DIS`), heartbeat (`CONNECT`), brillo (`LIG`), limpiar (`CLE`), refrescar (`STP`) | ev_fc155407…, ev_5acc4f52…, ev_d9a56647…, ev_f1f17fbd…, ev_0d38404d… | ✅ |
| Subir imagen a tecla/panel (`BAT`) | ev_a7ccd819… | ✅ |
| Pantalla apagada (`HAN`) y temporizador con 3 acciones (apagar por software / `HAN` / desconectar) | ev_d428211c…, ev_0fdea875… (`timerEvent`) | ✅ probado en vivo (apaga tras inactividad y enciende con una tecla) |
| Despertar descartando la pulsación que despierta (`setInterceptKeyEventsDuringSleepEnable`) | export en SDLibrary1 | ✅ (confirmado por ti; el log solo registra el encendido) |
| Dibujar en un rectángulo de la pantalla secundaria (`DRA`) | ev_9ac23d79… | 🟡 comando listo; significado de x/y/ancho/alto sin verificar |
| Cambiar orientación (`SET`, `sendChangeDirectionCommand`) | ev_15a5a62c… | 🟡 comando listo, efecto sin verificar |
| Brillo +/- (`increase/decreaseBrightness`), brillo por defecto | exports | ✅ (acciones `brightness+N`) |
| Control de LED (`LBLIG`, `SETLB`, `addLampControlCommand`) | exports | ⬜ (¿el SS-552 tiene LED? sin comprobar) |
| Protector de pantalla en el dispositivo (`SDScreensaver*`, `ScreensaverMode`) | clases del exe | ⬜ |
| Subir logo de arranque (`sendLogoSizeCommand`, `sigLogoUploaded`) | exports | ⬜ |
| Versión de firmware (`getFirmwareVersion`, `sendGetHardwareFirmwareVersion`) y `FirmwareUpgradeTool.exe` | exports, ejecutable | ⬜ (no actualizar firmware sin prueba) |

## Entradas
| Función | Evidencia | Estado |
|---|---|---|
| Teclas 1–10, 4 perillas (giro/pulsación), deslizamiento 0x38/0x39 | captura en vivo | ✅ teclas y perillas; 🟡 deslizamiento (qué código es izquierda/derecha sin verificar) |
| Toque de los 4 segmentos de la franja | captura en vivo: códigos 0x40–0x43, siempre estado 0 (sin evento de soltar) | 🟡 códigos vistos; asignación a segmentos inferida del orden, sin verificar por separado |

## Acciones de plugins (29 plugins, ~110 acciones)
| Grupo | Acciones | Estado |
|---|---|---|
| Sistema: abrir app/web, atajo de teclado, texto, multimedia, volumen | `system.*` | ✅ `open:`/`tool:`, `text:`, `media:`, `volume:` confirmados en vivo (`text:` solo ASCII y teclado US); 🟡 `key:` genérico (solo probado vía `browser:*`); ⬜ contraseña, cerrar app |
| Control rápido: **suspender**, silenciar, volumen, micrófono, mostrar escritorio, cambiar pantalla | `quickcontrol` | ✅ `volume:mute`, `desktop:show` (confirmados por ti; `desktop:show` ahora por D-Bus, también confirmado); ✅ `volume:up/down`, `mic:mute`, `desktop:switch-screen` (confirmados en vivo); 🟡 `suspend` (no ejecutado a propósito); ⬜ reconocimiento de voz |
| **Bloquear equipo** | `SimulatedKeyboardEvent::computerLockWorkStation` | ✅ acción `lock` |
| Seguir bloqueo de sesión (la app importa `WTSAPI32`) | import del exe | ✅ probado en vivo (`follow_lock`: apaga al bloquear, enciende al desbloquear) |
| Páginas: anterior, siguiente, ir a, indicador | `page.*` | ✅ `page:next/prev/N` (probado en vivo, confirmado por ti) |
| Carpetas y volver (`profile.openchild`, `backtoparent`), cambio de escena | `profile.*` | 🟡 (perfiles encadenados; sin carpeta anidada) |
| Multi-acción: rutina, alternar, retardo, aleatoria, rueda, disparador, carrusel | `multiactions.*` | 🟡 rutina, retardo, `toggle`, `random`; ⬜ rueda, disparador, carrusel (semántica sin analizar) |
| Anillo de acciones | `actionRing` | ⬜ |
| Navegador: atrás, adelante, recargar, favorito | `browser` | ✅ `browser:back/forward/refresh` confirmados en vivo; 🟡 `browser:collect` (Ctrl+D, no probado) |
| Herramientas: calculadora, correo, música, inicio, administrador de tareas, panel de control, notificaciones, búsqueda, emoticonos | `quicktool` | ✅ `tool:calculator/mail/controlpanel/taskmanager` y `desktop:search/emoji/overview` confirmados en vivo; ❌ **«abrir notificaciones»**: KDE no tiene acción global (probé `Meta+N` y solo escribió una `n`); alternativas `desktop:dnd` (✅ activado y revertido en vivo, confirmado por ti) y `desktop:clear-notifications` |
| Soundboard (reproducir/parar audio) | `soundboard` | ✅ `sound:play:<archivo>`, `sound:stop` (confirmado en vivo) |
| OBS Studio (11 acciones), vMix, YouTube | plugins | ⬜ |
| UDP (envío de datagramas) | `network.udp` | ✅ `udp:host:port:mensaje` (probado con un receptor local) |
| Touchbar (25 acciones, estilo macOS) | `touchbar` | ❌ |
| LED K1 Pro | `device.k1proLED±` | ❌ otro modelo |

## Aplicación
| Función | Estado |
|---|---|
| Perfiles con cambio automático por aplicación en primer plano (`MonitorApplicationsTool`) | ⬜ |
| Tienda de plugins/iconos (`space.key123.vip`), actualizaciones, GIF en teclas | ⬜ / ❌ |
| Bandeja del sistema, interfaz gráfica de edición | ⬜ |

## Nota sobre deslizamientos (dos capturas guiadas)
- Captura 1 (lento): `>>>` y `<<<` dieron ambos `0x39`.
- Captura 2 (velocidad normal, 3 rondas por sentido): cada gesto generó **un solo evento**: `0x39` en 5 de 6 (ambos sentidos) y `0x38` en 1 (un `>>>`).
**Corrección (16-nov, captura con el servicio, 6 + 8 deslizamientos):** `0x38` = el dedo va de izquierda a derecha (6 de 6) y `0x39` = de derecha a izquierda (8 de 8). Sí codifican el sentido; las capturas anteriores eran poco cuidadosas. `swipe.right` = izquierda→derecha, `swipe.left` = derecha→izquierda, `swipe.any` ambos. `strip.touch` (0x40–0x43) es fiable. 🟡 falta probar en vivo el cambio de página con deslizamiento.

## Prueba en vivo del 13-nov (service propio, 150 s previstos)
Log: apagado por inactividad 17:21:11 y 17:21:53, apagado por bloqueo 17:21:38, encendido al desbloquear 17:21:47, encendido por tecla 17:22:18.
Observaciones: (1) el primer apagado ocurrió a los 40 s y no a los 15 s configurados (probablemente hubo entradas que reiniciaron el contador; no hay registro de entradas para confirmarlo); (2) a las 17:21:35 el servicio recibió `No such device` y reconectó en 3 s; el kernel registró en ese mismo segundo un reset de otro dispositivo USB (n.º 11, el adaptador Bluetooth), el deck conservó su número (6). Causa no demostrada; (3) la acción `lock`/`suspend` no se ejecutó (solo se probó el seguimiento del bloqueo).

## Prueba en vivo de acciones de plugins (13-nov, 18:39)
Confirmado por ti: `desktop:show`, `tool:calculator`, `volume:mute` (dos veces), `sound:play`/`sound:stop`, `text:` (`Hola 123!`) y `toggle` (`AAA`/`bbb`).
Fallo: `desktop:notifications` (`Meta+N`) escribió una `n`: ese atajo no existe en tu Plasma (`kglobalshortcutsrc` no lo tiene). Corregido: ya no inyecta teclas, se rechaza con un mensaje y se ofrecen `desktop:dnd` y `desktop:clear-notifications`; los demás atajos de escritorio pasaron a invocar la acción por D-Bus (`kde:<componente>:<acción>`).

## Segunda prueba en vivo de acciones (13-nov, 18:44–18:46)
Confirmado por ti: VOL+/VOL−, MIC (dos veces), BUSCAR, EMOJI, OVERVIEW, MONITOR, AJUSTES, MEDIA, CORREO, SIG.PANT, ATRAS, ADELANTE, RECARGAR. Volumen y micrófono quedaron como al inicio (1.00, sin silencio).
NOTIFIC. (`desktop:notifications`): rechazada a propósito; en el registro solo aparece el aviso, no se escribió ninguna tecla.
Detalles: `media:play-pause` registró 4 avisos «found nothing to act on» (18:44:57–59) porque aún no había reproductor MPRIS abierto; después no hubo más avisos. `volume:up` está limitado al 100 % (`wpctl -l 1.0`), por eso en 100 % no sube.
Sin probar: `suspend`, `browser:collect`, `desktop:clear-notifications`, `key:` con combinaciones arbitrarias.

## Interfaz gráfica (`python -m streamstation.ui`)
| Función | Estado |
|---|---|
| Ver y elegir perfiles (escenas), páginas por perfil, perfil nuevo | ✅ pruebas aisladas; ⬜ quitar perfil |
| Mostrar las 10 teclas con su icono (también los de perfiles existentes) | ✅ (captura con el perfil `General` real) |
| Poner una acción en una tecla: arrastrar desde la lista o doble clic | ✅ pruebas y uso real (confirmado por ti) |
| Lista predeterminada de acciones con iconos unificados | ✅ |
| **Apps instaladas** (lee `.desktop`, usa el icono del tema) como botón `open:<app>` | ✅ pruebas; 🟡 sin probar con todas las apps reales |
| **Agregar atajo** (común o propio, validado) → botón `key:<combo>` | ✅ pruebas |
| **Buscar en el sistema…** (lanzador `.desktop`, archivo/programa o carpeta) → botón; el icono sale de la app o del tipo de archivo | ✅ pruebas (rutas con espacios, lanzadores fuera de las carpetas estándar, cancelar, ruta inexistente) y confirmado por ti en tu escritorio; ⚠ lanzadores con `Terminal=true` no abren terminal |
| Editar etiqueta/acción, quitar, guardar y aplicar al servicio (`profile <nombre>`) | ✅ pruebas; 🟡 aplicación en vivo sobre el dispositivo sin probar |
| Perillas, franja táctil (GIF, imagen, texto, métricas), multi-acciones, ajustes (pantalla apagada, bloqueo) | ⬜ siguientes partes |

Guarda solo en `~/.config/streamstation/profiles/` (no toca `~/.config/ragnaros`). Errores reales encontrados con las pruebas: teclas perdidas en páginas nuevas y botón «Quitar» deshabilitado tras escribir; ambos corregidos.

## Franja táctil: contenido y editor (14-nov)
| Función | Estado |
|---|---|
| Orden de los 4 paneles de izquierda a derecha = ranuras 0, 1, 2, 3 | ✅ confirmado por ti en el dispositivo (números 1 2 3 4) |
| Cada panel muestra: métrica (hora, fecha, CPU, RAM, temperatura, volumen, disco), texto (ajuste automático, colores), imagen o GIF | ✅ pruebas; ✅ GIF animado y métricas confirmados en vivo («las animaciones corrieron bien») |
| Se envía solo el panel que cambió (sin parpadeo; reloj solo cada minuto) | ✅ pruebas con dispositivo simulado; 95 s en vivo sin avisos ni errores del servicio |
| Una imagen o GIF repartido en los 4 paneles («toda la franja») | ✅ pruebas (se parte en 4 en orden); 🟡 en el dispositivo no confirmado (la fase «Ancho» A–H no la reportaste) |
| Acción al tocar cada panel (campo o arrastrando una acción sobre el segmento) | ✅ pruebas; 🟡 en vivo: en la prueba de 95 s no se registró ningún toque (no sé si no tocaste) |
| Editor de franja con vista previa (tipo, contenido, ajuste, color, ruta de archivo) | ✅ pruebas y captura (`docs/ui-editor-franja.png`) |
| Velocidad máxima de animación 4 fps (límite de seguridad), máx. 120 fotogramas | ✅ pruebas; límite elegido por mí para no saturar el dispositivo |
Errores reales que encontraron las pruebas y la captura: nombres `metric`/`size` chocaban con métodos de `QWidget` (la ventana no abría); la fuente por defecto de Pillow no tiene acentos («Reunión» salía con un cuadro, también en el dispositivo y en etiquetas de teclas) → módulo `fonts.py` con Noto Sans; desplegables y cuadros de texto sin estilo (blanco sobre blanco).

## Franja como una sola imagen (DRA) — hallazgo REA (14-nov)
El original NO reparte la franja en 4 ranuras: para los tipos de dato 16/18/19 antepone al JPEG una cabecera `CRT 00 00 DRA` con **tamaño, índice, ancho, alto, x, y** (`getSecondaryScreenPicInfo`, ev_13cc76df…; `writeDataToHidDevice`, ev_0ead7a4f…) y lo envía como un único flujo. Es decir, un lienzo único con imágenes colocadas en rectángulos.
Los 4 «slots» (`BAT`) y los corrimientos de calibración eran un rodeo de software. Estado: 🟡 constructor implementado y probado con pruebas; **sin verificar en el dispositivo** (longitud de cabecera 32 inferida de `+0x20`; orientación y uso del índice por confirmar).
Prueba en el dispositivo (14-nov, tú): el rectángulo 400×64 en (200,30) funciona; una imagen de 832 px sale con rayas en un extremo y cortada en el otro; a **800×124** la cruz de diagonales se ve perfecta y dos mitades de 400 px en x=0 y x=400 se unen sin costura → **lienzo único de 800 px de ancho confirmado**. Pendiente: el borde rojo no se ve en los extremos izquierdo/derecho (¿bisel?) y se ve más grueso arriba que abajo (altura/desfase por medir; prueba con 120, 124 y 128 de alto preparada).

### Lienzo único de la franja (14-nov, medido en el dispositivo contigo)
| Medida | Resultado |
|---|---|
| Envío `DRA` de un rectángulo (x, y, ancho, alto) | ✅ rectángulo de 400×64 en (200,30) |
| Ancho | ✅ **800 px** (a 832 las filas se envolvían: rayas en un extremo, el otro cortado) |
| Alto | ✅ **128 px** (a 124 el borde rojo salía más grueso arriba que abajo; confirmaste 128) |
| Orientación | ✅ el lienzo **entero** se rota 180°; cada región se coloca en el rectángulo espejado (rotar cada mitad por separado las intercambiaba: era lo que ocultaba el borde rojo en los extremos) |
| Eliminado | las 4 ranuras `BAT` de 208×124, los corrimientos de calibración y la herramienta `calibrate-strip` (eran un rodeo; ya no hacen falta) |
Zonas táctiles: 4 de 200 px (`0x40`–`0x43`, de izquierda a derecha), solo para los toques; el contenido (imagen, GIF) puede cubrir todo el lienzo. 🟡 el motor reescrito (75 pruebas) aún sin verificar de punta a punta en el dispositivo.
Verificación de punta a punta (14-nov): lienzo completo ✅ (fases 1 y 4 correctas). Las **zonas de 200 px** fallaban: franja blanca vertical en la zona 1 (y en el GIF) y la zona 4 más grande. Causa probable (coincide con una nota de tu proyecto anterior): el decodificador JPEG del dispositivo trabaja en bloques de 16 px y deja basura si ancho/posición no son múltiplos de 16 (todos los tamaños que funcionaron lo son; 200 no). Corrección: cada actualización se envía como un rectángulo **alineado a 16 px recortado del lienzo completo**, de modo que las columnas extra llevan el contenido real del vecino. 🟡 78 pruebas (incluida una que reproduce el síntoma); pendiente repetir en el dispositivo.

## Estado al 14-nov (cierre de la interfaz)
✅ Franja (lienzo único 800×128, zonas, GIF, toques) verificada en el dispositivo · ✅ editor de perillas (giro derecha/izquierda/pulsar, plantillas, arrastrar) con pruebas · ✅ instalador reversible (`install.sh --apply` hecho; `--switch` / `--rollback`).
Pendiente para jugar: cambio de perfil según la aplicación/juego en primer plano (función original «escenas ligadas a aplicaciones»), editor visual de multi-acciones, OBS.

## Independencia y acceso como programa (14-nov)
- Auditoría de coincidencia literal con el otro driver: 10 de 1.297 líneas, todas triviales (`import`, un modismo de `subprocess`, dos líneas de datos del dispositivo); las no-`import` se reescribieron.
- Quitado el uso de `~/.config/ragnaros` en tiempo de ejecución; `streamstation import-profiles` lee solo los YAML del usuario y reconstruye los iconos con la tubería propia (101 archivos de arte ajeno borrados de la config; todo lo que queda en `assets/` lo genera este programa).
- Acciones con herramientas externas ausentes (`playerctl`) reescritas como verbos propios; nuevo `media:volume-up/down` por MPRIS.
- Servicios del driver antiguo retirados con copia de seguridad (`~/.config/streamstation/old-install-backup`); el puente de X-Plane es ahora `streamstation-xplane.service`.
- Editor como programa: entrada de menú, icono dibujado por código, instancia única, indicador y botón de inicio del servicio, y una acción «Abrir este editor» que se puede poner en una tecla.
- Pendiente (requiere administrador): instalar `udev/70-streamstation.rules` y retirar las reglas del driver antiguo.

## Perfil por aplicación / juego (14-nov)
| Función | Estado |
|---|---|
| Detección de la ventana activa en KDE (Wayland/X11) con un script de KWin que avisa al servicio por D-Bus | ✅ pruebas + detección real de tu ventana |
| Reglas `match:` por perfil (clase, nombre, lanzador, programa, título; comodines y regex; gana la más específica) | ✅ pruebas |
| Cambio automático con retardo de 0,35 s, vuelta al perfil anterior (el «hogar» manual), ventanas ignoradas (escritorio, lanzador, el propio editor) | ✅ pruebas; ✅ cambio real en el dispositivo confirmado por ti |
| Reglas creadas/editadas con la aplicación ya en primer plano se reevalúan | ✅ (fallo encontrado en la prueba real y corregido) |
| Editor: diálogo 🎮 con ventanas vistas, regla manual, interruptor persistente | ✅ pruebas |
| Probado con un juego real (X-Plane / Steam) | ⬜ pendiente |


## Prueba táctil en vivo (16-nov)
Tres rondas de toques de izquierda a derecha, con acciones asignadas a las 4 zonas: `0x40`→zona 1 … `0x43`→zona 4, 12 de 12, en orden, y cada acción se ejecutó una vez (12 de 12). El orden de las zonas queda ✅ confirmado, y también que `strip.touch` ejecuta acciones desde el dispositivo.

## Rueda de configuración: General · Dispositivo · Escenas (16-nov)
| Función | Estado |
|---|---|
| General: buscar actualizaciones en GitHub (`usuario/repositorio`), alerta con changelog, instalación en segundo plano y reinicio; omitir versión | ✅ pruebas con GitHub simulado; ⬜ sin probar contra un repositorio real |
| General: idioma, tema, estilo de iconos (movidos aquí), «Iniciar Stream Station al encender el equipo» + «Iniciar minimizado» (autostart XDG + servicio de usuario), abrir carpeta de instalación | ✅ pruebas |
| Dispositivo: número de serie (sysfs), deslizador de brillo en vivo, logo de arranque (800×128, rellenar/ajustar/estirar, vista previa) | ✅ pruebas; logo = pantalla de bienvenida por software al conectar; ⬜ el logo guardado en la flash del equipo (`LOG`) está decodificado pero NO probado |
| Escenas: crear, renombrar, duplicar, eliminar (recuperable), orden, escena predeterminada, asociar aplicaciones (con resolución de conflictos), importar/exportar `.ssscene`, acciones siguiente/anterior, deslizamiento para cambiar de escena | ✅ pruebas; ⬜ prueba real en el dispositivo |
