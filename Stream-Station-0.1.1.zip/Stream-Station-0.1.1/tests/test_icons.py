import os, sys, pathlib
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from PIL import Image, ImageDraw
from streamstation.ui import catalog, icons


def _white_glyph():
    im = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    ImageDraw.Draw(im).ellipse((30, 30, 98, 98), fill=(255, 255, 255, 255))
    return im


def test_glyph_detection():
    assert icons.is_glyph(_white_glyph())
    assert not icons.is_glyph(Image.new("RGBA", (128, 128), (200, 60, 60, 255)))   # opaque tile
    multi = Image.new("RGBA", (128, 128), (0, 0, 0, 0))
    d = ImageDraw.Draw(multi); d.rectangle((10, 10, 60, 60), fill=(255, 0, 0, 255)); d.rectangle((70, 10, 120, 60), fill=(0, 200, 0, 255))
    assert not icons.is_glyph(multi)                                                  # logos are kept


def test_tile_recipe_size_background_and_glyph_colour():
    t = icons.make_tile(_white_glyph(), "teal")
    assert t.size == (128, 128) and t.getpixel((2, 2))[3] == 255                      # full bleed, opaque
    assert sum(t.getpixel((64, 64))[:3]) < 60                                         # near-black glyph
    assert t.getpixel((2, 2))[:3] != t.getpixel((125, 125))[:3] or icons.PALETTE["lilac"][0] == icons.PALETTE["lilac"][1]


def test_palette_colours_are_valid_hex():
    for a, b in icons.PALETTE.values():
        assert len(icons._hex(a)) == 3 and len(icons._hex(b)) == 3


def test_every_catalog_action_gets_a_128_tile():
    lib = icons.IconLibrary()
    if not lib.available:
        return   # vendor icons are optional (personal use, not redistributed)
    for group, items in catalog.CATALOG:
        for label, action, plugin in items:
            img = lib.key_image("" if plugin == "—" else plugin, label, group, "unified", action=action)
            assert img.size == (128, 128), (group, label)
    # aliased actions must not fall back to the two-letter placeholder
    lock = lib.key_image("SimulatedKeyboardEvent.computerLockWorkStation", "Bloquear", "Sistema", "unified", action="lock")
    placeholder = icons.fallback_tile("Bloquear", "red")
    assert list(lock.getdata()) != list(placeholder.getdata())


def test_new_icons_are_drawn_without_text_and_every_catalog_action_has_its_own():
    from PIL import ImageChops
    from streamstation.ui import actionicons as A, catalog, icons
    for name in A.GLYPHS:
        g = A.glyph(name, 64)
        assert g.size == (64, 64) and g.getchannel("A").getbbox() is not None, name        # something is drawn
        t = A.tile(name, "Audio")
        assert t.size == (128, 128)
    names = []
    for group, items in catalog.CATALOG:
        for label, action, plugin in items:
            n = A.name_for(action) or "terminal"
            assert n in A.GLYPHS, (action, n)
            names.append(n)
    assert len(set(names)) >= 38                                      # distinct meanings get distinct pictures
    assert A.name_for("desktop:show") == "desktop" and A.name_for("page:3") == "page_goto" and A.name_for("page:next") == "page_next"
    assert A.name_for("xp:cmd:sim/lights/x") == "bolt" and A.name_for("") is None and A.name_for("echo hola") is None
    # the old fallback drew the first letters of the label ("MO"); now the label is ignored
    rgb = lambda im: im.convert("RGB")
    a, b = icons.fallback_tile("Mostrar", "lilac"), icons.fallback_tile("ZZZ otro texto", "lilac")
    assert ImageChops.difference(rgb(a), rgb(b)).getbbox() is None
    assert ImageChops.difference(rgb(icons.fallback_tile("", "lilac", "layers")), rgb(a)).getbbox() is not None
    # catalog keys come from the program's own icons even when no vendor pack is installed
    lib = icons.IconLibrary(root="/nonexistent")
    k = lib.key_image("quickcontrol.displaydesktop", "Mostrar escritorio", "Escritorio (KDE)", "unified", action="desktop:show")
    assert ImageChops.difference(k.convert("RGB"), A.tile("desktop", "Escritorio (KDE)").convert("RGB")).getbbox() is None
    other = lib.key_image("", "x", "Escritorio (KDE)", "unified", action="desktop:search")
    assert ImageChops.difference(k.convert("RGB"), other.convert("RGB")).getbbox() is not None
    assert lib.key_image("", "Comando…", "Herramientas", "unified", action="{}").size == (128, 128)


def test_icon_styles_change_the_look_and_the_choice_is_read_from_the_settings():
    import tempfile
    from PIL import ImageChops
    from streamstation import profiles
    from streamstation.ui import actionicons as A
    px = lambda im: im.convert("RGB")
    with tempfile.TemporaryDirectory() as tmp:
        profiles.CONFIG = tmp
        assert A.current_style() == "pastel"
        base = A.tile("lock", "Sistema")
        assert px(base).getpixel((3, 3)) != (8, 8, 12)                               # pastel: coloured background
        for style in ("neon", "line"):
            t = A.tile("lock", "Sistema", 128, style)
            assert t.size == (128, 128) and px(t).getpixel((1, 1)) == (8, 8, 12)               # black tile
            assert any(sum(px(t).getpixel((x, y))) > 200 for x in range(30, 100, 3) for y in range(30, 100, 3))  # a bright glyph on it
            assert ImageChops.difference(px(t), px(base)).getbbox() is not None
        assert ImageChops.difference(px(A.tile("lock", "Sistema", 128, "neon")), px(A.tile("lock", "Sistema", 128, "line"))).getbbox() is not None
        assert ImageChops.difference(px(A.tile("lock", "Sistema", 128, "neon")), px(A.tile("lock", "Audio", 128, "neon"))).getbbox() is not None  # one colour per category
        profiles.save_setting("icon_style", "neon")
        assert A.current_style() == "neon"
        assert ImageChops.difference(px(A.tile("lock", "Sistema")), px(A.tile("lock", "Sistema", 128, "neon"))).getbbox() is None
        profiles.save_setting("icon_style", "nonsense")
        assert A.current_style() == "pastel"                                          # an unknown value falls back
        profiles.save_setting("icon_style", "line")
        from streamstation.ui import icons
        assert px(icons.fallback_tile("", "lilac")).getpixel((1, 1)) == (8, 8, 12)   # the text-free fallback follows the style too
        from streamstation.xplane import glyphs
        assert px(glyphs.neutral_tile("bulb")).getpixel((1, 1)) == (8, 8, 12)


def test_neon_and_line_keys_are_just_the_icon_on_black_with_no_frame_around_the_key():
    import io
    from PIL import Image
    from streamstation.ui import actionicons as A
    for style in ("neon", "line"):
        t = A.tile("lock", "Sistema", 128, style).convert("RGB")
        border = [t.getpixel((x, y)) for x in range(128) for y in (0, 3, 6, 9, 118, 121, 124, 127)] + \
                 [t.getpixel((x, y)) for y in range(128) for x in (0, 3, 6, 9, 118, 121, 124, 127)]
        assert set(border) == {(8, 8, 12)}, style                      # the whole outer edge is plain black: no frame line
        assert any(sum(t.getpixel((x, y))) > 200 for x in range(40, 90, 2) for y in range(30, 100, 2))
        app = A.app_tile(Image.new("RGBA", (64, 64), (200, 40, 40, 255)), 128, style).convert("RGB")
        edge = [app.getpixel((x, y)) for x in range(128) for y in (0, 5, 10, 117, 122, 127)]
        assert set(edge) == {(8, 8, 12)}, style                          # applications too


def test_miami_style_is_a_sunset_with_a_white_icon_and_a_coloured_shadow():
    from PIL import Image, ImageChops
    from streamstation import profiles
    from streamstation.ui import actionicons as A
    import tempfile
    assert "miami" in A.STYLES and list(A.STYLES) == ["pastel", "neon", "line", "miami", "industrial"]
    rgb = lambda im: im.convert("RGB")
    t = rgb(A.tile("lock", "Sistema", 128, "miami"))
    assert t.size == (128, 128)
    top, bottom = t.getpixel((4, 2)), t.getpixel((4, 125))
    assert top != bottom and sum(top) < sum(bottom) + 400 and top != (8, 8, 12)                 # a gradient, not flat black
    assert any(t.getpixel((x, y)) == (255, 255, 255) for x in range(30, 100) for y in range(20, 90))   # the white icon
    assert ImageChops.difference(t, rgb(A.tile("lock", "Audio", 128, "miami"))).getbbox() is not None   # colours change per category
    for other in ("pastel", "neon", "line"):
        assert ImageChops.difference(t, rgb(A.tile("lock", "Sistema", 128, other))).getbbox() is not None
    app = rgb(A.app_tile(Image.new("RGBA", (64, 64), (200, 40, 40, 255)), 128, "miami"))
    assert app.getpixel((64, 64)) == (200, 40, 40) and app.getpixel((4, 2)) != (27, 27, 31)       # the app's colours over the sunset
    with tempfile.TemporaryDirectory() as tmp:
        profiles.CONFIG = tmp
        profiles.save_setting("icon_style", "miami")
        assert A.current_style() == "miami"
        from streamstation.ui import icons
        assert rgb(icons.fallback_tile("", "lilac")).getpixel((4, 2)) != (8, 8, 12)


def test_industrial_style_has_its_own_redrawn_pictograms_on_graphite_with_one_orange_detail():
    from PIL import Image, ImageChops
    from streamstation.ui import actionicons as A, industrial
    rgb = lambda im: im.convert("RGB")
    assert set(industrial.GLYPHS) == set(A.GLYPHS)                         # one pictogram for every action
    redrawn = 0
    for name in A.GLYPHS:
        rounded = A.glyph(name, 96, style="pastel")
        ind = A.glyph(name, 96, style="industrial")
        assert ind.getchannel("A").getbbox() is not None, name
        if ImageChops.difference(rounded.getchannel("A"), ind.getchannel("A")).getbbox() is not None:
            redrawn += 1
    assert redrawn >= 44                                                   # different shapes, not the same drawing on a new background
    t = rgb(A.tile("lock", "Sistema", 128, "industrial"))
    assert t.size == (128, 128)
    assert t.getpixel((100, 4)) != t.getpixel((100, 100)) and sum(t.getpixel((100, 4))) < 330      # a graphite gradient, dark
    border = [t.getpixel((x, y)) for x in range(128) for y in (0, 1, 126, 127)] + [t.getpixel((x, y)) for y in range(128) for x in (0, 1, 126, 127)]
    assert max(sum(c) for c in border) < 330                                                        # no bright frame line around the key
    cells = [t.getpixel((x, y)) for x in range(20, 110) for y in range(15, 105)]
    assert any(abs(c[0] - 238) < 6 and abs(c[1] - 234) < 6 and abs(c[2] - 224) < 6 for c in cells)  # warm white pictogram
    assert any(c[0] > 240 and 90 < c[1] < 125 and c[2] < 30 for c in cells)                          # and the safety-orange detail
    assert ImageChops.difference(t, rgb(A.tile("lock", "Audio", 128, "industrial"))).getbbox() is None   # one palette, not one colour per category
    assert ImageChops.difference(t, rgb(A.tile("lock", "Sistema", 128, "miami"))).getbbox() is not None
    assert ImageChops.difference(t, rgb(A.tile("vol_up", "Sistema", 128, "industrial"))).getbbox() is not None
    app = rgb(A.app_tile(Image.new("RGBA", (64, 64), (30, 200, 60, 255)), 128, "industrial"))
    assert app.getpixel((64, 58)) == (30, 200, 60) and app.getpixel((100, 4)) != (30, 200, 60)      # the app's own colours on the plate
    from streamstation.ui import icons
    import tempfile
    from streamstation import profiles
    with tempfile.TemporaryDirectory() as tmp:
        profiles.CONFIG = tmp
        profiles.save_setting("icon_style", "industrial")
        fb = rgb(icons.fallback_tile("", "lilac", "terminal"))
        assert sum(fb.getpixel((100, 4))) < 330 and any(abs(c[0] - 238) < 6 for c in (fb.getpixel((x, y)) for x in range(20, 110) for y in range(15, 105)))


def test_services_have_catalog_entries_drawn_pictograms_in_every_style_and_a_tint():
    from PIL import ImageChops
    from streamstation import services
    from streamstation.ui import actionicons as A, catalog, industrial, model
    group = dict(catalog.CATALOG)["Servicios"]
    assert [a for _l, a, _p in group] == [f"service:{s.id}" for s in services.SERVICES]
    assert [l for l, _a, _p in group][:3] == ["YouTube", "YouTube Music", "Spotify"]
    assert model.describe_action("service:youtube-music") == "YouTube Music" and A.category_for("service:spotify") == "Servicios"
    rgb = lambda im: im.convert("RGB")
    seen = set()
    for s in services.SERVICES:
        name = "svc_" + s.id
        assert A.name_for(f"service:{s.id}") == name and name in A.GLYPHS and name in industrial.GLYPHS
        assert A.service_tint(name) == s.color
        for style in A.STYLES:
            t = A.tile(name, "Servicios", 128, style)
            assert t.size == (128, 128) and A.glyph(name, 64, style=style).getchannel("A").getbbox() is not None, (name, style)
        seen.add(rgb(A.tile(name, "Servicios", 128, "neon")).tobytes())
    assert len(seen) == len(services.SERVICES)                                       # every service looks different
    assert A.name_for("service:inventado") == "globe"                                # an unknown service still gets a sensible icon
    yt, sp = rgb(A.tile("svc_youtube", "Servicios", 128, "neon")), rgb(A.tile("svc_spotify", "Servicios", 128, "neon"))
    reddish = max(yt.getpixel((x, y)) for x in range(20, 110) for y in range(40, 90))
    greenish = max(sp.getpixel((x, y)) for x in range(20, 110) for y in range(20, 100))
    assert reddish[0] > 200 and reddish[0] > reddish[2] + 60 and greenish[1] > 200 and greenish[1] > greenish[0] + 60   # red YouTube, green Spotify
    a_, b_ = rgb(A.tile("svc_youtube", "Servicios", 128, "industrial")), rgb(A.tile("svc_spotify", "Servicios", 128, "industrial"))
    assert ImageChops.difference(a_, b_).getbbox() is not None                       # industrial keeps one palette but different pictograms


def test_real_marks_are_fetched_on_demand_never_bundled_and_drawn_in_the_brand_colour():
    import io, tempfile, urllib.error
    from PIL import Image
    from streamstation import logos, profiles, services
    from streamstation.ui import actionicons as A
    rgb = lambda im: im.convert("RGB")
    assert not os.path.isdir(os.path.join(os.path.dirname(logos.__file__), "..", "assets", "logos"))        # the program ships no logo
    assert all(s.slug and s.brand.startswith("#") and len(s.brand) == 7 for s in services.SERVICES)
    svg = b'<svg role="img" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><title>T</title><path d="M2 2h20v20H2z"/></svg>'
    calls = []

    class R(io.BytesIO):
        def __enter__(self): return self
        def __exit__(self, *a): return False

    def opener(req, timeout=0):
        calls.append(req.full_url)
        if "twitch" in req.full_url:
            raise urllib.error.URLError("sin conexión")
        if "spotify" in req.full_url:
            return R(b"<html>not an svg</html>")
        return R(svg)

    with tempfile.TemporaryDirectory() as tmp:
        profiles.CONFIG = tmp
        assert logos.missing() == [s.id for s in services.SERVICES]
        # without the files the key uses the program's own drawn pictogram
        drawn = rgb(A.tile("svc_youtube", "Servicios", 128, "pastel"))
        assert logos.logo_image("youtube") is None
        out = []
        r = logos.fetch(opener=opener, out=out.append)
        assert "twitch" in r["failed"] and "spotify" in r["failed"] and "youtube" in r["done"] and len(r["done"]) == len(services.SERVICES) - 2
        assert all(u.startswith("https://raw.githubusercontent.com/simple-icons/simple-icons/") and u.endswith(".svg") for u in calls)
        assert not os.path.exists(logos.path("twitch")) and not os.path.exists(logos.path("spotify"))   # bad downloads are not kept
        assert not [f for f in os.listdir(logos.folder()) if f.endswith(".tmp")]
        mark = logos.logo_image("youtube", 128)
        assert mark is not None and mark.size == (128, 128) and mark.getpixel((64, 64))[:3] == (255, 0, 0)   # painted in YouTube's red
        assert mark.getpixel((0, 0))[3] == 0                                                              # transparent around it
        with_logo = rgb(A.tile("svc_youtube", "Servicios", 128, "pastel"))
        assert with_logo.tobytes() != drawn.tobytes()                                                     # the real mark replaces the drawing
        assert any(c[0] > 240 and c[1] < 20 and c[2] < 20 for c in with_logo.getdata())
        neon = rgb(A.tile("svc_youtube", "Servicios", 128, "neon"))
        assert neon.getpixel((1, 1)) == (8, 8, 12) and any(c[0] > 240 and c[1] < 20 for c in neon.getdata())    # on every style
        assert sorted(logos.missing()) == ["spotify", "twitch"]                                                # and what failed can be retried
        sp = rgb(A.tile("svc_spotify", "Servicios", 128, "pastel"))
        own = rgb(A.styled_tile(A.glyph("svc_spotify", 128, style="pastel"), "Servicios", 128, "pastel", tint=A.service_tint("svc_spotify")))
        assert logos.logo_image("spotify") is None and sp.tobytes() == own.tobytes()                   # failed ones keep the drawn pictogram
