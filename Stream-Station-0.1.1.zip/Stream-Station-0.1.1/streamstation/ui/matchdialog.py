"""Dialog to tie a profile to applications: the profile activates when one of them gets focus."""
from __future__ import annotations

from ..i18n import tr

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QLineEdit,
                               QListWidget, QListWidgetItem, QPushButton, QVBoxLayout)


def describe(rule: dict) -> str:
    names = {"class": tr("clase"), "name": tr("nombre"), "desktop": tr("lanzador"), "exe": tr("programa"), "title": tr("título")}
    return "  ·  ".join(f"{names.get(k, k)}: {v}" for k, v in rule.items())


class MatchDialog(QDialog):
    def __init__(self, rules: list[dict], recent: list[dict], auto: bool = True, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Aplicaciones asociadas a este perfil"))
        self.setMinimumWidth(560)
        self._rules = [dict(r) for r in rules]
        self._recent = recent
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel(tr("El perfil se activa cuando una de estas aplicaciones tiene el foco, "
                                "y se vuelve al anterior al salir.")))
        self.rule_list = QListWidget(); lay.addWidget(self.rule_list)
        row = QHBoxLayout(); self.remove_btn = QPushButton(tr("Quitar la seleccionada")); row.addWidget(self.remove_btn); row.addStretch()
        lay.addLayout(row)
        lay.addWidget(QLabel(tr("Aplicaciones vistas recientemente (cambia a la aplicación y vuelve aquí si no aparece):")))
        self.recent_list = QListWidget(); lay.addWidget(self.recent_list)
        self.add_recent_btn = QPushButton(tr("Añadir la seleccionada")); lay.addWidget(self.add_recent_btn)
        form = QHBoxLayout()
        self.cls_edit = QLineEdit(); self.cls_edit.setPlaceholderText(tr("Clase (admite *), p. ej. steam_app_*"))
        self.title_edit = QLineEdit(); self.title_edit.setPlaceholderText(tr("Título (opcional, expresión regular)"))
        self.add_manual_btn = QPushButton(tr("Añadir regla"))
        form.addWidget(self.cls_edit, 1); form.addWidget(self.title_edit, 1); form.addWidget(self.add_manual_btn)
        lay.addLayout(form)
        self.auto_box = QCheckBox(tr("Cambiar de perfil automáticamente")); self.auto_box.setChecked(auto); lay.addWidget(self.auto_box)
        self.msg = QLabel(""); self.msg.setObjectName("muted"); lay.addWidget(self.msg)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel); lay.addWidget(buttons)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        self.remove_btn.clicked.connect(lambda: self.remove(self.rule_list.currentRow()))
        self.add_recent_btn.clicked.connect(lambda: self.add_window(self.recent_list.currentRow()))
        self.add_manual_btn.clicked.connect(lambda: self.add_manual(self.cls_edit.text(), self.title_edit.text()))
        self._fill()

    def _fill(self):
        self.rule_list.clear()
        for r in self._rules:
            self.rule_list.addItem(describe(r))
        self.recent_list.clear()
        for w in self._recent:
            item = QListWidgetItem(f"{w.get('class') or w.get('name')}   —   {w.get('title', '')[:60]}")
            self.recent_list.addItem(item)
        if not self._recent:
            self.msg.setText(tr("Aún no se ha visto ninguna aplicación (¿el servicio está detenido?)."))

    def _add(self, rule: dict):
        if not rule:
            return
        if rule in self._rules:
            self.msg.setText(tr("Esa regla ya existe."))
            return
        self._rules.append(rule); self.msg.setText(""); self._fill()

    def add_window(self, index: int):
        if 0 <= index < len(self._recent):
            self._add({"class": self._recent[index].get("class") or self._recent[index].get("name")})

    def add_manual(self, cls: str, title: str = ""):
        rule = {}
        if cls.strip():
            rule["class"] = cls.strip()
        if title.strip():
            import re
            try:
                re.compile(title.strip())
            except re.error as exc:
                self.msg.setText(tr("Expresión regular no válida: {error}", error=exc))
                return
            rule["title"] = title.strip()
        if not rule:
            self.msg.setText(tr("Escribe una clase o un título."))
            return
        self._add(rule)

    def remove(self, index: int):
        if 0 <= index < len(self._rules):
            del self._rules[index]; self._fill()

    def rules(self) -> list[dict]:
        return [dict(r) for r in self._rules]

    def auto(self) -> bool:
        return self.auto_box.isChecked()
