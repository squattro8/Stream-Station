"""Main window: scenes (left) | device board + configuration (centre) | action tree (right)."""
from __future__ import annotations

from .. import i18n
from ..i18n import tr

import json
import os

from PySide6.QtCore import QMimeData, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (QApplication, QMenu, QAbstractItemView, QStackedWidget, QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPushButton, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from .. import service, profiles, updater
from .. import strip as stripmod
from . import actionicons, appicon, apps, catalog, configpanel, icons, knobpanel, matchdialog, model, settingsdialog, strippanel, theme as T
from .board import Board

KIND_NAMES = {"key": "Tecla", "strip": "Segmento de la franja", "knob": "Perilla"}


class MiniDevice(QWidget):
    """The schematic in the lower-left 'Device' panel, drawn in the theme's text colour (white on dark, black on light)."""
    def __init__(self):
        super().__init__()
        self.setFixedSize(180, 190)

    def paintEvent(self, _):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing); ink = QColor(T.TEXT)
        p.setPen(QPen(ink, 3)); p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(QRectF(2, 2, 176, 186), 14, 14)
        p.setPen(Qt.NoPen); p.setBrush(ink)
        for r in range(2):
            for c in range(5):
                p.drawRoundedRect(QRectF(15 + c * 30, 20 + r * 31, 26, 26), 3, 3)
        p.setPen(QPen(ink, 5)); p.setBrush(Qt.NoBrush)
        p.drawRect(QRectF(14, 108, 152, 28))
        p.setPen(Qt.NoPen); p.setBrush(ink)
        for i in range(4):
            p.drawEllipse(QRectF(21 + i * 40, 154, 22, 22))


class ActionTree(QTreeWidget):
    """Draggable list of actions / apps. The payload travels as JSON in a private mime type."""
    def mimeTypes(self):
        return [Board.MIME]

    def mimeData(self, items):
        md = QMimeData()
        for it in items:
            payload = it.data(0, Qt.UserRole)
            if isinstance(payload, dict) and payload.get("kind") in ("catalog", "app", "xplane", "xplane_ctl"):
                md.setData(Board.MIME, json.dumps(payload).encode())
                break
        return md


def _tool_button(text, tip):
    b = QPushButton(text); b.setObjectName("tool"); b.setToolTip(tr(tip)); b.setCursor(Qt.PointingHandCursor)
    return b


class MainWindow(QWidget):
    update_found = Signal(object)         # a newer release exists (found by the check in the background)
    update_installing = Signal()          # its installation was handed over: close, the installer reopens the editor
    rebuild_requested = Signal()          # the language changed: the owner recreates the window with the new texts

    def __init__(self, profile: str | None = None, ctl=None, state: dict | None = None):
        super().__init__()
        self.setObjectName("root")
        self.setWindowTitle("Stream Station")
        self.setFixedSize(*T.WINDOW)
        self.lib = icons.IconLibrary()
        self.ctl = ctl or service.ctl                      # injectable for tests
        names = model.ProfileModel.list_profiles()
        state = state or {}
        self.model = state.get("model") or model.ProfileModel(profile or (names[0] if names else "General"))
        self.page = int(state.get("page") or 0)
        self.model.view_page = self.page
        self.selected: tuple[str, int] | None = None
        lay = QHBoxLayout(self); lay.setContentsMargins(0, 0, 0, 0); lay.setSpacing(0)
        lay.addWidget(self._left(names))
        lay.addWidget(self._centre(), 1)
        lay.addWidget(self._right())
        self.board.selected.connect(self._on_selected)
        self.board.dropped.connect(self.assign)
        self.board.dropped_strip.connect(self.assign_touch)
        self.board.dropped_knob.connect(self.assign_knob)
        self.knob_panel.field_changed.connect(self._knob_field)
        self.knob_panel.apply_clicked.connect(self.save_and_apply)
        self.panel.edited.connect(self._panel_edited)
        self.panel.apply_clicked.connect(self.save_and_apply)
        self.panel.browse_requested.connect(self.browse)
        self.strip_panel.segment_changed.connect(self._strip_segment)
        self.strip_panel.full_changed.connect(self._strip_full)
        self.strip_panel.touch_changed.connect(self._strip_touch)
        self.strip_panel.mode_changed.connect(self._strip_mode)
        self.strip_panel.page_swipe_changed.connect(self._page_swipe)
        self.strip_panel.place_search_requested.connect(self._search_place)
        self._weather_timer = QTimer(self); self._weather_timer.timeout.connect(self._weather_tick); self._weather_timer.start(3000)
        self.strip_panel.pick_requested.connect(self.pick_media)
        self.strip_panel.apply_clicked.connect(self.save_and_apply)
        self.refresh()
        self.setWindowIcon(appicon.qicon())
        self.poll_service()
        self._timer = QTimer(self); self._timer.timeout.connect(self.poll_service); self._timer.start(2000)

    # --- service status -------------------------------------------------------------------------
    def poll_service(self):
        """Reflect whether the service runs and the deck is connected (asks it over its control socket)."""
        try:
            st = json.loads(self.ctl(["status"]))
            ok = bool(st.get("ok"))
            state = ("connected", tr("Conectado · perfil activo: {name}", name=st.get("profile"))) if st.get("connected") else \
                    ("nodeck", tr("Servicio activo, dispositivo desconectado"))
        except (OSError, ValueError):
            ok, state = False, ("stopped", tr("Servicio detenido"))
        color = {"connected": "#3ba84a", "nodeck": "#d4a017", "stopped": "#969696"}[state[0]]
        self.service_dot.setStyleSheet(f"color:{color}; font-size:14px;")
        self.service_text.setText(state[1])
        self.service_btn.setVisible(state[0] == "stopped")
        self.service_state = state[0]

    def start_service(self):
        import subprocess
        subprocess.Popen(["systemctl", "--user", "start", "streamstation.service"], start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.service_text.setText(tr("Iniciando…"))

    # --- dialogs (overridable in tests) --------------------------------------------------------
    def ask_value(self, title: str) -> str | None:
        text, ok = QInputDialog.getText(self, title, title + ":")
        return text.strip() if ok and text.strip() else None

    def pick_path(self, mode: str) -> str | None:
        """Ask for something on disk. mode: app | file | folder."""
        from PySide6.QtWidgets import QFileDialog
        if mode == "folder":
            path = QFileDialog.getExistingDirectory(self, "Elegir carpeta", os.path.expanduser("~"))
        elif mode == "app":
            start = "/usr/share/applications" if os.path.isdir("/usr/share/applications") else os.path.expanduser("~")
            path, _ = QFileDialog.getOpenFileName(self, "Elegir lanzador de aplicación", start,
                                                  "Lanzadores (*.desktop);;Todos los archivos (*)")
        else:
            path, _ = QFileDialog.getOpenFileName(self, "Elegir archivo o programa", os.path.expanduser("~"))
        return path or None

    def browse(self, mode: str):
        """'Buscar en el sistema': turn a launcher / program / file / folder into the selected key."""
        index = self._need_key()
        if index is None:
            return
        path = self.pick_path(mode)
        if not path:
            return
        try:
            entry = configpanel.entry_from_path(path, self.lib)
        except ValueError as exc:
            self.panel.status.setText(str(exc))
            return
        self._set_entry(index, entry)

    def confirm_discard(self) -> bool:
        r = QMessageBox.question(self, "Cambios sin guardar", "El perfil tiene cambios sin guardar. ¿Descartarlos?")
        return r == QMessageBox.Yes

    # --- left ---------------------------------------------------------------------------------
    def _left(self, names):
        w = QWidget(); w.setObjectName("left"); w.setFixedWidth(T.LEFT_W)
        v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        top = QHBoxLayout(); top.setContentsMargins(10, 12, 10, 12); top.setSpacing(6)
        for glyph, tip in (("⌂", "Inicio"), ("▤", "Escenas"), ("?", "Ayuda"), ("⚙", "Configuración")):
            btn = _tool_button(glyph, tip)
            if glyph == "⚙":
                self.settings_btn = btn
                btn.clicked.connect(self.open_settings)
            top.addWidget(btn)
        top.addStretch(); v.addLayout(top)
        sep = QWidget(); sep.setObjectName("sep"); sep.setFixedHeight(1); v.addWidget(sep)
        self.scenes = QListWidget()
        self.scenes.currentRowChanged.connect(self._scene_row)
        v.addWidget(self.scenes, 1)
        bar = QHBoxLayout(); bar.setContentsMargins(10, 6, 10, 6)
        add = _tool_button("+", "Nuevo perfil"); add.clicked.connect(self.new_profile)
        rem = _tool_button("−", "Quitar perfil (aún no disponible)"); rem.setEnabled(False)
        self.match_btn = _tool_button("🎮", "Aplicaciones o juegos que activan este perfil"); self.match_btn.clicked.connect(self.edit_matches)
        bar.addWidget(add); bar.addWidget(rem); bar.addWidget(self.match_btn); bar.addStretch(); v.addLayout(bar)
        dev = QWidget(); dv = QVBoxLayout(dev); dv.setContentsMargins(0, 8, 0, 8)
        title = QLabel(tr("Dispositivo")); title.setObjectName("heading"); title.setAlignment(Qt.AlignCenter)
        name = QLabel("Ragnaros SS-552"); name.setObjectName("muted"); name.setAlignment(Qt.AlignCenter)
        dv.addWidget(title); dv.addWidget(name); dv.addWidget(MiniDevice(), 0, Qt.AlignCenter)
        v.addWidget(dev)
        self._fill_scenes(names)
        return w

    def _fill_scenes(self, names):
        self.scenes.blockSignals(True)
        self.scenes.clear()
        names = list(names)
        if self.model.name not in names:
            names.append(self.model.name)
        self._scene_names = names
        rules = profiles.match_rules()
        for n in names:
            has = bool(self.model.match()) if n == self.model.name else bool(rules.get(n))
            item = QListWidgetItem(("○  " if n == self.model.name else "●  ") + n + ("   🎮" if has else ""))
            if has:
                item.setToolTip(tr("Se activa solo con: ") + "; ".join(matchdialog.describe(r) for r in (self.model.match() if n == self.model.name else rules[n])))
            self.scenes.addItem(item)
        self.scenes.setCurrentRow(names.index(self.model.name))
        self.scenes.blockSignals(False)

    def _recent_windows(self) -> list[dict]:
        try:
            return json.loads(self.ctl(["windows"])).get("windows", [])
        except (OSError, ValueError):
            return []

    def _auto_enabled(self) -> bool:
        try:
            return bool(json.loads(self.ctl(["status"])).get("auto", True))
        except (OSError, ValueError):
            return True

    def stop_background(self):
        """Stop the timers and the aircraft detector: this window is being replaced."""
        ev = getattr(self, "_stop_detector", None)
        if ev is not None:
            ev.set()
        for name in ("_timer", "_weather_timer", "_detect_timer"):
            t = getattr(self, name, None)
            if t is not None:
                t.stop()

    def state(self) -> dict:
        """What a rebuilt window needs to carry on exactly where this one is (including unsaved edits)."""
        return {"model": self.model, "page": self.page}

    def retheme(self, *_):
        """The theme changed: every colour that was read when the lists were built is read again."""
        self.refresh()
        self._fill_tree(self.search.text())
        self.board.update()
        self.update()

    def make_settings_dialog(self):
        st = profiles.load_settings()
        host = settingsdialog.Host()
        host.open_scene, host.open_scene_dirty = self.model.name, bool(self.model.dirty)
        return settingsdialog.SettingsDialog(actionicons.current_style(), self, i18n.language() if i18n.language() in i18n.CODES else i18n.DEFAULT,
                                             str(st.get("theme") or "dark"), host=host)

    def fetch_logos(self, dlg=None):
        """The user asked for the real brand marks: download them, then redraw the service keys with them."""
        from .. import logos
        from PySide6.QtWidgets import QApplication
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            result = logos.fetch(out=lambda *_: None)
        finally:
            QApplication.restoreOverrideCursor()
        ok, bad = len(result["done"]), len(result["failed"])
        msg = tr("{n} logos descargados", n=ok) + (tr("; {bad} fallaron (¿sin conexión?)", bad=bad) if bad else "")
        if ok:
            self.__dict__.pop("_prev_icons", None)
            try:
                self._restyle_icons()
            except Exception as exc:
                msg += tr(" · no se pudieron rehacer los iconos: {error}", error=exc)
            self.refresh(); self._fill_tree(self.search.text())
        if dlg is not None and hasattr(dlg, "set_logos_note"):
            dlg.set_logos_note(msg)
        self.panel.status.setText(msg)
        return result

    def open_settings(self):
        dlg = self.make_settings_dialog()
        if hasattr(dlg, "fetch_logos_requested"):
            dlg.fetch_logos_requested.connect(lambda: self.fetch_logos(dlg))
        old_language, old_theme = i18n.language(), str(profiles.load_settings().get("theme") or "dark")
        if hasattr(dlg, "theme_previewed"):                       # choosing a theme shows it at once; Cancel puts the old one back
            dlg.theme_previewed.connect(self.apply_theme)
        if hasattr(dlg, "restart_requested"):                     # an update was handed to the installer, which reopens the editor
            dlg.restart_requested.connect(lambda: QApplication.quit())
        accepted = dlg.exec()
        self._after_scene_changes(dlg)                            # scenes are changed in the window itself, whatever the button
        if not accepted:
            if hasattr(dlg, "theme_previewed") and dlg.theme() != old_theme:
                self.apply_theme(old_theme)
            return
        style = dlg.style()
        profiles.save_setting("icon_style", style)
        self.__dict__.pop("_prev_icons", None); self.__dict__.pop("_xp_icons", None)         # previews are drawn in the old style
        msg = tr("Estilo de iconos: {name}", name=tr(actionicons.STYLES[style]).split(":")[0])
        try:
            self._restyle_icons()
            msg += tr(" · todos los iconos de las teclas rehechos")
        except Exception as exc:                                  # never leave the user guessing why nothing changed
            msg += tr(" · NO se pudieron rehacer los iconos: {error}", error=exc)
        self.refresh()
        self._fill_tree(self.search.text())
        self.panel.status.setText(msg)
        new_theme = dlg.theme() if hasattr(dlg, "theme") else old_theme
        if new_theme != old_theme:
            profiles.save_setting("theme", new_theme)
            self.apply_theme(new_theme)
        new_language = dlg.language() if hasattr(dlg, "language") else old_language
        if new_language != old_language:
            profiles.save_setting("language", new_language)
            self.apply_language(new_language)

    def start_update_check(self, delay_ms: int = 2500):
        """When the editor opens: ask GitHub (once, in the background) whether a newer version exists, and offer it."""
        st = profiles.load_settings()
        repo = str(st.get("update_repo") or "")
        if not st.get("update_check", True) or not updater.REPO_RE.match(repo):
            return
        skip = str(st.get("update_skip") or "")

        def work():
            try:
                release = updater.check(repo)
            except Exception:
                return                                            # no connection, no release yet...: nothing to say
            if release.newer and release.version != skip:
                self.update_found.emit(release)
        self.update_found.connect(self._offer_update)
        self.update_installing.connect(lambda: QApplication.quit())
        QTimer.singleShot(delay_ms, lambda: threading.Thread(target=work, daemon=True).start())

    def _offer_update(self, release):
        from . import updatedialog
        dlg = updatedialog.UpdateDialog(release, self)
        dlg.exec()
        if dlg.choice == updatedialog.SKIP:
            profiles.save_setting("update_skip", release.version)
        elif dlg.choice == updatedialog.UPDATE:
            from . import settingshost
            host = settingshost.Host()

            def work():
                try:
                    host.install(release)
                except Exception as exc:
                    self.panel.status.setText(tr("No se pudo actualizar: {error}", error=exc)); return
                self.update_installing.emit()
            self.panel.status.setText(tr("Descargando la nueva versión, espera un momento…"))
            threading.Thread(target=work, daemon=True).start()

    def _after_scene_changes(self, dlg):
        """Scenes were added / renamed / deleted / reordered in the settings window: the list and the open scene follow."""
        page = getattr(dlg, "scenes_page", None)
        if page is None or not page.changed:
            return
        from .. import scenes
        names = scenes.names()
        current = page.renamed.get(self.model.name, self.model.name)
        if current != self.model.name and current in names and not self.model.dirty:
            self.model = model.ProfileModel(current)
        elif self.model.name not in names and names and not self.model.dirty:
            self.model = model.ProfileModel(current if current in names else names[0])
        self.page, self.selected = 0, None
        self.model.view_page = 0
        self._fill_scenes(names)
        self.panel.show_none()
        self.refresh()

    def apply_theme(self, setting: str):
        """Use the theme now (through the application's Appearance when there is one, directly otherwise)."""
        look = getattr(self, "appearance", None)
        if look is not None:
            look.set_theme(setting)
            return
        from PySide6.QtWidgets import QApplication
        theme_mod = T
        theme_mod.apply(theme_mod.resolve(setting))
        QApplication.instance().setStyleSheet(theme_mod.qss())
        self.retheme()

    def apply_language(self, code: str):
        """Use the language and ask the owner to rebuild the window, so that every text is drawn again."""
        look = getattr(self, "appearance", None)
        if look is not None:
            look.set_language(code)
        else:
            i18n.set_language(code)
        self.rebuild_requested.emit()

    def _restyle_icons(self):
        """Every icon of every profile in the current style: the files on disk and the profile open in the editor
        (including edits not saved yet, which stay unsaved)."""
        from .. import importer
        dirty = self.model.dirty
        importer.rebuild_icons(out=lambda *_: None)            # every profile's file (a copy is kept next to each)
        if dirty:
            self.model.raw, _notes = importer.convert_profile(self.model.raw)    # the open one, with its pending edits
            self.model.dirty = True
        else:
            name, page = self.model.name, self.page
            self.model = model.ProfileModel(name)
            self.model.view_page = page
        try:
            self.ctl(["reload"])
        except OSError:
            pass

    def make_match_dialog(self):
        return matchdialog.MatchDialog(self.model.match(), self._recent_windows(), self._auto_enabled(), self)

    def edit_matches(self):
        dlg = self.make_match_dialog()
        if dlg.exec():
            self.model.set_match(dlg.rules())
            try:
                self.ctl(["auto", "on" if dlg.auto() else "off"])
            except OSError:
                pass
            self._mark_dirty_title()
            self._fill_scenes(self._scene_names)

    def _mark_dirty_title(self):
        self.setWindowTitle(f"Stream Station — {self.model.name} *")

    def _scene_row(self, row):
        if row < 0 or self._scene_names[row] == self.model.name:
            return
        if self.model.dirty and not self.confirm_discard():
            self._fill_scenes(self._scene_names)
            return
        self.model = model.ProfileModel(self._scene_names[row])
        self.page, self.selected = 0, None
        self._fill_scenes(self._scene_names)
        self.panel.show_none()
        self.refresh()

    def new_profile(self):
        name = self.ask_value("Nombre del perfil")
        if not name or name in self._scene_names:
            return
        if self.model.dirty and not self.confirm_discard():
            return
        self.model = model.ProfileModel(name)
        self.model.dirty = True
        self.page, self.selected = 0, None
        self._fill_scenes(self._scene_names + [name])
        self.panel.show_none()
        self.refresh()
        self.panel.status.setText(tr("Perfil nuevo sin guardar"))

    # --- centre -------------------------------------------------------------------------------
    def _centre(self):
        w = QWidget(); w.setObjectName("board")
        v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)
        bar = QHBoxLayout(); bar.setContentsMargins(14, 8, 14, 0)
        self.service_dot = QLabel("●"); self.service_text = QLabel(tr("Comprobando…")); self.service_text.setObjectName("muted")
        self.service_btn = QPushButton(tr("Iniciar")); self.service_btn.setVisible(False); self.service_btn.clicked.connect(self.start_service)
        bar.addWidget(self.service_dot); bar.addWidget(self.service_text); bar.addWidget(self.service_btn); bar.addStretch()
        v.addLayout(bar)
        self.board = Board()
        v.addSpacing(40); v.addWidget(self.board, 0, Qt.AlignHCenter)
        self.pages_row = QHBoxLayout()
        v.addSpacing(8); v.addLayout(self.pages_row); v.addStretch()
        line = QWidget(); line.setObjectName("sep"); line.setFixedHeight(2); v.addWidget(line)
        self.panel = configpanel.ConfigPanel(); self.strip_panel = strippanel.StripPanel()
        self.editors = QStackedWidget(); self.editors.setMinimumHeight(290)
        self.knob_panel = knobpanel.KnobPanel()
        self.editors.addWidget(self.panel); self.editors.addWidget(self.strip_panel); self.editors.addWidget(self.knob_panel)
        v.addWidget(self.editors)
        return w

    def _asset_roots(self):
        return [os.path.join(profiles.CONFIG, "assets")] + profiles.search_dirs("assets")

    def entry_pixmap(self, entry: dict) -> QPixmap:
        icon = entry.get("icon")
        for base in self._asset_roots():
            path = icon if icon and os.path.isabs(icon) else (os.path.join(base, icon) if icon else None)
            if path and os.path.isfile(path):
                pm = QPixmap(path)
                if not pm.isNull():
                    return pm
        return icons.to_qpixmap(icons.fallback_tile("", "lilac", "terminal"))

    def refresh(self):
        self.board.keys = {}
        for i in range(10):
            entry = self.model.get(i, self.page)
            if entry:
                self.board.keys[i] = {"label": "", "pixmap": self.entry_pixmap(entry), "tip": model.tooltip(entry)}
        self.refresh_strip()
        if not self.selected:
            self.editors.setCurrentIndex(0)
        while self.pages_row.count():
            item = self.pages_row.takeAt(0)
            if item.widget():
                item.widget().hide()            # gone at once; deleteLater alone leaves a ghost until the event loop runs
                item.widget().deleteLater()
        self.pages_row.addStretch()
        for n in range(self.model.page_count()):
            b = QPushButton(str(n + 1)); b.setObjectName("chip" if n == self.page else "pagebtn")
            b.clicked.connect(lambda _=False, n=n: self.set_page(n))
            b.setContextMenuPolicy(Qt.CustomContextMenu)
            b.customContextMenuRequested.connect(lambda pos, n=n, b=b: self._page_menu(n, b.mapToGlobal(pos)))
            b.setToolTip(tr("Clic derecho para eliminar") if self.model.page_count() > 1 else "")
            self.pages_row.addWidget(b); self.pages_row.addSpacing(6)
        plus = QPushButton("+"); plus.setObjectName("plus"); plus.setToolTip(tr("Añadir página"))
        plus.clicked.connect(self.add_page)
        self.pages_row.addWidget(plus); self.pages_row.addStretch()
        self.setWindowTitle(f"Stream Station — {self.model.name}" + (" *" if self.model.dirty else ""))

    # --- touch strip ------------------------------------------------------------------------
    def _strip_content(self) -> dict:
        full = self.model.full()
        return {"mode": "full", "full": full} if full else {"mode": "segments", "segments": self.model.segments()}

    def refresh_strip(self):
        """Preview of the strip: the same plan the service sends, composed on one canvas and cut in 4 zones."""
        try:
            canvas = stripmod.compose(stripmod.StripEngine().plan(self._strip_content(), now=0.0))
            z = stripmod.SEG[0]
            self.board.strip_pix = [icons.to_qpixmap(canvas.crop((i * z, 0, (i + 1) * z, canvas.height))) for i in range(4)]
        except Exception as exc:                       # a broken file must not break the editor
            self.board.strip_pix = [None] * 4
            self.panel.status.setText(tr("Vista previa de la franja: {error}", error=exc))
        self.board.update()
        if self.selected and self.selected[0] == "strip" and self.editors.currentIndex() == 1:
            self.strip_panel.set_preview(self.board.strip_pix[self.selected[1]])

    def pick_media(self, kind: str):
        from PySide6.QtWidgets import QFileDialog
        flt = "GIF (*.gif)" if kind == "gif" else "Imágenes (*.png *.jpg *.jpeg *.webp *.bmp *.gif)"
        path, _ = QFileDialog.getOpenFileName(self, tr("Elegir archivo"), os.path.expanduser("~"), flt + ";;" + tr("Todos los archivos (*)"))
        if path:
            self.strip_panel.set_path(path)

    def _mark_dirty(self):
        self.setWindowTitle(f"Stream Station — {self.model.name} *")
        self.strip_panel.status.setText(tr("Sin guardar"))
        self.refresh_strip()

    def _strip_segment(self, spec):
        if self.selected and self.selected[0] == "strip":
            self.model.set_segment(self.selected[1], spec)
            self._mark_dirty()

    def _strip_full(self, spec):
        if self.selected and self.selected[0] == "strip" and spec != self.model.full():
            self.model.set_full(spec)
            self._mark_dirty()

    def _strip_touch(self, action):
        if self.selected and self.selected[0] == "strip":
            self.model.set_touch(self.selected[1], action)
            self._mark_dirty()

    def assign_touch(self, index: int, payload: dict):
        """Dropping an action on a strip segment makes it the segment's touch action."""
        try:
            value = None
            if payload.get("kind") == "catalog" and "{}" in payload["action"]:
                value = self.ask_value(payload["label"].rstrip("…"))
                if value is None:
                    return
            action = configpanel.action_from_payload(payload, value)
        except ValueError as exc:
            self.panel.status.setText(str(exc)); self.strip_panel.status.setText(str(exc))
            return
        self._on_selected("strip", index)
        self.model.set_touch(index, action)
        self.strip_panel.touch.setText(action)
        self._mark_dirty()

    # --- knobs -------------------------------------------------------------------------------
    def _knob_field(self, field, action):
        if self.selected and self.selected[0] == "knob":
            self.model.set_knob_field(self.selected[1], field, action)
            self.setWindowTitle(f"Stream Station — {self.model.name} *")
            self.knob_panel.status.setText(tr("Sin guardar"))

    def assign_knob(self, index: int, payload: dict):
        """An action dropped on a knob goes to the field being edited (press by default)."""
        self._on_selected("knob", index)
        self._knob_apply(payload)

    def _knob_apply(self, payload: dict):
        try:
            value = None
            if payload.get("kind") == "catalog" and "{}" in payload["action"]:
                value = self.ask_value(payload["label"].rstrip("…"))
                if value is None:
                    return
            action = configpanel.action_from_payload(payload, value)
        except ValueError as exc:
            self.knob_panel.status.setText(str(exc))
            return
        self.knob_panel.set_field(self.knob_panel.active, action)

    def _search_place(self, query: str):
        """The user typed a city in the weather panel: look it up (Open-Meteo geocoding) and offer the matches."""
        from .. import weather
        from PySide6.QtWidgets import QApplication
        if not query.strip():
            self.strip_panel.status.setText(tr("Escribe el nombre de una ciudad"))
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            places = weather.search(query)
        except weather.WeatherError:
            self.strip_panel.status.setText(tr("No pude buscar la ciudad: ¿hay conexión a internet?"))
            return
        finally:
            QApplication.restoreOverrideCursor()
        self.strip_panel.show_places(places)
        self.strip_panel.status.setText(tr("{n} resultado(s): elige uno", n=len(places)) if places else tr("No encontré «{name}»", name=query.strip()))

    def _weather_tick(self):
        """The strip preview says 'Cargando…' until a city's reading arrives; redraw it once when it does."""
        from .. import weather
        content = self._strip_content()
        specs = [content.get("full")] if content.get("mode") == "full" else (content.get("segments") or [])
        sig = tuple((sp["place"].get("lat"), sp["place"].get("lon"),
                     weather.SERVICE.get(sp["place"].get("lat"), sp["place"].get("lon")) is not None)
                    for sp in specs if isinstance(sp, dict) and sp.get("type") == "weather"
                    and isinstance(sp.get("place"), dict) and sp["place"].get("lat") is not None)
        if sig != getattr(self, "_weather_sig", ()):
            self._weather_sig = sig
            self.refresh_strip()

    def _page_swipe(self, on: bool):
        self.model.set_page_swipe(on)
        self.strip_panel.status.setText(tr("Sin guardar"))

    def _strip_mode(self, mode: str):
        if mode == self.model.strip_mode():
            return
        self.model.set_strip_mode(mode)
        self.refresh()
        if self.selected and self.selected[0] == "strip":
            self._on_selected("strip", self.selected[1])
        self.strip_panel.status.setText(tr("Sin guardar · cada página tiene su franja") if mode == "per_page" else tr("Sin guardar · la misma franja en todas las páginas"))

    def set_page(self, n):
        self.page, self.selected = n, None
        self.model.view_page = n
        self.board.sel = None
        self.panel.show_none()
        self.refresh()

    def _page_menu(self, n: int, pos):
        menu = QMenu(self)
        act = menu.addAction(tr("Eliminar la página {n}", n=n + 1))
        act.setEnabled(self.model.page_count() > 1)          # a profile always keeps at least one page
        if self.model.page_count() <= 1:
            menu.addAction(tr("(es la única página)")).setEnabled(False)
        chosen = menu.exec(pos)
        if chosen is act:
            self.remove_page(n)

    def remove_page(self, n: int):
        if self.model.page_count() <= 1:
            self.panel.status.setText(tr("No se puede eliminar la única página"))
            return
        if self.model.page_has_keys(n):
            ask = QMessageBox.question(self, tr("Eliminar página"), tr("¿Eliminar la página {n}? Se pierden sus teclas.", n=n + 1),
                                       QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if ask != QMessageBox.Yes:
                return
        self.model.remove_page(n)
        keep = self.page - 1 if self.page > n else self.page          # pages after the removed one shift down by one
        self.set_page(max(0, min(keep, self.model.page_count() - 1)))
        self.panel.status.setText(tr("Página {n} eliminada · sin guardar", n=n + 1))

    def add_page(self):
        self.set_page(self.model.add_page())
        self.panel.status.setText(tr("Sin guardar"))

    # --- selection / editing ----------------------------------------------------------------------
    def _on_selected(self, kind, index):
        self.selected = (kind, index)
        if kind not in ("strip", "knob"):
            self.editors.setCurrentIndex(0)
        if kind == "key":
            entry = self.model.get(index, self.page)
            self.panel.show_entry(tr("Tecla {n} · página {page}", n=index + 1, page=self.page + 1), entry,
                                  self.entry_pixmap(entry) if entry else None)
        elif kind == "strip":
            self.editors.setCurrentIndex(1)
            self.strip_panel.show_segment(index, self.model.segments()[index], self.model.full(), self.model.touch(index),
                                          self.model.strip_mode(), self.page, self.model.page_swipe())
            self.strip_panel.set_preview(self.board.strip_pix[index])
        else:   # knob
            self.editors.setCurrentIndex(2)
            self.knob_panel.show_knob(index, self.model.knob(index))

    def _need_key(self) -> int | None:
        if self.selected and self.selected[0] == "key":
            return self.selected[1]
        self.panel.status.setText(tr("Selecciona primero una tecla"))
        return None

    def assign(self, index: int, payload: dict):
        """Put a catalog action or an installed app on a key."""
        try:
            kind = payload.get("kind")
            if kind == "catalog":
                value = None
                if "{}" in payload["action"]:
                    value = self.ask_value(payload["label"].rstrip("…"))
                    if value is None:
                        return
                entry = configpanel.entry_from_catalog(payload, self.lib, value)
            elif kind == "xplane":
                entry = configpanel.entry_from_xplane(payload)
            elif kind == "xplane_ctl":
                entry = configpanel.entry_from_control(payload)
            elif kind == "app":
                entry = configpanel.entry_from_app(apps.App(payload["id"], payload["name"], payload.get("icon", "")))
            else:
                return
        except ValueError as exc:
            self.panel.status.setText(str(exc))
            return
        self._set_entry(index, entry)

    def _set_entry(self, index: int, entry: dict | None):
        self.model.set(index, self.page, entry)
        self.refresh()
        self._on_selected("key", index)
        self.panel.status.setText(tr("Sin guardar"))

    def add_shortcut(self):
        index = self._need_key()
        if index is None:
            return
        dlg = configpanel.ShortcutDialog(self)
        if dlg.exec():
            label, combo = dlg.values()
            try:
                self._set_entry(index, configpanel.entry_from_shortcut(label, combo, self.lib))
            except ValueError as exc:
                self.panel.status.setText(str(exc))

    def _panel_edited(self, entry):
        if not self.selected or self.selected[0] != "key":
            return
        self.model.set(self.selected[1], self.page, entry)
        self.board.keys.pop(self.selected[1], None)
        if entry:
            self.board.keys[self.selected[1]] = {"label": "", "pixmap": self.entry_pixmap(entry), "tip": model.tooltip(entry)}
        self.board.update()
        self.setWindowTitle(f"Stream Station — {self.model.name} *")
        self.panel.status.setText(tr("Sin guardar"))
        if entry is None:
            self._on_selected("key", self.selected[1])

    def save_and_apply(self):
        path = self.model.save()
        try:
            reply = json.loads(self.ctl(["apply", self.model.name]))
            msg = (tr("Guardado y aplicado al dispositivo (el equipo sigue en su página {page})", page=reply["page"]) if reply.get("page")
                   else tr("Guardado y aplicado al dispositivo")) if reply.get("ok") else tr("Guardado; el servicio respondió: {error}", error=reply.get("error"))
        except OSError:
            msg = tr("Guardado; el servicio no está corriendo, se verá al iniciarlo")
        except ValueError:
            msg = tr("Guardado; respuesta ilegible del servicio")
        self.panel.status.setText(msg); self.strip_panel.status.setText(msg); self.knob_panel.status.setText(msg)
        self.refresh()
        return path

    # --- right --------------------------------------------------------------------------------
    def _right(self):
        w = QWidget(); w.setObjectName("right"); w.setFixedWidth(T.RIGHT_W)
        v = QVBoxLayout(w); v.setContentsMargins(0, 12, 0, 0); v.setSpacing(8)
        self.search = QLineEdit(); self.search.setPlaceholderText(tr("Buscar"))
        self.search.textChanged.connect(self._fill_tree)
        sv = QHBoxLayout(); sv.setContentsMargins(20, 0, 14, 0); sv.addWidget(self.search); v.addLayout(sv)
        tabs = QHBoxLayout(); tabs.setContentsMargins(20, 0, 14, 0); tabs.setSpacing(0)
        self.tab_key, self.tab_knob = QPushButton(tr("Tecla")), QPushButton(tr("Perilla"))
        for b in (self.tab_key, self.tab_knob):
            b.setObjectName("tab"); b.setCheckable(True); tabs.addWidget(b)
        self.tab_key.setChecked(True); v.addLayout(tabs)
        self.tree = ActionTree(); self.tree.setHeaderHidden(True); self.tree.setIndentation(0)
        self.tree.setIconSize(QSize(32, 32)); self.tree.setExpandsOnDoubleClick(False)
        self.tree.setDragEnabled(True); self.tree.setDragDropMode(QAbstractItemView.DragOnly)
        self.tree.itemClicked.connect(self._toggle)
        self.tree.itemDoubleClicked.connect(self._activate)
        v.addWidget(self.tree, 1)
        self._apps = None
        self._fill_tree("")
        return w

    def _installed_apps(self):
        if self._apps is None:
            self._apps = apps.list_apps()
        return self._apps

    def _fill_tree(self, text):
        self.tree.clear()
        groups = [(g, items) for g, items in catalog.search(text)]
        for group, items in groups:
            top = self._group_item(group)
            if group == "Herramientas":
                add = QTreeWidgetItem(["      ＋  Agregar atajo…"])
                add.setData(0, Qt.UserRole, {"kind": "shortcut"}); add.setBackground(0, QColor(T.BG_DEEP))
                add.setSizeHint(0, QSize(0, 40)); add.setForeground(0, QColor(T.ACCENT)); add.setIcon(0, self._preview_icon("keyboard", group))
                top.addChild(add)
            for label, action, plugin in items:
                child = QTreeWidgetItem(["      " + tr(label)]); child.setForeground(0, QColor(T.TEXT_MUTED))
                child.setBackground(0, QColor(T.BG_DEEP)); child.setSizeHint(0, QSize(0, 40))
                payload = {"kind": "catalog", "label": tr(label), "action": action, "plugin": plugin, "group": group}
                child.setData(0, Qt.UserRole, payload); child.setToolTip(0, f"{action}  ·  {plugin}")
                f = child.font(0); f.setBold(False); child.setFont(0, f)
                child.setIcon(0, self._preview_icon(actionicons.name_for(action) or "terminal", group))   # the button itself
                top.addChild(child)
            self._finish_group(top, group, bool(text) or group == "Herramientas")
        t = text.strip().lower()
        self._fill_aircraft(t)
        self._fill_xplane(t)
        found = [a for a in self._installed_apps() if not t or t in a.name.lower() or t in a.id.lower()]
        if found:
            top = self._group_item("Aplicaciones instaladas")
            for a in found[:400]:
                child = QTreeWidgetItem(["      " + a.name]); child.setForeground(0, QColor(T.TEXT_MUTED))
                child.setBackground(0, QColor(T.BG_DEEP)); child.setSizeHint(0, QSize(0, 40))
                child.setData(0, Qt.UserRole, {"kind": "app", "id": a.id, "name": a.name, "icon": a.icon})
                child.setToolTip(0, f"open:{a.id}")
                f = child.font(0); f.setBold(False); child.setFont(0, f)
                ic = QIcon.fromTheme(a.icon) if a.icon else QIcon()
                if not ic.isNull():
                    child.setIcon(0, ic)
                top.addChild(child)
            self._finish_group(top, "Aplicaciones instaladas", bool(t))

    def _xplane_data(self):
        if getattr(self, "_xp", None) is None:
            from ..xplane import catalog as xc
            inst = xc.find_install(profiles.load_settings().get("xplane_dir"))
            self._xp = (xc, xc.load_commands(inst) if inst else [])
            if inst:
                self.panel.set_dataref_names(xc.load_datarefs(inst))
        return self._xp

    def _start_detector(self):
        """Background thread: which aircraft does X-Plane have loaded? (None when the sim is not reachable)"""
        import threading, time
        from ..xplane import link as xl
        self._detected = None
        lk = xl.XPlaneLink(str(profiles.load_settings().get("xplane_url") or xl.DEFAULT_URL), timeout=1.0)
        self._stop_detector = threading.Event()

        def run():
            caps = False
            while not self._stop_detector.is_set():
                try:
                    if not caps:
                        lk.capabilities(); caps = True
                    self._detected = lk.read_text("sim/aircraft/view/acf_relative_path") or None
                except Exception:
                    self._detected = None; caps = False
                self._stop_detector.wait(4)
        threading.Thread(target=run, daemon=True, name="streamstation-detect").start()
        self._detected_shown = None
        self._detect_timer = QTimer(self); self._detect_timer.timeout.connect(self._detected_changed); self._detect_timer.start(2000)

    def _detected_changed(self):
        """Refresh the tree when the aircraft in the simulator changed and the user has not chosen one by hand."""
        if profiles.load_settings().get("xplane_aircraft"):
            return
        now = self._detected
        if now != self._detected_shown:
            self._detected_shown = now
            self._fill_tree(self.search.text())

    def _aircraft_scan(self):
        """(aircraft list, name, scan result) for the aircraft chosen in the tree, scanned once per name."""
        from ..xplane import aircraft as ac, catalog as xc
        inst = xc.find_install(profiles.load_settings().get("xplane_dir"))
        if not inst:
            return [], "", None
        cache = self.__dict__.setdefault("_ac_cache", {})
        if "list" not in cache:
            cache["list"] = ac.list_aircraft(inst)
        name = str(profiles.load_settings().get("xplane_aircraft") or "")
        self.auto_aircraft = not name
        if not name and getattr(self, "_detected", None):
            hit = ac.detect_folder(self._detected, cache["list"])
            name = hit["name"] if hit else ""
        found = next((a for a in cache["list"] if a["name"] == name), None)
        if found and name not in cache:
            cache[name] = ac.scan(found["path"])
        return cache["list"], name, cache.get(name)

    def _fill_aircraft(self, t):
        from ..xplane import aircraft as ac
        try:
            listing, name, result = self._aircraft_scan()
        except Exception as exc:                          # an unreadable folder must never break the editor
            self.panel.status.setText(tr("No pude leer los aviones: {error}", error=exc))
            return
        if not listing:
            return
        head = tr("Elegir avión de X-Plane") + ((tr(" (detectado: {name})", name=name) if self.auto_aircraft else tr(" (elegido: {name})", name=name)) if name else "")
        top = self._group_item(head)
        auto = QTreeWidgetItem(["      ⟳  " + tr("Detectar automáticamente")]); auto.setForeground(0, QColor(T.ACCENT))
        auto.setBackground(0, QColor(T.BG_DEEP)); auto.setSizeHint(0, QSize(0, 40))
        auto.setData(0, Qt.UserRole, {"kind": "aircraft", "name": ""}); auto.setToolTip(0, "Usa el avión que esté cargado en X-Plane")
        top.addChild(auto)
        for a in listing:
            if t and t not in a["name"].lower():
                continue
            child = QTreeWidgetItem(["      " + a["name"]]); child.setForeground(0, QColor(T.TEXT_MUTED))
            child.setBackground(0, QColor(T.BG_DEEP)); child.setSizeHint(0, QSize(0, 40))
            child.setData(0, Qt.UserRole, {"kind": "aircraft", "name": a["name"]})
            child.setToolTip(0, a["path"])
            f = child.font(0); f.setBold(a["name"] == name); child.setFont(0, f)
            top.addChild(child)
        self._finish_group(top, head, bool(t) and not result)
        if not result:
            return
        sections: dict[str, list] = {}
        for c in ac.search(result["controls"], t, 1500):
            sections.setdefault(c.section or tr("Controles"), []).append(c)
        for sec, items in sections.items():
            title = f"{name} · {sec}"
            grp = self._group_item(title)
            for c in items[:300]:
                child = QTreeWidgetItem(["      " + c.title]); child.setForeground(0, QColor(T.TEXT_MUTED))
                child.setBackground(0, QColor(T.BG_DEEP)); child.setSizeHint(0, QSize(0, 40))
                child.setData(0, Qt.UserRole, {"kind": "xplane_ctl", "title": c.title, "command": c.command, "state": c.state,
                                               "values": c.values, "confidence": c.confidence, "source": c.source})
                child.setToolTip(0, tr("Comando: {command}\nEstado: {state}", command=c.command or "—", state=c.state or "—")
                                 + (f"  ({c.values})" if c.values else "")
                                 + tr("\nConfianza de la pareja: {confidence} · fuente: {source}", confidence=f"{c.confidence:.0%}", source=c.source))
                f = child.font(0); f.setBold(False); child.setFont(0, f)
                from ..xplane import glyphs as _g
                child.setIcon(0, self._xp_icon(_g.pick_glyph(f"{c.command or c.state} {c.title}")))
                grp.addChild(child)
            self._finish_group(grp, title, False)

    def _preview_icon(self, glyph: str, category: str = "Herramientas") -> QIcon:
        """The key as it will look on the deck, small, for the action list (cached: there are few distinct ones)."""
        cache = self.__dict__.setdefault("_prev_icons", {})
        key = (glyph, category)
        if key not in cache:
            tile = actionicons.tile(glyph, category, 64)
            cache[key] = QIcon(icons.to_qpixmap(tile))
        return cache[key]

    def _xp_icon(self, glyph):
        cache = self.__dict__.setdefault("_xp_icons", {})
        if glyph not in cache:
            from ..xplane import glyphs
            cache[glyph] = QIcon(icons.to_qpixmap(glyphs.neutral_tile(glyph, size=64)))
        return cache[glyph]

    def _fill_xplane(self, t):
        """X-Plane's own commands (from its Commands.txt), by category, each with a glyph and a state hint."""
        xc, commands = self._xplane_data()
        if not commands:
            return
        from ..xplane import glyphs, states
        hits = xc.search(commands, t) if t else commands
        for cat, items in xc.by_category(hits).items():
            top = self._group_item("X-Plane · " + tr(cat))
            for c in items[:400]:
                glyph = glyphs.pick_glyph(c.name, c.description)
                child = QTreeWidgetItem(["      " + c.title]); child.setForeground(0, QColor(T.TEXT_MUTED))
                child.setBackground(0, QColor(T.BG_DEEP)); child.setSizeHint(0, QSize(0, 40))
                child.setData(0, Qt.UserRole, {"kind": "xplane", "name": c.name, "title": c.title, "description": c.description})
                child.setToolTip(0, c.name + ("\n" + c.description if c.description else "") +
                                 (tr("\nEstado: {state}", state=", ".join(n for n, _ in states.refs(states.suggest(c.name)))) if states.suggest(c.name) else ""))
                f = child.font(0); f.setBold(False); child.setFont(0, f)
                child.setIcon(0, self._xp_icon(glyph))
                top.addChild(child)
            self._finish_group(top, "X-Plane · " + tr(cat), bool(t) and len(hits) < 400)

    def _group_item(self, group):
        top = QTreeWidgetItem(["›   " + tr(group)]); top.setBackground(0, QColor(T.BG)); top.setSizeHint(0, QSize(0, 50))
        self.tree.addTopLevelItem(top)
        return top

    def _finish_group(self, top, group, expanded):
        top.setExpanded(expanded)
        top.setText(0, ("⌄   " if expanded else "›   ") + tr(group))

    def _toggle(self, item, _col):
        if not item.childCount():
            return
        item.setExpanded(not item.isExpanded())
        item.setText(0, ("⌄   " if item.isExpanded() else "›   ") + item.text(0)[4:])

    def _activate(self, item, _col):
        payload = item.data(0, Qt.UserRole)
        if not isinstance(payload, dict):
            return
        if payload.get("kind") == "shortcut":
            self.add_shortcut()
        elif payload.get("kind") == "aircraft":
            profiles.save_setting("xplane_aircraft", payload["name"])
            self._detected_shown = getattr(self, "_detected", None)
            self._fill_tree(self.search.text() if hasattr(self, "search") else "")
            self.panel.status.setText(tr("Avión: {name}", name=payload["name"]) if payload["name"] else tr("Avión: detección automática"))
        elif self.selected and self.selected[0] == "knob":
            self._knob_apply(payload)
        elif self.selected and self.selected[0] == "strip":
            self.assign_touch(self.selected[1], payload)
        else:
            index = self._need_key()
            if index is not None:
                self.assign(index, payload)
