"""Protocol layer for the Redragon "Ragnaros" SS-552 (USB 0200:3001).

Every constant here is tagged with where it comes from:

  [DLL]   observed in the decompilation of the vendor SDLibrary1.dll
          (sha256 4a4a4a06...16ebdfc), see NOTES.md for evidence IDs.
  [LIVE]  must be confirmed on the device; not provable statically.

Wire format [DLL]: the vendor builds a buffer of ``maxPacket + 1`` bytes and
passes it to ``hid_write``. Byte 0 is the HID report id (0). Bytes 1-3 are
``"CRT"``, bytes 4-5 are zero, and the command mnemonic starts at byte 6.
On this deck the interface has no report id, so hidapi strips byte 0 and the
interrupt OUT endpoint receives ``maxPacket`` bytes starting at ``"CRT"``.
"""
from __future__ import annotations

VID = 0x0200          # [LIVE] lsusb on the host
PID = 0x3001          # [LIVE] lsusb on the host
EP_OUT = 0x03         # [LIVE] lsusb -v: interrupt OUT, 1024 bytes
EP_IN = 0x82          # [LIVE] lsusb -v: interrupt IN, 512 bytes
PACKET_OUT = 1024     # [LIVE] wMaxPacketSize of EP 0x03
PACKET_IN = 512       # [LIVE] wMaxPacketSize of EP 0x82

CRT = b"CRT"

# Geometry, confirmed on the device by painting numbered images [LIVE]:
# Touch strip: ONE canvas, drawn with DRA rectangles. Confirmed on the deck [LIVE]:
#   width 800 (832 wrapped rows), height 128 (124 showed an uneven border), image rotated 180 as a
#   whole. The old 4 BAT slots of 208x124 were a workaround, not the device's model.
STRIP_W, STRIP_H = 800, 128
STRIP_SIZE = (STRIP_W, STRIP_H)
ZONE_W = 200                         # the four touch zones (codes 0x40-0x43), left to right
KEY_SLOTS = tuple(range(5, 15))     # ten LCD keys, 120x120 each
KEY_SIZE = (120, 120)
ROTATION = 180                      # images are sent rotated by 180 degrees
# Logical key (0-9, input code - 1) -> display slot. Confirmed live with the
# service: K0 top-left ... K4 top-right, K5 bottom-left ... K9 bottom-right [LIVE].
KEY_TO_SLOT = {i: (10 + i if i < 5 else i) for i in range(10)}   # top row -> slots 10-14, bottom row -> 5-9

# Input codes (byte 9), captured live with `streamstation listen` [LIVE].
# Which direction is clockwise and which physical knob is which still has
# to be confirmed by turning knobs with a profile loaded.
KNOB_ROTATE = {0xA0: (0, -1), 0xA1: (0, 1), 0x50: (1, -1), 0x51: (1, 1),
               0x90: (2, -1), 0x91: (2, 1), 0x70: (3, -1), 0x71: (3, 1)}
KNOB_PRESS = {0x37: 0, 0x35: 1, 0x33: 2, 0x36: 3}
# Swipes along the strip. Two guided captures of 6 and 8 swipes (14-nov... 16-nov) gave 0x38 for EVERY left-to-right swipe and
# 0x39 for EVERY right-to-left one [LIVE]: +1 = the finger moved to the right, -1 = to the left. (Earlier, less careful captures
# had suggested the code did not depend on the direction.)
STRIP_SWIPE = {0x38: 1, 0x39: -1}
# Strip touches: codes 0x40-0x43 seen live, always with state 0 (no release
# event), arriving in order 0x40..0x43 along a swipe [LIVE]. Mapping to
# segments 0-3 left to right CONFIRMED live (16-nov): 12 taps, 3 rounds left to right, each ran its zone's action.
STRIP_TOUCH = {0x40: 0, 0x41: 1, 0x42: 2, 0x43: 3}


def decode_event(code: int, state: int):
    """Turn a raw (code, state) into a logical event tuple."""
    if 1 <= code <= 10:
        return ("key", code - 1, state != 0)
    if code in KNOB_ROTATE:
        knob, direction = KNOB_ROTATE[code]
        return ("knob", knob, direction)
    if code in KNOB_PRESS:
        return ("knob_press", KNOB_PRESS[code], bool(state))
    if code in STRIP_SWIPE:
        return ("strip_swipe", STRIP_SWIPE[code], None)
    if code in STRIP_TOUCH:
        return ("strip_touch", STRIP_TOUCH[code], None)
    return ("unknown", code, state)


def _packet(*tail: int | bytes) -> bytes:
    """CRT 00 00 <tail...>, zero padded to PACKET_OUT (report id stripped)."""
    body = bytearray(CRT + b"\x00\x00")
    for part in tail:
        body += bytes([part]) if isinstance(part, int) else part
    if len(body) > PACKET_OUT:
        raise ValueError("command longer than one packet")
    return bytes(body).ljust(PACKET_OUT, b"\x00")


# --- commands -------------------------------------------------------------

def connect() -> bytes:
    """Heartbeat / keep-alive. [DLL] addHeartbeatPack: bytes 5.. = "CONNECT"."""
    return _packet(b"CONNECT")


def wake() -> bytes:
    """Wake screen. [DLL] addWakeUpScreenPack: "DIS"."""
    return _packet(b"DIS")


def brightness(percent: int) -> bytes:
    """[DLL] addAdjustBrightnessPack: "LIG", value clamped >=0, at byte 10."""
    return _packet(b"LIG", 0, 0, max(0, min(100, percent)))


def clear(index: int) -> bytes:
    """[DLL] addClearCommand: "CLE", display index at byte 11 (0xFF = all)."""
    return _packet(b"CLE", 0, 0, 0, index & 0xFF)


def stop() -> bytes:
    """Commit / refresh display. [DLL] addFinishCommand: "STP"."""
    return _packet(b"STP")


def sleep() -> bytes:
    """[DLL] addHandshakePack / HAN: sent to put the screen to sleep."""
    return _packet(b"HAN")


def image_header(slot: int, size: int) -> bytes:
    """Start an image upload. [DLL] sendPicSizeCommand: "BAT" at byte 6,
    16-bit big-endian size at bytes 11-12, target slot at byte 13
    (report-id layout), i.e. CRT 00 00 BAT 00 00 <hi> <lo> <slot>."""
    if not 0 <= size <= 0xFFFF:
        raise ValueError("image too large for the 16-bit BAT length")
    return _packet(b"BAT", 0, 0, size >> 8, size & 0xFF, slot & 0xFF)


DRAW_HEADER_LEN = 32


def draw_stream(jpeg: bytes, x: int, y: int, w: int, h: int, index: int = 0) -> bytes:
    """Draw ONE image into a rectangle of the secondary screen (the touch strip as a single canvas).

    [DLL] getSecondaryScreenPicInfo (ev_13cc76df...) builds the header and writeDataToHidDevice
    (ev_0ead7a4f...) PREPENDS it to the image data for data types 16/18/19, then sends the whole
    stream in report-sized chunks. Header, no report id:
        0-2  "CRT"      5-7  "DRA"
        8-11 u32 big-endian = len(image) + 0x20
        12   image index
        13-14 width   15-16 height   17-18 x   19-20 y   (u16 big-endian)
    The 32-byte header length is inferred from that +0x20 and has to be confirmed on the device [LIVE].
    """
    import struct
    if not (len(jpeg) and 0 <= x <= 0xFFFF and 0 <= y <= 0xFFFF and 0 < w <= 0xFFFF and 0 < h <= 0xFFFF):
        raise ValueError("invalid rectangle or empty image")
    hdr = bytearray(DRAW_HEADER_LEN)
    hdr[0:3], hdr[5:8] = CRT, b"DRA"
    struct.pack_into(">I", hdr, 8, len(jpeg) + DRAW_HEADER_LEN)
    hdr[12] = index & 0xFF
    struct.pack_into(">HHHH", hdr, 13, w, h, x, y)
    return bytes(hdr) + jpeg


def change_direction(a: int, b: int) -> bytes:
    """[DLL] sendChangeDirectionCommand: "SET" at byte 6, args at bytes 11-12.
    Effect on the deck is [LIVE] unverified."""
    return _packet(b"SET", 0, 0, a & 0xFF, b & 0xFF)


def image_chunks(jpeg: bytes) -> list[bytes]:
    """The JPEG payload follows the BAT header in PACKET_OUT sized writes."""
    return [jpeg[i:i + PACKET_OUT].ljust(PACKET_OUT, b"\x00")
            for i in range(0, len(jpeg), PACKET_OUT)]


# --- input reports --------------------------------------------------------

def parse_report(data: bytes):
    """Decode an input report.

    [DLL] readDataFromHidDevice: valid frames start with "ACK", have "OK" at
    byte 5-6 and byte 9 == 0 for a plain acknowledge. Otherwise byte 9 is the
    event code and byte 10 the state (passed to sigHandleKeyEvents).
    Returns None for non-frames, ("ack",) for acknowledges, or
    ("event", code, state).
    """
    if len(data) < 11 or data[:3] != b"ACK" or data[5:7] != b"OK":
        return None
    code, state = data[9], data[10]
    if code == 0:
        return ("ack",)
    return ("event", code, state)
