"""Design tokens measured from the original app's own screenshots (Guidance/*.gif, 1200x800)
and cross-checked against the stylesheet strings inside its exe. See UI_STYLE.md."""

# colours (measured with pixel sampling; hex in comments = value in the exe QSS where it exists).
# Two palettes: "dark" is the original look; "light" is white with black text. `apply(name)` swaps the module's colour
# names, so code that reads T.BG, T.TEXT... at paint time follows the theme.
PALETTES = {
    "dark": dict(
        BG="#2d2d2d",            # window, scene list, board, config area
        BG_DEEP="#232323",       # plugin sidebar, empty key fill, dividers
        BG_STRIP="#141414",      # touch-strip screen
        BG_FIELD="#3b3b3b",      # search box
        BG_HOVER="#3c3c3c",      # button hover
        OUTLINE="#474747",       # key/strip/knob borders, menus
        CHIP="#c8c8c8",          # selected page chip
        CHIP_TEXT="#333333",
        TEXT="#ffffff",
        TEXT_SOFT="#e5e5e5",     # category rows
        TEXT_MUTED="#969696",    # sub-items, '+' button
        ACCENT="#0078ff",        # active tab underline, selection, focus
        ACCENT_DARK="#1c6691",   # pressed border
        PRESSED="#1f77b4",
    ),
    "light": dict(
        BG="#ffffff", BG_DEEP="#f0f0f0", BG_STRIP="#141414", BG_FIELD="#ececec", BG_HOVER="#e2e2e2",
        OUTLINE="#c4c4c4", CHIP="#3a3a3a", CHIP_TEXT="#ffffff", TEXT="#000000", TEXT_SOFT="#1a1a1a",
        TEXT_MUTED="#666666", ACCENT="#0078ff", ACCENT_DARK="#005bbf", PRESSED="#8bbcff",
    ),
}
THEMES = ("light", "dark", "system")           # what the user can choose
current = "dark"                               # the palette in use ("light" | "dark")


def apply(name: str) -> str:
    """Use the "light" or "dark" palette from now on. Returns the one in use."""
    global current
    current = name if name in PALETTES else "dark"
    globals().update(PALETTES[current])
    return current


def portal_scheme(run=None) -> str | None:
    """The desktop's colour scheme read from the XDG portal (works for KDE and GNOME, even while this window is
    forced to light or dark): "dark", "light", or None when the desktop expresses no preference or has no portal."""
    import re
    import subprocess
    run = run or subprocess.run
    try:
        out = run(["busctl", "--user", "call", "org.freedesktop.portal.Desktop", "/org/freedesktop/portal/desktop",
                   "org.freedesktop.portal.Settings", "Read", "ss", "org.freedesktop.appearance", "color-scheme"],
                  capture_output=True, text=True, timeout=1.5).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    m = re.search(r"\bu\s+(\d)", out or "")
    return {"1": "dark", "2": "light"}.get(m.group(1)) if m else None


def system_scheme() -> str:
    """"dark" or "light" according to the desktop's colour scheme (the portal first, then Qt, then the window palette)."""
    portal = portal_scheme()
    if portal:
        return portal
    try:
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QGuiApplication
        app = QGuiApplication.instance()
        if app is not None:
            scheme = app.styleHints().colorScheme()
            if scheme == Qt.ColorScheme.Dark:
                return "dark"
            if scheme == Qt.ColorScheme.Light:
                return "light"
            return "dark" if app.palette().window().color().lightness() < 128 else "light"
    except Exception:
        pass
    return "dark"


def resolve(setting: str) -> str:
    """The palette a theme setting means right now: "system" follows the desktop."""
    return system_scheme() if setting == "system" else ("light" if setting == "light" else "dark")


apply("dark")

# shapes (px)
KEY = 64
KEY_RADIUS = 12
KEY_BORDER = 3
KEY_PITCH = (87, 80)      # horizontal / vertical distance between key origins
STRIP = (420, 68)
STRIP_RADIUS = 10
KNOB = 64
RADIUS_CONTROL = 6        # search box, buttons, chips (exe uses 3-12 px; 5 px most common)
LEFT_W, RIGHT_W = 202, 262
WINDOW = (1200, 800)
ROW_H = 36

def qss() -> str:
    """The application stylesheet for the palette in use."""
    g = globals()
    BG, BG_DEEP, BG_FIELD, BG_HOVER, OUTLINE, CHIP, CHIP_TEXT = (g[k] for k in ("BG", "BG_DEEP", "BG_FIELD", "BG_HOVER", "OUTLINE", "CHIP", "CHIP_TEXT"))
    TEXT, TEXT_SOFT, TEXT_MUTED, ACCENT, ACCENT_DARK, PRESSED = (g[k] for k in ("TEXT", "TEXT_SOFT", "TEXT_MUTED", "ACCENT", "ACCENT_DARK", "PRESSED"))
    return f"""
* {{ color: {TEXT}; font-size: 13px; }}
QWidget#root, QWidget#board, QWidget#left, QWidget#config {{ background: {BG}; }}
QWidget#right {{ background: {BG_DEEP}; }}
QLabel {{ background: transparent; }}
QWidget#sep {{ background: {BG_DEEP}; }}
QLabel#muted {{ color: {TEXT_MUTED}; }}
QLabel#heading {{ font-size: 15px; font-weight: bold; }}
QListWidget {{ background: {BG}; border: none; outline: none; }}
QListWidget::item {{ height: {ROW_H}px; padding-left: 6px; }}
QListWidget::item:selected {{ background: {BG_HOVER}; color: {TEXT}; }}
QListWidget::item:hover {{ background: {BG_HOVER}; }}
QPushButton {{ background: transparent; border: 1px solid {OUTLINE}; border-radius: {RADIUS_CONTROL}px; padding: 2px 8px; }}
QPushButton:hover {{ background: {BG_HOVER}; }}
QPushButton:pressed {{ background: {PRESSED}; border: 2px solid {ACCENT_DARK}; }}
QPushButton#tab {{ border: none; border-radius: 12px; background: {BG_FIELD}; color: {TEXT_MUTED}; padding: 4px 0; }}
QPushButton#tab:checked {{ color: {TEXT}; border-bottom: 3px solid {ACCENT}; border-radius: 12px; }}
QPushButton#chip {{ background: {CHIP}; color: {CHIP_TEXT}; border: none; min-width: 26px; max-width: 26px; min-height: 26px; max-height: 26px; padding: 0; }}
QPushButton#pagebtn {{ color: {TEXT_MUTED}; border: 1px solid {OUTLINE}; border-radius: {RADIUS_CONTROL}px; min-width: 26px; max-width: 26px; min-height: 26px; max-height: 26px; padding: 0; }}
QPushButton#plus {{ color: {TEXT_MUTED}; border: 2px solid {TEXT_MUTED}; border-radius: 8px; min-width: 28px; max-width: 28px; min-height: 28px; max-height: 28px; padding: 0; font-size: 18px; }}
QPushButton#tool {{ min-width: 26px; max-width: 26px; min-height: 26px; max-height: 26px; padding: 0; }}
QLineEdit {{ background: {BG_FIELD}; border: none; border-radius: {RADIUS_CONTROL}px; padding: 4px 8px; selection-background-color: {ACCENT}; }}
QTreeWidget {{ background: {BG_DEEP}; border: none; outline: none; show-decoration-selected: 1; }}
QTreeWidget::item {{ color: {TEXT_SOFT}; font-weight: bold; border-bottom: 1px solid {BG_DEEP}; }}
QTreeWidget::item:selected {{ background: {BG_HOVER}; }}
QTreeWidget::item:hover {{ background: {BG_HOVER}; }}
QComboBox, QSpinBox, QPlainTextEdit {{ background: {BG_FIELD}; border: none; border-radius: {RADIUS_CONTROL}px; padding: 4px 8px; selection-background-color: {ACCENT}; }}
QComboBox {{ min-height: 22px; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {OUTLINE}; color: {TEXT}; border: none; selection-background-color: {ACCENT}; outline: none; }}
QSpinBox::up-button, QSpinBox::down-button {{ width: 0; }}
QToolButton {{ background: transparent; border: 1px solid {OUTLINE}; border-radius: 10px; padding: 6px; }}
QToolButton:hover {{ background: {BG_HOVER}; }}
QToolButton:checked {{ border: 2px solid {ACCENT}; background: {BG_HOVER}; }}
QRadioButton {{ spacing: 8px; }}
QRadioButton::indicator {{ width: 16px; height: 16px; border: 2px solid {TEXT_MUTED}; border-radius: 9px; background: transparent; }}
QRadioButton::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border: 2px solid {TEXT_MUTED}; border-radius: 4px; background: transparent; }}
QCheckBox::indicator:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
QDialog {{ background: {BG}; }}
QMenu {{ background: {OUTLINE}; padding: 4px; }}
QMenu::item {{ padding: 6px; }}
QMenu::item:selected {{ background: {ACCENT}; }}
QScrollBar:vertical {{ background: transparent; width: 6px; }}
QScrollBar::handle:vertical {{ background: {OUTLINE}; border-radius: 3px; min-height: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
"""
