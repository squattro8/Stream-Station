import os, sys, pathlib, socket, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from streamstation import plugins as PL


class FakeUI:
    def __init__(self): self.events = []
    def write(self, t, c, v): self.events.append((c, v))
    def syn(self): self.events.append("SYN")


def runner(outputs=None):
    calls, spawned, ui = [], [], FakeUI()

    def sys_run(argv, timeout=3):
        calls.append(argv)
        return (outputs or {}).get(argv[1] if argv[0] == "busctl" else "", "")
    p = PL.Plugins(sys_run=sys_run, sys_spawn=lambda a: spawned.append(a) or None,
                   uinput_factory=lambda: ui)
    return p, calls, spawned, ui


def test_parse_combo():
    assert PL.parse_combo("ctrl+shift+t") == ["KEY_LEFTCTRL", "KEY_LEFTSHIFT", "KEY_T"]
    assert PL.parse_combo("alt+left") == ["KEY_LEFTALT", "KEY_LEFT"]
    assert PL.parse_combo("meta+period") == ["KEY_LEFTMETA", "KEY_DOT"]
    assert PL.parse_combo("f5") == ["KEY_F5"]
    try: PL.parse_combo("hyper+x")
    except ValueError: return
    raise AssertionError


def test_key_press_and_release_order():
    from evdev import ecodes as E
    p, _, _, ui = runner()
    p.run("key:ctrl+c")
    assert ui.events == [(E.KEY_LEFTCTRL, 1), (E.KEY_C, 1), "SYN", (E.KEY_C, 0), (E.KEY_LEFTCTRL, 0), "SYN"]


def test_browser_and_desktop_aliases_are_hotkeys():
    from evdev import ecodes as E
    p, _, _, ui = runner()
    p.run("browser:back")
    assert ui.events[0] == (E.KEY_LEFTALT, 1) and ui.events[1] == (E.KEY_LEFT, 1)
    assert ui.events[0] == (E.KEY_LEFTALT, 1)


def test_text_typing_uses_shift_for_capitals_and_symbols():
    from evdev import ecodes as E
    p, _, _, ui = runner()
    p.run("text:Hi!")
    downs = [e for e in ui.events if e != "SYN" and e[1] == 1]
    assert downs == [(E.KEY_LEFTSHIFT, 1), (E.KEY_H, 1), (E.KEY_I, 1), (E.KEY_LEFTSHIFT, 1), (E.KEY_1, 1)]
    try: p.run("text:ñ")
    except ValueError: return
    raise AssertionError("non-ASCII must be refused, not mistyped")


def test_volume_and_mic():
    p, calls, _, _ = runner()
    p.run("volume:up:10"); p.run("volume:down"); p.run("volume:mute"); p.run("volume:set:40"); p.run("mic:mute")
    assert calls == [
        ["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", "10%+"],
        ["wpctl", "set-volume", "@DEFAULT_AUDIO_SINK@", "5%-"],
        ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"],
        ["wpctl", "set-volume", "-l", "1.0", "@DEFAULT_AUDIO_SINK@", "40%"],
        ["wpctl", "set-mute", "@DEFAULT_AUDIO_SINK@", "toggle"][:1] + ["set-mute", "@DEFAULT_AUDIO_SOURCE@", "toggle"],
    ]


def test_media_prefers_playing_player():
    listing = ("org.mpris.MediaPlayer2.vlc 1 x\norg.mpris.MediaPlayer2.firefox.instance1 2 y\n")
    seen = {}
    def sys_run(argv, timeout=3):
        seen.setdefault("calls", []).append(argv)
        if argv[2] == "list": return listing
        if argv[2] == "get-property": return 's "Playing"' if "firefox" in argv[3] else 's "Paused"'
        return ""
    p = PL.Plugins(sys_run=sys_run, sys_spawn=lambda a: None, uinput_factory=FakeUI)
    assert p.run("media:play-pause") is True
    last = seen["calls"][-1]
    assert last[2] == "call" and "firefox" in last[3] and last[-1] == "PlayPause"


def test_media_without_player_returns_false():
    p, _, _, _ = runner()
    assert p.run("media:next") is False


def test_open_url_and_tools():
    p, _, spawned, _ = runner()
    p.run("url:https://example.org")
    p.run("open:org.kde.dolphin")
    assert spawned[0] == ["xdg-open", "https://example.org"]
    assert spawned[1] == ["gtk-launch", "org.kde.dolphin"]


def test_udp_sends_datagram():
    srv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); srv.bind(("127.0.0.1", 0)); srv.settimeout(2)
    port = srv.getsockname()[1]
    p, _, _, _ = runner()
    p.run(f"udp:127.0.0.1:{port}:BAT1:1")        # message may itself contain ':'
    assert srv.recv(100) == b"BAT1:1"
    srv.close()


def test_unknown_and_handles():
    p, _, _, _ = runner()
    assert p.handles("key:a") and p.handles("browser:back") and not p.handles("echo hi")
    try: p.run("volume:sideways")
    except ValueError: return
    raise AssertionError


def test_kde_actions_use_dbus_not_keys():
    p, calls, _, ui = runner()
    p.run("desktop:show"); p.run("desktop:dnd"); p.run("tool:taskmanager")
    assert ui.events == []                                   # no key injection involved
    assert calls[0] == ["busctl", "--user", "call", "org.kde.kglobalaccel", "/component/kwin",
                        "org.kde.kglobalaccel.Component", "invokeShortcut", "s", "Show Desktop"]
    assert calls[1][-1] == "toggle do not disturb" and "/component/plasmashell" in calls[1]
    assert "/component/org_kde_plasma_systemmonitor_desktop" in calls[2]


def test_notifications_open_is_refused_not_faked():
    p, calls, _, ui = runner()
    try: p.run("desktop:notifications")
    except ValueError as e: assert "desktop:dnd" in str(e)
    else: raise AssertionError
    assert calls == [] and ui.events == []


def test_player_volume_up_down_clamps_and_targets_the_playing_player():
    sets = []
    def sys_run(argv, timeout=3):
        if argv[2] == "list": return "org.mpris.MediaPlayer2.vlc 1 x\norg.mpris.MediaPlayer2.mpv 2 y\n"
        if argv[2] == "get-property" and argv[-1] == "PlaybackStatus": return 's "Playing"' if "mpv" in argv[3] else 's "Paused"'
        if argv[2] == "get-property" and argv[-1] == "Volume": return "d 0.97"
        if argv[2] == "set-property": sets.append(argv)
        return ""
    p = PL.Plugins(sys_run=sys_run, sys_spawn=lambda a: None, uinput_factory=FakeUI)
    assert p.run("media:volume-up:5") is True
    assert "mpv" in sets[-1][3] and sets[-1][-3:] == ["Volume", "d", "1.000"]            # 0.97 + 0.05 clamped to 1.0
    p.run("media:volume-down")                                                          # default step 5
    assert sets[-1][-1] == "0.920"
    try: p.run("media:volume-sideways")
    except ValueError: pass
    else: raise AssertionError


def test_service_keys_open_the_installed_app_or_else_the_website():
    import tempfile
    from streamstation import services
    ids = [s.id for s in services.SERVICES]
    assert len(ids) == len(set(ids)) >= 10 and {"youtube", "youtube-music", "spotify"} <= set(ids)
    assert all(s.url.startswith("https://") and s.name for s in services.SERVICES)
    with tempfile.TemporaryDirectory() as tmp:
        assert services.command_for("youtube", [tmp]) == ["xdg-open", "https://www.youtube.com"]
        assert services.command_for("spotify", [tmp]) == ["xdg-open", "https://open.spotify.com"]        # not installed: website
        open(os.path.join(tmp, "com.spotify.Client.desktop"), "w").write("[Desktop Entry]\n")
        assert services.command_for("spotify", [tmp]) == ["gtk-launch", "com.spotify.Client"]            # installed: the app
        assert services.installed_app(services.BY_ID["youtube"], [tmp]) is None                           # web-only services never launch an app
    try:
        services.command_for("nope")
    except ValueError:
        pass
    else:
        raise AssertionError("an unknown service must be refused")
    spawned = []
    p = PL.Plugins(sys_run=lambda *a, **k: None, sys_spawn=spawned.append)
    assert p.handles("service:youtube") and p.run("service:youtube-music")
    assert spawned[-1] == ["xdg-open", "https://music.youtube.com"]                  # a web-only service always opens the site
    try:
        p.run("service:nope")
    except ValueError:
        pass
    else:
        raise AssertionError("the service must refuse an unknown service instead of guessing")
