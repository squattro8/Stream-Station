"""Editor for one touch-strip segment: what it shows and what happens when it is touched."""
from __future__ import annotations

from ..i18n import tr

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QFont, QColor, QPixmap
from PySide6.QtWidgets import (QButtonGroup, QCheckBox, QColorDialog, QComboBox, QHBoxLayout, QLabel, QLineEdit,
                               QPlainTextEdit, QPushButton, QSpinBox, QStackedWidget, QVBoxLayout, QWidget)

from .. import fonts, strip as stripmod

TYPES = [("Vacío", "empty"), ("Métrica", "metric"), ("Clima", "weather"), ("Texto", "text"), ("Imagen", "image"), ("GIF animado", "gif")]
METRICS = [("Hora", "clock"), ("Fecha", "date"), ("CPU", "cpu"), ("Memoria RAM", "ram"),
           ("Temperatura", "temp"), ("Volumen", "volume"), ("Disco", "disk")]
FITS = [("Cubrir (recorta lo que sobra)", "cover"), ("Contener (con barras)", "contain"), ("Estirar", "stretch")]
DEFAULT_COLOR, DEFAULT_BG = "#ffffff", "#141414"


class ColorButton(QPushButton):
    colorChanged = Signal(str)

    def __init__(self, color: str):
        super().__init__()
        self.setFixedSize(36, 26)
        self.set_color(color, emit=False)
        self.clicked.connect(self._pick)

    def set_color(self, color: str, emit=True):
        self.color = color
        self.setStyleSheet(f"background:{color}; border:1px solid #474747; border-radius:5px;")
        if emit:
            self.colorChanged.emit(color)

    def _pick(self):
        c = QColorDialog.getColor(QColor(self.color), self, "Elegir color")
        if c.isValid():
            self.set_color(c.name())


class StripPanel(QWidget):
    segment_changed = Signal(object)     # spec dict, or None for an empty panel
    full_changed = Signal(object)        # spec dict (image/gif across the 4 panels), or None
    touch_changed = Signal(object)       # action string, or None
    page_swipe_changed = Signal(bool)    # "change page by swiping the strip" ticked / unticked
    mode_changed = Signal(str)           # "fixed" | "per_page"
    place_search_requested = Signal(str) # text typed in the weather page: the window looks it up
    pick_requested = Signal(str)         # "image" | "gif": the window opens the file dialog
    apply_clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("config")
        self._index = 0
        self._loading = False
        lay = QHBoxLayout(self); lay.setContentsMargins(40, 20, 40, 20); lay.setSpacing(24)
        left = QVBoxLayout(); lay.addLayout(left)
        self.preview = QLabel(); self.preview.setFixedSize(208, 124); self.preview.setStyleSheet("background:#141414; border-radius:8px;")
        left.addWidget(self.preview); left.addStretch()
        col = QVBoxLayout(); col.setSpacing(8); lay.addLayout(col, 1)
        self.title = QLabel(tr("Segmento")); self.title.setObjectName("heading"); col.addWidget(self.title)
        mrow = QHBoxLayout(); mrow.addWidget(QLabel(tr("Franja")))
        self.mode_fixed = QCheckBox(tr("La misma en todas las páginas"))
        self.mode_page = QCheckBox(tr("Una distinta por cada página"))
        self.mode_fixed.setToolTip(tr("Se ve igual al cambiar de página."))
        self.mode_page.setToolTip(tr("Cada página guarda su propia franja."))
        self.mode_group = QButtonGroup(self); self.mode_group.setExclusive(True)       # exactly one is always ticked
        for box in (self.mode_fixed, self.mode_page):
            self.mode_group.addButton(box); mrow.addWidget(box)
        mrow.addStretch(); col.addLayout(mrow)
        self.swipe_box = QCheckBox(tr("Cambiar de páginas con deslizamiento en franja"))
        self.swipe_box.setToolTip(tr("Desliza el dedo por la franja de derecha a izquierda para pasar a la página siguiente, y de izquierda a derecha para volver a la anterior. Desde los extremos da la vuelta."))
        col.addWidget(self.swipe_box)
        self.swipe_box.clicked.connect(lambda on: None if self._loading else self.page_swipe_changed.emit(bool(on)))
        row = QHBoxLayout(); row.addWidget(QLabel(tr("Muestra"))); self.type = QComboBox()
        for label, key in TYPES:
            self.type.addItem(tr(label), key)
        row.addWidget(self.type, 1); col.addLayout(row)
        self.stack = QStackedWidget(); col.addWidget(self.stack)
        self.stack.addWidget(self._page_empty()); self.stack.addWidget(self._page_metric())
        self.stack.addWidget(self._page_text()); self.stack.addWidget(self._page_media()); self.stack.addWidget(self._page_weather())
        self.touch = QLineEdit(); self.touch.setPlaceholderText(tr("Acción al tocar (o arrastra una acción sobre el segmento)"))
        col.addWidget(self.touch)
        bottom = QHBoxLayout(); self.apply_btn = QPushButton(tr("Guardar y aplicar"))
        self.status = QLabel(""); self.status.setObjectName("muted")
        bottom.addWidget(self.apply_btn); bottom.addWidget(self.status, 1); col.addLayout(bottom); col.addStretch()
        self.mode_fixed.clicked.connect(lambda: None if self._loading else self.mode_changed.emit("fixed"))
        self.mode_page.clicked.connect(lambda: None if self._loading else self.mode_changed.emit("per_page"))
        self.type.currentIndexChanged.connect(self._type_changed)
        self.metric_box.currentIndexChanged.connect(self._emit)
        self.metric_font.currentIndexChanged.connect(self._emit); self.text_font.currentIndexChanged.connect(self._emit)
        self.text.textChanged.connect(self._emit); self.size_spin.valueChanged.connect(self._emit)
        self.color.colorChanged.connect(self._emit); self.bg.colorChanged.connect(self._emit)
        self.path.textEdited.connect(self._emit); self.fit.currentIndexChanged.connect(self._emit)
        self.span.toggled.connect(self._emit)
        self.choose.clicked.connect(lambda: self.pick_requested.emit(self.type.currentData()))
        self.touch.textEdited.connect(lambda t: None if self._loading else self.touch_changed.emit(t.strip() or None))
        self.apply_btn.clicked.connect(self.apply_clicked)

    # --- pages ------------------------------------------------------------------------------
    def _page_empty(self):
        w = QLabel(tr("El segmento queda apagado.")); w.setObjectName("muted"); return w

    def _font_combo(self) -> QComboBox:
        """"Predeterminada" plus every installed font that really draws letters; each name is shown in its own typeface."""
        box = QComboBox(); box.addItem(tr("Predeterminada"), "")
        for f in fonts.usable():
            box.addItem(f["family"], f["family"])
            box.setItemData(box.count() - 1, QFont(f["family"]), Qt.FontRole)
        box.setMaxVisibleItems(14)
        return box

    def _set_font(self, box: QComboBox, family: str | None):
        family = family or ""
        i = box.findData(family)
        if i < 0:                                            # a font the profile uses that is not installed here
            box.addItem(tr("{family} (no instalada)", family=family), family); i = box.count() - 1
        box.setCurrentIndex(i)

    def _page_metric(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0)
        r = QHBoxLayout(); r.addWidget(QLabel(tr("Dato"))); self.metric_box = QComboBox()
        for label, key in METRICS:
            self.metric_box.addItem(tr(label), key)
        r.addWidget(self.metric_box, 1); l.addLayout(r)
        r2 = QHBoxLayout(); r2.addWidget(QLabel(tr("Fuente"))); self.metric_font = self._font_combo(); r2.addWidget(self.metric_font, 1)
        l.addLayout(r2); return w

    def _page_weather(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0)
        self._place: dict | None = None
        r = QHBoxLayout(); r.addWidget(QLabel(tr("Ciudad")))
        self.place_query = QLineEdit(); self.place_query.setPlaceholderText(tr("Escribe una ciudad (p. ej. Rosario) y pulsa Buscar"))
        self.place_search = QPushButton(tr("Buscar")); r.addWidget(self.place_query, 1); r.addWidget(self.place_search); l.addLayout(r)
        self.place_results = QComboBox(); self.place_results.hide(); l.addWidget(self.place_results)
        self.place_current = QLabel(tr("Ninguna ciudad elegida")); self.place_current.setObjectName("muted"); self.place_current.setWordWrap(True)
        l.addWidget(self.place_current)
        r2 = QHBoxLayout(); r2.addWidget(QLabel(tr("Unidad")))
        self.unit_c = QCheckBox("°C"); self.unit_f = QCheckBox("°F")
        self.unit_group = QButtonGroup(self); self.unit_group.setExclusive(True)
        for box in (self.unit_c, self.unit_f):
            self.unit_group.addButton(box); r2.addWidget(box)
        self.unit_c.setChecked(True); r2.addStretch(); l.addLayout(r2)
        r3 = QHBoxLayout(); r3.addWidget(QLabel(tr("Fuente"))); self.weather_font = self._font_combo(); r3.addWidget(self.weather_font, 1)
        l.addLayout(r3)
        self.place_search.clicked.connect(lambda: self.place_search_requested.emit(self.place_query.text()))
        self.place_query.returnPressed.connect(lambda: self.place_search_requested.emit(self.place_query.text()))
        self.place_results.activated.connect(self._place_picked)
        self.unit_c.toggled.connect(self._emit); self.unit_f.toggled.connect(self._emit)
        self.weather_font.currentIndexChanged.connect(self._emit)
        return w

    def show_places(self, places):
        """The cities the window found for what was typed; the user picks one."""
        self.place_results.clear()
        for p in places:
            self.place_results.addItem(p.label, p.as_spec())
        self.place_results.setVisible(bool(places))
        if places:
            self.place_results.showPopup() if self.isVisible() else None

    def _place_picked(self, _i=0):
        spec = self.place_results.currentData()
        if spec:
            self._place = dict(spec)
            self.place_current.setText(tr("Ciudad: {name}", name=self._place.get("label", self._place["name"])))
            self._emit()

    def _page_text(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0)
        self.text = QPlainTextEdit(); self.text.setFixedHeight(54); self.text.setPlaceholderText(tr("Texto a mostrar"))
        l.addWidget(self.text)
        r = QHBoxLayout(); r.addWidget(QLabel(tr("Tamaño"))); self.size_spin = QSpinBox(); self.size_spin.setRange(0, 80)
        self.size_spin.setSpecialValueText("auto"); r.addWidget(self.size_spin)
        r.addWidget(QLabel(tr("Texto"))); self.color = ColorButton(DEFAULT_COLOR); r.addWidget(self.color)
        r.addWidget(QLabel(tr("Fondo"))); self.bg = ColorButton(DEFAULT_BG); r.addWidget(self.bg); r.addStretch()
        l.addLayout(r)
        r2 = QHBoxLayout(); r2.addWidget(QLabel(tr("Fuente"))); self.text_font = self._font_combo(); r2.addWidget(self.text_font, 1)
        l.addLayout(r2); return w

    def _page_media(self):
        w = QWidget(); l = QVBoxLayout(w); l.setContentsMargins(0, 0, 0, 0)
        r = QHBoxLayout(); self.path = QLineEdit(); self.path.setPlaceholderText(tr("Ruta del archivo"))
        self.choose = QPushButton(tr("Elegir archivo…")); r.addWidget(self.path, 1); r.addWidget(self.choose); l.addLayout(r)
        r2 = QHBoxLayout(); r2.addWidget(QLabel(tr("Ajuste"))); self.fit = QComboBox()
        for label, key in FITS:
            self.fit.addItem(tr(label), key)
        r2.addWidget(self.fit, 1); l.addLayout(r2)
        self.span = QCheckBox(tr("Usar en toda la franja (ocupa los 4 segmentos)")); l.addWidget(self.span)
        return w

    # --- state ------------------------------------------------------------------------------
    def show_segment(self, index: int, spec: dict | None, full: dict | None, touch, mode: str = "fixed", page: int = 0, page_swipe: bool = False):
        self._loading = True
        self.swipe_box.setChecked(page_swipe)
        self._index = index
        self.mode_page.setChecked(mode == "per_page"); self.mode_fixed.setChecked(mode != "per_page")
        self.title.setText(tr("Segmento {n} de la franja", n=index + 1) + (tr(" · página {page}", page=page + 1) if mode == "per_page" else ""))
        spec = full if full else (spec or {})
        kind = spec.get("type") or "empty"
        self.type.setCurrentIndex(max(0, self.type.findData(kind)))
        self.stack.setCurrentIndex({"empty": 0, "metric": 1, "text": 2, "image": 3, "gif": 3, "weather": 4}.get(kind, 0))
        self.metric_box.setCurrentIndex(max(0, self.metric_box.findData(spec.get("kind", "clock"))))
        self.text.setPlainText(str(spec.get("text") or ""))
        self.size_spin.setValue(int(spec.get("size") or 0))
        self._set_font(self.text_font, spec.get("font")); self._set_font(self.metric_font, spec.get("font"))
        self._set_font(self.weather_font, spec.get("font"))
        self._place = dict(spec["place"]) if kind == "weather" and isinstance(spec.get("place"), dict) else None
        self.place_current.setText(tr("Ciudad: {name}", name=self._place.get("label") or self._place.get("name", "")) if self._place else tr("Ninguna ciudad elegida"))
        self.place_results.clear(); self.place_results.hide(); self.place_query.clear()
        self.unit_f.setChecked(spec.get("units") == "f"); self.unit_c.setChecked(spec.get("units") != "f")
        self.color.set_color(spec.get("color") or DEFAULT_COLOR, emit=False)
        self.bg.set_color(spec.get("bg") or DEFAULT_BG, emit=False)
        self.path.setText(str(spec.get("path") or ""))
        self.fit.setCurrentIndex(max(0, self.fit.findData(spec.get("fit") or "cover")))
        self.span.setChecked(bool(full))
        self.touch.setText(touch if isinstance(touch, str) else "")
        self.status.setText("")
        self._loading = False

    def set_path(self, path: str):
        self.path.setText(path)
        self._emit()

    def set_preview(self, pixmap: QPixmap | None):
        self.preview.setPixmap(pixmap.scaled(208, 124, Qt.KeepAspectRatio, Qt.SmoothTransformation) if pixmap else QPixmap())

    def current_spec(self) -> dict | None:
        kind = self.type.currentData()
        if kind == "empty":
            return None
        if kind == "metric":
            spec = {"type": "metric", "kind": self.metric_box.currentData()}
            if self.metric_font.currentData():
                spec["font"] = self.metric_font.currentData()
            return spec
        if kind == "weather":
            spec = {"type": "weather"}
            if self._place:
                spec["place"] = dict(self._place)
            if self.unit_f.isChecked():
                spec["units"] = "f"
            if self.weather_font.currentData():
                spec["font"] = self.weather_font.currentData()
            return spec
        if kind == "text":
            spec = {"type": "text", "text": self.text.toPlainText()}
            if self.size_spin.value():
                spec["size"] = self.size_spin.value()
            if self.color.color != DEFAULT_COLOR:
                spec["color"] = self.color.color
            if self.bg.color != DEFAULT_BG:
                spec["bg"] = self.bg.color
            if self.text_font.currentData():
                spec["font"] = self.text_font.currentData()
            return spec
        return {"type": kind, "path": self.path.text().strip(), "fit": self.fit.currentData()}

    def _type_changed(self, _):
        kind = self.type.currentData()
        self.stack.setCurrentIndex({"empty": 0, "metric": 1, "text": 2, "image": 3, "gif": 3, "weather": 4}.get(kind, 0))
        if kind not in ("image", "gif"):
            self.span.setChecked(False)
        self._emit()

    def _emit(self, *_):
        if self._loading:
            return
        spec = self.current_spec()
        media = spec is not None and spec["type"] in ("image", "gif")
        if media and self.span.isChecked():
            self.full_changed.emit(spec)
        else:
            self.full_changed.emit(None)
            self.segment_changed.emit(spec)
