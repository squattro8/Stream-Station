"""Image preparation: any picture -> JPEG sized and rotated for a panel."""
from __future__ import annotations

import io
import os

from PIL import Image, ImageDraw, ImageFont

from . import fonts, protocol as P


def to_jpeg(img: Image.Image, size: tuple[int, int], sharp: bool = False) -> bytes:
    """Rotate for the panel and encode as JPEG within the 16-bit BAT length.
    `sharp` keeps full colour resolution (no 4:2:0 subsampling): clean edges for the strip."""
    img = img.convert("RGBA")
    img.thumbnail(size, Image.LANCZOS)
    canvas = Image.new("RGB", size, (0, 0, 0))
    canvas.paste(img, ((size[0] - img.width) // 2, (size[1] - img.height) // 2), img)
    canvas = canvas.rotate(P.ROTATION)
    extra = {"subsampling": 0} if sharp else {}
    for quality in (90, 75, 60, 45):
        buf = io.BytesIO()
        canvas.save(buf, "JPEG", quality=quality, **extra)
        data = buf.getvalue()
        if len(data) <= 0xFFFF:          # 16-bit BAT length
            break
    return data


def key_image(icon: str | None, label: str, assets: list[str]) -> bytes:
    for base in assets:
        path = icon if icon and os.path.isabs(icon) else (os.path.join(base, icon) if icon else None)
        if path and os.path.isfile(path):
            return to_jpeg(Image.open(path), P.KEY_SIZE)
    img = Image.new("RGB", P.KEY_SIZE, (30, 30, 36))
    d = ImageDraw.Draw(img)
    d.text((P.KEY_SIZE[0] // 2, P.KEY_SIZE[1] // 2), label[:10], fill=(235, 235, 235),
           font=fonts.font(22), anchor="mm")
    return to_jpeg(img, P.KEY_SIZE)


CYAN = (0, 229, 255)


def breathing_ring(level: float) -> Image.Image:
    """A black key with a cyan outline all around it; `level` (0..1) is how bright the outline is right now."""
    w, h = P.KEY_SIZE
    img = Image.new("RGB", (w, h), (0, 0, 0))
    d = ImageDraw.Draw(img)
    scale = lambda k: tuple(round(c * max(0.0, min(1.0, level * k))) for c in CYAN)
    d.rounded_rectangle([2, 2, w - 3, h - 3], radius=14, outline=scale(0.35), width=3)      # soft outer halo
    d.rounded_rectangle([6, 6, w - 7, h - 7], radius=11, outline=scale(1.0), width=4)       # the outline itself
    return img


def blank_key() -> bytes:
    return to_jpeg(Image.new("RGB", P.KEY_SIZE, (0, 0, 0)), P.KEY_SIZE)


ALIGN = 16     # the deck decodes in 16 px blocks: widths/positions that are not multiples of 16 leave garbage


def strip_stream(canvas: Image.Image, rect: tuple[int, int, int, int], index: int = 0) -> bytes:
    """The DRA stream that updates `rect` of the strip, cut from the WHOLE viewer canvas (800x128).

    rect = (x, y, w, h) as the viewer sees it. The deck stores the canvas rotated 180 degrees, so the
    rectangle is mirrored. It is then grown to the 16 px grid; the extra margin is taken from the
    canvas, so it carries the neighbours' real content instead of garbage.
    """
    x, y, w, h = rect
    if not (0 <= x and 0 <= y and w > 0 and h > 0 and x + w <= P.STRIP_W and y + h <= P.STRIP_H):
        raise ValueError(f"region {rect} is outside the {P.STRIP_W}x{P.STRIP_H} canvas")
    canvas = canvas.convert("RGB")
    if canvas.size != (P.STRIP_W, P.STRIP_H):
        raise ValueError("the canvas must be 800x128")
    device = canvas.rotate(180)
    dx, dy = P.STRIP_W - x - w, P.STRIP_H - y - h
    x0, y0 = dx // ALIGN * ALIGN, dy // ALIGN * ALIGN
    x1, y1 = -(-(dx + w) // ALIGN) * ALIGN, -(-(dy + h) // ALIGN) * ALIGN
    piece = device.crop((x0, y0, min(x1, P.STRIP_W), min(y1, P.STRIP_H)))
    for quality in (90, 80, 70, 60, 45):
        buf = io.BytesIO()
        piece.save(buf, "JPEG", quality=quality, subsampling=0)
        if len(buf.getvalue()) <= 0x30000:
            break
    return P.draw_stream(buf.getvalue(), x0, y0, piece.width, piece.height, index)


def strip_region_stream(img: Image.Image, x: int, y: int, w: int, h: int, index: int = 0) -> bytes:
    """One picture placed at (x, y, w, h) on an otherwise black canvas (the `draw` probe command)."""
    canvas = Image.new("RGB", (P.STRIP_W, P.STRIP_H), (0, 0, 0))
    canvas.paste(img.convert("RGB").resize((w, h), Image.LANCZOS), (x, y))
    return strip_stream(canvas, (x, y, w, h), index)
