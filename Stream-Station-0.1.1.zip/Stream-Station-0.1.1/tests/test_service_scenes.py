import os, sys, pathlib, tempfile, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from PIL import Image
from streamstation import bootlogo, profiles, protocol as P, scenes
from streamstation.service import Service
from test_service import FakeDeck


class Env:
    def __enter__(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.saved = (profiles.CONFIG, profiles.search_dirs)
        profiles.CONFIG = os.path.join(self.tmp.name, "cfg"); os.makedirs(profiles.CONFIG)
        profiles.search_dirs = lambda sub: [d for d in [os.path.join(profiles.CONFIG, sub)] if sub == "profiles" and os.path.isdir(d)]
        return self
    def __exit__(self, *a):
        profiles.CONFIG, profiles.search_dirs = self.saved
        self.tmp.cleanup()
    def service(self, first="A", **settings):
        d = Service(profile=first, sock_path=os.path.join(self.tmp.name, "s.sock"))
        d.deck = FakeDeck()
        d.settings = dict(profiles.DEFAULT_SETTINGS, follow_lock=False, **settings)
        return d


def test_scene_next_prev_wraps_in_user_order():
    with Env() as e:
        for n in ("A", "B", "C"): scenes.create(n)
        d = e.service("A")
        d.run_action("scene:next"); assert d.profile.name == "B"
        d.run_action("scene:next"); d.run_action("scene:next"); assert d.profile.name == "A"
        d.run_action("scene:prev"); assert d.profile.name == "C"
        scenes.move("C", -2)                                        # order C A B
        d.run_action("scene:next"); assert d.profile.name == "A"
        d.close_sockets()


def test_single_scene_does_nothing():
    with Env() as e:
        scenes.create("A"); d = e.service("A")
        d.run_action("scene:next"); assert d.profile.name == "A"
        d.close_sockets()


def test_default_scene_is_the_fallback_for_unbound_windows():
    from streamstation import windows as W
    with Env() as e:
        for n in ("A", "B", "C"): scenes.create(n)
        d = e.service("A"); d._base_profile = "A"
        scenes.set_default("B")
        d._consider(W.Window("whatever", "x", "t", 0, ""), 100.0)
        assert d._pending and d._pending[0] == "B"
        scenes.set_default(None)
        d._pending = None; d._consider(W.Window("whatever", "x", "t", 0, ""), 200.0)
        assert d._pending is None                                   # base profile is already open
        d.close_sockets()


def test_scene_swipe_only_when_enabled_and_no_pages():
    with Env() as e:
        for n in ("A", "B"): scenes.create(n)
        d = e.service("A", scene_swipe=True)
        d.handle(P.decode_event(0x39, 0))                           # right-to-left -> next
        assert d.profile.name == "B"
        d._last_strip = 0
        d.handle(P.decode_event(0x38, 0))
        assert d.profile.name == "A"
        off = e.service("A", scene_swipe=False)
        off.handle(P.decode_event(0x39, 0)); assert off.profile.name == "A"
        d.close_sockets(); off.close_sockets()


def test_boot_logo_drawn_before_profile_and_optional():
    with Env() as e:
        scenes.create("A")
        d = e.service("A")
        assert d._show_boot_logo(sleep=lambda s: None) is False and d.deck.sent == []    # off by default
        d.settings["boot_logo"] = True
        assert d._show_boot_logo(sleep=lambda s: None) is False                          # on but no picture stored
        bootlogo.save(Image.new("RGB", (100, 100), (255, 0, 0)))
        d.running = True; d.settings["boot_logo_seconds"] = 0
        assert d._show_boot_logo(sleep=lambda s: None) is True
        cmds = d.deck.cmds()
        assert b"CLE" in cmds and b"DRA" in cmds and cmds[-1] == b"STP"
        d.close_sockets()
