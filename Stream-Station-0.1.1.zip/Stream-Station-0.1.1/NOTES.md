# Evidence notes (SDLibrary1.dll sha256 4a4a4a0641776f15449896442b05239f46dbe1bc8e8b437df82fcaf1c16ebdfc)

All from static analysis (REA / Hopper) of the installed vendor DLL. Nothing was executed.

| Fact | Function (VA) | Evidence ID |
|---|---|---|
| Transport is HID via embedded hidapi (`hid_write`, `hid_read_timeout`, `hid_enumerate`) | `SDDevice::writeData` 0x180021a60, `findDevice` 0x180018620 | ev_67dd8340…, ev_f44cec76… |
| Heartbeat = `CONNECT` | `addHeartbeatPack` 0x180015430 | ev_5acc4f52… |
| Wake = `DIS` | `addWakeUpScreenPack` 0x1800170a0 | ev_fc155407… |
| Clear = `CLE`, index at byte 11 | `addClearCommand` 0x180014e70 | ev_f1f17fbd… |
| Commit = `STP` | `addFinishCommand` 0x180015030 | ev_0d38404d… |
| Brightness = `LIG`, value at byte 10 | `addAdjustBrightnessPack` 0x180014aa0 | ev_d9a56647… |
| Image = `BAT`, 16-bit BE size, slot byte | `sendPicSizeCommand` 0x18001f350 | ev_a7ccd819… |
| Input frames start `ACK`, `OK` at 5-6, code at byte 9, state at byte 10 | `readDataFromHidDevice` 0x18001ca30 | ev_… (retained) |

Not provable statically (must be confirmed on the device): VID/PID table in the
exe, key/knob/strip event code table, slot numbering, panel pixel geometry.
