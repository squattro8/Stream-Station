"""Configuration panel for the selected key, the 'add shortcut' dialog and entry builders."""
from __future__ import annotations

from ..i18n import tr

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout, QLabel,
                               QLineEdit, QMenu, QPushButton, QVBoxLayout, QWidget)

from .. import plugins
from . import icons, model

SHORTCUT_PRESETS = [
    ("Refrescar página", "f5"), ("Copiar", "ctrl+c"), ("Pegar", "ctrl+v"), ("Deshacer", "ctrl+z"),
    ("Guardar", "ctrl+s"), ("Buscar", "ctrl+f"), ("Pestaña nueva", "ctrl+t"), ("Cerrar pestaña", "ctrl+w"),
    ("Pantalla completa", "f11"), ("Captura de pantalla", "print"),
]


# --- entry builders ---------------------------------------------------------------------------
def save_tile(img, name: str) -> str:
    """Write a 128x128 tile to the user's icon directory; return the profile-relative path."""
    from . import actionicons
    style = actionicons.current_style()
    os.makedirs(model.user_icons_dir(), exist_ok=True)
    fname = model.slug(name if style == "pastel" else f"{name}@{style}") + ".png"      # a style never overwrites another's files
    img.convert("RGBA").save(os.path.join(model.user_icons_dir(), fname))
    return f"icons/user/{fname}"


def action_from_payload(payload: dict, value: str | None = None) -> str:
    """Just the action string of something dragged from the tree (used as a strip touch action)."""
    if payload.get("kind") == "app":
        return f"open:{payload['id']}"
    action = payload["action"]
    if "{}" in action:
        if not value:
            raise ValueError(tr("esta acción necesita un valor"))
        action = action.replace("{}", value)
    if action in ("{toggle}", "{random}", "{sequence}"):
        raise ValueError(tr("las multi-acciones aún no tienen editor visual"))
    return action


def entry_from_catalog(payload: dict, lib: icons.IconLibrary, value: str | None = None) -> dict:
    action = payload["action"]
    if "{}" in action:
        if not value:
            raise ValueError(tr("esta acción necesita un valor"))
        action = action.replace("{}", value)
    if action in ("{toggle}", "{random}", "{sequence}"):
        raise ValueError(tr("las multi-acciones aún no tienen editor visual"))
    plugin = "" if payload["plugin"] == "—" else payload["plugin"]
    img = lib.key_image(plugin, payload["label"], payload["group"], "unified", action=payload["action"])
    return {"label": payload["label"], "action": action, "icon": save_tile(img, action + payload["label"])}


def entry_from_xplane(payload: dict, lib=None) -> dict:
    """A key that runs an X-Plane command and shows the state of the dataref that goes with it."""
    from ..xplane import glyphs, states
    name = payload["name"]
    glyph = glyphs.pick_glyph(name, payload.get("description", ""))
    entry = {"label": payload.get("title") or name.rsplit("/", 1)[-1], "action": "xp:cmd:" + name,
             "icon": save_tile(glyphs.neutral_tile(glyph), "xp:" + name)}
    entry["xp"] = {"glyph": glyph, **(states.suggest(name) or {})}
    return entry


def entry_from_control(payload: dict) -> dict:
    """A key for one control of an aircraft: its command when it has one, its lamp/switch as the state."""
    from ..xplane import glyphs
    title = payload.get("title") or (payload.get("command") or payload.get("state") or "?").rsplit("/", 1)[-1]
    probe = f"{payload.get('command') or payload.get('state')} {title}"
    glyph = glyphs.pick_glyph(probe)
    entry: dict = {"label": title[:14], "icon": save_tile(glyphs.neutral_tile(glyph), "xpc:" + probe)}
    if payload.get("command"):
        entry["action"] = "xp:cmd:" + payload["command"]
    xp: dict = {"glyph": glyph}
    if payload.get("state"):
        xp.update({"dataref": payload["state"], "template": "onoff"})
    entry["xp"] = xp
    return entry


def xp_to_split(xp: dict) -> dict:
    """A single-lamp state becomes the bottom lamp of a two-lamp switch; the top lamp starts empty."""
    keep = {k: v for k, v in xp.items() if k not in ("glyph", "top", "bottom")}
    return {"glyph": xp.get("glyph", "plane"), "top": {"template": "warning"}, "bottom": keep}


def xp_to_single(xp: dict) -> dict:
    """Back to one lamp: the bottom lamp's state is kept."""
    out = {"glyph": xp.get("glyph", "plane")}
    out.update(xp.get("bottom") or {})
    return out


def _join(ref) -> str:
    return ", ".join(ref) if isinstance(ref, list) else str(ref or "")


def _split_refs(text: str):
    parts = [r.strip() for r in text.split(",") if r.strip()]
    return parts if len(parts) > 1 else (parts[0] if parts else "")


def entry_from_app(app) -> dict:
    from .apps import app_key_image
    img = app_key_image(app.icon) or icons.fallback_tile("", "lilac", "app")
    return {"label": app.name, "action": f"open:{app.id}", "icon": save_tile(img, "app:" + app.id)}


def entry_from_shortcut(label: str, combo: str, lib: icons.IconLibrary) -> dict:
    plugins.parse_combo(combo)          # raises ValueError when invalid
    img = lib.key_image("system.hotkey", label, "Herramientas", "unified", action="key:" + combo)
    return {"label": label, "action": f"key:{combo}", "icon": save_tile(img, f"key:{combo}:{label}")}


def entry_from_path(path: str, lib: icons.IconLibrary | None = None) -> dict:
    """Turn something found on disk into a button: an application launcher (.desktop), an
    executable, a folder or any file (opened with the default application)."""
    import shlex
    from PySide6.QtCore import QFileInfo
    from PySide6.QtWidgets import QFileIconProvider
    from . import apps
    path = os.path.abspath(os.path.expanduser(path))
    if not os.path.exists(path):
        raise ValueError(tr("no existe: {path}", path=path))
    label, action, img = os.path.basename(path.rstrip("/")) or path, None, None
    if os.path.isdir(path):
        action = f"open:{path}"
    elif path.endswith(".desktop"):
        app = apps.parse_desktop(path)
        if not app:
            raise ValueError(tr("no es un lanzador de aplicación válido"))
        label = app.name
        ident = apps.in_standard_dirs(path)
        action = f"open:{ident}" if ident else apps.exec_command(path)
        if not action:
            raise ValueError(tr("el lanzador no tiene comando (Exec)"))
        img = apps.app_key_image(app.icon)
    elif os.access(path, os.X_OK):
        action = shlex.quote(path)
    else:
        action = f"open:{path}"
    if img is None:
        pm = QFileIconProvider().icon(QFileInfo(path)).pixmap(128, 128)
        if not pm.isNull():
            import io
            from PIL import Image
            from PySide6.QtCore import QBuffer, QIODevice
            buf = QBuffer(); buf.open(QIODevice.WriteOnly); pm.save(buf, "PNG")
            from . import actionicons
            img = actionicons.app_tile(Image.open(io.BytesIO(bytes(buf.data()))), 128)
    if img is None:
        img = icons.fallback_tile("", "lilac", "folder" if os.path.isdir(path) else "file")
    return {"label": label, "action": action, "icon": save_tile(img, "path:" + path)}


# --- dialogs / widgets --------------------------------------------------------------------------
class ShortcutDialog(QDialog):
    """Pick or type a keyboard shortcut and name the button ('Refrescar página' -> F5)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(tr("Agregar atajo"))
        form = QFormLayout(self)
        self.preset = QComboBox(); self.preset.addItem(tr("Elegir un atajo común…"), None)
        for label, combo in SHORTCUT_PRESETS:
            self.preset.addItem(f"{tr(label)}  ({combo})", (tr(label), combo))
        self.name = QLineEdit(); self.name.setPlaceholderText(tr("Nombre del botón"))
        self.combo = QLineEdit(); self.combo.setPlaceholderText(tr("p. ej. ctrl+shift+t"))
        self.msg = QLabel(""); self.msg.setObjectName("muted")
        form.addRow(tr("Común"), self.preset); form.addRow(tr("Nombre"), self.name)
        form.addRow(tr("Atajo"), self.combo); form.addRow(self.msg)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept); self.buttons.rejected.connect(self.reject)
        form.addRow(self.buttons)
        self.preset.currentIndexChanged.connect(self._preset)
        self.combo.textChanged.connect(self._validate); self.name.textChanged.connect(self._validate)
        self._validate()

    def _preset(self, _):
        data = self.preset.currentData()
        if data:
            self.name.setText(data[0]); self.combo.setText(data[1])

    def _validate(self):
        ok = bool(self.name.text().strip())
        try:
            plugins.parse_combo(self.combo.text()); self.msg.setText("")
        except ValueError as exc:
            ok = False
            self.msg.setText(str(exc) if self.combo.text().strip() else "")
        self.buttons.button(QDialogButtonBox.Ok).setEnabled(ok)

    def values(self) -> tuple[str, str]:
        return self.name.text().strip(), self.combo.text().strip().lower()


class ConfigPanel(QWidget):
    """Shown under the board. Emits edits; the window owns saving."""
    edited = Signal(object)        # new entry dict, or None to clear the key
    apply_clicked = Signal()
    browse_requested = Signal(str)     # "app" | "file" | "folder"

    def __init__(self):
        super().__init__()
        self.setObjectName("config")
        lay = QHBoxLayout(self); lay.setContentsMargins(40, 24, 40, 24); lay.setSpacing(24)
        self.preview = QLabel(); self.preview.setFixedSize(96, 96); self.preview.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.preview, 0, Qt.AlignTop)
        col = QVBoxLayout(); col.setSpacing(10); lay.addLayout(col, 1)
        self.title = QLabel(tr("Selecciona la tecla cuya acción quieres configurar")); self.title.setObjectName("heading")
        self.title.setWordWrap(True)
        self.label = QLineEdit(); self.label.setPlaceholderText(tr("Etiqueta"))
        self.action = QLineEdit(); self.action.setPlaceholderText(tr("Acción (p. ej. volume:mute)"))
        self.what = QLabel(""); self.what.setObjectName("muted"); self.what.setWordWrap(True)
        row = QHBoxLayout()
        self.clear_btn = QPushButton(tr("Quitar")); self.apply_btn = QPushButton(tr("Guardar y aplicar"))
        self.browse_btn = QPushButton(tr("Buscar en el sistema…"))
        menu = QMenu(self.browse_btn)
        for text, mode in (("Aplicación o lanzador (.desktop)…", "app"), ("Archivo o programa…", "file"), ("Carpeta…", "folder")):
            menu.addAction(text, lambda m=mode: self.browse_requested.emit(m))
        self.browse_btn.setMenu(menu)
        self.status = QLabel(""); self.status.setObjectName("muted")
        row.addWidget(self.browse_btn); row.addWidget(self.clear_btn); row.addWidget(self.apply_btn); row.addWidget(self.status, 1)
        for w in (self.title, self.label, self.action, self.what):
            col.addWidget(w)
        # X-Plane state: which dataref drives the key's colour, and how its value is read
        self.xp_box = QWidget(); xl = QHBoxLayout(self.xp_box); xl.setContentsMargins(0, 0, 0, 0)
        self.xp_dataref = QLineEdit(); self.xp_dataref.setPlaceholderText(tr("Dataref de X-Plane (estado de la tecla)"))
        self.xp_template = QComboBox(); self.xp_glyph = QComboBox()
        from ..xplane import glyphs as _g, states as _s
        self.xp_template.addItems(list(_s.TEMPLATES)); self.xp_glyph.addItems(list(_g.GLYPHS))
        for w, stretch in ((self.xp_dataref, 3), (self.xp_template, 1), (self.xp_glyph, 1)):
            xl.addWidget(w, stretch)
        col.addWidget(self.xp_box); self.xp_box.hide()
        self.xp_two = QCheckBox(tr("Dos luces (arriba y abajo), como un pulsador iluminado"))
        self.xp_lamps = QWidget(); ll = QHBoxLayout(self.xp_lamps); ll.setContentsMargins(0, 0, 0, 0)
        self.xp_top = QLineEdit(); self.xp_top.setPlaceholderText(tr("Luz de ARRIBA: dataref del aviso (anunciador)"))
        self.xp_bottom = QLineEdit(); self.xp_bottom.setPlaceholderText(tr("Luz de ABAJO: dataref del estado"))
        ll.addWidget(self.xp_top, 1); ll.addWidget(self.xp_bottom, 1)
        col.addWidget(self.xp_two); col.addWidget(self.xp_lamps); self.xp_two.hide(); self.xp_lamps.hide()
        self.xp_two.toggled.connect(self._xp_two_toggled)
        self.xp_top.textEdited.connect(self._xp_changed); self.xp_bottom.textEdited.connect(self._xp_changed)
        self.xp_dataref.textEdited.connect(self._xp_changed)
        self.xp_template.activated.connect(self._xp_changed); self.xp_glyph.activated.connect(self._xp_changed)
        col.addLayout(row); col.addStretch()
        self._entry: dict | None = None
        self._loading = False
        self.label.textEdited.connect(self._changed); self.action.textEdited.connect(self._changed)
        self.clear_btn.clicked.connect(lambda: self.edited.emit(None))
        self.apply_btn.clicked.connect(self.apply_clicked)
        self.show_none()

    def show_none(self, text="Selecciona la tecla cuya acción quieres configurar"):
        self._loading = True
        self.title.setText(text); self.preview.setPixmap(QPixmap()); self.label.clear(); self.action.clear()
        self.what.setText(""); self._entry = None
        for w in (self.label, self.action, self.clear_btn, self.apply_btn, self.browse_btn):
            w.setEnabled(False)
        self._loading = False

    def show_entry(self, title: str, entry: dict | None, pixmap: QPixmap | None):
        self._loading = True
        self._entry = dict(entry) if entry else None
        self.title.setText(title)
        self.preview.setPixmap(pixmap.scaled(96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation) if pixmap else QPixmap())
        e = entry or {}
        self.label.setText(str(e.get("label") or ""))
        plain = isinstance(e.get("action"), str)
        self.action.setText(e["action"] if plain else "")
        self.action.setEnabled(plain or not e)
        self.what.setText(model.summary(entry))
        xp = e.get("xp") if isinstance(e.get("xp"), dict) else None
        self.xp_box.setVisible(xp is not None)
        two = xp is not None and ("top" in xp or "bottom" in xp)
        self.xp_two.setVisible(xp is not None); self.xp_two.setChecked(two)
        self.xp_lamps.setVisible(two); self.xp_dataref.setVisible(not two); self.xp_template.setVisible(not two)
        if two:
            self.xp_top.setText(_join((xp.get("top") or {}).get("dataref")))
            self.xp_bottom.setText(_join((xp.get("bottom") or {}).get("dataref")))
            self.xp_glyph.setCurrentText(str(xp.get("glyph") or "plane"))
        elif xp is not None:
            ref = xp.get("dataref") or ""
            self.xp_dataref.setText(_join(ref))
            self.xp_template.setCurrentText(str(xp.get("template") or "onoff"))
            self.xp_glyph.setCurrentText(str(xp.get("glyph") or "plane"))
        self.label.setEnabled(True); self.clear_btn.setEnabled(bool(entry)); self.apply_btn.setEnabled(True); self.browse_btn.setEnabled(True)
        self._loading = False

    def set_dataref_names(self, names):
        from PySide6.QtWidgets import QCompleter
        c = QCompleter(sorted(names), self); c.setCaseSensitivity(Qt.CaseInsensitive); c.setFilterMode(Qt.MatchContains)
        self.xp_dataref.setCompleter(c)

    def _xp_two_toggled(self, on: bool):
        if self._loading or self._entry is None or not isinstance(self._entry.get("xp"), dict):
            return
        e = dict(self._entry)
        xp = e["xp"]
        two = "top" in xp or "bottom" in xp
        if on == two:
            return
        e["xp"] = xp_to_split(xp) if on else xp_to_single(xp)
        self._entry = e
        self.show_entry(self.title.text(), e, self.preview.pixmap())
        self.what.setText(model.summary(e))
        self.edited.emit(e)

    def _xp_changed(self, *_):
        if self._loading or self._entry is None:
            return
        e = dict(self._entry)
        xp = dict(e.get("xp") or {})
        if "top" in xp or "bottom" in xp:             # two lamps: only the datarefs and the glyph are edited here
            for key, box in (("top", self.xp_top), ("bottom", self.xp_bottom)):
                half = dict(xp.get(key) or {})
                ref = _split_refs(box.text())
                if ref:
                    half["dataref"] = ref
                else:
                    half.pop("dataref", None)
                xp[key] = half
            xp["glyph"] = self.xp_glyph.currentText()
            e["xp"] = xp
            self._entry = e
            self.what.setText(model.summary(e))
            self.edited.emit(e)
            return
        ref = self.xp_dataref.text().strip()
        if ref:
            parts = [r.strip() for r in ref.split(",") if r.strip()]
            xp["dataref"] = parts if len(parts) > 1 else parts[0]
            if len(parts) < 2:
                xp.pop("index", None) if isinstance(xp.get("index"), list) else None
        else:
            xp.pop("dataref", None)
        if self.sender() is self.xp_template or not xp.get("states"):
            xp.pop("states", None)          # picking a template replaces hand-written rules
            xp["template"] = self.xp_template.currentText()
        xp["glyph"] = self.xp_glyph.currentText()
        e["xp"] = xp
        self._entry = e
        self.what.setText(model.summary(e))
        self.edited.emit(e)

    def _changed(self, *_):
        if self._loading:
            return
        e = dict(self._entry or {})
        e["label"] = self.label.text()
        if self.action.isEnabled():
            if self.action.text().strip():
                e["action"] = self.action.text().strip()
            else:
                e.pop("action", None)
        self._entry = e
        self.what.setText(model.summary(e))
        self.clear_btn.setEnabled(True)        # there is now something to remove
        self.edited.emit(e)
