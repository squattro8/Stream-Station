"""The real brand marks of the services, fetched from the Simple Icons set on the USER's request.

The program does not ship any logo: they are brand assets (trademarks of their owners), so they are downloaded into
the user's own config folder (`~/.config/streamstation/assets/logos/`) only when the user asks for it
(`streamstation fetch-logos`, or the button in the settings window). Simple Icons publishes the shapes under CC0.
Without the files the keys simply use the program's own drawn pictograms.
"""
from __future__ import annotations

import os
import urllib.error
import urllib.request

from . import profiles, services

BASE = "https://raw.githubusercontent.com/simple-icons/simple-icons/develop/icons/{slug}.svg"


def folder() -> str:
    return os.path.join(profiles.CONFIG, "assets", "logos")


def path(service_id: str) -> str:
    return os.path.join(folder(), f"{service_id}.svg")


def have(service_id: str) -> bool:
    return os.path.isfile(path(service_id))


def missing() -> list[str]:
    return [s.id for s in services.SERVICES if s.slug and not have(s.id)]


def _valid(data: bytes) -> bool:
    return b"<svg" in data[:400] and b"<path" in data and len(data) < 60_000


def fetch(ids=None, opener=None, out=print) -> dict:
    """Download the marks of `ids` (default: all services). Returns {"done": [...], "failed": {id: reason}}."""
    opener = opener or urllib.request.urlopen
    done, failed = [], {}
    os.makedirs(folder(), exist_ok=True)
    for svc in services.SERVICES:
        if (ids and svc.id not in ids) or not svc.slug:
            continue
        try:
            with opener(urllib.request.Request(BASE.format(slug=svc.slug), headers={"User-Agent": "streamstation"}), timeout=8) as r:
                data = r.read()
            if not _valid(data):
                raise ValueError("not an SVG mark")
            tmp = path(svc.id) + ".tmp"
            with open(tmp, "wb") as fh:
                fh.write(data)
            os.replace(tmp, path(svc.id))
            done.append(svc.id)
            out(f"descargado {svc.name} ({len(data)} bytes)")
        except (urllib.error.URLError, OSError, ValueError) as exc:
            failed[svc.id] = str(exc)
            out(f"no se pudo {svc.name}: {exc}")
    return {"done": done, "failed": failed}


def logo_image(service_id: str, size: int = 256):
    """The brand mark painted in its colour as a transparent RGBA picture, or None when it is not downloaded."""
    svc = services.BY_ID.get(service_id)
    if svc is None or not have(service_id):
        return None
    try:
        from PIL import Image
        from PySide6.QtCore import QByteArray, Qt
        from PySide6.QtGui import QImage, QPainter
        from PySide6.QtSvg import QSvgRenderer
        with open(path(service_id), "rb") as fh:
            svg = fh.read().decode("utf-8", "replace")
        svg = svg.replace("<path ", f'<path fill="{svc.brand}" ', 1)
        renderer = QSvgRenderer(QByteArray(svg.encode()))
        if not renderer.isValid():
            return None
        image = QImage(size, size, QImage.Format_RGBA8888)
        image.fill(Qt.transparent)
        painter = QPainter(image)
        renderer.render(painter)
        painter.end()
        return Image.frombytes("RGBA", (size, size), bytes(image.constBits())[: size * size * 4])
    except Exception:
        return None
