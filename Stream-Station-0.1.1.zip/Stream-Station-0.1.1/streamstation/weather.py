"""Outdoor temperature and sky for a place the user chose, from Open-Meteo (free, no account, no API key).

Only the coordinates of the chosen place are sent, nothing that identifies the user. The strip never waits for the
network: `Service.get` returns what it has (or None) at once and refreshes in a background thread.

    search("Rosario")      -> [Place(...), ...]       (the city picker; blocking, called from the editor)
    SERVICE.get(lat, lon)  -> Reading | None          (the strip widget; never blocks)
"""
from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

FORECAST = ("https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}"
            "&current=temperature_2m,weather_code,is_day&timezone=auto")
GEOCODE = "https://geocoding-api.open-meteo.com/v1/search?name={name}&count={count}&language={lang}&format=json"
TTL_S = 900          # a reading is fresh for 15 minutes
RETRY_S = 120        # after a failure, wait this long before asking again


class WeatherError(RuntimeError):
    pass


@dataclass(frozen=True)
class Place:
    name: str
    lat: float
    lon: float
    region: str = ""
    country: str = ""

    @property
    def label(self) -> str:
        return ", ".join(p for p in (self.name, self.region, self.country) if p)

    def as_spec(self) -> dict:
        return {"name": self.name, "lat": round(self.lat, 4), "lon": round(self.lon, 4), "label": self.label}


@dataclass(frozen=True)
class Reading:
    temp_c: float
    code: int
    is_day: bool


def _get_json(url: str, opener=None, timeout: float = 6.0) -> dict:
    opener = opener or urllib.request.urlopen
    try:
        with opener(urllib.request.Request(url, headers={"User-Agent": "streamstation"}), timeout=timeout) as resp:
            return json.loads(resp.read())
    except (urllib.error.URLError, OSError, ValueError, TimeoutError) as exc:
        raise WeatherError(str(exc)) from exc


def search(query: str, count: int = 6, opener=None, lang: str = "es") -> list[Place]:
    """Places that match a name typed by the user (city, town...). Empty for an empty query."""
    query = query.strip()
    if not query:
        return []
    data = _get_json(GEOCODE.format(name=urllib.parse.quote(query), count=count, lang=lang), opener)
    out = []
    for r in data.get("results") or []:
        try:
            out.append(Place(str(r["name"]), float(r["latitude"]), float(r["longitude"]),
                             str(r.get("admin1") or ""), str(r.get("country") or "")))
        except (KeyError, TypeError, ValueError):
            continue
    return out


def parse_current(data: dict) -> Reading | None:
    cur = (data or {}).get("current") or {}
    try:
        return Reading(float(cur["temperature_2m"]), int(cur["weather_code"]), bool(cur.get("is_day", 1)))
    except (KeyError, TypeError, ValueError):
        return None


# WMO weather interpretation codes -> (kind of picture, Spanish name)
def describe(code: int, is_day: bool = True) -> tuple[str, str]:
    if code == 0:
        return "clear", "Despejado"
    if code == 1:
        return "clear", "Mayormente despejado"
    if code == 2:
        return "partly", "Parcialmente nublado"
    if code == 3:
        return "cloudy", "Nublado"
    if code in (45, 48):
        return "fog", "Niebla"
    if code in (51, 53, 55, 56, 57):
        return "drizzle", "Llovizna"
    if code in (61, 63, 65, 66, 67, 80, 81, 82):
        return "rain", "Lluvia" if code in (61, 63, 80, 81) else "Lluvia fuerte"
    if code in (71, 73, 75, 77, 85, 86):
        return "snow", "Nieve"
    if code in (95, 96, 99):
        return "storm", "Tormenta"
    return "cloudy", "Nublado"


def to_unit(temp_c: float, units: str) -> float:
    return temp_c * 9 / 5 + 32 if units == "f" else temp_c


class Service:
    """Cached readings per place, refreshed in the background. Safe to call from any thread."""

    def __init__(self, opener=None, ttl: float = TTL_S, retry: float = RETRY_S, clock=time.monotonic):
        self._opener, self._ttl, self._retry, self._clock = opener, ttl, retry, clock
        self._data: dict[tuple, tuple[Reading, float]] = {}
        self._fail: dict[tuple, float] = {}
        self._busy: set[tuple] = set()
        self._lock = threading.Lock()

    @staticmethod
    def key(lat, lon) -> tuple:
        return (round(float(lat), 2), round(float(lon), 2))

    def get(self, lat, lon) -> Reading | None:
        key = self.key(lat, lon)
        now = self._clock()
        with self._lock:
            hit = self._data.get(key)
            stale = hit is None or now - hit[1] >= self._ttl
            backoff = now - self._fail.get(key, -1e9) < self._retry
            if stale and not backoff and key not in self._busy:
                self._busy.add(key)
                threading.Thread(target=self._fetch, args=(key,), daemon=True, name="streamstation-weather").start()
            return hit[0] if hit else None

    def state(self, lat, lon) -> str:
        """"ok" (has a reading), "loading" or "error" (no reading and the last try failed)."""
        key = self.key(lat, lon)
        with self._lock:
            if key in self._data:
                return "ok"
            return "loading" if key in self._busy or key not in self._fail else "error"

    def _fetch(self, key: tuple):
        try:
            reading = parse_current(_get_json(FORECAST.format(lat=key[0], lon=key[1]), self._opener))
            if reading is None:
                raise WeatherError("unexpected answer")
            with self._lock:
                self._data[key] = (reading, self._clock())
                self._fail.pop(key, None)
        except WeatherError:
            with self._lock:
                self._fail[key] = self._clock()
        finally:
            with self._lock:
                self._busy.discard(key)

    def wait(self, timeout: float = 3.0) -> bool:
        """Test helper: block until no fetch is running."""
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            with self._lock:
                if not self._busy:
                    return True
            time.sleep(0.01)
        return False


SERVICE = Service()
