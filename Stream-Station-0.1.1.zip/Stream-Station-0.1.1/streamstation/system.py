"""Desktop/system actions the original app offers.

Original evidence (Redragon Stream Station, see FEATURES.md):
  SimulatedKeyboardEvent::computerLockWorkStation / computerSleep  -> lock, suspend
  WTSAPI32 import (session notifications)                          -> follow session lock
  SDDevice::setScreenOffTime / setScreenOffAction                  -> idle screen off
"""
from __future__ import annotations

import os
import subprocess

VERBS = {
    "lock": ["loginctl", "lock-session"],
    "suspend": ["systemctl", "suspend"],
    "sleep": ["systemctl", "suspend"],     # the original calls it "Sleep"
    "hibernate": ["systemctl", "hibernate"],
}


def run_verb(name: str) -> bool:
    cmd = VERBS.get(name)
    if not cmd:
        return False
    subprocess.Popen(cmd, start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True


def session_locked() -> bool:
    """True when the desktop session reports LockedHint=yes (best effort)."""
    sid = os.environ.get("XDG_SESSION_ID") or "self"
    try:
        out = subprocess.run(["loginctl", "show-session", sid, "-p", "LockedHint", "--value"],
                             capture_output=True, text=True, timeout=2).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return False
    return out == "yes"
