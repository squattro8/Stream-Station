"""Weather pictures for the strip, drawn by code: sun, moon, clouds, rain, snow, fog, storm. No artwork from anywhere.

`icon(kind, is_day, size)` is a transparent RGBA picture; `widget_image(...)` is the 200x128 panel of the strip.
"""
from __future__ import annotations

import math

from PIL import Image, ImageDraw

from . import fonts
from .i18n import tr_strip

SS = 4
SUN = (255, 196, 40, 255)
MOON = (236, 232, 205, 255)
CLOUD = (214, 222, 235, 255)
CLOUD_DARK = (128, 138, 156, 255)
RAIN = (86, 168, 255, 255)
SNOW = (238, 246, 255, 255)
BOLT = (255, 214, 60, 255)
FOG = (168, 178, 194, 255)
PANEL = (0, 0, 0)
LABEL = (150, 160, 180)


class _C:
    """Drawing context in a 100x100 grid."""

    def __init__(self, size: int):
        self.img = Image.new("RGBA", (size * SS, size * SS), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.img)
        self.k = size * SS / 100

    def circ(self, x, y, r, c):
        k = self.k
        self.d.ellipse([(x - r) * k, (y - r) * k, (x + r) * k, (y + r) * k], fill=c)

    def line(self, pts, w, c):
        k = self.k
        self.d.line([(x * k, y * k) for x, y in pts], fill=c, width=max(1, round(w * k)), joint="curve")
        for x, y in (pts[0], pts[-1]):
            self.circ(x, y, w / 2, c)

    def poly(self, pts, c):
        self.d.polygon([(x * self.k, y * self.k) for x, y in pts], fill=c)

    def cloud(self, cx, cy, w, c):
        k = self.k
        self.d.rounded_rectangle([(cx - w / 2) * k, (cy - 0.14 * w) * k, (cx + w / 2) * k, (cy + 0.24 * w) * k], radius=0.2 * w * k, fill=c)
        self.circ(cx - 0.17 * w, cy - 0.06 * w, 0.24 * w, c)
        self.circ(cx + 0.10 * w, cy - 0.15 * w, 0.30 * w, c)

    def done(self, size: int) -> Image.Image:
        return self.img.resize((size, size), Image.LANCZOS)


def _sun(c, x, y, r, rays=True):
    c.circ(x, y, r, SUN)
    if rays:
        for a in range(0, 360, 45):
            ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
            c.line([(x + (r + 6) * ca, y + (r + 6) * sa), (x + (r + 14) * ca, y + (r + 14) * sa)], 5, SUN)


def _moon(c, x, y, r):
    c.circ(x, y, r, MOON)
    c.circ(x + r * 0.55, y - r * 0.35, r * 0.88, (0, 0, 0, 0))
    c.circ(x + r * 1.5, y - r * 1.0, 2.6, MOON)


def icon(kind: str, is_day: bool = True, size: int = 96) -> Image.Image:
    c = _C(size)
    if kind == "clear":
        _sun(c, 50, 50, 21) if is_day else (_moon(c, 46, 52, 30), c.circ(78, 24, 3, MOON))
    elif kind == "partly":
        _sun(c, 36, 36, 15) if is_day else _moon(c, 36, 38, 20)
        c.cloud(58, 66, 62, CLOUD)
    elif kind == "cloudy":
        c.cloud(38, 44, 52, CLOUD_DARK)
        c.cloud(60, 64, 62, CLOUD)
    elif kind == "fog":
        c.cloud(50, 36, 60, CLOUD)
        for y, x0, x1 in ((62, 18, 82), (74, 28, 90), (86, 14, 72)):
            c.line([(x0, y), (x1, y)], 6, FOG)
    elif kind in ("drizzle", "rain"):
        c.cloud(50, 36, 66, CLOUD if kind == "drizzle" else CLOUD_DARK)
        drops = ((30, 66), (48, 70), (66, 66)) if kind == "drizzle" else ((26, 62), (42, 70), (58, 62), (74, 70))
        for x, y in drops:
            c.line([(x, y), (x - 6, y + (14 if kind == "rain" else 9))], 5, RAIN)
    elif kind == "snow":
        c.cloud(50, 36, 66, CLOUD)
        for x, y in ((30, 70), (50, 80), (70, 70)):
            c.circ(x, y, 5, SNOW)
            for a in (0, 60, 120):
                ca, sa = math.cos(math.radians(a)), math.sin(math.radians(a))
                c.line([(x - 8 * ca, y - 8 * sa), (x + 8 * ca, y + 8 * sa)], 2.6, SNOW)
    elif kind == "storm":
        c.cloud(50, 34, 68, CLOUD_DARK)
        c.poly([(54, 54), (36, 78), (49, 78), (42, 98), (68, 70), (54, 70), (62, 54)], BOLT)
    else:
        c.cloud(50, 50, 66, CLOUD)
    return c.done(size)


def _fit(text: str, size: int, width: int, family: str | None):
    """The largest font (down to 9 px) that makes `text` fit `width`, with an ellipsis if even that is too wide."""
    while size > 9:
        f = fonts.font(size, False, family)
        if f.getlength(text) <= width:
            return text, f
        size -= 1
    f = fonts.font(9, False, family)
    while len(text) > 2 and f.getlength(text + "…") > width:
        text = text[:-1]
    return (text + "…" if len(text) > 2 else text), f


def widget_image(reading, place: dict | None, units: str = "c", family: str | None = None, state: str = "ok",
                 size: tuple[int, int] = (200, 128)) -> Image.Image:
    """The strip panel: sky picture, temperature, place and sky description."""
    from . import weather
    w, h = size
    img = Image.new("RGB", size, PANEL)
    d = ImageDraw.Draw(img)
    if not place or place.get("lat") is None:
        text, f = _fit(tr_strip("Elige una ciudad"), 22, w - 20, family)
        d.text((w // 2, h // 2), text, fill=LABEL, font=f, anchor="mm")
        return img
    name = place.get("name") or place.get("label") or ""
    if reading is None:
        label = tr_strip("Sin datos") if state == "error" else tr_strip("Cargando…")
        text, f = _fit(label, 24, w - 20, family)
        d.text((w // 2, h // 2 - 8), text, fill=LABEL, font=f, anchor="mm")
        text, f = _fit(name, 16, w - 20, family)
        d.text((w // 2, h - 22), text, fill=LABEL, font=f, anchor="mm")
        return img
    kind, desc = weather.describe(reading.code, reading.is_day)
    pic = icon(kind, reading.is_day, 76)
    img.paste(pic, (8, 10), pic)
    temp = f"{round(weather.to_unit(reading.temp_c, units))}°" + ("F" if units == "f" else "")
    text, f = _fit(temp, 52, w - 92 - 6, family)
    d.text((92 + (w - 92 - 6) // 2, 46), text, fill=(240, 240, 245), font=f, anchor="mm")
    text, f = _fit(name, 17, w - 16, family)
    d.text((w // 2, 98), text, fill=(205, 212, 226), font=f, anchor="mm")
    text, f = _fit(tr_strip(desc), 14, w - 16, family)
    d.text((w // 2, 117), text, fill=LABEL, font=f, anchor="mm")
    return img
