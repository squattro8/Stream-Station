#!/usr/bin/env python3
"""Import the icons of an installed Redragon Stream Station into assets/vendor/redragon/.

Unified criterion (measured on the installed app, see UI_STYLE.md):
  key images   128x128 PNG   (the app ships 126/128 px sources; icon packs 256 px)
  list icons   native size, 20x20 (+ @2x 40x40 when the app ships it)
Only static images are imported (animated GIF-only entries are skipped).
The files belong to the vendor: personal use only, do not redistribute.

usage: import_vendor_icons.py <install_dir> <out_dir>
"""
from __future__ import annotations

import glob
import hashlib
import json
import os
import sys

from PIL import Image

KEY = 128
EXT = (".png", ".PNG", ".jpg", ".jpeg", ".JPG")


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def find(base, rel, prefer_2x=False):
    if not rel:
        return None
    order = ("@2x.png", "@2x.PNG") + EXT if prefer_2x else EXT + ("@2x.png", "@2x.PNG")
    for e in order:
        p = os.path.join(base, rel + e) if e.startswith("@") or e.startswith(".") else None
        if p and os.path.isfile(p):
            return p
    p = os.path.join(base, rel)
    return p if os.path.isfile(p) and p.lower().endswith((".png", ".jpg", ".jpeg")) else None


def norm_key(src, dst):
    im = Image.open(src)
    im = im.convert("RGBA")
    if im.size != (KEY, KEY):
        im = im.resize((KEY, KEY), Image.LANCZOS)
    im.save(dst)


def safe(s):
    return "".join(c if c.isalnum() or c in "._-" else "_" for c in s)


def main(install, out):
    os.makedirs(out, exist_ok=True)
    entries, skipped = [], []
    # 1) plugin actions: list icon + key image
    for d in sorted(glob.glob(os.path.join(install, "plugins", "*.sdPlugin"))):
        m = json.load(open(os.path.join(d, "manifest.json"), encoding="utf-8-sig"))
        for a in m.get("Actions", []):
            uuid = a["UUID"]
            key = safe(uuid.replace("com.hotspot.streamdock.", ""))
            li = find(d, a.get("Icon"), prefer_2x=False)
            li2 = find(d, (a.get("Icon") or "") + "@2x") if a.get("Icon") else None
            if li:
                dst = os.path.join(out, "actions", f"{key}.list.png")
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                Image.open(li).convert("RGBA").save(dst)
                entries.append(dict(kind="action-list", uuid=uuid, name=a.get("Name"), file=os.path.relpath(dst, out),
                                    size=list(Image.open(dst).size), source=os.path.relpath(li, install), sha256=sha(li)))
            if li2:
                dst = os.path.join(out, "actions", f"{key}.list@2x.png")
                Image.open(li2).convert("RGBA").save(dst)
                entries.append(dict(kind="action-list@2x", uuid=uuid, name=a.get("Name"), file=os.path.relpath(dst, out),
                                    size=list(Image.open(dst).size), source=os.path.relpath(li2, install), sha256=sha(li2)))
            st = ((a.get("States") or [{}])[0]).get("Image")
            ki = find(d, st)
            if ki:
                dst = os.path.join(out, "actions", f"{key}.key.png")
                norm_key(ki, dst)
                entries.append(dict(kind="action-key", uuid=uuid, name=a.get("Name"), file=os.path.relpath(dst, out),
                                    size=[KEY, KEY], source=os.path.relpath(ki, install), source_size=list(Image.open(ki).size),
                                    sha256=sha(ki)))
            elif st:
                skipped.append((uuid, st, "sin imagen estática"))
    # 2) icon packs (256 px)
    for pack in sorted(glob.glob(os.path.join(install, "icons", "*.sdIconPack"))):
        pm = json.load(open(os.path.join(pack, "manifest.json"), encoding="utf-8-sig"))
        pid = os.path.basename(pack).replace(".sdIconPack", "")
        for f in sorted(glob.glob(os.path.join(pack, "icons", "*"))):
            if not f.lower().endswith((".png", ".jpg", ".jpeg")):
                skipped.append((pid, os.path.basename(f), "no estática")); continue
            dst = os.path.join(out, "packs", safe(pid), os.path.splitext(os.path.basename(f))[0] + ".png")
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            im = Image.open(f).convert("RGBA")
            if im.size != (256, 256):
                im = im.resize((256, 256), Image.LANCZOS)
            im.save(dst)
            entries.append(dict(kind="pack-icon", pack=pm.get("Name"), file=os.path.relpath(dst, out), size=[256, 256],
                                source=os.path.relpath(f, install), sha256=sha(f)))
    json.dump(dict(license="Vendor assets (Hotspot/Mirabox/Redragon). Personal use only; do not redistribute.",
                   key_px=KEY, entries=entries, skipped=skipped), open(os.path.join(out, "manifest.json"), "w"),
              indent=1, ensure_ascii=False)
    kinds = {}
    for e in entries:
        kinds[e["kind"]] = kinds.get(e["kind"], 0) + 1
    print(kinds, "| omitidos:", len(skipped))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
