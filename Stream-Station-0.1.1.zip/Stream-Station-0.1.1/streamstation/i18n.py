"""Interface languages.

The texts in the code are the Spanish originals; every other language is a table `locales/<code>.json` that maps
a Spanish text to its translation. `tr(text)` looks the text up in the language in use and falls back, in order, to
English and then to the Spanish original, so a missing translation can never break the interface.

English is the default language of a new installation (see profiles.DEFAULT_SETTINGS). Until a language is set the
module behaves as Spanish (the source), which is what the program's tests rely on.
"""
from __future__ import annotations

import json
import os

# the 20 most spoken languages (Ethnologue, total speakers), in that order, with their own name;
# varieties with no standard interface language (Nigerian Pidgin, Egyptian Arabic, Hausa, Yue) are replaced by Korean and Italian
LANGUAGES = [
    ("en", "English"), ("zh", "中文 (简体)"), ("hi", "हिन्दी"), ("es", "Español"), ("fr", "Français"),
    ("ar", "العربية"), ("bn", "বাংলা"), ("pt", "Português"), ("ru", "Русский"), ("ur", "اردو"),
    ("id", "Bahasa Indonesia"), ("de", "Deutsch"), ("ja", "日本語"), ("mr", "मराठी"), ("te", "తెలుగు"),
    ("tr", "Türkçe"), ("ta", "தமிழ்"), ("vi", "Tiếng Việt"), ("ko", "한국어"), ("it", "Italiano"),
]
CODES = [c for c, _n in LANGUAGES]
RTL = {"ar", "ur"}                       # written right to left
LATIN_STRIP = {"en", "es", "fr", "pt", "ru", "id", "de", "tr", "vi", "it"}   # scripts the strip's font can draw
SOURCE = "es"
DEFAULT = "en"
LOCALES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locales")

_lang = SOURCE
_cache: dict[str, dict[str, str]] = {}


def _table(code: str) -> dict[str, str]:
    if code not in _cache:
        try:
            with open(os.path.join(LOCALES_DIR, f"{code}.json"), encoding="utf-8") as fh:
                data = json.load(fh)
            _cache[code] = {str(k): str(v) for k, v in data.items()} if isinstance(data, dict) else {}
        except (OSError, ValueError):
            _cache[code] = {}
    return _cache[code]


def set_language(code: str) -> str:
    """Use `code` from now on (an unknown code falls back to the default). Returns the code in use."""
    global _lang
    _lang = code if code in CODES else DEFAULT
    return _lang


def language() -> str:
    return _lang


def init_from_settings() -> str:
    """Take the language from the user's settings (a new installation has none: English)."""
    from . import profiles
    return set_language(str(profiles.load_settings().get("language") or DEFAULT))


def is_rtl(code: str | None = None) -> bool:
    return (code or _lang) in RTL


def tr(text: str, **fmt) -> str:
    """The text in the language in use. `fmt` fills {placeholders} after translating (a bad format keeps the text)."""
    out = text
    if _lang != SOURCE:
        out = _table(_lang).get(text) or (_table(DEFAULT).get(text) if _lang != DEFAULT else None) or text
    if fmt:
        try:
            out = out.format(**fmt)
        except (KeyError, IndexError, ValueError):
            try:
                out = text.format(**fmt)
            except (KeyError, IndexError, ValueError):
                pass
    return out


def strip_language() -> str:
    """The language of the text the service draws on the strip: the chosen one when the strip's font can draw its script,
    English otherwise (the strip would show empty boxes)."""
    return _lang if _lang in LATIN_STRIP else DEFAULT


def tr_strip(text: str, **fmt) -> str:
    """Like tr() for text drawn on the strip, using strip_language()."""
    global _lang
    keep, _lang = _lang, strip_language()
    try:
        return tr(text, **fmt)
    finally:
        _lang = keep


def missing(code: str, keys) -> list[str]:
    """Texts of `keys` that `code` does not translate (for tests and the translator's checklist)."""
    table = _table(code)
    return [k for k in keys if not table.get(k)]
