"""Editor for one knob: turn right, turn left, press."""
from __future__ import annotations

from ..i18n import tr

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QLineEdit, QPushButton, QVBoxLayout, QWidget

FIELDS = (("cw", "Girar a la derecha"), ("ccw", "Girar a la izquierda"), ("press", "Pulsar"))
TEMPLATES = [
    ("Plantillas…", None),
    ("Volumen del sistema", {"cw": "volume:up:5", "ccw": "volume:down:5", "press": "volume:mute"}),
    ("Brillo del deck", {"cw": "brightness+10", "ccw": "brightness-10", "press": "screen-off"}),
    ("Cambiar de página", {"cw": "page:next", "ccw": "page:prev", "press": "page:0"}),
    ("Multimedia", {"cw": "media:next", "ccw": "media:prev", "press": "media:play-pause"}),
]


class KnobPanel(QWidget):
    field_changed = Signal(str, object)     # "cw" | "ccw" | "press", action string or None
    apply_clicked = Signal()

    def __init__(self):
        super().__init__()
        self.setObjectName("config")
        self.active = "press"               # where a double-clicked / dropped action goes
        lay = QVBoxLayout(self); lay.setContentsMargins(40, 24, 40, 24); lay.setSpacing(10)
        self.title = QLabel(tr("Perilla")); self.title.setObjectName("heading"); lay.addWidget(self.title)
        self.edits: dict[str, QLineEdit] = {}
        for key, label in FIELDS:
            row = QHBoxLayout(); lab = QLabel(tr(label)); lab.setFixedWidth(160); row.addWidget(lab)
            e = QLineEdit(); e.setPlaceholderText(tr("Acción (p. ej. volume:up:5) o arrastra una de la lista"))
            e.textEdited.connect(lambda t, k=key: self._edited(k, t))
            e.installEventFilter(self); e.setProperty("field", key)
            self.edits[key] = e; row.addWidget(e, 1); lay.addLayout(row)
        row = QHBoxLayout(); self.templates = QComboBox()
        for label, _ in TEMPLATES:
            self.templates.addItem(tr(label))
        self.templates.currentIndexChanged.connect(self._template)
        self.apply_btn = QPushButton(tr("Guardar y aplicar")); self.apply_btn.clicked.connect(self.apply_clicked)
        self.status = QLabel(""); self.status.setObjectName("muted")
        row.addWidget(self.templates); row.addWidget(self.apply_btn); row.addWidget(self.status, 1); lay.addLayout(row)
        lay.addStretch()
        self._loading = False

    def eventFilter(self, obj, event):
        if event.type() == event.Type.FocusIn and obj.property("field"):
            self.active = obj.property("field")
        return super().eventFilter(obj, event)

    def show_knob(self, index: int, cfg: dict):
        self._loading = True
        self.title.setText(tr("Perilla {n}", n=index + 1))
        rot = (cfg or {}).get("rotate") or {}
        values = {"cw": rot.get("cw"), "ccw": rot.get("ccw"), "press": (cfg or {}).get("press")}
        for k, e in self.edits.items():
            e.setText(values[k] if isinstance(values[k], str) else "")
            e.setEnabled(isinstance(values[k], str) or values[k] is None)   # lists/dicts are edited in the YAML
        self.templates.setCurrentIndex(0); self.status.setText("")
        self._loading = False

    def set_field(self, field: str, action: str | None):
        self.edits[field].setText(action or "")
        self.field_changed.emit(field, action or None)

    def _edited(self, field, text):
        if not self._loading:
            self.field_changed.emit(field, text.strip() or None)

    def _template(self, i):
        tpl = TEMPLATES[i][1]
        if tpl and not self._loading:
            for k, v in tpl.items():
                self.set_field(k, v)
