import io, os, sys, pathlib, tempfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from PIL import Image, ImageDraw
from streamstation import protocol as P, render, strip


class FakeMetrics:
    def __init__(self): self.v = 10.0
    def cpu(self): return self.v
    def ram(self): return 50.0
    def temp(self): return 40.0
    def disk(self, p="/"): return 70.0
    def volume(self): return (36, False)


def test_canvas_constants_confirmed_on_the_deck():
    assert (P.STRIP_W, P.STRIP_H) == (800, 128) and P.ZONE_W * 4 == P.STRIP_W
    assert strip.SEG == (200, 128) and strip.FULL == (800, 128)


def test_text_fits_and_wraps():
    img = strip.text_image({"text": "Reunión con el equipo a las 15:30 en la sala grande"})
    assert img.size == strip.SEG
    px = img.load()
    assert any(px[x, y] != (20, 20, 20) for x in range(20, 180) for y in range(10, 118))
    assert all(px[0, y] == px[1, y] for y in range(0, 128, 20))
    assert strip.text_image({"text": ""}).getpixel((100, 60)) == (20, 20, 20)


def test_fit_modes_always_return_the_target_size():
    src = Image.new("RGB", (400, 100), (200, 0, 0))
    for mode in ("cover", "contain", "stretch"):
        assert strip.fit_image(src, strip.SEG, mode).size == strip.SEG
    assert strip.fit_image(src, strip.SEG, "contain").getpixel((100, 2)) == (0, 0, 0)
    assert strip.fit_image(src, strip.SEG, "cover").getpixel((100, 2)) == (200, 0, 0)


def _gif(path, n=3, ms=100, size=(64, 32)):
    frames = [Image.new("RGB", size, (i * 80, 0, 0)) for i in range(n)]
    frames[0].save(path, save_all=True, append_images=frames[1:], duration=ms, loop=0)


def test_gif_timing_is_capped_and_wraps():
    with tempfile.TemporaryDirectory() as tmp:
        p = os.path.join(tmp, "a.gif"); _gif(p, 3, ms=100)
        a = strip.load_animation(p, strip.SEG)
        assert len(a.frames) == 3 and a.delays == [250, 250, 250]
        assert [a.index_at(t) for t in (0, 249, 250, 600, 749, 750, 1000)] == [0, 0, 1, 2, 2, 0, 1]
        big = os.path.join(tmp, "big.gif"); _gif(big, 300, ms=300)
        assert len(strip.load_animation(big, strip.SEG).frames) <= strip.MAX_FRAMES


def test_zones_are_four_regions_of_200_by_128_left_to_right():
    plan = strip.StripEngine(FakeMetrics()).plan({"mode": "segments", "segments": [None] * 4}, now=1.0)
    assert [rect for _, rect, _ in plan] == [(0, 0, 200, 128), (200, 0, 200, 128), (400, 0, 200, 128), (600, 0, 200, 128)]
    assert all(draw().size == (200, 128) for _, _, draw in plan)


def test_plan_signature_is_stable_until_the_value_or_frame_changes():
    m = FakeMetrics(); eng = strip.StripEngine(m)
    content = {"mode": "segments", "segments": [{"type": "metric", "kind": "cpu"}, None,
                                                  {"type": "text", "text": "hola"}, {"type": "metric", "kind": "volume"}]}
    a = eng.plan(content, now=100.0)
    m.v = 99.0
    b = eng.plan(content, now=100.5)
    assert [s for s, _, _ in a] == [s for s, _, _ in b]
    c = eng.plan(content, now=101.2)
    assert c[0][0] != a[0][0] and c[1][0] == a[1][0] == ("empty",) and c[2][0] == a[2][0]


def test_animated_segment_changes_signature_with_the_frame():
    with tempfile.TemporaryDirectory() as tmp:
        p = os.path.join(tmp, "a.gif"); _gif(p, 3)
        eng = strip.StripEngine(FakeMetrics()); eng._t0 = 0.0
        content = {"mode": "segments", "segments": [{"type": "gif", "path": p}, None, None, None]}
        sigs = [eng.plan(content, now=t)[0][0] for t in (0.0, 0.1, 0.3, 0.6)]
        assert sigs[0] == sigs[1] and sigs[1] != sigs[2] and sigs[2] != sigs[3]


def test_full_width_image_is_one_region_covering_the_whole_canvas_without_cuts():
    with tempfile.TemporaryDirectory() as tmp:
        src = Image.new("RGB", strip.FULL)
        cols = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
        for i, c in enumerate(cols):
            src.paste(Image.new("RGB", (200, 128), c), (i * 200, 0))
        p = os.path.join(tmp, "wide.png"); src.save(p)
        plan = strip.StripEngine(FakeMetrics()).plan({"mode": "full", "full": {"type": "image", "path": p}}, now=1.0)
        assert len(plan) == 1 and plan[0][1] == (0, 0, 800, 128)
        img = plan[0][2]()
        assert img.size == (800, 128)
        assert [img.getpixel((i * 200 + 100, 60)) for i in range(4)] == cols       # no spacing, no cut
        assert img.getpixel((799, 127)) == cols[3] and img.getpixel((0, 0)) == cols[0]   # first and last pixel kept


def test_compose_pastes_regions_where_the_viewer_sees_them():
    plan = strip.StripEngine(FakeMetrics()).plan({"mode": "segments", "segments": [
        {"type": "text", "text": "A", "bg": "#ff0000"}, None, None, {"type": "text", "text": "D", "bg": "#0000ff"}]}, now=1.0)
    canvas = strip.compose(plan)
    assert canvas.size == (800, 128)
    assert canvas.getpixel((5, 5)) == (255, 0, 0) and canvas.getpixel((795, 5)) == (0, 0, 255)
    assert canvas.getpixel((300, 5)) == strip.BG


def test_missing_and_broken_files_render_a_message_instead_of_crashing():
    with tempfile.TemporaryDirectory() as tmp:
        bad = os.path.join(tmp, "bad.gif"); open(bad, "wb").write(b"GIF89a-not-really")
        plan = strip.StripEngine(FakeMetrics()).plan({"mode": "segments", "segments": [
            {"type": "image", "path": os.path.join(tmp, "nope.png")}, {"type": "gif", "path": bad},
            {"type": "weird"}, {"type": "image", "path": ""}]}, now=1.0)
        assert [s[0] for s, _, _ in plan] == ["missing", "error", "error", "missing"]
        assert all(draw().size == strip.SEG for _, _, draw in plan)
        full = strip.StripEngine(FakeMetrics()).plan({"mode": "full", "full": {"type": "image", "path": "/no/existe.png"}}, now=1.0)
        assert full[0][2]().size == strip.FULL


def test_spanish_accents_render_with_a_real_font_not_boxes():
    from streamstation import fonts
    f = fonts.font(28)
    assert f.getbbox("ó")[1] < f.getbbox("o")[1] and f.getbbox("ñ")[1] < f.getbbox("n")[1]


# --- the geometry confirmed on the device ------------------------------------------------------
def _decode(stream):
    """(header fields, decoded device image) of a DRA stream."""
    assert stream[:3] == b"CRT" and stream[5:8] == b"DRA"
    f = dict(total=int.from_bytes(stream[8:12], "big"), index=stream[12], w=int.from_bytes(stream[13:15], "big"),
             h=int.from_bytes(stream[15:17], "big"), x=int.from_bytes(stream[17:19], "big"), y=int.from_bytes(stream[19:21], "big"))
    return f, Image.open(io.BytesIO(stream[32:])).convert("RGB")


def test_region_is_mirrored_and_rotated_as_the_whole_canvas_would_be():
    """A mark in the viewer's top-left of the canvas must land at the deck's bottom-right, upside down."""
    canvas = Image.new("RGB", strip.FULL, (0, 0, 0))
    ImageDraw.Draw(canvas).rectangle([0, 0, 29, 29], fill=(255, 0, 0))                # viewer top-left
    ImageDraw.Draw(canvas).rectangle([770, 0, 799, 29], fill=(0, 255, 0))             # viewer top-right
    f, dev = _decode(render.strip_stream(canvas, (0, 0, 800, 128)))
    assert (f["x"], f["y"], f["w"], f["h"]) == (0, 0, 800, 128)
    r, g, b = dev.getpixel((785, 112))                                                  # bottom-right of the device image
    assert r > 200 and g < 60 and b < 60
    r, g, b = dev.getpixel((14, 112))                                                   # bottom-left = viewer top-right
    assert g > 200 and r < 60 and b < 60


def test_every_stream_is_aligned_to_the_decoders_16_px_blocks_and_covers_the_request():
    """The deck draws garbage at the edge of regions whose width is not a multiple of 16 (seen on the device)."""
    canvas = Image.new("RGB", strip.FULL, (30, 30, 30))
    for rect in ((0, 0, 200, 128), (200, 0, 200, 128), (400, 0, 200, 128), (600, 0, 200, 128),
                 (0, 0, 800, 128), (100, 20, 333, 50), (7, 3, 1, 1), (200, 30, 400, 64)):
        f, img = _decode(render.strip_stream(canvas, rect))
        assert f["x"] % 16 == 0 and f["y"] % 16 == 0 and f["w"] % 16 == 0 and f["h"] % 16 == 0, (rect, f)
        assert img.size == (f["w"], f["h"])
        x, y, w, h = rect
        dx, dy = 800 - x - w, 128 - y - h                                               # the mirrored request
        assert f["x"] <= dx and f["x"] + f["w"] >= dx + w and f["y"] <= dy and f["y"] + f["h"] >= dy + h, (rect, f)
        assert f["x"] + f["w"] <= 800 and f["y"] + f["h"] <= 128


def test_the_margin_added_for_alignment_carries_the_neighbours_real_content():
    """Zone 1 is 200 wide, so its 208 px stream spills 8 px over zone 2: those columns must be zone 2's colour."""
    canvas = Image.new("RGB", strip.FULL)
    for i, c in enumerate([(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]):
        canvas.paste(Image.new("RGB", (200, 128), c), (i * 200, 0))
    f, dev = _decode(render.strip_stream(canvas, (0, 0, 200, 128)))                       # zone 1 (leftmost for the viewer)
    assert (f["x"], f["w"]) == (592, 208)
    assert dev.getpixel((f["w"] - 20, 60))[0] > 200                                        # zone 1's own red (device right end)
    spill = dev.getpixel((4, 60))                                                          # device x=596: viewer x=203 -> zone 2
    assert spill[1] > 200 and spill[0] < 60, spill                                         # green, not garbage or red


def test_updating_zones_one_by_one_draws_the_same_canvas_as_sending_it_whole():
    canvas = Image.new("RGB", strip.FULL)
    px = canvas.load()
    for x in range(800):
        for y in range(128):
            px[x, y] = (x // 4, y, (x // 200) * 60)
    _, whole = _decode(render.strip_stream(canvas, (0, 0, 800, 128)))
    device = Image.new("RGB", (800, 128))
    for i in range(4):
        f, img = _decode(render.strip_stream(canvas, (i * 200, 0, 200, 128)))
        device.paste(img, (f["x"], f["y"]))
    diff = max(abs(a - b) for a_, b_ in zip(whole.getdata(), device.getdata()) for a, b in zip(a_, b_))
    assert diff < 40                                                                       # only JPEG noise at block edges


def test_regions_outside_the_canvas_or_a_wrong_canvas_are_refused():
    canvas = Image.new("RGB", strip.FULL)
    for rect in ((750, 0, 100, 50), (0, 100, 100, 50), (-1, 0, 100, 50), (0, 0, 0, 10)):
        try: render.strip_stream(canvas, rect)
        except ValueError: continue
        raise AssertionError(rect)
    try: render.strip_stream(Image.new("RGB", (100, 50)), (0, 0, 10, 10))
    except ValueError: pass
    else: raise AssertionError("canvas of the wrong size")
    assert len(render.strip_region_stream(Image.new("RGB", (100, 50)), 700, 78, 100, 50)) > 32


def test_sharp_jpeg_keeps_full_colour_resolution_and_fits_the_bat_limit():
    from PIL import JpegImagePlugin
    img = Image.new("RGB", (208, 124))
    px = img.load()
    for x in range(208):
        for y in range(124):
            px[x, y] = (255, 0, 0) if (x // 2) % 2 else (0, 0, 255)
    sharp, soft = render.to_jpeg(img, (208, 124), sharp=True), render.to_jpeg(img, (208, 124))
    assert sharp[:2] == b"\xff\xd8" and len(sharp) <= 0xFFFF
    sub = lambda b: JpegImagePlugin.get_sampling(Image.open(io.BytesIO(b)))
    assert sub(sharp) == 0 and sub(soft) != 0


def test_fonts_list_only_fonts_that_draw_real_letters_and_the_strip_uses_the_chosen_one():
    from streamstation import fonts
    from PIL import Image, ImageChops
    usable = fonts.usable()
    if not usable:
        return
    names = [f["family"] for f in usable]
    assert names == sorted(names, key=str.lower) and len(set(names)) == len(names)
    assert not any(w in n.lower() for n in names for w in ("dingbat", "symbol", "emoji"))
    first = usable[0]
    assert fonts.resolve(first["family"]) == first["regular"] and fonts.resolve("No Existe XYZ") is None and fonts.resolve(None) is None
    assert fonts.renders_text(first["regular"]) and not fonts.renders_text("/no/such/font.ttf")
    # a font that draws empty/same boxes for the sample is rejected: the default PIL bitmap font cannot do accents
    from PIL import ImageFont
    assert fonts.font(20, False, "No Existe XYZ") is not None                # unknown family falls back to the default font
    other = next((f for f in usable if f["family"] != usable[0]["family"] and f["regular"] != first["regular"]), None)
    if other:
        a = strip.text_image({"type": "text", "text": "Hola Ñandú", "size": 30, "font": first["family"]})
        b = strip.text_image({"type": "text", "text": "Hola Ñandú", "size": 30, "font": other["family"]})
        assert ImageChops.difference(a, b).getbbox() is not None            # a different typeface really changes the picture
        m1 = strip.metric_image("clock", strip.Metrics(), ("12:34", "sáb"), first["family"])
        m2 = strip.metric_image("clock", strip.Metrics(), ("12:34", "sáb"), other["family"])
        assert ImageChops.difference(m1, m2).getbbox() is not None
    eng = strip.StripEngine()
    sig1 = eng.plan({"mode": "segments", "segments": [{"type": "metric", "kind": "clock"}, None, None, None]})[0][0]
    sig2 = eng.plan({"mode": "segments", "segments": [{"type": "metric", "kind": "clock", "font": first["family"]}, None, None, None]})[0][0]
    assert sig1 != sig2                                                      # changing the font makes the service repaint that panel


# ---------------------------------------------------------------------------------- weather widget -----------
def _fake_opener(payloads, calls=None):
    import io, json, urllib.error

    class R(io.BytesIO):
        def __enter__(self): return self
        def __exit__(self, *a): return False

    def opener(req, timeout=0):
        if calls is not None:
            calls.append(req.full_url)
        for needle, body in payloads.items():
            if needle in req.full_url:
                if isinstance(body, Exception):
                    raise body
                return R(json.dumps(body).encode() if not isinstance(body, bytes) else body)
        raise urllib.error.URLError("no route")
    return opener


GEO = {"results": [{"name": "Rosario", "latitude": -32.94682, "longitude": -60.63932, "admin1": "Santa Fe", "country": "Argentina"},
                   {"name": "Rosario", "latitude": 10.3, "longitude": -72.3, "admin1": "Zulia", "country": "Venezuela"},
                   {"broken": True}]}
CUR = {"current": {"temperature_2m": 23.4, "weather_code": 2, "is_day": 1}}


def test_weather_search_parses_places_and_reports_network_errors():
    import urllib.error
    from streamstation import weather
    calls = []
    places = weather.search("  Rosario ", opener=_fake_opener({"geocoding-api": GEO}, calls))
    assert [p.label for p in places] == ["Rosario, Santa Fe, Argentina", "Rosario, Zulia, Venezuela"]    # the broken row is skipped
    assert "name=Rosario" in calls[0] and "language=es" in calls[0]
    assert places[0].as_spec() == {"name": "Rosario", "lat": -32.9468, "lon": -60.6393, "label": "Rosario, Santa Fe, Argentina"}
    assert weather.search("   ", opener=_fake_opener({})) == []
    try:
        weather.search("x", opener=_fake_opener({"geocoding-api": urllib.error.URLError("sin red")}))
    except weather.WeatherError:
        pass
    else:
        raise AssertionError("a network failure must raise WeatherError")
    assert weather.search("zz", opener=_fake_opener({"geocoding-api": {}})) == []


def test_weather_codes_map_to_the_right_picture_and_description():
    from streamstation import weather
    d = weather.describe
    assert d(0)[0] == "clear" and d(2) == ("partly", "Parcialmente nublado") and d(3)[0] == "cloudy" and d(45)[0] == "fog"
    assert d(53)[0] == "drizzle" and d(63)[0] == "rain" and d(65)[1] == "Lluvia fuerte" and d(75)[0] == "snow" and d(95)[0] == "storm"
    assert d(999)[0] == "cloudy"                                                      # an unknown code never breaks the panel
    assert weather.parse_current(CUR) == weather.Reading(23.4, 2, True)
    assert weather.parse_current({}) is None and weather.parse_current({"current": {"temperature_2m": "x"}}) is None
    assert round(weather.to_unit(0, "f")) == 32 and weather.to_unit(21, "c") == 21


def test_weather_service_never_blocks_caches_and_backs_off_after_a_failure():
    from streamstation import weather
    calls = []
    clock = {"t": 0.0}
    svc = weather.Service(opener=_fake_opener({"api.open-meteo": CUR}, calls), ttl=900, retry=120, clock=lambda: clock["t"])
    assert svc.get(-32.95, -60.64) is None and svc.state(-32.95, -60.64) in ("loading", "ok")    # returns at once, fetches in the background
    assert svc.wait()
    r = svc.get(-32.95, -60.64)
    assert r == weather.Reading(23.4, 2, True) and svc.state(-32.95, -60.64) == "ok" and len(calls) == 1
    assert "latitude=-32.95" in calls[0] and "longitude=-60.64" in calls[0] and "streamstation" not in calls[0]   # only coordinates are sent
    svc.get(-32.95, -60.64); assert svc.wait() and len(calls) == 1                             # fresh: no new request
    clock["t"] = 901
    assert svc.get(-32.95, -60.64) == r and svc.wait() and len(calls) == 2                      # stale: old value now, refresh behind
    bad = weather.Service(opener=_fake_opener({"api.open-meteo": OSError("down")}, calls), retry=120, clock=lambda: clock["t"])
    assert bad.get(1, 2) is None and bad.wait() and bad.state(1, 2) == "error"
    n = len(calls); bad.get(1, 2); bad.wait()
    assert len(calls) == n                                                                      # backing off: it does not hammer the server
    clock["t"] += 200; bad.get(1, 2); bad.wait(); assert len(calls) == n + 1                    # and tries again later


def test_weather_pictures_and_the_strip_panel():
    from PIL import Image, ImageChops
    from streamstation import weather, weatherart
    kinds = ["clear", "partly", "cloudy", "fog", "drizzle", "rain", "snow", "storm", "mystery"]
    seen = set()
    for kind in kinds:
        for day in (True, False):
            ic = weatherart.icon(kind, day, 64)
            assert ic.size == (64, 64) and ic.getchannel("A").getbbox() is not None, (kind, day)
            seen.add(ic.tobytes())
    assert len(seen) == 11                                                                      # 7 skies + day/night for the clear and partly ones + the fallback
    place = {"name": "Rosario", "lat": -32.95, "lon": -60.64}
    img = weatherart.widget_image(weather.Reading(23.4, 0, True), place)
    assert img.size == (200, 128) and img.mode == "RGB"
    assert any(c[0] > 240 and c[1] > 180 and c[2] < 80 for c in img.crop((0, 0, 90, 100)).getdata())   # a yellow sun on the left
    assert any(sum(c) > 700 for c in img.crop((92, 20, 200, 70)).getdata())                              # the big white temperature
    f = weatherart.widget_image(weather.Reading(31, 0, True), place, "f")
    assert ImageChops.difference(f, img).getbbox() is not None
    assert weatherart.widget_image(None, place, "c", None, "loading").getbbox() is not None
    assert ImageChops.difference(weatherart.widget_image(None, place, "c", None, "loading"), weatherart.widget_image(None, place, "c", None, "error")).getbbox() is not None
    assert weatherart.widget_image(None, None).getbbox() is not None                                    # "Elige una ciudad"
    long = weatherart.widget_image(weather.Reading(5, 3, False), {"name": "Ciudad con un nombre larguísimo de verdad", "lat": 1, "lon": 2})
    assert long.size == (200, 128)                                                                      # long names are shrunk or cut, never overflow
    # the strip engine: a weather segment repaints only when what it shows changes
    svc = weather.SERVICE
    saved = (svc._opener, dict(svc._data))
    try:
        svc._opener = _fake_opener({"api.open-meteo": CUR})
        svc._data.clear(); svc._fail.clear()
        eng = strip.StripEngine()
        content = {"mode": "segments", "segments": [{"type": "weather", "place": place}, None, None, None]}
        sig0, draw0 = eng.plan(content)[0][0], None
        assert svc.wait()
        sig1, rect, draw = eng.plan(content)[0]
        assert sig1 != sig0 and draw().size == (200, 128)                                               # arrival of the reading triggers a redraw
        assert eng.plan(content)[0][0] == sig1                                                         # and then it is stable
        c2 = {"mode": "segments", "segments": [{"type": "weather", "place": place, "units": "f"}, None, None, None]}
        assert eng.plan(c2)[0][0] != sig1
        empty = eng.plan({"mode": "segments", "segments": [{"type": "weather"}, None, None, None]})[0]
        assert empty[2]().size == (200, 128)                                                           # no city chosen yet: still a valid panel
    finally:
        svc._opener, svc._data = saved[0], saved[1]
