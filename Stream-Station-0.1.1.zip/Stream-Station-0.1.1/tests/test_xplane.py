import json, os, sys, pathlib, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from streamstation.xplane import catalog, glyphs, link, states

REAL = catalog.find_install()


# ---------------------------------------------------------------- a fake X-Plane web API ----------
class FakeSim:
    def __init__(self):
        self.values = {"sim/cockpit/electrical/landing_lights_on": 0, "sim/cockpit/electrical/generator_on": [1, 0, 0],
                       "sim/cockpit2/autopilot/heading_status": 1}
        self.commands = {"sim/lights/landing_lights_toggle": 11}
        self.ids = {n: 100 + i for i, n in enumerate(self.values)}
        self.activated = []
        self.requests = []
        sim = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, obj, code=200):
                body = json.dumps(obj).encode()
                self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
            def do_GET(self):
                sim.requests.append(self.path)
                if self.path == "/api/capabilities":
                    return self._send({"api": {"versions": ["v1", "v2"]}, "x-plane": {"version": "12.4.4"}})
                if "/datarefs?filter" in self.path:
                    name = self.path.split("filter[name]=")[1].replace("%2F", "/")
                    return self._send({"data": [{"id": sim.ids[name], "name": name}] if name in sim.ids else []})
                if "/datarefs/" in self.path and self.path.endswith("/value"):
                    ident = int(self.path.split("/datarefs/")[1].split("/")[0])
                    name = next(n for n, i in sim.ids.items() if i == ident)
                    return self._send({"data": sim.values[name]})
                if "/commands?filter" in self.path:
                    name = self.path.split("filter[name]=")[1].replace("%2F", "/")
                    return self._send({"data": [{"id": sim.commands[name], "name": name}] if name in sim.commands else []})
                self._send({"error": "nope"}, 404)
            def do_POST(self):
                length = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(length) or b"{}")
                sim.activated.append((self.path, body))
                self._send({}, 200)
        self.server = HTTPServer(("127.0.0.1", 0), H)
        self.url = f"http://127.0.0.1:{self.server.server_port}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown(); self.server.server_close()


# ------------------------------------------------------------------------------ catalog -----------
def test_parsers_read_the_real_files_when_x_plane_is_installed():
    if not REAL:
        return
    cmds = catalog.load_commands(REAL)
    assert len(cmds) > 2000 and any(c.name == "sim/lights/landing_lights_toggle" and c.title == "Landing lights toggle" for c in cmds)
    refs = catalog.load_datarefs(REAL)
    assert len(refs) > 4000 and refs["sim/cockpit/electrical/landing_lights_on"].type == "int"
    assert refs["sim/cockpit/electrical/generator_on"].is_array and not refs["sim/time/paused"].writable
    groups = catalog.by_category(cmds)
    assert list(groups)[0] == "Luces" and "Piloto automático" in groups and "sim/none/none" not in [c.name for g in groups.values() for c in g]
    hits = catalog.search(cmds, "landing gear toggle")
    assert hits and all("landing" in c.name.lower() or "landing" in c.description.lower() for c in hits)
    assert len(catalog.search(cmds, "")) == len(cmds) and catalog.search(cmds, "zzzz_no_existe") == []


def test_parsers_survive_a_small_fixture_and_junk():
    with tempfile.TemporaryDirectory() as tmp:
        d = os.path.join(tmp, "X-Plane 12", "Resources", "plugins"); os.makedirs(d)
        open(os.path.join(d, "Commands.txt"), "w").write("sim/lights/nav_lights_on    Nav lights on.\n\nbad line without slash\n# comment\nsim/none/none  Do nothing.\nsim/view/chase\n")
        open(os.path.join(d, "DataRefs.txt"), "w").write("2 1210 header\n\nsim/time/paused\tint\tn\tboolean\tIs paused\t\nbroken\tline\nsim/x/y\tfloat[4]\ty\tm\tdesc\t\n")
        inst = catalog.find_install(os.path.join(tmp, "X-Plane 12"))
        assert inst and catalog.find_install(os.path.join(tmp, "nada")) in (None, REAL)
        cmds = catalog.load_commands(inst)
        assert [c.name for c in cmds] == ["sim/lights/nav_lights_on", "sim/none/none", "sim/view/chase"]
        assert cmds[0].category == "lights" and cmds[2].title == "chase"                      # no description: falls back to the name
        refs = catalog.load_datarefs(inst)
        assert set(refs) == {"sim/time/paused", "sim/x/y"} and refs["sim/x/y"].is_array and refs["sim/x/y"].writable


# ------------------------------------------------------------------------------- states -----------
def test_state_templates_cover_off_standby_on_and_formatting():
    ev = states.evaluate
    onoff = {"dataref": "d", "template": "onoff"}
    assert (ev(onoff, 0).name, ev(onoff, 0).label) == ("off", "APAGADO") and ev(onoff, 1).name == "on" and ev(onoff, 1.0).label == "ENCENDIDO"
    ap = {"dataref": "d", "template": "off_armed_on"}
    assert [ev(ap, v).name for v in (0, 1, 2, 3)] == ["off", "standby", "on", "on"] and ev(ap, 1).label == "EN ESPERA"
    ratio = {"dataref": "d", "template": "ratio_pct"}
    assert ev(ratio, 0).name == "off" and ev(ratio, 1).name == "on" and ev(ratio, 0.5).label == "50%" and ev(ratio, 0.5).name == "standby"
    assert ev({"dataref": "d", "template": "paused"}, 1).name == "warn" and ev({"dataref": "d", "template": "gear"}, 1).label == "ABAJO"


def test_custom_rules_first_match_wins_and_bad_input_never_raises():
    ev = states.evaluate
    spec = {"dataref": "d", "states": [{"gt": 90, "name": "warn", "label": "ALTO {value:.0f}"}, {"between": [10, 90], "name": "on", "color": "#123456"}]}
    assert (ev(spec, 95).name, ev(spec, 95).label) == ("warn", "ALTO 95") and ev(spec, 50).color == "#123456"
    assert ev(spec, 5).name == "unknown" and ev(spec, 5).label == "5"                      # nothing matched
    assert ev(None, 1).name == "unknown" and ev({}, 1).name == "unknown" and ev({"dataref": "d"}, "x").name == "unknown"
    assert ev(onoff := {"dataref": "d"}, None).name == "offline" and ev(onoff, 1, online=False).label == "SIN SIM"
    assert ev({"dataref": "d", "states": [{"eq": 1, "label": "{bad}"}]}, 1).label == "{bad}"   # broken format string is kept as text
    assert ev({"dataref": "d", "states": ["junk", {"zzz": 1}]}, 1).name == "unknown"


def test_curated_table_only_references_names_that_exist_in_the_real_x_plane():
    """The table is checked against the user's own Commands.txt / DataRefs.txt, so no state can point at a typo."""
    if not REAL:
        return
    names = {c.name for c in catalog.load_commands(REAL)}
    refs = catalog.load_datarefs(REAL)
    known = list(states.EXACT) + list(states.SPECS)
    for base in states.BASES:
        known += [base + s for s in ("_toggle", "_tog", "_on", "_off") if base + s in names]
    assert len(known) > 40
    for cmd in known:
        assert cmd in names, cmd
        s = states.suggest(cmd)
        assert s and all(n in refs for n, _ in states.refs(s)), (cmd, s)
        assert s.get("states") or states.halves(s) is not None or s["template"] in states.TEMPLATES
        if "index" in s:
            assert refs[s["dataref"]].is_array, cmd
    assert states.suggest("sim/lights/landing_lights_toggle") == {"dataref": "sim/cockpit/electrical/landing_lights_on", "template": "onoff"}
    assert states.suggest("sim/electrical/generator_1_off")["index"] == 0 and states.suggest("sim/view/chase") is None


# ------------------------------------------------------------------------------- glyphs -----------
def test_glyph_choice_by_name_and_tiles_have_the_key_size():
    assert glyphs.pick_glyph("sim/lights/landing_lights_toggle") == "bulb"
    assert glyphs.pick_glyph("sim/flight_controls/landing_gear_down") == "gear"
    assert glyphs.pick_glyph("sim/autopilot/heading", "Autopilot heading-select.") == "autopilot"
    assert glyphs.pick_glyph("sim/fuel/fuel_pump_1_on") == "drop" and glyphs.pick_glyph("sim/operation/pause_toggle") == "pause"
    assert glyphs.pick_glyph("sim/zzz/qqq") == "plane" and glyphs.abbreviation("sim/foo/bar_baz_toggle") == "BB"
    for name in list(glyphs.GLYPHS) + ["nope"]:
        g = glyphs.glyph_image(name, 40)
        assert g.size == (40, 40) and g.getbbox() is not None                                 # something was drawn
        assert glyphs.neutral_tile(name).size == (128, 128)
    on = glyphs.state_tile("bulb", states.evaluate({"dataref": "d"}, 1))
    off = glyphs.state_tile("bulb", states.evaluate({"dataref": "d"}, 0))
    assert on.size == (128, 128) and on.getpixel((3, 3))[:3] != off.getpixel((3, 3))[:3]      # colour follows the state
    assert glyphs.state_tile("bulb", states.StateView("on", "ETIQUETA MUY LARGA QUE NO CABE EN LA TECLA", "#27ae60")).size == (128, 128)


# --------------------------------------------------------------------------------- link -----------
def test_link_reads_values_arrays_and_runs_commands_against_a_fake_sim():
    sim = FakeSim()
    try:
        lk = link.XPlaneLink(sim.url)
        assert lk.capabilities()["x-plane"]["version"] == "12.4.4" and lk._version == "v2"
        assert lk.read("sim/cockpit/electrical/landing_lights_on") == 0
        assert lk.read("sim/cockpit/electrical/generator_on", 0) == 1 and lk.read("sim/cockpit/electrical/generator_on", 2) == 0
        n = len(sim.requests); lk.read("sim/cockpit/electrical/landing_lights_on")
        assert len(sim.requests) == n + 1                                                      # the id lookup is cached
        lk.command("sim/lights/landing_lights_toggle")
        assert sim.activated == [("/api/v2/command/11/activate", {"duration": 0})]
        for bad in (lambda: lk.read("sim/not/a/dataref"), lambda: lk.command("sim/not/a/command")):
            try: bad()
            except link.XPlaneError: pass
            else: raise AssertionError("unknown names must raise XPlaneError")
    finally:
        sim.close()


def test_link_polls_in_the_background_follows_changes_and_reports_offline():
    sim = FakeSim()
    lk = link.XPlaneLink(sim.url)
    try:
        key = ("sim/cockpit2/autopilot/heading_status", None)
        lk.set_watch([key])
        for _ in range(40):
            if lk.value(*key) is not None: break
            time.sleep(0.05)
        assert lk.value(*key) == 1 and lk.online
        sim.values["sim/cockpit2/autopilot/heading_status"] = 2
        for _ in range(40):
            if lk.value(*key) == 2: break
            time.sleep(0.05)
        assert lk.value(*key) == 2                                                             # a change in the sim reaches the cache
        lk.set_watch([]); assert lk.value(*key) is None                                        # unwatched values are dropped
    finally:
        lk.close(); sim.close()
    down = link.XPlaneLink("http://127.0.0.1:1", timeout=0.2)
    down.set_watch([("x/y", None)]); time.sleep(0.4)
    assert down.online is False and down.value("x/y") is None
    try: down.command("sim/x")
    except link.XPlaneError as exc: assert "not reachable" in str(exc)
    else: raise AssertionError
    down.close()


def test_annunciator_and_multi_dataref_states():
    ev = states.evaluate
    mc = states.suggest("sim/annunciator/clear_master_caution")
    assert ev(mc, 0).name == "off" and ev(mc, 1).name == "standby" and ev(mc, 1).label == "CAUTION"     # lit while the warning is present
    ap = states.suggest("sim/autopilot/servos_toggle")
    assert states.halves(ap) is not None and states.halves({"dataref": "x"}) is None
    assert states.refs(ap) == [("sim/cockpit2/annunciators/autopilot_disconnect", None), ("sim/cockpit2/autopilot/servos_on", None)]
    vals = {"sim/cockpit2/autopilot/servos_on": 1, "sim/cockpit2/annunciators/autopilot_disconnect": 0}
    top, bottom = states.views(ap, lambda n, i=None: vals[n])
    assert (top.name, bottom.name, bottom.label) == ("off", "on", "ON")
    vals["sim/cockpit2/annunciators/autopilot_disconnect"] = 1; vals["sim/cockpit2/autopilot/servos_on"] = 0
    top, bottom = states.views(ap, lambda n, i=None: vals[n])
    assert (top.name, bottom.name, bottom.label) == ("warn", "off", "OFF")        # the two lamps are independent
    assert [v.name for v in states.views(ap, lambda n, i=None: None)] == ["offline", "offline"]
    assert [v.name for v in states.views({"top": {}, "bottom": {"dataref": "x"}}, lambda n, i=None: 1)] == ["unknown", "on"]
    assert len(states.views({"dataref": "x"}, lambda n, i=None: 0)) == 1
    tile = glyphs.switch_tile(states.views(ap, lambda n, i=None: vals[n]), "AP")
    assert tile.size == (128, 128) and tile.getpixel((64, 20))[:3] != tile.getpixel((64, 108))[:3]   # red top lamp, grey bottom lamp
    two = {"dataref": ["a", "b"], "template": "onoff"}
    assert ev(two, [0, 1]).name == "on" and ev({**two, "combine": "all"}, [0, 1]).name == "off"
    nested = {"dataref": ["a", "b"], "states": [{"all": [{"ref": 0, "ne": 0}, {"ref": 1, "eq": 0}], "name": "on"}, {"ref": 0, "ge": -1e9, "name": "off"}]}
    assert ev(nested, [1, 0]).name == "on" and ev(nested, [1, 1]).name == "off"
    assert states.refs({"dataref": "x", "index": 2}) == [("x", 2)] and states.refs(None) == []


# ---------------------------------------------------------------------------- aircraft explorer -----------
from streamstation.xplane import aircraft


def _fake_aircraft(tmp):
    d = os.path.join(tmp, "Aircraft", "Other Aircraft", "Fake 737"); os.makedirs(d)
    open(os.path.join(d, "f.acf"), "w").write("I\n")
    open(os.path.join(d, "F_Datarefs.txt"), "w").write(
        "Release 1\n---------\n\nAUTOPILOT LIGHTS (read only)\n----------------------------\n"
        "N1\t\t\tfake/ap/n1_status\nHDG SEL\t\tfake/ap/hdg_sel_status\n\n"
        "AUTOPILOT SWITCHES (read/write)\n-------------------------------\nF/D captain\t\t0-off, 1-on\t\tfake/switches/ap/fd_ca\n\n"
        "ANNUNCIATORS\n------------\nCAUTION LIGHT\t\t\tfake/annunciator/master_caution_light\n")
    open(os.path.join(d, "F_Commands.txt"), "w").write(
        "-- ap.lua\nfake/ap/n1_press\t\t\tAutopilot N1 press\nfake/ap/hdg_sel_press\tAutopilot HDG press\n"
        "-- misc\nfake/push_button/master_caution1\tCaptain master caution\nfake/misc/unrelated\tSomething else\nnot a command line\n")
    open(os.path.join(d, "cockpit.obj"), "w").write(
        "A\n800\nOBJ\n"
        "ANIM_begin\nANIM_trans 0 0 0 0 0 0 0 1 fake/anim/outer_pos\nANIM_begin\nANIM_show 1 1 fake/anim/switch_lamp\n"
        "ATTR_manip_command\thand\tfake/cmd/landing_light_toggle\tLanding light\nTRIS 0 3\nANIM_end\n"
        "ATTR_manip_toggle\tswitch_up_down\t1.0\t0.0\tfake/sw/taxi\tTaxi light switch\nANIM_end\n"
        "ATTR_manip_command_knob rotate_large fake/cmd/cw fake/cmd/ccw Heading knob\nATTR_manip_noop\n")
    return d


def test_aircraft_doc_parsers_read_sections_labels_and_commands():
    with tempfile.TemporaryDirectory() as tmp:
        d = _fake_aircraft(tmp)
        drs, cmds = aircraft.doc_files(d)
        assert [os.path.basename(p) for p in drs] == ["F_Datarefs.txt"] and [os.path.basename(p) for p in cmds] == ["F_Commands.txt"]
        entries = aircraft.parse_dataref_doc(drs[0])
        by = {e.name: e for e in entries}
        assert by["fake/ap/n1_status"].label == "N1" and by["fake/ap/n1_status"].readonly and by["fake/ap/n1_status"].section.startswith("AUTOPILOT LIGHTS")
        assert by["fake/switches/ap/fd_ca"].values == "0-off, 1-on" and not by["fake/switches/ap/fd_ca"].readonly
        cm = aircraft.parse_command_doc(cmds[0])
        assert [c.name for c in cm][:2] == ["fake/ap/n1_press", "fake/ap/hdg_sel_press"] and cm[0].description == "Autopilot N1 press"
        assert len(cm) == 4 and cm[2].section == "misc"
        inst = tmp
        assert [a["name"] for a in aircraft.list_aircraft(inst)] == ["Fake 737"]


def test_aircraft_pairs_commands_with_lamps_and_keeps_unpaired_ones_low():
    with tempfile.TemporaryDirectory() as tmp:
        d = _fake_aircraft(tmp)
        controls = aircraft.scan(d)["controls"]
        by = {c.command: c for c in controls if c.command}
        n1 = by["fake/ap/n1_press"]
        assert n1.state == "fake/ap/n1_status" and n1.title == "N1" and n1.confidence >= 0.8 and n1.readonly_state
        assert by["fake/ap/hdg_sel_press"].state == "fake/ap/hdg_sel_status"
        mc = by["fake/push_button/master_caution1"]                      # different folder: found by the looser pass
        assert mc.state == "fake/annunciator/master_caution_light" and 0.5 <= mc.confidence < 0.8
        assert by["fake/misc/unrelated"].state == "" and by["fake/misc/unrelated"].confidence < 0.5
        assert any(c.state == "fake/switches/ap/fd_ca" and not c.command for c in controls)   # a switch with no command of its own
        assert aircraft.stem("laminar/B738/autopilot/hdg_sel_status") == "hdg_sel" and aircraft.stem("a/b/n1_press") == "n1"


def test_aircraft_obj_parser_links_manipulators_to_their_animation_datarefs():
    with tempfile.TemporaryDirectory() as tmp:
        d = _fake_aircraft(tmp)
        manips = aircraft.parse_obj(os.path.join(d, "cockpit.obj"))
        assert [m.kind for m in manips] == ["command", "toggle", "command"]          # ATTR_manip_noop is skipped
        light = manips[0]
        assert light.commands == ["fake/cmd/landing_light_toggle"] and light.tooltip == "Landing light"
        assert light.anim == ["fake/anim/switch_lamp", "fake/anim/outer_pos"]          # innermost block first
        tog = manips[1]
        assert tog.dataref == "fake/sw/taxi" and tog.tooltip == "Taxi light switch" and tog.anim == ["fake/anim/outer_pos"]
        assert manips[2].commands == ["fake/cmd/cw", "fake/cmd/ccw"] and manips[2].tooltip == "Heading knob"
        objc = {c.command or c.state: c for c in aircraft.controls_from_objs(manips)}
        assert objc["fake/cmd/landing_light_toggle"].state == "fake/anim/switch_lamp" and objc["fake/cmd/landing_light_toggle"].confidence == 0.5
        assert objc["fake/sw/taxi"].confidence == 0.7 and not objc["fake/sw/taxi"].readonly_state
        assert [c.title for c in aircraft.search(list(objc.values()), "taxi")] == ["Taxi light switch"]


def test_aircraft_explorer_on_the_real_737ng_when_installed():
    if not REAL:
        return
    found = [a for a in aircraft.list_aircraft(REAL) if "737NG" in a["name"]]
    if not found:
        return
    r = aircraft.scan(found[0]["path"])
    pairs = {c.command: c for c in r["controls"] if c.command and c.state and c.confidence >= 0.8}
    assert len(pairs) > 25 and r["datarefs_documented"] > 200
    assert pairs["laminar/B738/autopilot/alt_hld_press"].state == "laminar/B738/autopilot/alt_hld_status"


def test_detect_aircraft_from_the_path_x_plane_reports_and_read_text_datarefs():
    listing = [{"name": "737NG Series_v2.S1.50", "path": "/x/737NG Series_v2.S1.50", "acf": []},
               {"name": "Cessna 172 SP", "path": "/x/Cessna 172 SP", "acf": []}, {"name": "Cessna", "path": "/x/Cessna", "acf": []}]
    d = aircraft.detect_folder
    assert d("Aircraft/Other Aircraft/737NG Series_v2.S1.50/737_70NG.acf", listing)["name"] == "737NG Series_v2.S1.50"
    assert d("Aircraft\\Laminar Research\\Cessna 172 SP\\Cessna_172SP.acf", listing)["name"] == "Cessna 172 SP"   # longest name wins
    assert d("Aircraft/Other/Unknown Plane/x.acf", listing) is None and d("", listing) is None
    import base64
    sim = FakeSim(); sim.values["sim/aircraft/view/acf_relative_path"] = base64.b64encode(b"Aircraft/Cessna/c.acf\0\0\0").decode()
    sim.ids["sim/aircraft/view/acf_relative_path"] = 900
    try:
        lk = link.XPlaneLink(sim.url)
        assert lk.read_text("sim/aircraft/view/acf_relative_path") == "Aircraft/Cessna/c.acf"
    finally:
        sim.close()
