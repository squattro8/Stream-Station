"""Linux implementations of the original app's plugin actions.

Action strings (``verb:arg``) usable anywhere an ``action``/``press``/``cw`` is allowed.
Each maps to an original plugin action (see FEATURES.md). Nothing here needs
extra packages: volume uses wpctl, media uses MPRIS through busctl, key
injection uses /dev/uinput through python-evdev.

  key:ctrl+shift+t            system.hotkey, browser.*, quickcontrol hotkeys
  text:hello                  system.text   (US keyboard layout, ASCII only)
  volume:up[:5] volume:down[:5] volume:mute volume:set:40     system.volume / quickcontrol
  mic:mute                    quickcontrol.microphone
  media:play-pause|next|prev|stop|volume-up[:N]|volume-down[:N]  system.multimedia (player volume via MPRIS)
  open:<path-or-desktop-id>   system.open / openApps
  url:<https://...>           system.website
  sound:play:<file>  sound:stop                                soundboard
  udp:<host>:<port>:<message>                                  network.udp
  browser:back|forward|refresh|collect                         browser.*
  desktop:show|overview|switch-screen|search|emoji|dnd|clear-notifications   KDE actions via D-Bus
  kde:<component>:<action>    any KGlobalAccel action, e.g. kde:kwin:Show Desktop
  tool:calculator|mail|home|taskmanager|controlpanel|music     quicktool.*
"""
from __future__ import annotations

import os
import shutil
import signal
import socket
import subprocess
import time

# KDE Plasma default shortcuts for the original "hotkey" plugin actions.
ALIASES = {
    "browser:back": "key:alt+left",
    "browser:forward": "key:alt+right",
    "browser:refresh": "key:f5",
    "browser:collect": "key:ctrl+d",
    # KDE actions invoked through KGlobalAccel: independent of the keys the user bound.
    "desktop:show": "kde:kwin:Show Desktop",
    "desktop:overview": "kde:kwin:Overview",
    "desktop:switch-screen": "kde:kwin:Switch to Next Screen",
    "desktop:search": "kde:org_kde_krunner_desktop:_launch",
    "desktop:emoji": "kde:org_kde_plasma_emojier_desktop:_launch",
    "desktop:dnd": "kde:plasmashell:toggle do not disturb",
    "desktop:clear-notifications": "kde:plasmashell:clear-history",
    "tool:taskmanager": "kde:org_kde_plasma_systemmonitor_desktop:_launch",
}
# Not available as a global KDE action (the notification popup is a tray widget with a
# per-user id), so it is refused with a pointer instead of guessing a key.
UNSUPPORTED = {"desktop:notifications": "KDE has no global 'open notifications' action; "
                                       "use desktop:dnd or desktop:clear-notifications"}

TOOLS = {
    "calculator": [["kcalc"], ["gnome-calculator"]],
    "controlpanel": [["systemsettings"], ["gnome-control-center"]],
    "mail": [["xdg-open", "mailto:"]],
    "music": [["gtk-launch", "org.kde.elisa"], ["elisa"]],
    "home": [["xdg-open", "https://"]],
}

MODS = {"ctrl": "KEY_LEFTCTRL", "control": "KEY_LEFTCTRL", "shift": "KEY_LEFTSHIFT",
        "alt": "KEY_LEFTALT", "meta": "KEY_LEFTMETA", "super": "KEY_LEFTMETA", "win": "KEY_LEFTMETA"}
KEY_NAMES = {"esc": "KEY_ESC", "enter": "KEY_ENTER", "return": "KEY_ENTER", "space": "KEY_SPACE",
             "tab": "KEY_TAB", "left": "KEY_LEFT", "right": "KEY_RIGHT", "up": "KEY_UP",
             "down": "KEY_DOWN", "period": "KEY_DOT", "comma": "KEY_COMMA", "minus": "KEY_MINUS",
             "backspace": "KEY_BACKSPACE", "delete": "KEY_DELETE", "home": "KEY_HOME",
             "end": "KEY_END", "pageup": "KEY_PAGEUP", "pagedown": "KEY_PAGEDOWN"}

# ASCII punctuation on a US layout: char -> (key name, needs shift)
US_PUNCT = {
    " ": ("SPACE", 0), "\n": ("ENTER", 0), "\t": ("TAB", 0),
    "-": ("MINUS", 0), "_": ("MINUS", 1), "=": ("EQUAL", 0), "+": ("EQUAL", 1),
    "[": ("LEFTBRACE", 0), "{": ("LEFTBRACE", 1), "]": ("RIGHTBRACE", 0), "}": ("RIGHTBRACE", 1),
    ";": ("SEMICOLON", 0), ":": ("SEMICOLON", 1), "'": ("APOSTROPHE", 0), '"': ("APOSTROPHE", 1),
    ",": ("COMMA", 0), "<": ("COMMA", 1), ".": ("DOT", 0), ">": ("DOT", 1),
    "/": ("SLASH", 0), "?": ("SLASH", 1), "\\": ("BACKSLASH", 0), "|": ("BACKSLASH", 1),
    "`": ("GRAVE", 0), "~": ("GRAVE", 1),
    "!": ("1", 1), "@": ("2", 1), "#": ("3", 1), "$": ("4", 1), "%": ("5", 1),
    "^": ("6", 1), "&": ("7", 1), "*": ("8", 1), "(": ("9", 1), ")": ("0", 1),
}


def parse_combo(spec: str) -> list[str]:
    """'ctrl+shift+t' -> ['KEY_LEFTCTRL', 'KEY_LEFTSHIFT', 'KEY_T'] (modifiers first)."""
    parts = [p.strip().lower() for p in spec.split("+") if p.strip()]
    if not parts:
        raise ValueError("empty key combo")
    for p in parts[:-1]:
        if p not in MODS:
            raise ValueError(f"unknown modifier {p!r}")
    names = [MODS[p] for p in parts[:-1]]
    last = parts[-1]
    if last in MODS:
        names.append(MODS[last])
    else:
        names.append(KEY_NAMES.get(last) or ("KEY_" + last.upper()))
    return names


def char_keys(ch: str) -> tuple[str, bool]:
    if ch.isascii() and ch.isalpha():
        return "KEY_" + ch.upper(), ch.isupper()
    if ch.isascii() and ch.isdigit():
        return "KEY_" + ch, False
    if ch in US_PUNCT:
        name, shift = US_PUNCT[ch]
        return "KEY_" + name, bool(shift)
    raise ValueError(f"cannot type {ch!r} (ASCII, US layout only)")


class Plugins:
    """Stateful runner; ``sys_run``/``sys_spawn``/``uinput`` are injectable for tests."""

    def __init__(self, sys_run=None, sys_spawn=None, uinput_factory=None):
        self.sys_run = sys_run or self._run
        self.sys_spawn = sys_spawn or self._spawn
        self._uinput_factory = uinput_factory or self._make_uinput
        self._ui = None
        self._sounds: list[subprocess.Popen] = []

    # --- process helpers -------------------------------------------------
    @staticmethod
    def _run(argv, timeout=3):
        return subprocess.run(argv, capture_output=True, text=True, timeout=timeout).stdout

    @staticmethod
    def _spawn(argv):
        return subprocess.Popen(argv, start_new_session=True,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # --- key injection ---------------------------------------------------
    @staticmethod
    def _make_uinput():
        from evdev import UInput, ecodes
        # only real keyboard codes: other KEY_* constants (KEY_MAX, aliases) are rejected by the kernel
        keys = sorted(c for c in ecodes.keys if isinstance(c, int) and 0 < c < 256)
        ui = UInput({ecodes.EV_KEY: keys}, name="streamstation-keyboard")
        time.sleep(0.3)   # let the compositor pick the new device up
        return ui

    def _ui_get(self):
        if self._ui is None:
            self._ui = self._uinput_factory()
        return self._ui

    def _emit(self, names: list[str]):
        from evdev import ecodes
        ui = self._ui_get()
        codes = [getattr(ecodes, n) for n in names]
        for c in codes:
            ui.write(ecodes.EV_KEY, c, 1)
        ui.syn()
        for c in reversed(codes):
            ui.write(ecodes.EV_KEY, c, 0)
        ui.syn()

    def key(self, combo: str):
        self._emit(parse_combo(combo))

    def type_text(self, text: str):
        for ch in text:
            name, shift = char_keys(ch)
            self._emit((["KEY_LEFTSHIFT"] if shift else []) + [name])
            time.sleep(0.01)

    # --- volume / media --------------------------------------------------
    def volume(self, arg: str):
        sink = "@DEFAULT_AUDIO_SINK@"
        action, _, n = arg.partition(":")
        step = f"{int(n or 5)}%"
        if action == "up":
            self.sys_run(["wpctl", "set-volume", "-l", "1.0", sink, step + "+"])
        elif action == "down":
            self.sys_run(["wpctl", "set-volume", sink, step + "-"])
        elif action == "mute":
            self.sys_run(["wpctl", "set-mute", sink, "toggle"])
        elif action == "set":
            self.sys_run(["wpctl", "set-volume", "-l", "1.0", sink, f"{int(n)}%"])
        else:
            raise ValueError(f"unknown volume action {action!r}")

    def mic_mute(self):
        self.sys_run(["wpctl", "set-mute", "@DEFAULT_AUDIO_SOURCE@", "toggle"])

    MPRIS = ("/org/mpris/MediaPlayer2", "org.mpris.MediaPlayer2.Player")

    def _players(self) -> list[str]:
        out = self.sys_run(["busctl", "--user", "list", "--no-legend"])
        return [ln.split()[0] for ln in out.splitlines() if ln.startswith("org.mpris.MediaPlayer2.")]

    def _pick_player(self, names: list[str]) -> str:
        for n in names:   # prefer the player that is playing right now
            out = self.sys_run(["busctl", "--user", "get-property", n, *self.MPRIS, "PlaybackStatus"])
            if "Playing" in out:
                return n
        return names[0]

    def media(self, arg: str):
        """media:play-pause|next|prev|stop and media:volume-up[:N] / media:volume-down[:N] (player volume)."""
        action, _, amount = arg.partition(":")
        methods = {"play-pause": "PlayPause", "next": "Next", "prev": "Previous", "previous": "Previous", "stop": "Stop"}
        if action not in methods and action not in ("volume-up", "volume-down"):
            raise ValueError(f"unknown media action {arg!r}")
        names = self._players()
        if not names:
            return False
        target = self._pick_player(names)
        if action in methods:
            self.sys_run(["busctl", "--user", "call", target, *self.MPRIS, methods[action]])
            return True
        step = float(amount or 5) / 100
        cur = self.sys_run(["busctl", "--user", "get-property", target, *self.MPRIS, "Volume"]).split()
        volume = float(cur[1]) if len(cur) >= 2 and cur[0] == "d" else 1.0
        volume = max(0.0, min(1.0, volume + (step if action == "volume-up" else -step)))
        self.sys_run(["busctl", "--user", "set-property", target, *self.MPRIS, "Volume", "d", f"{volume:.3f}"])
        return True

    # --- soundboard / network / apps ------------------------------------------
    def sound_play(self, path: str):
        player = next((p for p in ("pw-play", "paplay") if shutil.which(p)), None)
        if not player or not os.path.isfile(os.path.expanduser(path)):
            raise ValueError(f"cannot play {path!r}")
        self._sounds = [p for p in self._sounds if p.poll() is None]
        self._sounds.append(self.sys_spawn([player, os.path.expanduser(path)]))

    def sound_stop(self):
        for p in self._sounds:
            if p.poll() is None:
                try:
                    os.killpg(p.pid, signal.SIGTERM)
                except OSError:
                    pass
        self._sounds = []

    @staticmethod
    def udp(arg: str):
        host, port, msg = arg.split(":", 2)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.sendto(msg.encode(), (host, int(port)))
        finally:
            s.close()

    def tool(self, name: str):
        for argv in TOOLS.get(name, []):
            if shutil.which(argv[0]):
                self.sys_spawn(argv)
                return True
        return False

    # --- dispatch ------------------------------------------------------------
    VERBS = ("key", "text", "volume", "mic", "media", "open", "url", "sound", "udp",
             "browser", "desktop", "tool", "kde", "service")

    def handles(self, action: str) -> bool:
        return action.partition(":")[0] in self.VERBS

    def kde(self, arg: str):
        """kde:<component>:<action name> -> KGlobalAccel invokeShortcut over D-Bus."""
        component, _, name = arg.partition(":")
        if not component or not name:
            raise ValueError("kde action needs component:name")
        self.sys_run(["busctl", "--user", "call", "org.kde.kglobalaccel", f"/component/{component}",
                      "org.kde.kglobalaccel.Component", "invokeShortcut", "s", name])

    def run(self, action: str) -> bool:
        if action in UNSUPPORTED:
            raise ValueError(UNSUPPORTED[action])
        action = ALIASES.get(action, action)
        verb, _, arg = action.partition(":")
        if verb == "kde":
            self.kde(arg)
        elif verb == "key":
            self.key(arg)
        elif verb == "text":
            self.type_text(arg)
        elif verb == "volume":
            self.volume(arg)
        elif verb == "mic" and arg == "mute":
            self.mic_mute()
        elif verb == "media":
            return self.media(arg)
        elif verb == "open":
            target = os.path.expanduser(arg)
            self.sys_spawn(["xdg-open", target] if os.path.exists(target) else ["gtk-launch", arg])
        elif verb == "url":
            self.sys_spawn(["xdg-open", arg])
        elif verb == "service":
            from . import services
            self.sys_spawn(services.command_for(arg))
        elif verb == "sound" and arg == "stop":
            self.sound_stop()
        elif verb == "sound" and arg.startswith("play:"):
            self.sound_play(arg[5:])
        elif verb == "udp":
            self.udp(arg)
        elif verb == "tool":
            return self.tool(arg)
        else:
            raise ValueError(f"unknown action {action!r}")
        return True
