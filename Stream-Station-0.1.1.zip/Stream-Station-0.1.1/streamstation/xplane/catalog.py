"""Read X-Plane's own lists: Resources/plugins/Commands.txt and DataRefs.txt (static files, no game needed)."""
from __future__ import annotations

import os
from collections import OrderedDict
from dataclasses import dataclass

STEAM_ROOTS = ("~/.local/share/Steam/steamapps/common", "~/.steam/steam/steamapps/common",
               "~/.var/app/com.valvesoftware.Steam/.local/share/Steam/steamapps/common")

# Spanish names for the biggest command groups; anything else is shown with its own name.
CATEGORY_NAMES = {
    "lights": "Luces", "flight_controls": "Controles de vuelo", "autopilot": "Piloto automático", "engines": "Motores",
    "fuel": "Combustible", "radios": "Radios", "instruments": "Instrumentos", "GPS": "GPS", "FMS": "FMS", "FMS2": "FMS 2",
    "view": "Vistas", "operation": "Simulador", "ice": "Hielo y deshielo", "magnetos": "Magnetos", "electrical": "Eléctrico",
    "systems": "Sistemas", "annunciator": "Anunciadores", "transponder": "Transpondedor", "audio_panel": "Panel de audio",
    "replay": "Repetición", "weapons": "Armamento", "ATC": "ATC", "pressurization": "Presurización", "hydraulics": "Hidráulica",
    "flightmodel": "Modelo de vuelo", "general": "General", "misc": "Varios", "joystick": "Joystick", "cameras": "Cámaras",
}


@dataclass(frozen=True)
class Command:
    name: str
    description: str

    @property
    def category(self) -> str:
        parts = self.name.split("/")
        return parts[1] if len(parts) > 2 else (parts[0] if parts else "")

    @property
    def title(self) -> str:
        return self.description.rstrip(".").strip() or self.name.rsplit("/", 1)[-1]


@dataclass(frozen=True)
class DataRef:
    name: str
    type: str
    writable: bool
    units: str
    description: str

    @property
    def is_array(self) -> bool:
        return "[" in self.type


def find_install(configured: str | None = None) -> str | None:
    """The X-Plane 12 folder: the configured one, else the first Steam library that has it."""
    candidates = [configured] if configured else []
    candidates += [os.path.join(os.path.expanduser(r), "X-Plane 12") for r in STEAM_ROOTS]
    for c in candidates:
        c = os.path.expanduser(c) if c else c
        if c and os.path.isfile(os.path.join(c, "Resources", "plugins", "Commands.txt")):
            return os.path.realpath(c)
    return None


def load_commands(install: str) -> list[Command]:
    out = []
    path = os.path.join(install, "Resources", "plugins", "Commands.txt")
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.rstrip("\n")
                if not line.strip() or line.startswith("#"):
                    continue
                name, _, desc = line.strip().partition(" ")
                if "/" in name:
                    out.append(Command(name, desc.strip()))
    except OSError:
        pass                                         # no list: the editor just has no base commands to offer
    return out


def load_datarefs(install: str) -> dict[str, DataRef]:
    out: dict[str, DataRef] = {}
    path = os.path.join(install, "Resources", "plugins", "DataRefs.txt")
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 5 and "/" in parts[0] and parts[2] in ("y", "n"):
                    out[parts[0]] = DataRef(parts[0], parts[1], parts[2] == "y", parts[3], parts[4].strip())
    except OSError:
        pass
    return out


def category_title(key: str) -> str:
    return CATEGORY_NAMES.get(key, key.replace("_", " ").capitalize())


def by_category(commands: list[Command]) -> "OrderedDict[str, list[Command]]":
    """{display name: commands}, the biggest/most useful groups first, commands in file order."""
    groups: dict[str, list[Command]] = {}
    for c in commands:
        if c.name in ("sim/none/none",):
            continue
        groups.setdefault(category_title(c.category), []).append(c)
    first = [category_title(k) for k in ("lights", "flight_controls", "autopilot", "engines", "fuel", "electrical", "systems",
                                         "radios", "instruments", "view", "operation")]
    ordered = OrderedDict((k, groups[k]) for k in first if k in groups)
    for k in sorted(groups, key=str.lower):
        ordered.setdefault(k, groups[k])
    return ordered


def search(commands: list[Command], text: str, limit: int = 300) -> list[Command]:
    t = text.strip().lower()
    if not t:
        return commands
    words = t.split()
    hit = [c for c in commands if all(w in c.name.lower() or w in c.description.lower() for w in words)]
    return hit[:limit]
