"""The "Industrial" icon set: pictograms redrawn from scratch, in the language of industrial product design.

Rules (what makes the set one family): a single stroke weight, square geometry with a few circles, solid masses
where something is solid, and exactly ONE detail per icon in safety orange (the part that "does" the action).
Everything else is the main colour (warm white on the tile). The two colours are drawn straight onto the glyph:
`W` parts take the main colour, `A` parts keep the accent.
"""
from __future__ import annotations

import math

from .actionicons import CUT, W, _P

A = (255, 106, 0, 255)      # the accent (safety orange); the tile keeps it as drawn
S = 9                       # the one stroke weight of this set


def blk(p, x0, y0, x1, y1, c=W):
    p.rect((x0, y0, x1, y1), r=0, fill=c, c=c)


def frm(p, box, w=S, c=W):
    p.rect(box, r=0, outline=True, w=w, c=c)


def ln(p, pts, w=S, c=W):
    p.line(pts, w=w, c=c)


def tri(p, pts, c=W):
    p.poly(pts, c)


def ring(p, cx, cy, r, w=S, c=W):
    p.circ(cx, cy, r, outline=True, w=w, c=c)


def dot(p, cx, cy, r, c=W):
    p.circ(cx, cy, r, fill=c, c=c)


# --- the pictograms ---------------------------------------------------------------------------------
def sun(p, sign):
    ring(p, 50, 50, 22)
    for a in range(0, 360, 45):
        x0, y0 = 50 + 34 * math.cos(math.radians(a)), 50 + 34 * math.sin(math.radians(a))
        x1, y1 = 50 + 46 * math.cos(math.radians(a)), 50 + 46 * math.sin(math.radians(a))
        ln(p, [(x0, y0), (x1, y1)], 8)
    ln(p, [(40, 50), (60, 50)], 8, A)
    if sign > 0:
        ln(p, [(50, 40), (50, 60)], 8, A)


def monitor(p, box=(8, 12, 92, 66), stand=True):
    frm(p, box)
    if stand:
        blk(p, 44, box[3], 56, box[3] + 12)
        blk(p, 28, box[3] + 12, 72, box[3] + 21)


def screen_off(p):
    monitor(p)
    p.arc((36, 24, 64, 52), -55, 235, w=8, c=A)
    ln(p, [(50, 22), (50, 40)], 8, A)


def page_next(p):
    frm(p, (8, 10, 50, 90))
    blk(p, 20, 30, 38, 38)
    blk(p, 20, 50, 38, 58)
    ln(p, [(58, 50), (80, 50)], S, A)
    tri(p, [(76, 30), (98, 50), (76, 70)], A)


def page_goto(p):
    frm(p, (16, 8, 84, 92))
    tri(p, [(48, 8), (68, 8), (68, 44), (58, 35), (48, 44)], A)
    blk(p, 28, 62, 72, 70)
    blk(p, 28, 76, 54, 84)


def profile(p):
    blk(p, 36, 8, 64, 38, A)
    tri(p, [(12, 92), (12, 66), (28, 46), (72, 46), (88, 66), (88, 92)])


def globe(p):
    ring(p, 50, 50, 40)
    ln(p, [(10, 50), (90, 50)], 7)
    p.ell((30, 10, 70, 90), w=7, c=A)
    ln(p, [(50, 10), (50, 90)], 7)


def keyboard(p):
    frm(p, (4, 24, 96, 76))
    for y in (34, 48):
        for i in range(5):
            blk(p, 14 + i * 15, y, 22 + i * 15, y + 7)
    blk(p, 24, 62, 76, 68, A)


def text(p):
    blk(p, 10, 22, 90, 32, A)
    blk(p, 10, 45, 64, 55)
    blk(p, 10, 68, 78, 78)


def folder(p):
    tri(p, [(6, 20), (40, 20), (50, 32), (94, 32), (94, 84), (6, 84)])
    blk(p, 16, 46, 84, 74, CUT)
    blk(p, 6, 20, 40, 28, A)


def terminal(p):
    frm(p, (6, 14, 94, 86))
    ln(p, [(24, 36), (44, 50), (24, 64)], S, A)
    blk(p, 52, 60, 76, 68)


def speaker(p):
    blk(p, 6, 38, 24, 62)
    tri(p, [(24, 38), (50, 16), (50, 84), (24, 62)])


def vol(p, n):
    speaker(p)
    for i in range(n):
        x = 60 + i * 17
        ln(p, [(x, 50 - 14 - i * 8), (x + 12, 50), (x, 50 + 14 + i * 8)], 8, A)


def mute(p):
    speaker(p)
    ln(p, [(62, 36), (90, 64)], 9, A)
    ln(p, [(90, 36), (62, 64)], 9, A)


def mic(p):
    blk(p, 36, 6, 64, 56, A)
    ln(p, [(24, 40), (24, 62), (76, 62), (76, 40)], 8)
    blk(p, 46, 62, 54, 82)
    blk(p, 32, 82, 68, 91)


def play_pause(p):
    tri(p, [(6, 16), (6, 84), (50, 50)], A)
    blk(p, 60, 18, 72, 82)
    blk(p, 80, 18, 92, 82)


def nxt(p):
    tri(p, [(8, 16), (8, 84), (64, 50)], A)
    blk(p, 72, 16, 90, 84)


def sound(p, kind):
    tri(p, [(6, 38), (24, 38), (46, 18), (46, 82), (24, 62), (6, 62)])
    if kind == "play":
        tri(p, [(58, 30), (58, 70), (94, 50)], A)
    else:
        blk(p, 60, 32, 90, 68, A)


def toggle(p):
    frm(p, (6, 28, 94, 72))
    blk(p, 54, 36, 86, 64, A)


def dice(p):
    frm(p, (10, 10, 90, 90))
    for x, y in ((22, 22), (66, 22), (22, 66), (66, 66)):
        blk(p, x, y, x + 12, y + 12)
    blk(p, 44, 44, 56, 56, A)


def steps(p):
    for y in (18, 44, 70):
        blk(p, 8, y, 24, y + 14, A)
        blk(p, 36, y, 92, y + 14)


def lock(p):
    frm(p, (28, 6, 72, 52))
    blk(p, 14, 42, 86, 92)
    blk(p, 45, 56, 55, 80, A)


def moon(p):
    p.circ(46, 52, 38, fill=True)
    p.circ(68, 38, 33, fill=CUT)
    blk(p, 78, 12, 88, 22, A)
    blk(p, 88, 38, 96, 46, A)


def sliders(p):
    for y, x in ((22, 30), (50, 66), (78, 44)):
        blk(p, 6, y - 4, 94, y + 4)
        blk(p, x - 10, y - 14, x + 10, y + 14, A)


def desktop(p):
    frm(p, (6, 10, 94, 70))
    blk(p, 16, 20, 48, 42, A)
    blk(p, 16, 54, 84, 60)
    blk(p, 24, 82, 76, 90)


def overview(p):
    for x, y in ((8, 8), (54, 8), (8, 54)):
        blk(p, x, y, x + 38, y + 38)
    blk(p, 54, 54, 92, 92, A)


def search(p):
    ring(p, 40, 40, 30, 10, A)
    ln(p, [(62, 62), (90, 90)], 16)


def emoji(p):
    ring(p, 50, 50, 41)
    blk(p, 28, 32, 40, 46)
    blk(p, 60, 32, 72, 46)
    p.arc((28, 34, 72, 74), 25, 155, w=8, c=A)


def bell_off(p):
    tri(p, [(24, 68), (28, 38), (40, 18), (60, 18), (72, 38), (76, 68)])
    blk(p, 12, 66, 88, 78)
    blk(p, 42, 82, 58, 94)
    ln(p, [(10, 8), (90, 92)], 17, CUT)
    ln(p, [(10, 8), (90, 92)], 9, A)


def two_screens(p):
    frm(p, (4, 46, 46, 80), 8)
    frm(p, (54, 46, 96, 80), 8)
    blk(p, 14, 86, 36, 92)
    blk(p, 64, 86, 86, 92)
    ln(p, [(14, 26), (66, 26)], 9, A)
    tri(p, [(62, 10), (92, 26), (62, 42)], A)


def pulse(p):
    frm(p, (6, 12, 94, 88))
    ln(p, [(16, 56), (30, 56), (30, 32), (46, 32), (46, 66), (62, 66), (62, 44), (84, 44)], 9, A)


def gear(p):
    for i in range(8):
        a = i * 45
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        p.poly([(50 + 28 * c - 9 * s, 50 + 28 * s + 9 * c), (50 + 46 * c - 9 * s, 50 + 46 * s + 9 * c),
                (50 + 46 * c + 9 * s, 50 + 46 * s - 9 * c), (50 + 28 * c + 9 * s, 50 + 28 * s - 9 * c)])
    p.circ(50, 50, 34, fill=True)
    p.circ(50, 50, 20, fill=CUT)
    p.circ(50, 50, 11, fill=A, c=A)


def calculator(p):
    frm(p, (14, 6, 86, 94))
    blk(p, 26, 18, 74, 36, A)
    for r_ in range(3):
        for c_ in range(3):
            blk(p, 27 + c_ * 16, 46 + r_ * 14, 36 + c_ * 16, 54 + r_ * 14)


def mail(p):
    frm(p, (6, 20, 94, 80))
    ln(p, [(12, 26), (50, 58), (88, 26)], 9, A)


def arrow_left(p):
    tri(p, [(6, 50), (40, 18), (40, 82)], A)
    blk(p, 36, 41, 94, 59, A)


def refresh(p):
    ln(p, [(80, 56), (80, 82), (20, 82), (20, 24), (58, 24)], 10)
    tri(p, [(52, 6), (92, 24), (52, 42)], A)


def star(p):
    pts = []
    for i in range(10):
        r = 46 if i % 2 == 0 else 20
        a = math.radians(-90 + i * 36)
        pts.append((50 + r * math.cos(a), 54 + r * math.sin(a)))
    p.poly(pts, A)


def send(p):
    tri(p, [(6, 44), (94, 10), (66, 90), (48, 62)])
    ln(p, [(48, 62), (94, 10)], 6, CUT)
    tri(p, [(48, 62), (66, 90), (60, 62)], A)


def file(p):
    tri(p, [(14, 6), (60, 6), (86, 32), (86, 94), (14, 94)])
    tri(p, [(60, 6), (60, 32), (86, 32)], CUT)
    blk(p, 28, 52, 72, 60, CUT)
    blk(p, 28, 70, 72, 78, CUT)
    blk(p, 28, 52, 72, 60, A)


def app(p):
    frm(p, (6, 12, 94, 88))
    blk(p, 6, 12, 94, 34, A)


def layers(p):
    tri(p, [(50, 8), (94, 32), (50, 56), (6, 32)], A)
    ln(p, [(6, 52), (50, 76), (94, 52)], 10)
    ln(p, [(6, 72), (50, 96), (94, 72)], 10)


def bolt(p):
    tri(p, [(60, 4), (16, 56), (44, 56), (36, 96), (86, 40), (56, 40)], A)


# --- service pictograms ------------------------------------------------------------------------------------
def svc_youtube(p):
    frm(p, (6, 22, 94, 78))
    tri(p, [(41, 36), (41, 64), (66, 50)], A)


def svc_ytmusic(p):
    ring(p, 50, 50, 41)
    tri(p, [(40, 34), (40, 66), (68, 50)], A)


def svc_spotify(p):
    ring(p, 50, 50, 41)
    for dy, half in ((-13, 25), (2, 20), (16, 14)):
        p.arc((50 - half - 4, 52 + dy - half, 50 + half + 4, 52 + dy + half + 18), 205, 335, w=8, c=A)


def svc_twitch(p):
    tri(p, [(14, 6), (90, 6), (90, 58), (70, 78), (52, 78), (38, 92), (38, 78), (14, 78)])
    blk(p, 38, 22, 46, 46, A)
    blk(p, 62, 22, 70, 46, A)


def svc_discord(p):
    tri(p, [(8, 64), (14, 38), (28, 28), (72, 28), (86, 38), (92, 64), (84, 76), (70, 70), (60, 60), (40, 60), (30, 70), (16, 76)])
    blk(p, 25, 38, 31, 60, CUT)
    blk(p, 19, 46, 37, 52, CUT)
    blk(p, 25, 38, 31, 60, A)
    blk(p, 19, 46, 37, 52, A)
    blk(p, 62, 40, 70, 48, CUT)
    blk(p, 72, 50, 80, 58, CUT)


def svc_whatsapp(p):
    ring(p, 50, 48, 41)
    tri(p, [(12, 94), (20, 62), (38, 82)])
    ln(p, [(36, 34), (36, 46), (46, 58), (64, 64)], 9, A)


def svc_telegram(p):
    ring(p, 50, 50, 41)
    tri(p, [(22, 48), (78, 26), (66, 74), (50, 60)], A)


def svc_gmail(p):
    frm(p, (6, 20, 94, 80))
    ln(p, [(14, 30), (30, 54), (50, 38), (70, 54), (86, 30)], 9, A)


def svc_calendar(p):
    frm(p, (10, 16, 90, 90))
    blk(p, 10, 16, 90, 38, A)
    for r_ in range(2):
        for c_ in range(3):
            blk(p, 22 + c_ * 20, 50 + r_ * 18, 32 + c_ * 20, 60 + r_ * 18)


def svc_drive(p):
    tri(p, [(34, 12), (66, 12), (94, 62), (78, 88), (50, 40)])
    tri(p, [(30, 18), (6, 62), (22, 88), (50, 40)], A)
    tri(p, [(26, 92), (74, 92), (86, 70), (14, 70)])


def svc_maps(p):
    p.circ(50, 38, 30, fill=True)
    tri(p, [(26, 52), (74, 52), (50, 94)])
    p.circ(50, 38, 12, fill=A, c=A)


def svc_github(p):
    for x, y in ((26, 20), (26, 80), (72, 40)):
        ring(p, x, y, 12, 8)
    ln(p, [(26, 32), (26, 68)], 8)
    ln(p, [(72, 52), (72, 56), (60, 62), (26, 68)], 8, A)


def _mirror(fn):
    def draw(p):
        q = _P(p.img.width // 4)
        fn(q)
        from PIL import Image
        p.img.paste(q.img.transpose(Image.FLIP_LEFT_RIGHT), (0, 0))
    return draw


GLYPHS = {
    "sun_plus": lambda p: sun(p, 1), "sun_minus": lambda p: sun(p, -1), "screen_off": screen_off,
    "page_next": page_next, "page_prev": _mirror(page_next), "page_goto": page_goto, "profile": profile,
    "globe": globe, "keyboard": keyboard, "text": text, "folder": folder, "terminal": terminal,
    "vol_up": lambda p: vol(p, 2), "vol_down": lambda p: vol(p, 1), "vol_mute": mute, "mic": mic,
    "play_pause": play_pause, "next": nxt, "prev": _mirror(nxt), "sound_play": lambda p: sound(p, "play"),
    "sound_stop": lambda p: sound(p, "stop"), "toggle": toggle, "dice": dice, "steps": steps, "lock": lock,
    "moon": moon, "sliders": sliders, "desktop": desktop, "overview": overview, "search": search, "emoji": emoji,
    "bell_off": bell_off, "two_screens": two_screens, "pulse": pulse, "gear": gear, "calculator": calculator,
    "mail": mail, "arrow_left": arrow_left, "arrow_right": _mirror(arrow_left), "refresh": refresh, "star": star,
    "send": send, "file": file, "app": app, "layers": layers, "bolt": bolt,
    "svc_youtube": svc_youtube, "svc_youtube-music": svc_ytmusic, "svc_spotify": svc_spotify, "svc_twitch": svc_twitch,
    "svc_discord": svc_discord, "svc_whatsapp": svc_whatsapp, "svc_telegram": svc_telegram, "svc_gmail": svc_gmail,
    "svc_calendar": svc_calendar, "svc_drive": svc_drive, "svc_maps": svc_maps, "svc_github": svc_github,
}
