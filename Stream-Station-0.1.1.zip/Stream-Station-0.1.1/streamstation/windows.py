"""Active-window detection (KDE Plasma, Wayland or X11) and the rules that tie a profile to an application.

A tiny KWin script reports every focus change to this program over D-Bus:

    KWin script  --callDBus-->  org.streamstation.Service.ActiveWindow(class, name, title, pid, desktop)

The service is exported with Gio in a background thread; events are handed to a callback, which the service
queues for its own loop (USB writes must happen on one thread).

Profile rules (``match:`` in a profile file): a list of dicts, ALL keys of a dict must match, ANY dict may match.
    class:   window class (case-insensitive, shell wildcards allowed)       e.g. "X-Plane*", "steam_app_*"
    name:    resource name (same rules)
    desktop: desktop file name (same rules)
    exe:     executable name of the process (same rules)
    title:   regular expression searched in the window title
"""
from __future__ import annotations

import fnmatch
import os
import re
import threading
from dataclasses import dataclass, field
from typing import Callable

SERVICE = "org.streamstation.Service"
PATH = "/org/streamstation/Service"
IFACE = "org.streamstation.Service"
SCRIPT_NAME = "streamstation-activewindow"

# Windows that must never trigger a profile change (shell, launchers, this program's own editor).
IGNORE = {"streamstation", "plasmashell", "org.kde.plasmashell", "krunner", "org.kde.krunner", "kwin_wayland",
          "ksmserver-logout-greeter", "xdg-desktop-portal-kde", "org.freedesktop.impl.portal.desktop.kde"}

SCRIPT_JS = """// Reports focus changes to the Stream Station service. Generated; edits are overwritten.
function report(w) {
    if (!w) return;
    callDBus("%(service)s", "%(path)s", "%(iface)s", "ActiveWindow",
             String(w.resourceClass || ""), String(w.resourceName || ""), String(w.caption || ""),
             parseInt(w.pid || 0), String(w.desktopFileName || ""));
}
var signal = workspace.windowActivated || workspace.clientActivated;   // Plasma 6 / Plasma 5
if (signal) signal.connect(report);
report(workspace.activeWindow || workspace.activeClient);
"""

INTROSPECTION = f"""<node><interface name="{IFACE}">
  <method name="ActiveWindow">
    <arg type="s" name="cls" direction="in"/><arg type="s" name="name" direction="in"/>
    <arg type="s" name="title" direction="in"/><arg type="i" name="pid" direction="in"/>
    <arg type="s" name="desktop" direction="in"/>
  </method></interface></node>"""


@dataclass(frozen=True)
class Window:
    cls: str = ""
    name: str = ""
    title: str = ""
    pid: int = 0
    desktop: str = ""

    @property
    def exe(self) -> str:
        try:
            return os.path.basename(os.readlink(f"/proc/{self.pid}/exe")) if self.pid > 0 else ""
        except OSError:
            return ""

    def label(self) -> str:
        return self.cls or self.name or self.desktop or "?"

    def as_dict(self) -> dict:
        return {"class": self.cls, "name": self.name, "title": self.title, "pid": self.pid,
                "desktop": self.desktop, "exe": self.exe}


# --- rules ---------------------------------------------------------------------------------------
def _glob(pattern: str, value: str) -> bool:
    return fnmatch.fnmatchcase(value.lower(), str(pattern).lower())


def rule_matches(rule: dict, w: Window) -> bool:
    """All keys present in `rule` must match; an empty rule matches nothing."""
    if not isinstance(rule, dict) or not rule:
        return False
    checks = {"class": lambda p: _glob(p, w.cls), "name": lambda p: _glob(p, w.name),
              "desktop": lambda p: _glob(p, w.desktop), "exe": lambda p: bool(w.exe) and _glob(p, w.exe),
              "title": lambda p: re.search(str(p), w.title, re.IGNORECASE) is not None}
    for key, pattern in rule.items():
        check = checks.get(key)
        try:
            if check is None or not check(pattern):
                return False
        except re.error:
            return False
    return True


def find_profile(w: Window, rules_by_profile: dict[str, list]) -> str | None:
    """The profile whose rules match `w`. More specific rules (more keys) win; ties go to the name order."""
    best: tuple[int, str] | None = None
    for name in sorted(rules_by_profile):
        for rule in rules_by_profile[name] or []:
            if rule_matches(rule, w):
                score = len(rule)
                if best is None or score > best[0]:
                    best = (score, name)
    return best[1] if best else None


def is_ignored(w: Window) -> bool:
    return w.cls.lower() in IGNORE or (not w.cls and not w.name)      # nothing to identify it by


# --- watcher -------------------------------------------------------------------------------------
class WindowWatcher:
    """Exports the D-Bus service and (optionally) loads the KWin script that feeds it."""

    def __init__(self, on_window: Callable[[Window], None], service: str = SERVICE, load_kwin: bool = True,
                 script_dir: str | None = None):
        self.on_window, self.service, self.load_kwin = on_window, service, load_kwin
        self.script_dir = script_dir or os.path.join(os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"),
                                                      "streamstation", "kwin")
        self._loop = None
        self._thread: threading.Thread | None = None
        self._owner_id = None
        self._ready = threading.Event()
        self.error: str | None = None

    # D-Bus service ---------------------------------------------------------------------------
    def _run(self):
        import gi
        gi.require_version("Gio", "2.0")
        from gi.repository import Gio, GLib
        node = Gio.DBusNodeInfo.new_for_xml(INTROSPECTION)

        def on_call(conn, sender, path, iface, method, params, invocation):
            try:
                cls, name, title, pid, desktop = params.unpack()
                self.on_window(Window(cls, name, title, int(pid), desktop))
            except Exception as exc:                       # never let a callback kill the service thread
                self.error = str(exc)
            invocation.return_value(None)

        def on_bus(conn, name):
            conn.register_object(PATH, node.interfaces[0], on_call, None, None)

        def on_acquired(conn, name):
            self._ready.set()

        def on_lost(conn, name):
            self.error = self.error or f"could not own {self.service}"
            self._ready.set()

        ctx = GLib.MainContext()
        ctx.push_thread_default()
        self._owner_id = Gio.bus_own_name(Gio.BusType.SESSION, self.service, Gio.BusNameOwnerFlags.NONE,
                                          on_bus, on_acquired, on_lost)
        self._loop = GLib.MainLoop(ctx)
        self._loop.run()
        Gio.bus_unown_name(self._owner_id)

    def start(self) -> bool:
        try:
            self._thread = threading.Thread(target=self._run, daemon=True, name="streamstation-dbus")
            self._thread.start()
        except Exception as exc:
            self.error = str(exc)
            return False
        if not self._ready.wait(5) or self.error:
            return False
        return self._load_script() if self.load_kwin else True

    def stop(self):
        if self.load_kwin:
            self._kwin_call("unloadScript", "(s)", (SCRIPT_NAME,))
        if self._loop:
            self._loop.quit()

    # KWin script -----------------------------------------------------------------------------
    def _kwin_call(self, method: str, sig: str, args: tuple):
        import gi
        gi.require_version("Gio", "2.0")
        from gi.repository import Gio, GLib
        try:
            bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)
            return bus.call_sync("org.kde.KWin", "/Scripting", "org.kde.kwin.Scripting", method,
                                 GLib.Variant(sig, args), None, Gio.DBusCallFlags.NONE, 3000, None).unpack()
        except Exception as exc:
            self.error = f"KWin scripting not available: {exc}"
            return None

    def _load_script(self) -> bool:
        os.makedirs(self.script_dir, exist_ok=True)
        path = os.path.join(self.script_dir, "activewindow.js")
        with open(path, "w") as fh:
            fh.write(SCRIPT_JS % {"service": self.service, "path": PATH, "iface": IFACE})
        self._kwin_call("unloadScript", "(s)", (SCRIPT_NAME,))          # a stale copy from a previous run
        if self._kwin_call("loadScript", "(ss)", (path, SCRIPT_NAME)) is None:
            return False
        self._kwin_call("start", "()", ())
        return True
