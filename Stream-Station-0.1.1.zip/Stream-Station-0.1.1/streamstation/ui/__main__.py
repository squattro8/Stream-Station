"""python -m streamstation.ui [--snapshot out.png]

Normal start is a single-instance application: starting it again brings the open window to the front.
"""
import os
import sys

SERVER = f"streamstation-ui-{os.getuid()}"


def main(argv):
    snapshot = argv[argv.index("--snapshot") + 1] if "--snapshot" in argv else None
    if snapshot:
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtCore import QTimer
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    from PySide6.QtWidgets import QApplication
    from .. import i18n, profiles
    from . import appearance, appicon
    from .mainwindow import MainWindow
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName("streamstation")
    app.setApplicationDisplayName("Stream Station")
    app.setDesktopFileName("streamstation")
    app.setWindowIcon(appicon.qicon())

    settings = profiles.load_settings()
    look = appearance.Appearance(app)
    look.set_language(str(settings.get("language") or i18n.DEFAULT))
    look.set_theme(str(settings.get("theme") or "dark"))

    if not snapshot:
        probe = QLocalSocket()
        probe.connectToServer(SERVER)
        if probe.waitForConnected(300):               # already running: ask it to come forward, then leave
            probe.write(b"raise"); probe.waitForBytesWritten(300); probe.disconnectFromServer()
            return 0
        QLocalServer.removeServer(SERVER)

    holder = {}

    def make_window(state=None):
        win = MainWindow(state=state)
        win.appearance = look
        win.rebuild_requested.connect(lambda: QTimer.singleShot(0, rebuild))
        look.theme_changed.connect(win.retheme)
        holder["win"] = win
        return win

    def rebuild():
        """A new language changes every text: carry the old window's state over to a new one and close the old."""
        old = holder["win"]
        old.stop_background()
        geometry = old.geometry()
        new = make_window(old.state())
        new._start_detector()
        new.move(geometry.topLeft())
        new.show()
        old.hide(); old.deleteLater()

    win = make_window()
    if snapshot:
        win.show(); app.processEvents()
        ok = win.grab().save(snapshot)
        print("snapshot", snapshot, "ok" if ok else "FALLÓ")
        return 0 if ok else 1

    win._start_detector()                         # follows the aircraft loaded in X-Plane (only in the real editor)
    win.start_update_check()                      # a newer release on GitHub? (only if the user set a repository)
    server = QLocalServer()
    server.listen(SERVER)

    def bring_forward():
        conn = server.nextPendingConnection()
        if conn:
            conn.readAll(); conn.close()
        w = holder["win"]
        w.setWindowState(w.windowState() & ~w.windowState().WindowMinimized)
        w.show(); w.raise_(); w.activateWindow()
    server.newConnection.connect(bring_forward)
    if "--minimized" in argv:
        win.showMinimized()                        # started with the computer: out of the way until needed
    else:
        win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
