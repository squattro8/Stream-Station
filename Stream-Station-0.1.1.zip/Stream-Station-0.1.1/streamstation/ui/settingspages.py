"""The "Device" and "Scenes" pages of the settings window."""
from __future__ import annotations

from PIL import Image
from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtWidgets import (QCheckBox, QComboBox, QHBoxLayout, QLabel, QListWidget, QListWidgetItem, QPushButton, QSlider,
                               QVBoxLayout, QWidget)

from .. import bootlogo, profiles, scenes
from ..i18n import tr
from . import icons, matchdialog


def title(text: str) -> QLabel:
    label = QLabel(text); label.setObjectName("heading"); return label


def note(text: str) -> QLabel:
    label = QLabel(text); label.setObjectName("muted"); label.setWordWrap(True); return label


def new_page() -> tuple[QWidget, QVBoxLayout]:
    w = QWidget(); lay = QVBoxLayout(w); lay.setContentsMargins(24, 8, 8, 8); lay.setSpacing(10)
    return w, lay


FIT_LABELS = (("fill", "Rellenar (recorta lo que sobra)"), ("fit", "Ajustar (con bordes negros)"), ("stretch", "Estirar"))
SCENE_BUTTONS = (("new", "Crear escena"), ("rename", "Renombrar"), ("copy", "Duplicar"), ("delete", "Eliminar"),
                 ("up", "Subir"), ("down", "Bajar"), ("default", "Usar como predeterminada"),
                 ("apps", "Aplicaciones…"), ("import", "Importar escena…"), ("export", "Exportar escena…"))


class DevicePage(QWidget):
    """Serial number, brightness, and the start-up picture."""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        settings = host.settings()
        lay = QVBoxLayout(self); lay.setContentsMargins(24, 8, 8, 8); lay.setSpacing(10)

        lay.addWidget(title(tr("Dispositivo")))
        row = QHBoxLayout(); row.addWidget(QLabel(tr("Número de serie:")))
        serial = host.serial()
        self.serial_label = QLabel(serial or tr("no disponible (¿está conectado?)"))
        self.serial_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        row.addWidget(self.serial_label); row.addStretch(); lay.addLayout(row)

        # ---- brightness: applied while dragging, like turning the knob ----
        reply = host.ctl(["status"]) or {}
        current = int(reply.get("brightness", settings.get("brightness", 100)))
        row = QHBoxLayout(); row.addWidget(QLabel(tr("Brillo:")))
        self.brightness = QSlider(Qt.Horizontal); self.brightness.setRange(0, 100); self.brightness.setValue(current)
        self.brightness_value = QLabel(f"{current} %"); self.brightness_value.setMinimumWidth(48)
        row.addWidget(self.brightness, 1); row.addWidget(self.brightness_value); lay.addLayout(row)
        self._timer = QTimer(self); self._timer.setSingleShot(True); self._timer.setInterval(120)
        self._timer.timeout.connect(self._send_brightness)
        self.brightness.valueChanged.connect(self._brightness_moved)

        # ---- the start-up picture ----
        lay.addSpacing(8)
        lay.addWidget(title(tr("Logo de arranque")))
        lay.addWidget(note(tr("La imagen que se dibuja en la franja cuando Stream Station se conecta al equipo (al encender la PC o al reconectarlo).")))
        self.logo_preview = QLabel(); self.logo_preview.setFixedSize(400, 64)
        self.logo_preview.setStyleSheet("background:#000; border-radius:6px;")
        lay.addWidget(self.logo_preview)
        self.logo_info = QLabel(""); self.logo_info.setObjectName("muted"); lay.addWidget(self.logo_info)
        row = QHBoxLayout()
        self.logo_pick = QPushButton(tr("Elegir imagen…")); self.logo_clear = QPushButton(tr("Quitar"))
        self.logo_fit = QComboBox()
        for key, label in FIT_LABELS:
            self.logo_fit.addItem(tr(label), key)
        row.addWidget(self.logo_pick); row.addWidget(self.logo_fit); row.addWidget(self.logo_clear); row.addStretch(); lay.addLayout(row)
        self.logo_enabled = QCheckBox(tr("Mostrar al conectar el equipo")); lay.addWidget(self.logo_enabled)
        lay.addStretch()

        self._logo_source: Image.Image | None = None       # the picture the user chose now (None: keep what is stored)
        self._logo_removed = False
        stored = bootlogo.load()
        self._stored = stored
        self.logo_enabled.setChecked(bool(settings.get("boot_logo")) and stored is not None)
        self.logo_pick.clicked.connect(self._pick)
        self.logo_clear.clicked.connect(self._clear)
        self.logo_fit.currentIndexChanged.connect(self._refresh_logo)
        self._refresh_logo()

    # --- brightness ---
    def _brightness_moved(self, value: int):
        self.brightness_value.setText(f"{value} %")
        self._timer.start()

    def _send_brightness(self):
        self.host.ctl(["brightness", str(self.brightness.value())])

    # --- logo ---
    def _pick(self):
        path = self.host.pick_image(self)
        if not path:
            return
        try:
            img = Image.open(path); img.load()
        except Exception:
            self.logo_info.setText(tr("No se pudo abrir esa imagen."))
            return
        self._logo_source, self._logo_removed = img.convert("RGB"), False
        self.logo_enabled.setChecked(True)
        self._refresh_logo()

    def _clear(self):
        self._logo_source, self._logo_removed = None, True
        self._stored = None
        self.logo_enabled.setChecked(False)
        self._refresh_logo()

    def fit(self) -> str:
        return str(self.logo_fit.currentData() or "fill")

    def _refresh_logo(self, *_):
        src = self._logo_source if self._logo_source is not None else self._stored
        if src is None:
            self.logo_preview.clear()
            self.logo_info.setText(tr("Sin imagen. Se usa la del dispositivo."))
            self.logo_clear.setEnabled(False); self.logo_fit.setEnabled(False)
            return
        self.logo_clear.setEnabled(True); self.logo_fit.setEnabled(self._logo_source is not None)
        shown = bootlogo.scale(src, self.fit() if self._logo_source is not None else "fill")
        self.logo_preview.setPixmap(icons.to_qpixmap(shown.resize((400, 64), Image.LANCZOS)))
        self.logo_info.setText(tr("Tamaño: {sizes}", sizes=bootlogo.describe(src)))

    # --- what the dialog saves on OK ---
    def apply(self):
        host = self.host
        if self._logo_removed and self._logo_source is None:
            bootlogo.remove()
        if self._logo_source is not None:
            bootlogo.save(self._logo_source, self.fit())
        has = bootlogo.load() is not None
        host.save("boot_logo", bool(self.logo_enabled.isChecked() and has))
        reply = host.ctl(["reload"])                     # the service reads the settings again
        return reply


class ScenesPage(QWidget):
    """Add, rename, copy, delete, order and bind scenes; choose the default one."""

    def __init__(self, host, parent=None):
        super().__init__(parent)
        self.host = host
        lay = QVBoxLayout(self); lay.setContentsMargins(24, 8, 8, 8); lay.setSpacing(10)
        lay.addWidget(title(tr("Escenas")))
        lay.addWidget(note(tr("Cada escena es una distribución de teclas. Se puede asociar a aplicaciones para que cambie sola; la escena "
                              "predeterminada se muestra cuando la aplicación en primer plano no tiene escena propia.")))
        body = QHBoxLayout(); lay.addLayout(body, 1)
        self.list = QListWidget(); body.addWidget(self.list, 1)
        col = QVBoxLayout(); body.addLayout(col)
        self.buttons: dict[str, QPushButton] = {}
        for key, label in SCENE_BUTTONS:
            b = QPushButton(tr(label)); self.buttons[key] = b; col.addWidget(b)
        col.addStretch()
        self.swipe = QCheckBox(tr("Cambiar de escena con deslizamiento en franja"))
        self.swipe.setToolTip(tr("Desliza el dedo por la franja de derecha a izquierda para pasar a la escena siguiente, y de izquierda a derecha "
                                 "para volver a la anterior. Si el perfil ya cambia de página con el deslizamiento, ese tiene prioridad."))
        self.swipe.setChecked(bool(host.settings().get("scene_swipe")))
        lay.addWidget(self.swipe)
        self.message = QLabel(""); self.message.setObjectName("muted"); self.message.setWordWrap(True); lay.addWidget(self.message)
        self.renamed: dict[str, str] = {}       # old name -> new name, for the editor that may have that scene open
        self.changed = False                    # something about the scenes changed: the editor refreshes its list
        self.list.currentRowChanged.connect(lambda *_: self._enable())
        for key, handler in (("new", self.create), ("rename", self.rename), ("copy", self.duplicate), ("delete", self.remove),
                             ("up", lambda: self.move(-1)), ("down", lambda: self.move(1)), ("default", self.make_default),
                             ("apps", self.bind_apps), ("import", self.import_scene), ("export", self.export_scene)):
            self.buttons[key].clicked.connect(lambda _=False, h=handler: h())
        self.refresh()

    # --- the list ---
    def selected(self) -> str | None:
        item = self.list.currentItem()
        return str(item.data(Qt.UserRole)) if item else None

    def refresh(self, select: str | None = None):
        keep = select or self.selected() or self.host.open_scene
        default = scenes.default()
        rules = profiles.match_rules()
        self.list.blockSignals(True); self.list.clear()
        for n in scenes.names():
            marks = ("  ★" if n == default else "") + ("  🎮" if rules.get(n) else "")
            item = QListWidgetItem(n + marks); item.setData(Qt.UserRole, n); item.setSizeHint(QSize(0, 32))
            if rules.get(n):
                item.setToolTip(tr("Se activa solo con: ") + "; ".join(matchdialog.describe(r) for r in rules[n]))
            self.list.addItem(item)
            if n == keep:
                self.list.setCurrentItem(item)
        if self.list.currentItem() is None and self.list.count():
            self.list.setCurrentRow(0)
        self.list.blockSignals(False)
        self._enable()

    def _enable(self):
        n, total = self.selected(), self.list.count()
        row = self.list.currentRow()
        for key in ("rename", "copy", "default", "apps", "export"):
            self.buttons[key].setEnabled(n is not None)
        self.buttons["delete"].setEnabled(n is not None and total > 1)
        self.buttons["up"].setEnabled(n is not None and row > 0)
        self.buttons["down"].setEnabled(n is not None and 0 <= row < total - 1)
        if n is not None:
            self.buttons["default"].setText(tr("Quitar de predeterminada") if n == scenes.default() else tr("Usar como predeterminada"))

    def _say(self, text: str):
        self.message.setText(text)

    def _busy_with_open_scene(self, name: str) -> bool:
        """The scene being edited, with unsaved changes, cannot be renamed or deleted from under the editor."""
        if name == self.host.open_scene and self.host.open_scene_dirty:
            self._say(tr("«{name}» está abierta en el editor con cambios sin guardar: guárdalos o descártalos primero.", name=name))
            return True
        return False

    # --- actions ---
    def create(self):
        name = self.host.ask_text(self, tr("Crear escena"), tr("Nombre de la escena"))
        if not name:
            return
        try:
            made = scenes.create(name)
        except scenes.SceneError:
            self._say(tr("Ese nombre no es válido o ya existe.")); return
        self.changed = True; self.refresh(made); self._say(tr("Escena «{name}» creada.", name=made))

    def rename(self):
        old = self.selected()
        if not old or self._busy_with_open_scene(old):
            return
        new = self.host.ask_text(self, tr("Renombrar"), tr("Nombre de la escena"), old)
        if not new or new == old:
            return
        try:
            done = scenes.rename(old, new)
        except scenes.SceneError:
            self._say(tr("Ese nombre no es válido o ya existe.")); return
        self.renamed[old] = done
        self.changed = True; self.refresh(done); self._say(tr("Escena renombrada: «{name}».", name=done))

    def duplicate(self):
        name = self.selected()
        if not name:
            return
        if name == self.host.open_scene and self.host.open_scene_dirty:
            self._say(tr("«{name}» está abierta en el editor con cambios sin guardar: guárdalos o descártalos primero.", name=name)); return
        made = scenes.duplicate(name, tr(" (copia)"))
        self.changed = True; self.refresh(made); self._say(tr("Escena «{name}» creada.", name=made))

    def remove(self):
        name = self.selected()
        if not name or self._busy_with_open_scene(name):
            return
        if not self.host.confirm(self, tr("¿Eliminar la escena «{name}»?", name=name)):
            return
        if scenes.delete(name):
            self.changed = True; self.refresh(); self._say(tr("Escena «{name}» eliminada.", name=name))

    def move(self, delta: int):
        name = self.selected()
        if name:
            scenes.move(name, delta); self.changed = True; self.refresh(name)

    def make_default(self):
        name = self.selected()
        if not name:
            return
        scenes.set_default(None if name == scenes.default() else name)
        self.changed = True; self.refresh(name)

    def bind_apps(self):
        name = self.selected()
        if not name:
            return
        import yaml
        try:
            with open(scenes.path(name)) as fh:
                data = yaml.safe_load(fh) or {}
        except OSError:
            return
        auto = bool((self.host.settings().get("auto_profile", True)))
        dlg = matchdialog.MatchDialog(profiles._rules(data.get("match")), self.host.recent_windows(), auto, self)
        if not dlg.exec():
            return
        rules = dlg.rules()
        taken = scenes.bind(name, rules)                      # an application belongs to one scene only
        data = scenes._read(name)
        if rules:
            data["match"] = rules
        else:
            data.pop("match", None)
        scenes._write(name, data)
        self.host.ctl(["auto", "on" if dlg.auto() else "off"])
        self.changed = True; self.refresh(name)
        if taken:
            self._say(tr("Se quitó la asociación de {n} aplicación(es) de otras escenas: solo pueden pertenecer a una.",
                         n=sum(len(v) for v in taken.values())))

    def import_scene(self):
        src = self.host.pick_scene_file(self)
        if not src:
            return
        try:
            made = scenes.import_bundle(src)
        except scenes.SceneError:
            self._say(tr("No se pudo importar ese archivo.")); return
        self.changed = True; self.refresh(made); self._say(tr("Escena «{name}» importada.", name=made))

    def export_scene(self):
        name = self.selected()
        if not name:
            return
        dest = self.host.pick_scene_save(self, name)
        if not dest:
            return
        done = scenes.export_bundle(name, dest)
        self._say(tr("Escena exportada: {path}", path=done))

    def apply(self):
        self.host.save("scene_swipe", bool(self.swipe.isChecked()))
