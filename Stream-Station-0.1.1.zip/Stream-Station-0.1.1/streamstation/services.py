"""Common online services a key can open: the desktop app when it is installed, the website otherwise.

Nothing here is borrowed artwork: the key icons are pictograms drawn by this program (ui/actionicons.py, ui/industrial.py).
`color` is only the tint used by the icon styles that colour keys per service.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Service:
    id: str
    name: str
    url: str
    apps: tuple = ()          # desktop-file ids of a native/flatpak app, tried in order
    color: str = "#ffffff"    # tint of the drawn pictogram (styles that colour keys)
    slug: str = ""            # name of the brand's mark in the Simple Icons set (downloaded on demand, never bundled)
    brand: str = "#ffffff"    # the brand's own colour for its mark


SERVICES = (
    Service("youtube", "YouTube", "https://www.youtube.com", (), "#ff3b3b", "youtube", "#FF0000"),
    Service("youtube-music", "YouTube Music", "https://music.youtube.com", (), "#ff5a3c", "youtubemusic", "#FF0000"),
    Service("spotify", "Spotify", "https://open.spotify.com", ("spotify", "com.spotify.Client"), "#2ee06b", "spotify", "#1ED760"),
    Service("twitch", "Twitch", "https://www.twitch.tv", (), "#a970ff", "twitch", "#9146FF"),
    Service("discord", "Discord", "https://discord.com/app", ("discord", "com.discordapp.Discord", "vesktop"), "#7c8cff", "discord", "#5865F2"),
    Service("whatsapp", "WhatsApp", "https://web.whatsapp.com", ("com.rtosta.zapzap", "whatsapp-for-linux"), "#2ee07a", "whatsapp", "#25D366"),
    Service("telegram", "Telegram", "https://web.telegram.org", ("org.telegram.desktop", "telegramdesktop"), "#3db8ff", "telegram", "#26A5E4"),
    Service("gmail", "Gmail", "https://mail.google.com", (), "#ff6b5e", "gmail", "#EA4335"),
    Service("calendar", "Calendario de Google", "https://calendar.google.com", (), "#4d9bff", "googlecalendar", "#4285F4"),
    Service("drive", "Google Drive", "https://drive.google.com", (), "#ffc933", "googledrive", "#4285F4"),
    Service("maps", "Google Maps", "https://maps.google.com", (), "#3fd16b", "googlemaps", "#4285F4"),
    Service("github", "GitHub", "https://github.com", (), "#c9d1d9", "github", "#FFFFFF"),   # the brand's black is white on dark keys
)
BY_ID = {s.id: s for s in SERVICES}


def _desktop_dirs() -> list[str]:
    home = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
    dirs = [os.path.join(home, "applications"), "/usr/share/applications", "/usr/local/share/applications",
            "/var/lib/flatpak/exports/share/applications", os.path.join(home, "flatpak/exports/share/applications")]
    return dirs + [os.path.join(d, "applications") for d in (os.environ.get("XDG_DATA_DIRS") or "").split(":") if d]


def installed_app(service: Service, dirs: list[str] | None = None) -> str | None:
    """The desktop-file id of the first installed app of this service, or None (then the website is used)."""
    for app_id in service.apps:
        for d in dirs if dirs is not None else _desktop_dirs():
            if os.path.isfile(os.path.join(d, app_id + ".desktop")):
                return app_id
    return None


def command_for(service_id: str, dirs: list[str] | None = None) -> list[str]:
    """argv that opens the service: `gtk-launch <app>` when installed, else `xdg-open <url>`."""
    service = BY_ID.get(service_id)
    if service is None:
        raise ValueError(f"unknown service {service_id!r}")
    app = installed_app(service, dirs)
    return ["gtk-launch", app] if app else ["xdg-open", service.url]
