# Stream Station (Ragnaros) — driver y editor para Linux

Servicio y editor gráfico para el **Redragon Ragnaros SS-552** (USB `0200:3001`): 10 teclas con pantalla, 4 perillas y una
franja táctil de 800×128 px.

## Qué es y de dónde sale
Implementación **propia e independiente**. El protocolo del dispositivo se obtuvo por análisis estático del software del
fabricante instalado en el equipo del autor y se verificó, valor por valor, contra el dispositivo real (ver `NOTES.md` y
`FEATURES.md`, con las funciones analizadas y los resultados de cada prueba en vivo).
No incluye código de otros drivers para este dispositivo. Una auditoría de coincidencia literal contra otro driver de código
abierto del mismo aparato dio 0 líneas de lógica en común.

## Qué hace
- **Teclas:** icono + acción. Acciones de la lista, apps instaladas (con su icono), atajos de teclado, cualquier programa,
  archivo o carpeta, multi-acciones (alternar, aleatoria, secuencia con retardo), páginas y capas.
- **Perillas:** girar a la derecha / a la izquierda / pulsar, con plantillas (volumen, brillo, páginas, multimedia).
- **Franja:** un único lienzo; cada zona (o toda la franja) muestra métricas, texto, imagen o GIF animado, y cada zona táctil
  ejecuta una acción.
- **Perfil por aplicación:** un perfil con reglas `match:` se activa cuando su juego o aplicación tiene el foco (KDE), y se vuelve al
  anterior al salir. Se configura en el editor con el botón 🎮.
- **Sistema:** apagado de pantalla por inactividad, seguir el bloqueo de sesión, volumen/micrófono, multimedia por MPRIS,
  bloqueo y suspensión, acciones de escritorio de KDE.
- **Editor:** `streamstation ui` (o «Stream Station» en el menú de aplicaciones). Una sola ventana; si ya está abierta, se
  trae al frente. Muestra si el servicio y el dispositivo están conectados y permite iniciarlo.

## Instalar (solo toca tu usuario)
```bash
./install.sh --apply                                   # programa, icono y entrada de menú
systemctl --user enable --now streamstation.service    # el servicio, con tu sesión
```
Acceso al USB: `udev/70-streamstation.rules` (necesita administrador una vez; el instalador imprime los comandos).
`./install.sh --uninstall` lo retira; tus perfiles en `~/.config/streamstation/` se conservan.

## Datos y comandos útiles
| | |
|---|---|
| Perfiles | `~/.config/streamstation/profiles/*.yaml` |
| Iconos generados | `~/.config/streamstation/assets/` |
| Importar de una instalación anterior | `streamstation import-profiles CARPETA` (solo lee los YAML; reconstruye los iconos) |
| Regenerar iconos / limpiar | `streamstation rebuild-icons --all` · `streamstation prune-assets [--apply]` |
| Control del servicio | `streamstation ctl status\|profile X\|layer X\|reload` |

## Dependencias
Python 3.10+, PySide6, Pillow, PyYAML, pyusb (libusb), python-evdev (atajos de teclado por `/dev/uinput`).
Herramientas del sistema que se usan si existen: `wpctl`, `busctl`, `loginctl`, `systemctl`, `xdg-open`.

## Material de terceros
- **Iconos del fabricante** (`assets/vendor/`, opcional): propiedad de sus autores, **solo para uso personal y no se
  incluyen** al compartir el proyecto. Sin ellos, el programa dibuja un icono de respaldo con la inicial de la acción.
- La **fuente** es la del sistema (Noto Sans si está instalada). No se redistribuye ninguna.
