"""One place to get a TrueType font with Spanish/Latin coverage for everything painted by PIL.

Pillow's built-in default font has no accented glyphs (it draws a box for 'ó'), which showed
up both in the editor and on the deck's panels, so a real system font is resolved here.
"""
from __future__ import annotations

import os
import subprocess
from functools import lru_cache

from PIL import ImageFont

FALLBACKS = (
    "/usr/share/fonts/noto/NotoSans-{w}.ttf", "/usr/share/fonts/TTF/DejaVuSans{b}.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans{b}.ttf", "/usr/share/fonts/liberation/LiberationSans-{w}.ttf",
)


@lru_cache(maxsize=None)
def path(bold: bool = False) -> str | None:
    env = os.environ.get("STREAMSTATION_FONT")
    if env and os.path.isfile(env):
        return env
    try:
        out = subprocess.run(["fc-match", "-f", "%{file}", "Noto Sans:bold" if bold else "Noto Sans"],
                             capture_output=True, text=True, timeout=2).stdout.strip()
        if out and os.path.isfile(out):
            return out
    except (OSError, subprocess.SubprocessError):
        pass
    for pattern in FALLBACKS:
        p = pattern.format(w="Bold" if bold else "Regular", b="-Bold" if bold else "")
        if os.path.isfile(p):
            return p
    return None


@lru_cache(maxsize=None)
def font(size: int, bold: bool = False, family: str | None = None):
    """The font for `family` (a name from `usable()`), or the default one when it is empty or not installed."""
    p = (resolve(family, bold) if family else None) or path(bold)
    try:
        return ImageFont.truetype(p, size) if p else ImageFont.load_default(size=size)
    except OSError:
        return ImageFont.load_default(size=size)


# --- the fonts the user has installed that can really be used ---------------------------------------------
NOT_TEXT = ("dingbat", "d050000l", "symbol", "wingding", "webding", "emoji", "awesome", "icons", "material", "codicon", "ornament")
SAMPLE = "AaBbEeGgMmRrWw0123456789ñÑáéíóúüÁÉ¿¡%:°"


def renders_text(file: str) -> bool:
    """True when the font draws every sample character as its own visible shape.
    Rejects fonts that show rectangles (missing glyphs), nothing at all, or the same shape for every letter."""
    try:
        f = ImageFont.truetype(file, 40)
        shapes = {}
        for ch in SAMPLE:
            m = f.getmask(ch)
            if m.getbbox() is None:
                return False
            shapes[ch] = (m.size, bytes(m))
        return len({v for v in shapes.values()}) >= len(SAMPLE) - 2        # accents may share a base shape with another
    except Exception:
        return False


def _fc_list() -> str:
    try:
        return subprocess.run(["fc-list", "--format", "%{family[0]}\t%{style[0]}\t%{file}\n", ":lang=es"],
                              capture_output=True, text=True, timeout=15).stdout
    except (OSError, subprocess.SubprocessError):
        return ""


def _style_rank(style: str) -> int:
    st = style.lower()
    if any(w in st for w in ("italic", "oblique", "condensed", "narrow", "light", "thin", "black", "heavy", "semi", "extra", "medium")):
        return 9 if "bold" not in st else 8
    return 0 if st in ("regular", "book", "normal", "roman") else 5


@lru_cache(maxsize=1)
def usable() -> list[dict]:   # noqa: C901
    """[{family, regular, bold}] sorted by name: only fonts that cover Spanish AND draw real letters."""
    fams: dict[str, dict[str, tuple[int, str]]] = {}
    for line in _fc_list().splitlines():
        parts = line.split("\t")
        if len(parts) != 3 or not os.path.isfile(parts[2]):
            continue
        family, style, file = parts
        st = style.lower()
        slot = "bold" if st == "bold" else "regular"
        rank = 0 if st in ("bold", "regular", "book", "normal", "roman") else _style_rank(style)
        if slot == "regular" and rank >= 8:
            continue
        cur = fams.setdefault(family, {}).get(slot)
        if cur is None or rank < cur[0]:
            fams[family][slot] = (rank, file)
    out = []
    for family in sorted(fams, key=str.lower):
        if any(w in family.lower() for w in NOT_TEXT):
            continue
        reg = fams[family].get("regular") or fams[family].get("bold")
        if reg and renders_text(reg[1]):
            out.append({"family": family, "regular": reg[1], "bold": (fams[family].get("bold") or (0, None))[1]})
    return out


def resolve(family: str | None, bold: bool = False) -> str | None:
    """File of `family` (regular or bold) among the usable fonts, None when it is not available."""
    if not family:
        return None
    for f in usable():
        if f["family"] == family:
            return (f["bold"] if bold and f["bold"] else f["regular"])
    return None
